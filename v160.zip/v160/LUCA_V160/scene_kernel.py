"""Typed, original-coordinate scene programs. No complete native fitter is called.

The interpreter shares selection, masks and atomic edits between object extraction,
conditional colouring, geometric construction and reference alignment. Programs
contain only symbolic roles and parameters, never example grids or task IDs.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import lru_cache
from typing import Any
import attributes
from constraints import Choice, ConstraintSearch
from correspondence import grid, Grid
from region_geometry import region

class Inapplicable(ValueError):
    """A declared program's precondition is not supported by this input."""

@dataclass(frozen=True)
class Entity:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    properties: tuple[tuple[str, Any], ...]

    def value(self, feature: str):
        values = dict(self.properties)
        if feature not in values:
            raise Inapplicable('unknown feature: ' + feature)
        return values[feature]

@dataclass(frozen=True)
class Scene:
    source: Grid
    background: int
    entities: tuple[Entity, ...]
    coordinate_frame: str = 'original_pixel_coordinates'

@dataclass(frozen=True)
class Entities:
    scene: Scene
    indices: tuple[int, ...]

@dataclass(frozen=True)
class Regions:
    scene: Scene
    masks: tuple[tuple[int, frozenset[tuple[int, int]]], ...]

@dataclass(frozen=True)
class Assignment:
    scene: Scene
    sources: tuple[int, ...]
    references: tuple[int, ...]

@dataclass(frozen=True)
class Edits:
    scene: Scene
    writes: tuple[tuple[int, int, int], ...]
    clears: frozenset[tuple[int, int]]
    bounds: frozenset[tuple[int, int]]
    effect: str

@dataclass(frozen=True)
class Predicate:
    operator: str = 'all'
    feature: str = ''
    value: Any = None
    children: tuple['Predicate', ...] = ()

    def select(self, scene: Scene) -> tuple[int, ...]:
        n = len(scene.entities)
        if self.operator == 'all': return tuple(range(n))
        if self.operator in ('and', 'or', 'not'):
            if self.operator == 'not' and len(self.children) != 1:
                raise Inapplicable('not requires one predicate')
            if self.operator != 'not' and not self.children:
                raise Inapplicable('empty logical predicate')
            sets = [set(p.select(scene)) for p in self.children]
            chosen = (set(range(n)) - sets[0] if self.operator == 'not' else
                      set.intersection(*sets) if self.operator == 'and' else set.union(*sets))
            return tuple(i for i in range(n) if i in chosen)
        vals = [e.value(self.feature) for e in scene.entities]
        if not vals: return ()
        target = (min(vals) if self.operator == 'min' else max(vals)
                  if self.operator == 'max' else self.value)
        if self.operator not in ('min', 'max', 'eq', 'ne'):
            raise Inapplicable('unknown predicate operator')
        return tuple(i for i,v in enumerate(vals) if (v != target if self.operator == 'ne' else v == target))

    def to_dict(self):
        return {'operator':self.operator, 'feature':self.feature, 'value':self.value,
                'children':[c.to_dict() for c in self.children]}

    @classmethod
    def from_dict(cls, d):
        return cls(d['operator'], d.get('feature',''), freeze(d.get('value')),
                   tuple(cls.from_dict(c) for c in d.get('children',())))


def freeze(value):
    return tuple(freeze(x) for x in value) if isinstance(value,list) else value

@lru_cache(maxsize=512)
def perceive(a: Grid, background_rule: str | int, connectivity: int, monochrome: bool) -> Scene:
    a = grid(a)
    native = attributes.perceive(a, background_rule, connectivity, monochrome)
    if native is None: raise Inapplicable('unresolved background or empty scene')
    bg, obs, fs = native
    entities=[]
    for obj,props in zip(obs,fs):
        # The native extractor returns original pixel coordinates. Copy its features.
        props=dict(props)
        props['palette']=tuple(sorted({a[r][c] for r,c in obj.cells}))
        entities.append(Entity(obj.cells,obj.box,tuple(sorted(props.items()))))
    return Scene(a,bg,tuple(entities))

# Explicit operator contracts. These are dispatch instructions, not solver modules.
CONTRACTS = {
    'select': {'in':'Scene','out':'Entities','effect':'retains all predicate ties'},
    'mask': {'in':'Entities','out':'Regions','effect':'original-coordinate region construction'},
    'paint': {'in':'Regions','out':'Edits','effect':'staged writes; conflicting colours reject'},
    'bind_complement': {'in':'Entities','out':'Assignment','effect':'unselected entities are references'},
    'align': {'in':'Assignment','out':'Edits','effect':'rigid endpoint translation; material conserved'},
    'emit': {'in':'Edits','out':'Grid','effect':'atomic render; explicit canvas and crop frame'},
}


def masks(selection: Entities, kind: str) -> Regions:
    scene=selection.scene; h,w=len(scene.source),len(scene.source[0])
    if not selection.indices: raise Inapplicable('empty selection')
    out=[]
    for i in selection.indices:
        if not 0 <= i < len(scene.entities): raise Inapplicable('unknown entity')
        cells=scene.entities[i].cells
        mask=frozenset(cells) if kind=='support' else region(cells,kind,h,w)
        out.append((i,mask))
    return Regions(scene,tuple(out))


def colour(scene: Scene, owner: int, position, expr: str, value=None):
    r,c=position
    if expr=='original': return scene.source[r][c]
    if expr=='background': return scene.background
    if expr=='constant':
        if type(value) is not int or not 0 <= value <= 9: raise Inapplicable('invalid colour')
        return value
    if expr=='reference':
        return reference_colour(scene, owner, value)
    if expr=='source':
        palette=scene.entities[owner].value('palette')
        if len(palette)!=1: raise Inapplicable('source colour is not unique')
        return palette[0]
    raise Inapplicable('unknown paint expression')


def paint(regions: Regions, expr: str, value=None, scope='any') -> Edits:
    scene=regions.scene; writes={}; bounds=set()
    if scope not in ('any','background'): raise Inapplicable('unknown write scope')
    for owner,mask in regions.masks:
        bounds.update(mask)
        for r,c in mask:
            if scope=='background' and scene.source[r][c]!=scene.background: continue
            v=colour(scene,owner,(r,c),expr,value)
            if (r,c) in writes and writes[r,c]!=v:
                raise Inapplicable('conflicting simultaneous paint')
            writes[r,c]=v
    return Edits(scene,tuple((r,c,v) for (r,c),v in sorted(writes.items())),frozenset(),
                 frozenset(bounds),'background_addition' if scope=='background' else 'colour_edit')


def anchor_twice(box, axis, anchor):
    lo,hi=box[axis],box[axis+2]
    if anchor=='low': return 2*lo
    if anchor=='high': return 2*hi
    if anchor=='center': return lo+hi
    raise Inapplicable('unknown anchor')


def align(binding: Assignment, axis: int, source_anchor: str, reference_anchor: str) -> Edits:
    scene=binding.scene; a=scene.source; h,w=len(a),len(a[0])
    if axis not in (0,1) or not binding.sources or not binding.references:
        raise Inapplicable('empty or invalid alignment binding')
    if set(binding.sources)&set(binding.references): raise Inapplicable('source/reference overlap')
    values={anchor_twice(scene.entities[i].box,axis,reference_anchor) for i in binding.references}
    if len(values)!=1: raise Inapplicable('references disagree on coordinate')
    target=next(iter(values)); clears=set(); writes={}; destinations=set()
    for i in binding.sources: clears.update(scene.entities[i].cells)
    for i in binding.sources:
        obj=scene.entities[i]; delta=target-anchor_twice(obj.box,axis,source_anchor)
        if delta%2: raise Inapplicable('noninteger displacement')
        d=delta//2
        for r,c in obj.cells:
            nr,nc=r+(d if axis==0 else 0),c+(d if axis==1 else 0)
            if not (0<=nr<h and 0<=nc<w): raise Inapplicable('placement outside canvas')
            if (nr,nc) in destinations: raise Inapplicable('two bodies overlap')
            if (nr,nc) not in clears and a[nr][nc]!=scene.background:
                raise Inapplicable('collision with stationary material')
            destinations.add((nr,nc)); writes[nr,nc]=a[r][c]
    return Edits(scene,tuple((r,c,v) for (r,c),v in sorted(writes.items())),frozenset(clears),
                 frozenset(destinations),'rigid_translation')


def emit(edits: Edits, mode='preserve') -> Grid:
    scene=edits.scene; a=scene.source; h,w=len(a),len(a[0])
    if mode not in ('preserve','isolate','crop','context'): raise Inapplicable('unknown canvas mode')
    if not edits.bounds: raise Inapplicable('empty output region')
    if edits.effect=='rigid_translation' and mode!='preserve':
        raise Inapplicable('rigid material contract requires preserved canvas')
    out=[list(row) for row in a] if mode in ('preserve','context') else [[scene.background]*w for _ in range(h)]
    for r,c in edits.clears: out[r][c]=scene.background
    for r,c,v in edits.writes:
        if not (0<=r<h and 0<=c<w): raise Inapplicable('write outside canvas')
        out[r][c]=v
    if mode in ('crop','context'):
        r0=min(r for r,c in edits.bounds); r1=max(r for r,c in edits.bounds)
        c0=min(c for r,c in edits.bounds); c1=max(c for r,c in edits.bounds)
        out=[row[c0:c1+1] for row in out[r0:r1+1]]
    return grid(out)

@dataclass(frozen=True)
class Instruction:
    op: str
    args: tuple = ()

@dataclass(frozen=True)
class Program:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    predicate: Predicate
    instructions: tuple[Instruction,...]

    def check_types(self):
        value='Scene'
        for instruction in self.instructions:
            contract=CONTRACTS.get(instruction.op)
            if contract is None or contract['in']!=value:
                raise ValueError('ill-typed instruction: '+instruction.op+' after '+value)
            value=contract['out']
        if value!='Grid': raise ValueError('program must produce a Grid')

    def execute_scene(self, scene: Scene, trace: bool = False, *, expected_frame: str = 'original_pixel_coordinates'):
        self.check_types()
        if expected_frame not in ('original_pixel_coordinates', 'logical_cell_coordinates') or not isinstance(scene, Scene) or scene.coordinate_frame != expected_frame:
            raise Inapplicable('scene coordinate frame does not match its declared interpreter context')
        value=scene; records=[]
        for instruction in self.instructions:
            op,args=instruction.op,instruction.args
            if op=='select': value=Entities(value,self.predicate.select(value))
            elif op=='mask': value=masks(value,*args)
            elif op=='paint': value=paint(value,*args)
            elif op=='bind_complement':
                refs=tuple(i for i in range(len(value.scene.entities)) if i not in value.indices)
                value=Assignment(value.scene,value.indices,refs)
            elif op=='align': value=align(value,*args)
            elif op=='emit': value=emit(value,*args)
            if trace:
                records.append({'operator':op,'arguments':list(args),'type':CONTRACTS[op]['out'],
                    'entities':len(value.indices) if isinstance(value,Entities) else None,
                    'writes':len(value.writes) if isinstance(value,Edits) else None})
        return (value,records) if trace else value

    def predict(self, a):
        try:
            a=grid(a); return self.execute_scene(perceive(a,self.background_rule,self.connectivity,self.monochrome))
        except Inapplicable: return None

    def signature(self):
        # Parameter-free reusable structure; not a task-specific answer identifier.
        category = 'all' if self.predicate.operator=='all' else 'conditional'
        return category+' -> '+' -> '.join(i.op for i in self.instructions[1:])

    def describe(self):
        return {'language':'shared_scene_v1','background_rule':self.background_rule,
                'connectivity':self.connectivity,'monochrome':self.monochrome,
                'predicate':self.predicate.to_dict(),
                'instructions':[{'op':i.op,'args':list(i.args)} for i in self.instructions],
                'signature':self.signature(),'coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,d):
        if d.get('language')!='shared_scene_v1': raise ValueError('unsupported program language')
        p=cls(d['background_rule'],d['connectivity'],d['monochrome'],Predicate.from_dict(d['predicate']),
              tuple(Instruction(i['op'],tuple(freeze(x) for x in i.get('args',()))) for i in d['instructions']))
        p.check_types(); return p

# V86: a transaction can contain several conditional edit branches. Every branch
# reads the SAME original Scene. These are parallel edits, not sequential repainting.
CONTRACTS.update({
    'case': {'in':'Scene','out':'EditSet[]','effect':'dispatch every observed entity category'},
    'merge': {'in':'EditSet[]','out':'Edits','effect':'atomic compatible union; conflicts reject'},
})

@dataclass(frozen=True)
class EditAction:
    """A reusable Mask -> Paint fragment, interpreted by the existing primitives."""
    kind: str
    expression: str
    value: int | RelationSpec | None = None
    scope: str = 'any'

    def execute(self, selection: Entities) -> Edits:
        if self.kind == 'support':
            if self.scope != 'any': raise Inapplicable('support effects use explicit any scope')
        elif self.scope != 'background':
            raise Inapplicable('constructed regions may only modify original background')
        return paint(masks(selection, self.kind), self.expression, self.value, self.scope)

    def describe(self):
        return {'mask': self.kind, 'paint': self.expression,
                'value': self.value.describe() if isinstance(self.value, RelationSpec) else self.value, 'scope': self.scope}

    @classmethod
    def from_dict(cls, data):
        value = RelationSpec.from_dict(data['value']) if data['paint']=='reference' else data.get('value')
        return cls(data['mask'], data['paint'], value, data['scope'])


def merge_edits(scene: Scene, edits) -> Edits:
    """Union edits from the same immutable source. There is no last-writer priority.

    Explicit writes of the original value also constrain overlap. A clear is an
    explicit background write; incompatible clear/write transactions are rejected.
    Empty transactions are legal identities and bound the whole preserved canvas.
    """
    if scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('transaction requires original pixel coordinates')
    h,w=len(scene.source),len(scene.source[0]); writes={}; bounds=set()
    for edit in edits:
        if edit.scene != scene: raise Inapplicable('cannot merge edits from different scenes')
        cells = [(r,c,scene.background) for r,c in edit.clears] + list(edit.writes)
        for r,c,v in cells:
            if not (0<=r<h and 0<=c<w and type(v) is int and 0<=v<=9):
                raise Inapplicable('invalid transaction write')
            if (r,c) in writes and writes[r,c] != v:
                raise Inapplicable('incompatible branch writes')
            writes[r,c]=v
        bounds.update(edit.bounds)
    if not bounds: bounds={(r,c) for r in range(h) for c in range(w)}
    return Edits(scene,tuple((r,c,v) for (r,c),v in sorted(writes.items())),frozenset(),
                 frozenset(bounds),'joint_conditional_edit')


def case_key(entity: Entity, feature: str):
    return 'all' if feature == '__all__' else entity.value(feature)


@dataclass(frozen=True)
class JointProgram:
    """Case(feature) -> [Select -> Mask -> Paint]* -> Merge -> Emit.

    Cases store measured symbolic categories and instruction arguments, never grids,
    source coordinates, example edits or task identifiers. Empty actions mean no-op.
    """
    background_rule: str | int
    connectivity: int
    monochrome: bool
    feature: str | RelationalFeature
    cases: tuple[tuple[Any, tuple[EditAction, ...]], ...]

    def execute_scene(self, scene: Scene, trace: bool = False):
        if scene.coordinate_frame != 'original_pixel_coordinates':
            raise Inapplicable('joint program requires original pixel coordinates')
        table=dict(self.cases)
        if len(table)!=len(self.cases): raise Inapplicable('duplicate case key')
        grouped={}
        for i,k in enumerate(category_values(scene,self.feature)):
            if k not in table: raise Inapplicable('unobserved attribute category')
            grouped.setdefault(k,[]).append(i)
        edits=[];records=[]
        if trace and isinstance(self.feature,RelationalFeature):
            bound=relate(scene,self.feature.relation)
            records.append({'operator':'relate','relation':self.feature.relation.describe(),
                            'references':[list(x) for x in bound.references],
                            'categories':list(category_values(scene,self.feature))})
        for k,ids in grouped.items():
            selection=Entities(scene,tuple(ids));actions=table[k]
            if len(actions)>2: raise Inapplicable('at most two edits per branch in this grammar')
            if len(actions)==2 and (actions[0].kind!='support' or actions[1].kind=='support'):
                raise Inapplicable('paired edits must be support then background region')
            for action in actions:
                edit=action.execute(selection);edits.append(edit)
                if trace: records.append({'operator':'case_mask_paint','feature':self.feature.describe() if isinstance(self.feature,RelationalFeature) else self.feature,
                    'case':k,'entities':len(ids),'action':action.describe(),'writes':len(edit.writes)})
        output=emit(merge_edits(scene,edits),'preserve')
        if trace:
            records.append({'operator':'merge_emit','branches':len(grouped),'effects':len(edits)})
            return output,records
        return output

    def predict(self,a):
        try:
            return self.execute_scene(perceive(grid(a),self.background_rule,self.connectivity,self.monochrome))
        except Inapplicable: return None

    def signature(self):
        width=max((len(a) for _,a in self.cases),default=0)
        return ('relate -> ' if isinstance(self.feature,RelationalFeature) else '')+f'case -> {width} mask/paint slots -> merge -> emit'

    def describe(self):
        return {'language':'shared_scene_relational_v1' if isinstance(self.feature,RelationalFeature) else 'shared_scene_joint_v1',
                'background_rule':self.background_rule,
                'connectivity':self.connectivity,'monochrome':self.monochrome,
                'feature':self.feature.describe() if isinstance(self.feature,RelationalFeature) else self.feature,
                'cases':[{'key':k,'actions':[a.describe() for a in acts]} for k,acts in self.cases],
                'signature':self.signature(),'semantics':'parallel original-scene edits',
                'coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,d):
        if d.get('language') not in ('shared_scene_joint_v1','shared_scene_relational_v1'): raise ValueError('unsupported joint language')
        return cls(d['background_rule'],d['connectivity'],d['monochrome'],
                   RelationalFeature.from_dict(d['feature']) if isinstance(d['feature'],dict) else d['feature'],
                   tuple((freeze(c['key']),tuple(EditAction.from_dict(a) for a in c['actions']))
                         for c in d['cases']))


# Relational values enrich the same immutable Scene. The edit language and renderer
# remain shared; no complete task fitter is invoked to bind reference objects.
@dataclass(frozen=True)
class RelationSpec:
    """Directed query -> reference edges; self edges are always excluded.

    Contains/inside are strict bounding-box relations, NOT topological enclosure.
    Nearest uses exact L1 distances between twice-box-centres and retains all ties.
    """
    edge: str
    targets: str = 'other'

    def describe(self):
        return {'edge':self.edge,'targets':self.targets,'self_edges':False,
                'ties':'retain_all','coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,d):
        if d.get('coordinate_frame','original_pixel_coordinates')!='original_pixel_coordinates':
            raise Inapplicable('relation coordinate frame mismatch')
        if d.get('self_edges',False) is not False or d.get('ties','retain_all')!='retain_all':
            raise Inapplicable('unsupported relation semantics')
        r=cls(d['edge'],d.get('targets','other'));r.check();return r

    def check(self):
        if self.edge not in ('same_oriented_shape','same_shape','same_palette','contact4','contact8',
                             'inside_box','contains_box','same_row','same_column','nearest_center','all'):
            raise Inapplicable('unknown relation edge')
        if self.targets not in ('other','singleton','different_palette'):
            raise Inapplicable('unknown reference selector')


@dataclass(frozen=True)
class Relations:
    scene: Scene
    specification: RelationSpec
    references: tuple[tuple[int,...],...]


@dataclass(frozen=True)
class RelationalFeature:
    relation: RelationSpec
    reduction: str = 'present'

    def describe(self):
        return {'type':'relational_feature','relation':self.relation.describe(),
                'reduction':self.reduction}

    @classmethod
    def from_dict(cls,d):
        if d.get('type')!='relational_feature':raise Inapplicable('unknown feature type')
        f=cls(RelationSpec.from_dict(d['relation']),d['reduction'])
        if f.reduction not in ('count','present','singleton_present'):
            raise Inapplicable('unknown relational reduction')
        return f


RELATION_SPECS = tuple(RelationSpec(e,t) for e,t in (
    ('same_oriented_shape','other'),('same_shape','other'),('same_palette','other'),
    ('contact4','other'),('contact8','other'),('inside_box','other'),('contains_box','other'),
    ('same_row','other'),('same_column','other'),('nearest_center','singleton'),
    ('nearest_center','different_palette'),('nearest_center','other'),('all','singleton'),
))
RELATIONAL_FEATURES = tuple(RelationalFeature(r,k) for r in RELATION_SPECS
                            for k in ('count','present','singleton_present'))
CONTRACTS.update({
    'relate':{'in':'Scene','out':'Relations','effect':'input-derived directed edges; self exclusion; all ties retained'},
    'reduce_relation':{'in':'Relations','out':'Category[]','effect':'count/presence; optional singleton role product'},
})


@lru_cache(maxsize=128)
def relate(scene: Scene, spec: RelationSpec, allowed_references: tuple[int, ...] | None = None) -> Relations:
    if not isinstance(scene,Scene) or scene.coordinate_frame!='original_pixel_coordinates':
        raise Inapplicable('relations require original pixel coordinates')
    if not isinstance(spec,RelationSpec):raise Inapplicable('typed relation specification required')
    spec.check();es=scene.entities;n=len(es)
    if allowed_references is not None and (len(set(allowed_references))!=len(allowed_references) or
            any(type(i) is not int or not 0<=i<n for i in allowed_references)):
        raise Inapplicable('invalid reference domain')
    allowed=None if allowed_references is None else frozenset(allowed_references)
    palettes=tuple(e.value('palette') for e in es)
    boxes=tuple(e.box for e in es)
    centers=tuple((b[0]+b[2],b[1]+b[3]) for b in boxes)
    selected=None
    if spec.edge in ('same_oriented_shape','same_shape','same_palette','same_row','same_column'):
        groups={}
        for i,e in enumerate(es):
            if spec.edge=='same_oriented_shape':
                key=tuple(sorted((r-e.box[0],c-e.box[1]) for r,c in e.cells))
            elif spec.edge=='same_shape':key=attributes.normalized_shape(e.cells)
            elif spec.edge=='same_palette':key=palettes[i]
            elif spec.edge=='same_row':key=centers[i][0]
            else:key=centers[i][1]
            groups.setdefault(key,[]).append(i)
        selected=[[] for _ in es]
        for ids in groups.values():
            for i in ids:selected[i]=[j for j in ids if j!=i]
    elif spec.edge in ('contact4','contact8'):
        owner={p:i for i,e in enumerate(es) for p in e.cells};adj=[set() for _ in es]
        steps=attributes.D4 if spec.edge=='contact4' else attributes.D8
        for (r,c),i in owner.items():
            for dr,dc in steps:
                j=owner.get((r+dr,c+dc))
                if j is not None and j!=i:adj[i].add(j)
        selected=[sorted(row) for row in adj]
    def eligible(i,j):
        if i==j or (allowed is not None and j not in allowed):return False
        if spec.targets=='singleton':return len(es[j].cells)==1
        if spec.targets=='different_palette':return palettes[i]!=palettes[j]
        return True
    rows=[]
    for i in range(n):
        candidates=[j for j in (range(n) if selected is None else selected[i]) if eligible(i,j)]
        if spec.edge in ('inside_box','contains_box'):
            def enclosed(j):
                inner,outer=(boxes[i],boxes[j]) if spec.edge=='inside_box' else (boxes[j],boxes[i])
                return inner!=outer and outer[0]<=inner[0] and outer[1]<=inner[1] and outer[2]>=inner[2] and outer[3]>=inner[3]
            candidates=[j for j in candidates if enclosed(j)]
        elif spec.edge=='nearest_center' and candidates:
            distances={j:abs(centers[i][0]-centers[j][0])+abs(centers[i][1]-centers[j][1]) for j in candidates}
            best=min(distances.values());candidates=[j for j in candidates if distances[j]==best]
        rows.append(tuple(candidates))
    return Relations(scene,spec,tuple(rows))


def category_values(scene: Scene, feature):
    if not isinstance(feature,RelationalFeature):
        return tuple(case_key(e,feature) for e in scene.entities)
    bound=relate(scene,feature.relation)
    if feature.reduction=='count':return tuple(len(row) for row in bound.references)
    if feature.reduction=='present':return tuple(bool(row) for row in bound.references)
    if feature.reduction=='singleton_present':
        return tuple((len(e.cells)==1,bool(row)) for e,row in zip(scene.entities,bound.references))
    raise Inapplicable('unknown relational reduction')


def reference_colour(scene: Scene, owner: int, spec: RelationSpec) -> int:
    if not 0<=owner<len(scene.entities):raise Inapplicable('unknown query entity')
    refs=relate(scene,spec).references[owner]
    colours={c for j in refs for c in scene.entities[j].value('palette')}
    if len(colours)!=1:raise Inapplicable('missing or conflicting reference colour')
    return next(iter(colours))

# Reference-bound endpoint edits extend the SAME Scene / Relations / Edits language.
@dataclass(frozen=True)
class BoundAssignment:
    scene: Scene
    sources: tuple[int,...]
    domains: tuple[tuple[int,...],...]
    injective: bool = False


def bind_references(selection: Entities, specification: RelationSpec, injective: bool = False) -> BoundAssignment:
    """Nearest is computed within unselected stationary references, not movers."""
    s=selection.scene;ids=selection.indices
    if s.coordinate_frame!='original_pixel_coordinates':raise Inapplicable('assignment coordinate frame')
    if not ids or len(set(ids))!=len(ids) or any(type(i) is not int or not 0<=i<len(s.entities) for i in ids):
        raise Inapplicable('invalid selected sources')
    if type(injective) is not bool:raise Inapplicable('invalid reference capacity')
    refs=tuple(i for i in range(len(s.entities)) if i not in ids)
    if not refs:raise Inapplicable('no stationary reference objects')
    rel=relate(s,specification,refs);domains=tuple(rel.references[i] for i in ids)
    if any(not x for x in domains):raise Inapplicable('source without reference')
    return BoundAssignment(s,ids,domains,injective)


@dataclass(frozen=True)
class PlacementSpec:
    axes: tuple[int,...] = (0,)
    source_anchor: str = 'low'
    reference_anchor: str = 'low'
    offset: tuple[int,int] = (0,0)
    operation: str = 'move'
    reference_policy: str = 'preserve'

    def check(self):
        if self.axes not in ((0,),(1,),(0,1)) or self.source_anchor not in ('low','center','high') or self.reference_anchor not in ('low','center','high'):
            raise Inapplicable('invalid axes/anchors')
        if len(self.offset)!=2 or any(type(v) is not int for v in self.offset):raise Inapplicable('offset must be integer')
        if any(self.offset[k]!=0 for k in (0,1) if k not in self.axes):raise Inapplicable('inactive axis offset')
        if self.operation not in ('move','copy') or self.reference_policy not in ('preserve','consume'):
            raise Inapplicable('invalid material policy')

    def displacement(self,source: Entity,reference: Entity):
        self.check();v=[0,0]
        for axis in self.axes:
            d=anchor_twice(reference.box,axis,self.reference_anchor)-anchor_twice(source.box,axis,self.source_anchor)+2*self.offset[axis]
            if d%2:raise Inapplicable('noninteger anchor displacement')
            v[axis]=d//2
        return tuple(v)

    def describe(self):
        return {'axes':list(self.axes),'source_anchor':self.source_anchor,'reference_anchor':self.reference_anchor,
                'offset':list(self.offset),'operation':self.operation,'reference_policy':self.reference_policy,
                'collision_policy':'disjoint_occupied_destinations','coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,d):
        if d.get('coordinate_frame','original_pixel_coordinates')!='original_pixel_coordinates' or d.get('collision_policy','disjoint_occupied_destinations')!='disjoint_occupied_destinations':
            raise Inapplicable('unsupported placement semantics')
        p=cls(tuple(d['axes']),d['source_anchor'],d['reference_anchor'],tuple(d['offset']),d['operation'],d.get('reference_policy','preserve'))
        p.check();return p


@lru_cache(maxsize=512)
def assignment_edits(binding: BoundAssignment,specification: PlacementSpec,limit: int = 2):
    """Exhaust assignments for a unique answer; two complete outputs prove ambiguity.

    Clears are applied together before destinations. A consumed reference disappears
    once even if reused. Unassigned references remain obstacles. Order is not a vote.
    """
    if type(limit) is not int or limit<2:raise ValueError('at least two witnesses required')
    specification.check();s=binding.scene;a=s.source;h,w=len(a),len(a[0]);es=s.entities
    if s.coordinate_frame!='original_pixel_coordinates':raise Inapplicable('foreign coordinate frame')
    if not binding.sources or len(set(binding.sources))!=len(binding.sources) or len(binding.sources)!=len(binding.domains):
        raise Inapplicable('invalid assignment dimensions')
    if type(binding.injective) is not bool or any(type(i) is not int or not 0<=i<len(es) for i in binding.sources):
        raise Inapplicable('invalid assignment indices')
    if any(not row or len(set(row))!=len(row) or any(type(j) is not int or not 0<=j<len(es) or j in binding.sources for j in row) for row in binding.domains):
        raise Inapplicable('invalid stationary domains')
    origins=frozenset(p for i in binding.sources for p in es[i].cells) if specification.operation=='move' else frozenset()
    possible_clears=origins
    if specification.reference_policy=='consume':
        possible_clears |= frozenset(p for j in set(j for row in binding.domains for j in row) for p in es[j].cells)
    owner={p:j for j,e in enumerate(es) for p in e.cells}
    domains=[]
    for i,refs in zip(binding.sources,binding.domains):
        options=[]
        for j in refs:
            try:dr,dc=specification.displacement(es[i],es[j])
            except Inapplicable:continue
            writes=tuple((r+dr,c+dc,a[r][c]) for r,c in es[i].cells);cells=frozenset((r,c) for r,c,v in writes)
            if any(not (0<=r<h and 0<=c<w) or ((r,c) not in possible_clears and a[r][c]!=s.background) for r,c,v in writes):continue
            required=frozenset(owner[r,c] for r,c,v in writes if (r,c) in owner and (r,c) not in origins)
            if specification.reference_policy=='preserve' and required:continue
            options.append((j,writes,cells,required))
        if not options:return (),True,0
        domains.append(tuple(options))
    # Shared finite-domain engine: occupancy, reference capacity and required
    # reference clearing are constraints, not an arbitrary assignment order.
    choices=[]
    consume=specification.reference_policy=='consume'
    for options in domains:
        row=[]
        for ref,ws,cells,needs in options:
            emission=frozenset(('write',r,c,v) for r,c,v in ws)
            if consume:emission |= frozenset({('consume',ref)})
            row.append(Choice(emission,
                covers=(1<<ref) if consume else 0,
                needs=sum(1<<j for j in needs) if consume else 0,
                exclusive=sum(1<<(r*w+c) for r,c in cells),
                resource=ref))
        choices.append(tuple(row))
    search=ConstraintSearch(choices,unique_resources=binding.injective,label='placement')
    outputs={};stopped=False
    generator=search.solutions()
    try:
        for indices in generator:
            selected=[domains[i][j] for i,j in enumerate(indices)]
            used={ref for ref,ws,cells,needs in selected}
            clears=origins
            if consume:clears |= frozenset(p for j in used for p in es[j].cells)
            ws=tuple(sorted(p for ref,writes,cells,needs in selected for p in writes))
            bounds=frozenset(p for ref,writes,cells,needs in selected for p in cells)
            edit=Edits(s,ws,clears,bounds,'reference_bound_placement')
            outputs.setdefault(emit(edit,'preserve'),edit)
            if len(outputs)>=limit:
                stopped=True;break
    finally:
        generator.close()
    return tuple(outputs.values()),not stopped,search.stats['leaves']



CONTRACTS.update({
    'bind_relation':{'in':'Entities','out':'BoundAssignment','effect':'stationary edge domains, optional one-to-one capacity'},
    'place':{'in':'BoundAssignment','out':'Edits[]','effect':'simultaneous rigid move/copy and explicit reference lifecycle'},
})


@dataclass(frozen=True)
class PlacementProgram:
    """Select -> Bind -> Place -> Emit. Stores parameters, not exemplar grids."""
    background_rule: str | int
    connectivity: int
    monochrome: bool
    predicate: Predicate
    relation: RelationSpec
    placement: PlacementSpec
    injective: bool = False

    def execute_options(self,scene: Scene):
        ids=self.predicate.select(scene)
        if any(len(scene.entities[i].cells)<2 for i in ids):raise Inapplicable('placement source must be a multi-cell pattern')
        b=bind_references(Entities(scene,ids),self.relation,self.injective)
        edits,complete,n=assignment_edits(b,self.placement)
        return tuple(emit(e,'preserve') for e in edits),complete,n

    def predict_options(self,a):
        try:return self.execute_options(perceive(grid(a),self.background_rule,self.connectivity,self.monochrome))
        except Inapplicable:return (),True,0

    def predict(self,a):
        outputs,_,_=self.predict_options(a)
        return outputs[0] if len(outputs)==1 else None

    def describe(self):
        return {'language':'shared_scene_placement_v1','background_rule':self.background_rule,
                'connectivity':self.connectivity,'monochrome':self.monochrome,'predicate':self.predicate.to_dict(),
                'relation':self.relation.describe(),'placement':self.placement.describe(),'injective':self.injective,
                'signature':'select -> bind_relation -> place -> emit','source_contract':'multi_cell_components','coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,d):
        if d.get('language')!='shared_scene_placement_v1' or d.get('coordinate_frame')!='original_pixel_coordinates' or type(d['injective']) is not bool or d.get('source_contract','multi_cell_components')!='multi_cell_components':
            raise Inapplicable('unsupported placement program')
        return cls(d['background_rule'],d['connectivity'],d['monochrome'],Predicate.from_dict(d['predicate']),
                   RelationSpec.from_dict(d['relation']),PlacementSpec.from_dict(d['placement']),d['injective'])

# V90: the same constraint engine now covers target regions with whole pieces.
@dataclass(frozen=True)
class CoverSpec:
    region_kind: str = 'holes'
    orientation_group: str = 'identity'
    participation: str = 'all'
    one_piece: bool = False
    reference_grouping: str = 'individual'

    def check(self):
        if self.reference_grouping not in ('individual', 'palette', 'selected'):
            raise Inapplicable('unknown reference grouping')
        if self.region_kind not in ('box', 'holes', 'row_spans', 'column_spans', 'axial_spans', 'extend_left', 'extend_right', 'extend_up', 'extend_down'):
            raise Inapplicable('unknown target region')
        if self.orientation_group not in ('identity', 'rotations', 'dihedral'):
            raise Inapplicable('unknown piece orientation group')
        if self.participation not in ('all', 'palette_groups') or type(self.one_piece) is not bool:
            raise Inapplicable('invalid source participation/capacity')

    def describe(self):
        return {'region_kind': self.region_kind, 'orientation_group': self.orientation_group,
                'participation': self.participation, 'one_piece': self.one_piece,
                **({'reference_grouping': self.reference_grouping} if self.reference_grouping != 'individual' else {}),
                'material': 'move_whole_sources_preserve_references',
                'targets': 'originally_background', 'coordinate_frame': 'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls, d):
        if d.get('material') != 'move_whole_sources_preserve_references' or d.get('targets') != 'originally_background' or d.get('coordinate_frame') != 'original_pixel_coordinates':
            raise Inapplicable('unsupported covering semantics')
        value = cls(d['region_kind'], d['orientation_group'], d['participation'], d['one_piece'], d.get('reference_grouping', 'individual'))
        value.check()
        return value


@dataclass(frozen=True)
class CoverBinding:
    scene: Scene
    sources: tuple[int, ...]
    targets: tuple[tuple[int, frozenset[tuple[int, int]]], ...]
    reference_domains: tuple[tuple[int, ...], ...]


def reference_groups(references: Entities, grouping: str):
    """Groups retain original entity IDs; ordering is only a resource label."""
    scene, ids = references.scene, references.indices
    if not ids or len(set(ids)) != len(ids) or any(type(i) is not int or not 0 <= i < len(scene.entities) for i in ids):
        raise Inapplicable('invalid reference selection')
    if grouping == 'individual':
        return tuple((i,) for i in ids)
    if grouping == 'selected':
        return (tuple(ids),)
    if grouping == 'palette':
        groups = {}
        for i in ids:
            groups.setdefault(scene.entities[i].value('palette'), []).append(i)
        return tuple(tuple(g) for g in groups.values())
    raise Inapplicable('unknown reference grouping')


def bind_cover(references: Entities, spec: CoverSpec, relation: RelationSpec,
               source_predicate: Predicate | None = None) -> CoverBinding:
    """Select roles and derive blank targets from original reference pixels only.

    All geometry is recomputed per input. Multi-part references may define one
    target; grouping never creates painted cells or changes source segmentation.
    """
    spec.check()
    scene, ids = references.scene, references.indices
    if scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('covering requires original pixel coordinates')
    groups = reference_groups(references, spec.reference_grouping)
    pixels = tuple(tuple(sorted(p for i in g for p in scene.entities[i].cells)) for g in groups)
    boxes = tuple((min(r for r,c in pts), min(c for r,c in pts),
                   max(r for r,c in pts), max(c for r,c in pts)) for pts in pixels)
    def exterior(e):
        return not any(b[0] <= rr <= b[2] and b[1] <= cc <= b[3]
                       for rr, cc in e.cells for b in boxes)
    eligible = tuple(i for i,e in enumerate(scene.entities)
                     if i not in ids and len(e.cells) >= 2 and exterior(e))
    selected = set(source_predicate.select(scene)) if source_predicate is not None else set(eligible)
    sources = tuple(i for i in eligible if i in selected)
    if not sources:
        raise Inapplicable('no selected exterior multi-cell sources')
    if source_predicate is not None and spec.participation != 'all':
        raise Inapplicable('explicit source roles require all selected sources')
    h, w = len(scene.source), len(scene.source[0])
    if spec.region_kind.startswith('extend_'):
        if spec.participation != 'all':
            raise Inapplicable('extended rectangles require complete material participation')
        material = sum(len(scene.entities[i].cells) for i in (*sources, *ids))
        if material % len(groups):
            raise Inapplicable('nonintegral common target area')
        area = material // len(groups)
        horizontal = spec.region_kind in ('extend_left', 'extend_right')
        cross = {b[2]-b[0]+1 if horizontal else b[3]-b[1]+1 for b in boxes}
        if len(cross) != 1 or area % next(iter(cross)):
            raise Inapplicable('inconsistent target cross-section')
        length = area // next(iter(cross)); targets = []
        for g, pts, b in zip(groups,pixels,boxes):
            r0,c0,r1,c1 = b
            if horizontal:
                if length < c1-c0+1: raise Inapplicable('target smaller than reference')
                if spec.region_kind == 'extend_left': c0=c1-length+1
                else: c1=c0+length-1
            else:
                if length < r1-r0+1: raise Inapplicable('target smaller than reference')
                if spec.region_kind == 'extend_up': r0=r1-length+1
                else: r1=r0+length-1
            if r0<0 or c0<0 or r1>=h or c1>=w:
                raise Inapplicable('extended target outside canvas')
            cells = frozenset((r,c) for r in range(r0,r1+1) for c in range(c0,c1+1))-frozenset(pts)
            if any(scene.source[r][c]!=scene.background for r,c in cells):
                raise Inapplicable('foreign material inside extended target')
            targets.append((g[0],cells))
        targets = tuple(targets)
    else:
        targets = tuple((g[0],frozenset(p for p in region(pts,spec.region_kind,h,w)
                         if scene.source[p[0]][p[1]]==scene.background)) for g,pts in zip(groups,pixels))
    used=set()
    for _,mask in targets:
        if not mask or used.intersection(mask):
            raise Inapplicable('empty or overlapping target masks')
        used.update(mask)
    if sum(len(scene.entities[i].cells) for i in sources)<len(used):
        raise Inapplicable('not enough movable material')
    edges=relate(scene,relation,tuple(ids))
    domains=tuple(tuple(g[0] for g in groups if set(g).intersection(edges.references[i])) for i in sources)
    return CoverBinding(scene,sources,targets,domains)


@lru_cache(maxsize=256)
def _piece_patterns(scene: Scene, owner: int, group: str):
    """Reuse native D4 geometry; retain all distinct coloured orientations."""
    from oriented_panels import orient
    e = scene.entities[owner]
    r0, c0, r1, c1 = e.box
    patch = [[scene.background] * (c1 - c0 + 1) for _ in range(r1 - r0 + 1)]
    for rr, cc in e.cells:
        patch[rr - r0][cc - c0] = scene.source[rr][cc]
    codes = (0,) if group == 'identity' else range(4) if group == 'rotations' else range(8)
    patterns = {}
    for code in codes:
        a = orient(grid(patch), code)
        pixels = tuple((rr, cc, v) for rr, row in enumerate(a) for cc, v in enumerate(row) if v != scene.background)
        patterns.setdefault(pixels, []).append(code)
    return tuple((p, tuple(c)) for p, c in patterns.items())


@lru_cache(maxsize=128)
def cover_edits(binding: CoverBinding, spec: CoverSpec, limit: int = 2):
    """Whole-piece exact cover through the shared Choice/ConstraintSearch engine.

    One variable per source prevents source reuse. Mandatory target bits plus
    exclusive destination bits implement exact coverage. Clears are part of the
    emission signature, so different source subsets cannot be merged unsafely.
    Two different rendered outputs prove ambiguity; otherwise search exhausts.
    """
    spec.check()
    if type(limit) is not int or limit < 2:
        raise ValueError('at least two output witnesses required')
    s = binding.scene
    if s.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('covering coordinate frame')
    h, w = len(s.source), len(s.source[0])
    n = len(s.entities)
    if not binding.sources or len(set(binding.sources)) != len(binding.sources) or len(binding.reference_domains) != len(binding.sources):
        raise Inapplicable('invalid covering domain shape')
    if any(type(i) is not int or not 0 <= i < n for i in binding.sources):
        raise Inapplicable('invalid source index')
    target_map = dict(binding.targets)
    if len(target_map) != len(binding.targets) or not target_map:
        raise Inapplicable('invalid target indices')
    occupied = set()
    for ref, cells in binding.targets:
        if type(ref) is not int or not 0 <= ref < n or ref in binding.sources or not cells or occupied.intersection(cells):
            raise Inapplicable('invalid target regions')
        if any(type(rr) is not int or type(cc) is not int or not (0 <= rr < h and 0 <= cc < w) or s.source[rr][cc] != s.background for rr, cc in cells):
            raise Inapplicable('target not originally background')
        occupied.update(cells)
    if any(len(set(row)) != len(row) or any(ref not in target_map for ref in row) for row in binding.reference_domains):
        raise Inapplicable('invalid reference domains')
    # Exact integer area feasibility before geometric assignment. This is necessary
    # pruning, not a choice among equally plausible outputs.
    total = len(occupied)
    areas = [len(s.entities[i].cells) for i in binding.sources]
    if spec.participation == 'all':
        if sum(areas) != total:
            return (), True, {'area_rejected': 1}
    else:
        group_areas = {}
        for i, size in zip(binding.sources, areas):
            key = s.entities[i].value('palette')
            group_areas[key] = group_areas.get(key, 0) + size
        feasible = 1
        mask = (1 << (total + 1)) - 1
        for size in group_areas.values():
            feasible = (feasible | (feasible << size)) & mask
        if not (feasible & (1 << total)):
            return (), True, {'area_rejected': 1}
    pixel_bits = {p: 1 << k for k, p in enumerate(sorted(occupied))}
    source_bits = {i: 1 << (total + k) for k, i in enumerate(binding.sources)}
    palette_bits = {}
    for i in binding.sources:
        pal = s.entities[i].value('palette')
        palette_bits[pal] = palette_bits.get(pal, 0) | source_bits[i]
    ref_boxes = [s.entities[j].box for j in target_map]
    blocked_palettes = set()
    for j, entity in enumerate(s.entities):
        if j in binding.sources or j in target_map:
            continue
        outside = not any(b[0] <= rr <= b[2] and b[1] <= cc <= b[3]
                          for rr, cc in entity.cells for b in ref_boxes)
        if outside:
            blocked_palettes.add(entity.value('palette'))
    choices, descriptions = [], []
    for owner, refs in zip(binding.sources, binding.reference_domains):
        row, details, seen = [], [], set()
        if spec.participation == 'palette_groups':
            row.append(Choice(frozenset()))
            details.append(None)
        if spec.participation == 'palette_groups' and s.entities[owner].value('palette') in blocked_palettes:
            choices.append(tuple(row)); descriptions.append(tuple(details))
            continue
        for ref in refs:
            target = target_map[ref]
            for pattern, codes in _piece_patterns(s, owner, spec.orientation_group):
                if len(pattern) > len(target):
                    continue
                # Match a deterministic occupied pattern cell against ALL target
                # cells. The anchor is enumeration only, not a fitted coordinate.
                ar, ac, _ = pattern[0]
                for rr, cc in sorted(target):
                    dr, dc = rr - ar, cc - ac
                    writes = tuple(sorted((r + dr, c + dc, v) for r, c, v in pattern))
                    cells = frozenset((r, c) for r, c, v in writes)
                    if not cells <= target:
                        continue
                    key = (ref, writes)
                    if key in seen:
                        continue
                    seen.add(key)
                    cover = sum(pixel_bits[p] for p in cells)
                    emission = frozenset(('write', r, c, v) for r, c, v in writes) | frozenset(('clear', r, c) for r, c in s.entities[owner].cells)
                    row.append(Choice(emission, covers=cover | source_bits[owner],
                        needs=palette_bits[s.entities[owner].value('palette')] if spec.participation == 'palette_groups' else 0,
                        exclusive=cover, resource=ref))
                    details.append({'source': owner, 'reference': ref, 'writes': writes, 'orientations': codes})
        if not row:
            return (), True, {'empty_source_domain': 1}
        choices.append(tuple(row))
        descriptions.append(tuple(details))
    search = ConstraintSearch(choices, required=(1 << total) - 1,
                              unique_resources=spec.one_piece, label='material_cover')
    results = {}
    stopped = False
    gen = search.solutions()
    try:
        for indices in gen:
            selected = [descriptions[i][j] for i, j in enumerate(indices) if descriptions[i][j] is not None]
            clears = frozenset(p for option in selected for p in s.entities[option['source']].cells)
            writes = tuple(sorted(p for option in selected for p in option['writes']))
            # Constraints encode coverage and disjointness, while the final material
            # assertion guards adapter errors without choosing a preferred answer.
            if frozenset((r, c) for r, c, v in writes) != frozenset(occupied) or len(writes) != total or len(clears) != total:
                raise AssertionError('covering/material adapter invariant')
            edit = Edits(s, writes, clears, frozenset(occupied), 'rigid_translation')
            output = emit(edit, 'preserve')
            results.setdefault(output, (edit, tuple(selected)))
            if len(results) >= limit:
                stopped = True
                break
    finally:
        gen.close()
    return tuple(results.values()), not stopped, dict(search.stats)


CONTRACTS.update({
    'target_regions': {'in': 'Entities', 'out': 'CoverBinding', 'effect': 'input-derived originally-empty masks and exterior source domains'},
    'cover': {'in': 'CoverBinding', 'out': 'Edits[]', 'effect': 'exact region coverage; each whole source at most once; optional one-piece control'},
})


@dataclass(frozen=True)
class MaterialProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    reference_predicate: Predicate
    relation: RelationSpec
    cover: CoverSpec
    source_predicate: Predicate | None = None

    def execute_options(self, scene: Scene):
        refs = Entities(scene, self.reference_predicate.select(scene))
        binding = bind_cover(refs, self.cover, self.relation, self.source_predicate)
        edits, complete, stats = cover_edits(binding, self.cover)
        return tuple(emit(edit, 'preserve') for edit, trace in edits), complete, stats

    def predict_options(self, value):
        try:
            return self.execute_options(perceive(grid(value), self.background_rule, self.connectivity, self.monochrome))
        except Inapplicable:
            return (), True, {}

    def predict(self, value):
        outputs, _, _ = self.predict_options(value)
        return outputs[0] if len(outputs) == 1 else None

    def describe(self):
        return {'language': 'shared_scene_material_v2' if self.source_predicate is not None else 'shared_scene_material_v1',
                **({'source_predicate': self.source_predicate.to_dict()} if self.source_predicate is not None else {}),
                'background_rule': self.background_rule,
                'connectivity': self.connectivity, 'monochrome': self.monochrome,
                'reference_predicate': self.reference_predicate.to_dict(), 'relation': self.relation.describe(),
                'cover': self.cover.describe(), 'signature': 'select_references -> target_regions -> bind -> cover -> emit',
                'source_contract': 'exterior_multi_cell_components', 'coordinate_frame': 'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls, d):
        if d.get('language') not in ('shared_scene_material_v1', 'shared_scene_material_v2') or d.get('coordinate_frame') != 'original_pixel_coordinates' or d.get('source_contract') != 'exterior_multi_cell_components':
            raise Inapplicable('unsupported material program')
        return cls(d['background_rule'], d['connectivity'], d['monochrome'],
                   Predicate.from_dict(d['reference_predicate']), RelationSpec.from_dict(d['relation']), CoverSpec.from_dict(d['cover']),
                   Predicate.from_dict(d['source_predicate']) if d.get('language')=='shared_scene_material_v2' else None)

# Ordered inventory values reuse the original-coordinate Scene representation.
# This schema constructs a new canvas; it is not a material-conserving move.
@dataclass(frozen=True)
class InventoryItem:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    quantities: tuple[tuple[str, int], ...]
    palette: tuple[int, ...]

    def quantity(self, name: str) -> int:
        values = dict(self.quantities)
        if name not in values:
            raise Inapplicable('unknown inventory quantity: ' + name)
        return values[name]


@dataclass(frozen=True)
class Inventory:
    scene: Scene
    items: tuple[InventoryItem, ...]
    collection: str


@dataclass(frozen=True)
class InventoryTiles:
    inventory: Inventory
    tiles: tuple[Grid, ...]


INVENTORY_QUANTITIES = ('area', 'components', 'colours', 'height', 'width', 'bbox_area', 'holes')
INVENTORY_SPATIAL_ORDERS = ('reading_rows', 'reading_columns')
INVENTORY_ORDERS = INVENTORY_SPATIAL_ORDERS + INVENTORY_QUANTITIES


@lru_cache(maxsize=2048)
def collect_inventory(scene: Scene, collection: str, connectivity: int = 4) -> Inventory:
    """Collect original cells into components, colour groups, or one foreground union.

    A colour group's component count is connectivity in its own support, not a
    count of unrelated objects crossed by the group's bounding box.
    """
    if scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('inventory requires original pixel coordinates')
    if connectivity not in (4, 8):
        raise Inapplicable('invalid inventory connectivity')
    a = scene.source
    if collection == 'objects':
        groups = [e.cells for e in scene.entities]
    elif collection == 'colours':
        by_colour = {}
        for e in scene.entities:
            for r, c in e.cells:
                by_colour.setdefault(a[r][c], []).append((r, c))
        # Enumeration is not an ordering rule. All semantic order ties survive.
        groups = list(by_colour.values())
    elif collection == 'foreground':
        groups = [tuple(p for e in scene.entities for p in e.cells)]
    else:
        raise Inapplicable('unknown inventory collection')
    if not groups or any(not cells for cells in groups):
        raise Inapplicable('empty inventory')
    # Every rendered item has at least one cell along the output concatenation
    # axis. >30 items cannot fit the declared 30-cell output size contract.
    if len(groups) > 30:
        raise Inapplicable('inventory cannot fit an ARC-sized output')
    items = []
    directions = attributes.D4 if connectivity == 4 else attributes.D8
    for cells in groups:
        cells = tuple(sorted(set(cells)))
        r0, c0 = min(r for r, c in cells), min(c for r, c in cells)
        r1, c1 = max(r for r, c in cells), max(c for r, c in cells)
        todo = set(cells); parts = 0
        while todo:
            stack = [todo.pop()]; parts += 1
            while stack:
                r, c = stack.pop()
                for dr, dc in directions:
                    p = (r + dr, c + dc)
                    if p in todo:
                        todo.remove(p); stack.append(p)
        palette = tuple(sorted({a[r][c] for r, c in cells}))
        box = (r0, c0, r1, c1)
        measures = dict(area=len(cells), components=parts, colours=len(palette),
                        height=r1-r0+1, width=c1-c0+1,
                        bbox_area=(r1-r0+1)*(c1-c0+1),
                        holes=attributes.holes(attributes.Component(cells, box)))
        items.append(InventoryItem(cells, box, tuple(sorted(measures.items())), palette))
    return Inventory(scene, tuple(items), collection)


@dataclass(frozen=True)
class MeasureSpec:
    encoding: str = 'pattern'
    quantity: str = 'area'
    ink: str = 'source'
    value: int | None = None

    def check(self):
        if self.encoding not in ('pattern', 'symbol', 'bar_rows', 'bar_columns', 'square'):
            raise Inapplicable('unknown inventory encoding')
        if self.quantity not in INVENTORY_QUANTITIES:
            raise Inapplicable('unknown measured quantity')
        if self.ink not in ('source', 'constant'):
            raise Inapplicable('unknown inventory ink')
        if self.ink == 'constant' and (type(self.value) is not int or not 0 <= self.value <= 9):
            raise Inapplicable('invalid constant ink')


@lru_cache(maxsize=4096)
def measure_inventory(inventory: Inventory, spec: MeasureSpec) -> InventoryTiles:
    spec.check()
    scene = inventory.scene; a = scene.source; bg = scene.background
    tiles = []
    for item in inventory.items:
        r0, c0, r1, c1 = item.box
        if spec.encoding == 'pattern':
            out = [[bg] * (c1-c0+1) for _ in range(r1-r0+1)]
            for r, c in item.cells:
                out[r-r0][c-c0] = a[r][c]
        else:
            if spec.ink == 'source':
                if len(item.palette) != 1:
                    raise Inapplicable('symbol requires a unique source colour')
                ink = item.palette[0]
            else:
                ink = spec.value
            if ink == bg:
                raise Inapplicable('invisible inventory token')
            q = 1 if spec.encoding == 'symbol' else item.quantity(spec.quantity)
            if not 1 <= q <= 30:
                raise Inapplicable('quantity cannot be rendered under size contract')
            h = q if spec.encoding in ('bar_rows', 'square') else 1
            w = q if spec.encoding in ('bar_columns', 'square') else 1
            out = [[ink] * w for _ in range(h)]
        tiles.append(grid(out))
    return InventoryTiles(inventory, tuple(tiles))


def inventory_key(item: InventoryItem, order: str):
    if order == 'reading_rows': return (item.box[0], item.box[1])
    if order == 'reading_columns': return (item.box[1], item.box[0])
    return item.quantity(order)


def layout_inventory(value: InventoryTiles, order: str, descending: bool,
                     axis: int, gap: int, alignment: str) -> tuple[Grid, ...]:
    """One concatenation renderer; returns a unique grid or two ambiguity witnesses.

    Ties are NOT broken by colour or extraction order. After orthogonal padding,
    tiles are words of rows/columns. Every tied permutation has the same result
    exactly when all pairs commute with the declared separator. Otherwise placing
    a noncommuting pair adjacently provides two full, legal output witnesses.
    """
    if order not in INVENTORY_ORDERS or type(descending) is not bool:
        raise Inapplicable('invalid inventory ordering')
    if axis not in (0, 1) or type(axis) is not int or gap not in (0, 1, 2):
        raise Inapplicable('invalid inventory layout')
    if alignment not in ('low', 'center', 'high'):
        raise Inapplicable('invalid orthogonal alignment')
    tiles = value.tiles; bg = value.inventory.scene.background
    if not tiles or len(tiles) != len(value.inventory.items):
        raise Inapplicable('invalid tile inventory')
    cross = max(len(t[0]) if axis == 0 else len(t) for t in tiles)
    length = sum(len(t) if axis == 0 else len(t[0]) for t in tiles) + gap*(len(tiles)-1)
    if not 1 <= cross <= 30 or not 1 <= length <= 30:
        raise Inapplicable('layout exceeds ARC-sized output')
    words = []
    for t in tiles:
        own = len(t[0]) if axis == 0 else len(t)
        difference = cross - own
        if alignment == 'center' and difference % 2:
            raise Inapplicable('half-cell inventory alignment')
        offset = 0 if alignment == 'low' else difference if alignment == 'high' else difference//2
        if axis == 0:
            word = tuple((bg,)*offset + row + (bg,)*(difference-offset) for row in t)
        else:
            word = tuple((bg,)*offset + tuple(row[c] for row in t) + (bg,)*(difference-offset)
                         for c in range(len(t[0])))
        words.append(word)
    separator = ((bg,)*cross,)*gap
    groups = {}
    for i, item in enumerate(value.inventory.items):
        groups.setdefault(inventory_key(item, order), []).append(i)
    ordered = [tuple(groups[k]) for k in sorted(groups, reverse=descending)]

    def render(indices):
        out = ()
        for i in indices:
            if out: out += separator
            out += words[i]
        return grid(out if axis == 0 else tuple(zip(*out)))

    # Canonical enumeration creates a representative, never an accepted tie-break.
    canonical = tuple(i for group in ordered for i in group)
    first = render(canonical)
    for gi, group in enumerate(ordered):
        for p, i in enumerate(group):
            for j in group[p+1:]:
                if words[i]+separator+words[j] == words[j]+separator+words[i]:
                    continue
                rest = tuple(k for k in group if k not in (i, j))
                before = tuple(k for g in ordered[:gi] for k in g)
                after = tuple(k for g in ordered[gi+1:] for k in g)
                a = render(before+(i,j)+rest+after)
                b = render(before+(j,i)+rest+after)
                assert a != b
                return a, b
    return (first,)


CONTRACTS.update({
    'collect': {'in':'Scene','out':'Inventory','effect':'group original cells; preserve coordinate provenance'},
    'measure': {'in':'Inventory','out':'InventoryTiles','effect':'pattern, symbol or exact input-derived quantity'},
    'order_layout': {'in':'InventoryTiles','out':'Grid[]','effect':'ordered concatenation; retain observable ties'},
})


@dataclass(frozen=True)
class InventoryProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    collection: str
    measure: MeasureSpec
    order: str
    descending: bool
    axis: int
    gap: int
    alignment: str

    def execute_options(self, scene: Scene) -> tuple[Grid, ...]:
        items = collect_inventory(scene, self.collection, self.connectivity)
        tiles = measure_inventory(items, self.measure)
        return layout_inventory(tiles, self.order, self.descending, self.axis, self.gap, self.alignment)

    def predict_options(self, a) -> tuple[Grid, ...]:
        try:
            return self.execute_options(perceive(grid(a), self.background_rule, self.connectivity, self.monochrome))
        except Inapplicable:
            return ()

    def predict(self, a):
        predictions = self.predict_options(a)
        return predictions[0] if len(predictions) == 1 else None

    def describe(self):
        from dataclasses import asdict
        return {'language':'shared_scene_inventory_v1', **asdict(self),
                'signature':'collect -> measure -> order -> layout',
                'coordinate_frame':'original_pixel_coordinates',
                'tie_policy':'all_orderings_must_have_identical_visible_output'}

    @classmethod
    def from_dict(cls, value):
        if value.get('language') != 'shared_scene_inventory_v1' or value.get('coordinate_frame') != 'original_pixel_coordinates':
            raise Inapplicable('unsupported inventory program')
        return cls(value['background_rule'], value['connectivity'], value['monochrome'],
                   value['collection'], MeasureSpec(**value['measure']), value['order'],
                   value['descending'], value['axis'], value['gap'], value['alignment'])

# Structured inventory layout: the same collected items and measured tiles can
# inhabit a regular two-dimensional slot system instead of a single strip.
@dataclass(frozen=True)
class GridLayoutSpec:
    shape_rule: str = 'columns'
    count: int = 2
    traversal: str = 'rows'
    row_gap: int = 0
    column_gap: int = 0
    row_alignment: str = 'low'
    column_alignment: str = 'low'

    def shape(self, number: int) -> tuple[int, int]:
        from math import isqrt
        if type(number) is not int or not 4 <= number <= 30:
            raise Inapplicable('structured inventory requires 4..30 nonempty items')
        if self.shape_rule not in ('rows', 'columns', 'square'):
            raise Inapplicable('unknown grid shape rule')
        if type(self.count) is not int or not 2 <= self.count <= 30:
            raise Inapplicable('invalid grid count')
        if self.traversal not in ('rows', 'columns', 'snake_rows', 'snake_columns'):
            raise Inapplicable('unknown grid traversal')
        if any(type(x) is not int or x not in (0, 1, 2) for x in (self.row_gap, self.column_gap)):
            raise Inapplicable('invalid grid gaps')
        if any(x not in ('low', 'center', 'high') for x in (self.row_alignment, self.column_alignment)):
            raise Inapplicable('invalid within-slot alignment')
        if self.shape_rule == 'square':
            rows = columns = isqrt(number)
            if rows * columns != number:
                raise Inapplicable('item count is not a square')
        else:
            if number % self.count:
                raise Inapplicable('incomplete final grid band')
            rows, columns = ((self.count, number // self.count) if self.shape_rule == 'rows'
                             else (number // self.count, self.count))
        if min(rows, columns) < 2:
            raise Inapplicable('structured language excludes one-dimensional layouts')
        return rows, columns


def grid_inventory_slots(rows: int, columns: int, traversal: str):
    """Each occupied slot is visited exactly once; the path never changes tiles."""
    if type(rows) is not int or type(columns) is not int or min(rows, columns) < 2:
        raise Inapplicable('invalid grid shape')
    if traversal in ('rows', 'snake_rows'):
        return tuple((r, c) for r in range(rows)
                     for c in (range(columns - 1, -1, -1) if traversal == 'snake_rows' and r % 2 else range(columns)))
    if traversal in ('columns', 'snake_columns'):
        return tuple((r, c) for c in range(columns)
                     for r in (range(rows - 1, -1, -1) if traversal == 'snake_columns' and c % 2 else range(rows)))
    raise Inapplicable('unknown grid traversal')


@lru_cache(maxsize=2048)
def layout_inventory_grid(value: InventoryTiles, order: str, descending: bool,
                          layout: GridLayoutSpec) -> tuple[Grid, ...]:
    """Uniform-slot rendering with exact, non-factorial tie ambiguity detection.

    Slot geometry is independent of item order: each slot has the maximum tile
    height and width. Different padded tiles tied on rank can be swapped in two
    disjoint slots to prove ambiguity. Identical padded tiles permit all swaps.
    No arbitrary tie-break, truncation, rotation, overlap or trailing filler occurs.
    """
    if value.inventory.scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('grid inventory requires original coordinates')
    if order not in INVENTORY_ORDERS or type(descending) is not bool:
        raise Inapplicable('invalid grid ordering')
    tiles = value.tiles
    if not tiles or len(tiles) != len(value.inventory.items):
        raise Inapplicable('invalid grid inventory')
    rows, columns = layout.shape(len(tiles))
    height = max(len(t) for t in tiles); width = max(len(t[0]) for t in tiles)
    out_h = rows * height + (rows - 1) * layout.row_gap
    out_w = columns * width + (columns - 1) * layout.column_gap
    if min(height, width) < 1 or max(out_h, out_w) > 30:
        raise Inapplicable('structured output exceeds size contract')
    padded = pad_inventory_tiles(value, height, width, layout.row_alignment, layout.column_alignment)
    groups = {}
    for index, item in enumerate(value.inventory.items):
        groups.setdefault(inventory_key(item, order), []).append(index)
    ranks = [groups[k] for k in sorted(groups, reverse=descending)]
    canonical = [i for group in ranks for i in group]
    slots = grid_inventory_slots(rows, columns, layout.traversal)
    def render(indices):
        placements = tuple(slots[k] for k in range(len(indices)))
        ordered_tiles = tuple(padded[i] for i in indices)
        return render_inventory_slots(ordered_tiles, placements, rows, columns,
                                      layout.row_gap, layout.column_gap, value.inventory.scene.background)
    first = render(canonical)
    start = 0
    for group in ranks:
        for j in range(1, len(group)):
            if padded[group[j]] != padded[group[0]]:
                changed = list(canonical)
                changed[start], changed[start + j] = changed[start + j], changed[start]
                second = render(changed)
                assert first != second
                return first, second
        start += len(group)
    return (first,)


CONTRACTS.update({
    'grid_layout': {'in': 'InventoryTiles', 'out': 'Grid[]',
                    'effect': 'full rectangular inventory; input-derived slot extents; exact tied-output witnesses'},
})


@dataclass(frozen=True)
class GridInventoryProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    collection: str
    measure: MeasureSpec
    order: str
    descending: bool
    layout: GridLayoutSpec

    def execute_options(self, scene: Scene) -> tuple[Grid, ...]:
        inventory = collect_inventory(scene, self.collection, self.connectivity)
        tiles = measure_inventory(inventory, self.measure)
        return layout_inventory_grid(tiles, self.order, self.descending, self.layout)

    def predict_options(self, a) -> tuple[Grid, ...]:
        try:
            return self.execute_options(perceive(grid(a), self.background_rule, self.connectivity, self.monochrome))
        except Inapplicable:
            return ()

    def predict(self, a):
        outputs = self.predict_options(a)
        return outputs[0] if len(outputs) == 1 else None

    def describe(self):
        from dataclasses import asdict
        return {'language': 'shared_scene_grid_inventory_v1', **asdict(self),
                'signature': 'collect -> measure -> order -> grid_layout',
                'coordinate_frame': 'original_pixel_coordinates',
                'tie_policy': 'identical_padded_tiles_or_two_complete_witnesses'}

    @classmethod
    def from_dict(cls, value):
        if value.get('language') != 'shared_scene_grid_inventory_v1' or value.get('coordinate_frame') != 'original_pixel_coordinates':
            raise Inapplicable('unsupported structured inventory program')
        return cls(value['background_rule'], value['connectivity'], value['monochrome'],
                   value['collection'], MeasureSpec(**value['measure']), value['order'],
                   value['descending'], GridLayoutSpec(**value['layout']))


# Grouped inventory layouts use the same padded-slot renderer as the complete grid.
# Relations refer to ORIGINAL boxes; empty output slots do not become invented objects.
def pad_inventory_tiles(value: InventoryTiles, height: int, width: int,
                        row_alignment: str, column_alignment: str) -> tuple[Grid, ...]:
    if value.inventory.scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('slot layout requires original coordinates')
    if any(x not in ('low', 'center', 'high') for x in (row_alignment, column_alignment)):
        raise Inapplicable('invalid slot alignment')
    if type(height) is not int or type(width) is not int or not 1 <= height <= 30 or not 1 <= width <= 30:
        raise Inapplicable('invalid slot dimensions')
    if not value.tiles or len(value.tiles) != len(value.inventory.items):
        raise Inapplicable('invalid inventory tiles')
    bg = value.inventory.scene.background
    padded = []
    for raw in value.tiles:
        tile = grid(raw); dh, dw = height-len(tile), width-len(tile[0])
        if min(dh, dw) < 0:
            raise Inapplicable('tile exceeds slot')
        if (row_alignment == 'center' and dh % 2) or (column_alignment == 'center' and dw % 2):
            raise Inapplicable('half-cell tile centering')
        dr = 0 if row_alignment == 'low' else dh if row_alignment == 'high' else dh//2
        dc = 0 if column_alignment == 'low' else dw if column_alignment == 'high' else dw//2
        out = [[bg]*width for _ in range(height)]
        for r, row in enumerate(tile):
            out[r+dr][dc:dc+len(row)] = row
        padded.append(grid(out))
    return tuple(padded)


def render_inventory_slots(padded: tuple[Grid, ...], slots: tuple[tuple[int, int], ...],
                           rows: int, columns: int, row_gap: int, column_gap: int,
                           background: int) -> Grid:
    """Render one tile at each occupied slot; never reorder or overwrite collisions."""
    if any(type(v) is not int or not 1 <= v <= 30 for v in (rows, columns)):
        raise Inapplicable('invalid slot grid dimensions')
    if any(type(v) is not int or v not in (0,1,2) for v in (row_gap, column_gap)):
        raise Inapplicable('invalid slot gaps')
    if type(background) is not int or not 0 <= background <= 9:
        raise Inapplicable('invalid slot background')
    if not padded or len(padded) != len(slots):
        raise Inapplicable('incomplete tile-to-slot assignment')
    padded = tuple(grid(t) for t in padded)
    h,w = len(padded[0]),len(padded[0][0])
    if any((len(t),len(t[0])) != (h,w) for t in padded):
        raise Inapplicable('slot tiles must be padded to a common shape')
    if any(len(s) != 2 or any(type(v) is not int for v in s) or not 0 <= s[0] < rows or not 0 <= s[1] < columns for s in slots):
        raise Inapplicable('slot coordinate outside layout')
    if len(set(slots)) != len(slots):
        raise Inapplicable('two items assigned to one slot')
    H, W = rows*h+(rows-1)*row_gap, columns*w+(columns-1)*column_gap
    if max(H,W) > 30:
        raise Inapplicable('slot output exceeds size contract')
    out = [[background]*W for _ in range(H)]
    for t, (sr,sc) in zip(padded,slots):
        r0,c0 = sr*(h+row_gap), sc*(w+column_gap)
        for r,row in enumerate(t):out[r0+r][c0:c0+w]=row
    return grid(out)


AXIS_GROUP_RELATIONS = ('low', 'center', 'high', 'overlap')


@lru_cache(maxsize=4096)
def inventory_axis_groups(inventory: Inventory, axis: int, relation: str) -> tuple[int, ...]:
    """Geometrically ordered classes of exact anchors or interval connectivity.

    Overlap is the transitive closure of inclusive interval overlap. A chain
    belongs to one class even when its extreme intervals are disjoint. It is not
    an arbitrary learned distance threshold or a claim of true perceptual rows.
    """
    if inventory.scene.coordinate_frame != 'original_pixel_coordinates':
        raise Inapplicable('grouping requires original pixel coordinates')
    if type(axis) is not int or axis not in (0,1) or relation not in AXIS_GROUP_RELATIONS:
        raise Inapplicable('invalid axis grouping')
    if not 2 <= len(inventory.items) <= 30:
        raise Inapplicable('grouped inventory requires 2..30 items')
    intervals = [(item.box[axis],item.box[axis+2]) for item in inventory.items]
    if any(lo>hi for lo,hi in intervals):raise Inapplicable('invalid item interval')
    if relation != 'overlap':
        keys=[lo if relation=='low' else hi if relation=='high' else lo+hi for lo,hi in intervals]
        ranks={v:i for i,v in enumerate(sorted(set(keys)))}
        return tuple(ranks[v] for v in keys)
    labels=[None]*len(intervals); end=None; rank=-1
    for i in sorted(range(len(intervals)),key=lambda j:intervals[j]):
        lo,hi=intervals[i]
        if end is None or lo>end:rank+=1;end=hi
        else:end=max(end,hi)
        labels[i]=rank
    return tuple(labels)


@dataclass(frozen=True)
class GroupedLayoutSpec:
    row_relation: str = 'overlap'
    column_relation: str = 'overlap'
    row_gap: int = 0
    column_gap: int = 0
    row_alignment: str = 'low'
    column_alignment: str = 'low'
    require_complete: bool = False

    def slots(self, inventory: Inventory):
        if type(self.require_complete) is not bool:
            raise Inapplicable('invalid complete-lattice flag')
        if any(type(v) is not int or v not in (0,1,2) for v in (self.row_gap,self.column_gap)):
            raise Inapplicable('invalid grouped gaps')
        if any(v not in ('low','center','high') for v in (self.row_alignment,self.column_alignment)):
            raise Inapplicable('invalid grouped alignment')
        rs=inventory_axis_groups(inventory,0,self.row_relation)
        cs=inventory_axis_groups(inventory,1,self.column_relation)
        R,C=max(rs)+1,max(cs)+1
        if min(R,C)<2:raise Inapplicable('grouped layout requires two axes')
        slots=tuple(zip(rs,cs))
        if len(set(slots))!=len(slots):raise Inapplicable('ambiguous slot occupancy')
        if self.require_complete and len(slots)!=R*C:
            raise Inapplicable('complete-lattice control rejects empty slots')
        return R,C,slots


@lru_cache(maxsize=2048)
def layout_inventory_grouped(value: InventoryTiles, layout: GroupedLayoutSpec) -> tuple[Grid, ...]:
    rows,columns,slots=layout.slots(value.inventory)
    if not value.tiles:raise Inapplicable('empty grouped tiles')
    h=max(len(t) for t in value.tiles);w=max(len(t[0]) for t in value.tiles)
    padded=pad_inventory_tiles(value,h,w,layout.row_alignment,layout.column_alignment)
    return (render_inventory_slots(padded,slots,rows,columns,layout.row_gap,
                                   layout.column_gap,value.inventory.scene.background),)


CONTRACTS.update({
    'group_axes': {'in':'Inventory','out':'SlotMap','effect':'infer ordered row/column equivalence classes from original boxes'},
    'slot_layout': {'in':'InventoryTiles + SlotMap','out':'Grid[]','effect':'shared complete/sparse renderer; reject duplicate occupancy; keep unoccupied slots background'},
})


@dataclass(frozen=True)
class GroupedInventoryProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    collection: str
    measure: MeasureSpec
    layout: GroupedLayoutSpec

    def execute_options(self,scene: Scene) -> tuple[Grid, ...]:
        inv=collect_inventory(scene,self.collection,self.connectivity)
        return layout_inventory_grouped(measure_inventory(inv,self.measure),self.layout)

    def predict_options(self,a) -> tuple[Grid, ...]:
        try:return self.execute_options(perceive(grid(a),self.background_rule,self.connectivity,self.monochrome))
        except Inapplicable:return ()

    def predict(self,a):
        options=self.predict_options(a)
        return options[0] if len(options)==1 else None

    def describe(self):
        from dataclasses import asdict
        return {'language':'shared_scene_grouped_inventory_v1',**asdict(self),
                'signature':'collect -> measure -> group_axes -> slot_layout',
                'coordinate_frame':'original_pixel_coordinates',
                'occupancy':'unique input-derived slot; missing slots remain background'}

    @classmethod
    def from_dict(cls,value):
        if value.get('language')!='shared_scene_grouped_inventory_v1' or value.get('coordinate_frame')!='original_pixel_coordinates':
            raise Inapplicable('unsupported grouped inventory program')
        return cls(value['background_rule'],value['connectivity'],value['monochrome'],
                   value['collection'],MeasureSpec(**value['measure']),GroupedLayoutSpec(**value['layout']))

# Spatial provenance is a contract on COLLECT, distinct from semantic colour
# aggregation used by counting or ordinary ordered inventories.
@dataclass(frozen=True)
class AxisCoordinates:
    labels: tuple[int, ...]
    count: int
    origin: int | None = None
    pitch: int | None = None


def axis_coordinates(boxes, axis: int, relation: str, metric: str = 'rank') -> AxisCoordinates:
    """Infer ordinal classes or a witnessed regular lattice from original boxes.

    The lattice is the coarsest integer pitch dividing the anchor differences.
    The pitch itself must occur as an observed adjacent gap; at least three
    distinct anchors are required when that axis is not a singleton. This is a
    finite structural prior, not proof of a latent grid. No extrapolated outer
    rows/columns are introduced. Centres use doubled integer coordinates.
    """
    from math import gcd
    if type(axis) is not int or axis not in (0, 1) or relation not in AXIS_GROUP_RELATIONS or metric not in ('rank', 'pitch'):
        raise Inapplicable('invalid coordinate specification')
    boxes=tuple(boxes)
    if not boxes or any(len(b)!=4 or any(type(x) is not int for x in b) or b[axis]>b[axis+2] for b in boxes):
        raise Inapplicable('invalid coordinate boxes')
    if relation=='overlap':
        if metric!='rank':raise Inapplicable('interval overlap has no anchor pitch')
        intervals=[(b[axis],b[axis+2]) for b in boxes]
        labels=[0]*len(boxes);end=None;rank=-1
        for i in sorted(range(len(boxes)),key=lambda i:intervals[i]):
            lo,hi=intervals[i]
            if end is None or lo>end:rank+=1;end=hi
            else:end=max(end,hi)
            labels[i]=rank
        return AxisCoordinates(tuple(labels),rank+1)
    keys=[b[axis] if relation=='low' else b[axis+2] if relation=='high' else b[axis]+b[axis+2] for b in boxes]
    ordered=sorted(set(keys));origin=ordered[0]
    if metric=='rank':
        ranks={x:i for i,x in enumerate(ordered)}
        return AxisCoordinates(tuple(ranks[x] for x in keys),len(ordered))
    if len(ordered)==1:return AxisCoordinates((0,)*len(boxes),1,origin,None)
    if len(ordered)<3:raise Inapplicable('pitch needs at least three observed anchors')
    diffs=[b-a for a,b in zip(ordered,ordered[1:])];step=0
    for d in diffs:step=gcd(step,d)
    if step not in diffs:raise Inapplicable('inferred pitch has no observed adjacent witness')
    labels=tuple((x-origin)//step for x in keys);count=max(labels)+1
    if count>30:raise Inapplicable('coordinate lattice exceeds output contract')
    return AxisCoordinates(labels,count,origin,step)


@dataclass(frozen=True)
class CoordinateLayoutSpec:
    row_relation: str = 'overlap'
    column_relation: str = 'overlap'
    row_metric: str = 'rank'
    column_metric: str = 'rank'
    row_gap: int = 0
    column_gap: int = 0
    row_alignment: str = 'low'
    column_alignment: str = 'low'
    local_items: bool = True

    def slots(self, inventory: Inventory):
        if inventory.scene.coordinate_frame!='original_pixel_coordinates':
            raise Inapplicable('spatial lineage requires original coordinates')
        if type(self.local_items) is not bool or any(type(v) is not int or v not in (0,1,2) for v in (self.row_gap,self.column_gap)):
            raise Inapplicable('invalid coordinate layout')
        if any(v not in ('low','center','high') for v in (self.row_alignment,self.column_alignment)):
            raise Inapplicable('invalid coordinate padding')
        if not 2<=len(inventory.items)<=30:raise Inapplicable('coordinate inventory needs 2..30 items')
        # The reference coordinate system belongs to the original segmentation,
        # not a bounding box formed by aggregating same-colour distant objects.
        boxes=tuple(e.box for e in inventory.scene.entities) if self.local_items else tuple(i.box for i in inventory.items)
        rr=axis_coordinates(boxes,0,self.row_relation,self.row_metric)
        cc=axis_coordinates(boxes,1,self.column_relation,self.column_metric)
        if self.local_items:
            owners={p:i for i,e in enumerate(inventory.scene.entities) for p in e.cells}
            slots=[];used=set()
            for item in inventory.items:
                cells=set(item.cells)
                if len(cells)!=len(item.cells) or used&cells or any(p not in owners for p in cells):
                    raise Inapplicable('invalid collected support')
                used.update(cells);members={owners[p] for p in cells}
                if any(not set(inventory.scene.entities[i].cells)<=cells for i in members):
                    raise Inapplicable('a spatial item splits an original component')
                locations={(rr.labels[i],cc.labels[i]) for i in members}
                if len(locations)!=1:raise Inapplicable('a spatial item merges separate coordinate locations')
                slots.append(next(iter(locations)))
            if used!=set(owners):raise Inapplicable('spatial collection loses original components')
            slots=tuple(slots)
        else:slots=tuple(zip(rr.labels,cc.labels))
        if rr.count*cc.count<2 or max(rr.count,cc.count)>30 or len(set(slots))!=len(slots):
            raise Inapplicable('invalid or multiply occupied coordinate slots')
        return rr.count,cc.count,slots


@dataclass(frozen=True)
class CoordinateInventoryProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    collection: str
    measure: MeasureSpec
    layout: CoordinateLayoutSpec

    def execute_options(self,scene: Scene) -> tuple[Grid, ...]:
        inv=collect_inventory(scene,self.collection,self.connectivity)
        # Both coordinate interpretations share the exact padded-slot renderer.
        return layout_inventory_grouped(measure_inventory(inv,self.measure),self.layout)

    def predict_options(self,a) -> tuple[Grid, ...]:
        try:return self.execute_options(perceive(grid(a),self.background_rule,self.connectivity,self.monochrome))
        except Inapplicable:return ()

    def predict(self,a):
        options=self.predict_options(a)
        return options[0] if len(options)==1 else None

    def describe(self):
        from dataclasses import asdict
        return {'language':'shared_scene_coordinate_inventory_v1',**asdict(self),
                'signature':'collect -> certify_spatial_lineage -> measure -> infer_coordinates -> slot_layout',
                'coordinate_frame':'original_pixel_coordinates'}

    @classmethod
    def from_dict(cls,value):
        if value.get('language')!='shared_scene_coordinate_inventory_v1' or value.get('coordinate_frame')!='original_pixel_coordinates':
            raise Inapplicable('unsupported coordinate program')
        return cls(value['background_rule'],value['connectivity'],value['monochrome'],value['collection'],
                   MeasureSpec(**value['measure']),CoordinateLayoutSpec(**value['layout']))


CONTRACTS.update({
    'spatial_lineage':{'in':'Inventory + Scene','out':'Original-component membership','effect':'reject split components and merged distinct addresses'},
    'axis_coordinates':{'in':'Original boxes','out':'AxisCoordinates','effect':'rank or witnessed pitch; retain unsupported outer extent as unknown'},
})

# V96: a typed bridge to the SAME instruction interpreter. Source coordinates
# remain in a separate map; they are never replaced by logical-cell coordinates.
@dataclass(frozen=True)
class AbstractView:
    source: Grid
    symbols: Grid
    domains: tuple[tuple[tuple[int, int], ...], ...]
    background: int | None
    provenance: str
    metric_safe: bool

    def check(self):
        source=grid(self.source); symbols=grid(self.symbols)
        if len(self.domains)!=len(symbols)*len(symbols[0]):
            raise Inapplicable('one domain required per logical cell')
        seen=set()
        for domain in self.domains:
            if len(set(domain))!=len(domain):raise Inapplicable('duplicate coordinate inside domain')
            for r,c in domain:
                if not (0<=r<len(source) and 0<=c<len(source[0])) or (r,c) in seen:
                    raise Inapplicable('overlapping or out-of-range source domains')
                seen.add((r,c))
        if self.provenance not in ('cartesian_cells','component_support'):
            raise Inapplicable('unknown source provenance')
        return self

    def decode(self, symbols: Grid, output_mode: str) -> Grid:
        self.check(); symbols=grid(symbols)
        if output_mode=='abstract':return symbols
        if output_mode!='lift':raise Inapplicable('unsupported decode contract')
        if (len(symbols),len(symbols[0]))!=(len(self.symbols),len(self.symbols[0])):
            raise Inapplicable('write-back requires unchanged logical dimensions')
        result=[list(row) for row in self.source]
        for value,domain in zip((v for row in symbols for v in row),self.domains):
            if not domain and value!=self.background:
                raise Inapplicable('empty logical slot has no original support to receive paint')
            for r,c in domain:result[r][c]=value
        return grid(result)

    def target(self, output: Grid, output_mode: str) -> Grid:
        """Pull back demonstration output using INPUT domains; never segment it."""
        self.check(); output=grid(output)
        if output_mode=='abstract':return output
        if output_mode!='lift' or (len(output),len(output[0]))!=(len(self.source),len(self.source[0])):
            raise Inapplicable('wrong lifted target geometry')
        touched=set(); values=[]
        for domain in self.domains:
            touched.update(domain)
            colours={output[r][c] for r,c in domain}
            if len(colours)>1:raise Inapplicable('output is not uniform in an input-derived domain')
            values.append(next(iter(colours)) if colours else self.background)
        if any(output[r][c]!=v for r,row in enumerate(self.source) for c,v in enumerate(row) if (r,c) not in touched):
            raise Inapplicable('output changes pixels outside recorded source domains')
        width=len(self.symbols[0]); macro=grid(tuple(tuple(values[r:r+width]) for r in range(0,len(values),width)))
        if self.decode(macro,'lift')!=output:raise Inapplicable('target has no lossless pullback')
        return macro


@dataclass(frozen=True)
class AbstractionSpec:
    kind: str
    partition: Any = None
    reducer: str = 'uniform'
    background_rule: str | int | None = None
    connectivity: int = 4
    coordinates: CoordinateLayoutSpec | None = None

    def encode(self, a: Grid) -> AbstractView:
        from cell_abstraction import features
        from attributes import background
        a=grid(a);domains=[]
        if self.kind=='cells':
            if self.partition is None or self.reducer not in ('uniform','majority','mode','foreground'):
                raise Inapplicable('invalid cell abstraction')
            symbols=features(a,'whole',self.background_rule,self.partition,self.reducer)
            axes=self.partition.axes(a)
            if symbols is None or axes is None:raise Inapplicable('cell abstraction is inapplicable')
            rr,cc=axes
            domains=[tuple((r,c) for r in rs for c in cs) for rs in rr for cs in cc]
            bg=background(a,self.background_rule) if self.background_rule is not None else None
            metric_safe=self.partition.kind!='identical_runs' or all(len({len(x) for x in axis})==1 for axis in axes)
            provenance='cartesian_cells'
        elif self.kind=='coordinates':
            if self.coordinates is None or not self.coordinates.local_items or self.connectivity not in (4,8):
                raise Inapplicable('coordinate abstraction requires certified local components')
            scene=perceive(a,self.background_rule,self.connectivity,True)
            inv=collect_inventory(scene,'objects',self.connectivity)
            rows,cols,slots=self.coordinates.slots(inv);bg=scene.background
            array=[[bg]*cols for _ in range(rows)];domains=[() for _ in range(rows*cols)]
            for item,(r,c) in zip(inv.items,slots):
                colours={a[x][y] for x,y in item.cells}
                if len(colours)!=1:raise Inapplicable('symbol needs a unique original component colour')
                array[r][c]=next(iter(colours));domains[r*cols+c]=item.cells
            symbols=grid(array);metric_safe=False;provenance='component_support'
        else:raise Inapplicable('unknown abstraction kind')
        # Explicit compiler language bound, never reported as exhaustive ARC search.
        if len(symbols)*len(symbols[0])>64 or len(symbols)*len(symbols[0])>=len(a)*len(a[0]):
            raise Inapplicable('abstraction must reduce the grid to at most 64 logical sites')
        return AbstractView(a,symbols,tuple(domains),bg,provenance,metric_safe).check()

    def describe(self):
        from dataclasses import asdict
        return {'kind':self.kind,'partition':asdict(self.partition) if self.partition else None,
                'reducer':self.reducer,'background_rule':self.background_rule,'connectivity':self.connectivity,
                'coordinates':asdict(self.coordinates) if self.coordinates else None}

    @classmethod
    def from_dict(cls,value):
        from cell_abstraction import Partition
        return cls(value['kind'],Partition(**value['partition']) if value.get('partition') else None,
                   value.get('reducer','uniform'),value.get('background_rule'),value.get('connectivity',4),
                   CoordinateLayoutSpec(**value['coordinates']) if value.get('coordinates') else None)


def abstraction_reason_compatible(view: AbstractView, reason: Program | None) -> bool:
    """Do not infer physical metric predicates from nonuniform logical contraction."""
    if reason is None or view.metric_safe:return True
    def safe(predicate):
        return predicate.operator=='all' or (all(safe(c) for c in predicate.children)
               if predicate.operator in ('and','or','not') else predicate.feature in ('holes','border','solid','palette'))
    return safe(reason.predicate) and not any(i.op=='align' for i in reason.instructions)


@dataclass(frozen=True)
class EncodedSceneProgram:
    encoder: AbstractionSpec
    output_mode: str
    reason: Program | None = None

    def reason_view(self,view: AbstractView) -> Grid:
        from dataclasses import replace
        if not abstraction_reason_compatible(view,self.reason):
            raise Inapplicable('reasoning predicate is incompatible with contraction geometry')
        if self.reason is None:return view.symbols
        scene=perceive(view.symbols,self.reason.background_rule,self.reason.connectivity,self.reason.monochrome)
        logical=replace(scene,coordinate_frame='logical_cell_coordinates')
        return self.reason.execute_scene(logical,expected_frame='logical_cell_coordinates')

    def predict(self,a):
        try:
            view=_encoded_view_cached(self.encoder,grid(a))
            if not abstraction_reason_compatible(view,self.reason):raise Inapplicable('reason violates representation contract')
            return _decoded_view_cached(view,_reason_view_cached(self.reason,view.symbols,view.metric_safe),self.output_mode)
        except Inapplicable:return None

    def trace(self,a):
        view=self.encoder.encode(grid(a));logical=self.reason_view(view)
        return {'encoder':self.encoder.describe(),'logical_input':[list(r) for r in view.symbols],
                'logical_prediction':[list(r) for r in logical],'output_mode':self.output_mode,
                'source_domains':[[list(p) for p in domain] for domain in view.domains],
                'provenance':view.provenance,'metric_safe':view.metric_safe,
                'output':[list(r) for r in view.decode(logical,self.output_mode)]}

    def describe(self):
        return {'language':'shared_encode_reason_decode_v1','encoder':self.encoder.describe(),
                'reason':self.reason.describe() if self.reason else None,'output_mode':self.output_mode,
                'reason_coordinate_frame':'logical_cell_coordinates',
                'signature':'encode -> shared_scene_reason -> decode' if self.reason else 'encode -> identity -> decode'}

    @classmethod
    def from_dict(cls,value):
        if value.get('language')!='shared_encode_reason_decode_v1' or value.get('reason_coordinate_frame')!='logical_cell_coordinates':
            raise Inapplicable('unsupported encoded program')
        if value['output_mode'] not in ('abstract','lift'):raise Inapplicable('invalid output contract')
        return cls(AbstractionSpec.from_dict(value['encoder']),value['output_mode'],Program.from_dict(value['reason']) if value['reason'] else None)

CONTRACTS.update({
    'encode_view':{'in':'Grid','out':'AbstractView','effect':'record disjoint original supports and logical coordinate type'},
    'reason_view':{'in':'AbstractView + Program','out':'LogicalGrid','effect':'same interpreter; explicit logical coordinate context and metric guard'},
    'decode_view':{'in':'AbstractView + LogicalGrid','out':'Grid','effect':'return abstraction or write only mapped source regions'},
})


@lru_cache(maxsize=1024)
def _encoded_view_cached(encoder, source):
    return encoder.encode(source)


@lru_cache(maxsize=1024)
def _decoded_view_cached(view, symbols, mode):
    return view.decode(symbols, mode)


@lru_cache(maxsize=1024)
def _reason_view_cached(reason, symbols, metric_safe):
    from dataclasses import replace
    if reason is None:return symbols
    # Compatibility is checked with the true view before this helper is used.
    logical=replace(perceive(symbols,reason.background_rule,reason.connectivity,reason.monochrome),coordinate_frame='logical_cell_coordinates')
    return reason.execute_scene(logical,expected_frame='logical_cell_coordinates')


# V98: reusable cell-context representation inside the shared scene interpreter.
# It is an input-derived field over original pixel coordinates. The compiler lives
# in scene_programs.py; this module only defines representation + execution.
from collections import Counter as _ContextCounter

_CONTEXT_D4=((-1,0),(1,0),(0,-1),(0,1))
_CONTEXT_D8=((-1,-1),(-1,0),(-1,1),(0,-1),(0,1),(1,-1),(1,0),(1,1))
_CONTEXT_SENTINEL=-1
_CONTEXT_KEEP=('K',)


def _context_components(a: Grid):
    h,w=len(a),len(a[0]); cid=[[-1]*w for _ in range(h)]; comps=[]
    for r in range(h):
        for c in range(w):
            if cid[r][c]>=0: continue
            col=a[r][c]; k=len(comps); stack=[(r,c)]; cid[r][c]=k; cells=[]
            while stack:
                x,y=stack.pop(); cells.append((x,y))
                for dr,dc in _CONTEXT_D4:
                    xx,yy=x+dr,y+dc
                    if 0<=xx<h and 0<=yy<w and cid[xx][yy]<0 and a[xx][yy]==col:
                        cid[xx][yy]=k; stack.append((xx,yy))
            rs=[x for x,y in cells]; cs=[y for x,y in cells]
            comps.append({'colour':col,'area':len(cells),'height':max(rs)-min(rs)+1,
                          'width':max(cs)-min(cs)+1,
                          'border':int(min(rs)==0 or max(rs)==h-1 or min(cs)==0 or max(cs)==w-1),
                          'cells':tuple(cells)})
    return cid,comps


def _context_exterior(a: Grid,bg: int):
    h,w=len(a),len(a[0]); seen=set(); stack=[]
    for r in range(h):
        for c in range(w):
            if (r in (0,h-1) or c in (0,w-1)) and a[r][c]==bg:
                seen.add((r,c)); stack.append((r,c))
    while stack:
        r,c=stack.pop()
        for dr,dc in _CONTEXT_D4:
            p=(r+dr,c+dc)
            if 0<=p[0]<h and 0<=p[1]<w and p not in seen and a[p[0]][p[1]]==bg:
                seen.add(p); stack.append(p)
    return seen


def _context_visible(a: Grid,bg:int,r:int,c:int,dr:int,dc:int):
    h,w=len(a),len(a[0]); r+=dr; c+=dc; dist=1
    while 0<=r<h and 0<=c<w:
        if a[r][c]!=bg: return a[r][c],dist
        r+=dr; c+=dc; dist+=1
    return _CONTEXT_SENTINEL,0


@lru_cache(maxsize=512)
def context_scene(a: Grid, background_rule: str | int = 'modal') -> Scene:
    """Perceive a context field even when the canvas has no foreground entities."""
    a=grid(a); bg=attributes.background(a,background_rule)
    if bg is None: raise Inapplicable('unresolved background')
    try:
        return perceive(a,background_rule,4,True)
    except Inapplicable:
        return Scene(a,bg,tuple())


@lru_cache(maxsize=512)
def context_features(scene: Scene, tier: int = 1):
    """Return one reusable structural feature vector per original pixel.

    The field is representation only: it contains no output colours, task IDs or
    example coordinates. Features cover local neighbourhood, connected-region
    geometry, enclosure, row/column support, visibility, reflection and border.
    """
    if tier not in (1,2): raise Inapplicable('unknown context tier')
    a=scene.source; h,w=len(a),len(a[0]); bg=scene.background
    cid,comps=_context_components(a); ext=_context_exterior(a,bg)
    nonbg_sizes=sorted({x['area'] for x in comps if x['colour']!=bg})
    row_counts=[sum(v!=bg for v in row) for row in a]
    col_counts=[sum(a[r][c]!=bg for r in range(h)) for c in range(w)]
    out=[]
    for r in range(h):
        for c in range(w):
            v=a[r][c]; comp=comps[cid[r][c]]
            n4=sum(0<=r+dr<h and 0<=c+dc<w and a[r+dr][c+dc]!=bg for dr,dc in _CONTEXT_D4)
            n8=sum(0<=r+dr<h and 0<=c+dc<w and a[r+dr][c+dc]!=bg for dr,dc in _CONTEXT_D8)
            rank=nonbg_sizes.index(comp['area']) if v!=bg and comp['area'] in nonbg_sizes else -1
            base=[v,int(v==bg),int(v==bg and (r,c) not in ext),
                  comp['area'],rank,comp['height'],comp['width'],comp['border'],n4,n8,
                  row_counts[r],col_counts[c],int(r in (0,h-1)),int(c in (0,w-1)),
                  int(r==0 or c==0 or r==h-1 or c==w-1)]
            for dr,dc in _CONTEXT_D8:
                rr,cc=r+dr,c+dc; base.append(a[rr][cc] if 0<=rr<h and 0<=cc<w else _CONTEXT_SENTINEL)
            for dr,dc in _CONTEXT_D4:
                col,dist=_context_visible(a,bg,r,c,dr,dc); base.extend((col,dist))
            base.extend((a[r][w-1-c],a[h-1-r][c],a[h-1-r][w-1-c]))
            if tier>=2:
                base.extend((min(r,h-1-r),min(c,w-1-c),r==h//2,c==w//2,
                             int(row_counts[r]>0),int(col_counts[c]>0),
                             sum(x==v for x in a[r]),sum(a[x][c]==v for x in range(h))))
            out.append(tuple(int(x) for x in base))
    return tuple(out)


def context_rewrite_edits(scene: Scene, tier: int, tree, walker) -> Edits:
    """Apply a compiled context law through the common atomic edit representation."""
    fs=context_features(scene,tier); h,w=len(scene.source),len(scene.source[0]); writes=[]; bounds=[]
    k=0
    for r in range(h):
        for c in range(w):
            label=walker(tree,fs[k]); k+=1
            value=scene.source[r][c] if label==_CONTEXT_KEEP else label[1]
            bounds.append((r,c))
            if value!=scene.source[r][c]: writes.append((r,c,value))
    return Edits(scene,tuple(writes),frozenset(),frozenset(bounds),'contextual_rewrite')


@dataclass(frozen=True)
class ContextRewriteProgram:
    """Shared scene program: ContextField -> conditional Paint -> Emit.

    The decision tree is a symbolic predicate over the reusable field. Rendering
    goes through Edits/emit, the same write protocol used by other scene programs.
    """
    background_rule: str | int
    tier: int
    mode: str
    tree: Any

    def predict(self,a,walker):
        try:
            scene=context_scene(grid(a),self.background_rule)
            return emit(context_rewrite_edits(scene,self.tier,self.tree,walker),'preserve')
        except Inapplicable:
            return None

    def describe(self):
        return {'language':'shared_scene_v1','family':'shared_scene_context','background_rule':self.background_rule,
                'tier':self.tier,'encoding':self.mode,'tree':self.tree,
                'operators':['ContextField','Case','Paint','Emit'],
                'coordinate_frame':'original_pixel_coordinates'}


# V99: compositional wallpaper reconstruction in the shared scene language.
# One D4 transform can be followed by repeated output tiling with independently
# enabled row/column parity reflections. The program stores only transformation
# parameters and size ratios learned from demonstrations.
@dataclass(frozen=True)
class WallpaperProgram:
    base_orientation: int
    row_factor: int
    col_factor: int
    reflect_odd_rows: bool = False
    reflect_odd_cols: bool = False

    def check(self):
        if type(self.base_orientation) is not int or not 0 <= self.base_orientation < 8:
            raise Inapplicable('wallpaper orientation')
        if type(self.row_factor) is not int or type(self.col_factor) is not int or self.row_factor < 1 or self.col_factor < 1:
            raise Inapplicable('wallpaper factors')
        if (self.row_factor,self.col_factor)==(1,1):
            raise Inapplicable('identity wallpaper')

    def predict(self, value: Grid):
        self.check()
        from oriented_panels import orient
        a=orient(grid(value),self.base_orientation)
        h,w=len(a),len(a[0]); oh,ow=h*self.row_factor,w*self.col_factor
        if oh>30 or ow>30:
            raise Inapplicable('wallpaper exceeds ARC grid bound')
        out=[[0]*ow for _ in range(oh)]
        for ti in range(self.row_factor):
            for tj in range(self.col_factor):
                block=a
                if self.reflect_odd_rows and ti%2:
                    block=tuple(reversed(block))
                if self.reflect_odd_cols and tj%2:
                    block=tuple(tuple(reversed(row)) for row in block)
                for r,row in enumerate(block):
                    out[ti*h+r][tj*w:(tj+1)*w]=row
        return grid(out)

    def describe(self):
        return {'language':'shared_scene_v1','family':'shared_scene_wallpaper',
                'base_orientation':self.base_orientation,
                'row_factor':self.row_factor,'col_factor':self.col_factor,
                'reflect_odd_rows':self.reflect_odd_rows,'reflect_odd_cols':self.reflect_odd_cols,
                'operators':['D4Transform','Repeat2D','ParityReflect','Emit'],
                'conservation':'copies input colours exactly; no invented palette',
                'coordinate_frame':'output_tile_coordinates'}


# V100: shared structural-component grammar.
# A single program type covers four compositional operations over structural
# components: property-conditioned recolour, context-preserving patch transfer,
# compact symbol construction, and marker-guided reflection.  The compiler
# retains all exact demonstration explanations and uses output consensus.

def structural_components(g: Grid, colour: int):
    a=grid(g); H,W=len(a),len(a[0]); seen=set(); out=[]
    for r in range(H):
        for c in range(W):
            if a[r][c]!=colour or (r,c) in seen: continue
            stack=[(r,c)]; seen.add((r,c)); cells=[]
            while stack:
                rr,cc=stack.pop(); cells.append((rr,cc))
                for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                    q=(rr+dr,cc+dc)
                    if 0<=q[0]<H and 0<=q[1]<W and q not in seen and a[q[0]][q[1]]==colour:
                        seen.add(q); stack.append(q)
            out.append(tuple(cells))
    return tuple(out)


def structural_bbox(cells):
    rs=[r for r,c in cells]; cs=[c for r,c in cells]
    return min(rs),min(cs),max(rs),max(cs)


def structural_component_features(g: Grid, cells):
    a=grid(g); H,W=len(a),len(a[0]); S=set(cells)
    r0,c0,r1,c1=structural_bbox(cells); h,w=r1-r0+1,c1-c0+1
    deg=[sum((r+dr,c+dc) in S for dr,dc in ((1,0),(-1,0),(0,1),(0,-1))) for r,c in cells]
    bg={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if (r,c) not in S}
    seen=set(); holes=0
    for p in tuple(bg):
        if p in seen: continue
        q=[p]; seen.add(p); touch=False
        while q:
            r,c=q.pop(); touch |= r in (r0,r1) or c in (c0,c1)
            for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                z=(r+dr,c+dc)
                if z in bg and z not in seen: seen.add(z); q.append(z)
        if not touch: holes+=1
    return {'size':len(cells),'height':h,'width':w,'bbox_area':h*w,'holes':holes,
            'endpoints':sum(d==1 for d in deg),'branch_nodes':sum(d>=3 for d in deg),
            'maxdeg':max(deg),'mindeg':min(deg),'isolated':len(cells)==1,
            'line':h==1 or w==1,'rectangle':len(cells)==h*w,
            'touch_border':any(r in (0,H-1) or c in (0,W-1) for r,c in cells)}


def structural_predicate_holds(features, predicate):
    key,op,value=predicate; x=features[key]
    if op=='eq': return x==value
    if op=='ge': return x>=value
    if op=='le': return x<=value
    raise Inapplicable('unknown structural predicate')


def structural_component_recolour(g: Grid, source: int, target: int, predicate):
    a=grid(g); out=[list(row) for row in a]
    for cells in structural_components(a,source):
        if structural_predicate_holds(structural_component_features(a,cells),predicate):
            for r,c in cells: out[r][c]=target
    return grid(out)


def _struct_modal(g):
    from collections import Counter
    a=grid(g); cnt=Counter(v for row in a for v in row)
    if not cnt: raise Inapplicable('empty grid')
    high=max(cnt.values()); winners=[v for v,n in cnt.items() if n==high]
    if len(winners)!=1: raise Inapplicable('ambiguous modal background')
    return winners[0]


def _struct_solid_rect(cells):
    r0,c0,r1,c1=structural_bbox(cells)
    return len(cells)==(r1-r0+1)*(c1-c0+1)


def _struct_patch(g,r0,c0,h,w):
    return tuple(tuple(g[r0+i][c0+j] for j in range(w)) for i in range(h))


def _struct_rot90(x):
    return tuple(tuple(x[len(x)-1-r][c] for r in range(len(x))) for c in range(len(x[0])))


def structural_transform_patch(patch, name):
    x=tuple(tuple(row) for row in patch); mirror=name.endswith('_m'); base=name[:-2] if mirror else name
    turns={'r0':0,'r90':1,'r180':2,'r270':3}.get(base)
    if turns is None: raise Inapplicable('unknown patch transform')
    for _ in range(turns): x=_struct_rot90(x)
    if mirror: x=tuple(tuple(reversed(row)) for row in x)
    return x

STRUCTURAL_D4=('r0','r0_m','r90','r90_m','r180','r180_m','r270','r270_m')


def structural_patch_pair_candidates(a: Grid, b: Grid):
    a=grid(a); b=grid(b)
    if not a or len(a)!=len(b) or len(a[0])!=len(b[0]): return ()
    try: bg=_struct_modal(a)
    except Inapplicable: return ()
    try:
        if _struct_modal(b)!=bg: return ()
    except Inapplicable: return ()
    H,W=len(a),len(a[0]); changed={(r,c) for r in range(H) for c in range(W) if a[r][c]!=b[r][c]}
    if not changed: return ()
    out=[]
    for socket in sorted({v for row in a for v in row if v!=bg}):
        rects=[q for q in structural_components(a,socket) if _struct_solid_rect(q)]
        targets=[q for q in rects if any(p in changed for p in q)]
        if not targets: continue
        tcells=set().union(*(set(q) for q in targets))
        if not changed <= tcells: continue
        dims={(lambda z:(z[2]-z[0]+1,z[3]-z[1]+1))(structural_bbox(q)) for q in targets}
        if len(dims)!=1: continue
        th,tw=next(iter(dims)); sources=[]
        for sh,sw in {(th,tw),(tw,th)}:
            for r0 in range(H-sh+1):
                for c0 in range(W-sw+1):
                    cells={(r0+i,c0+j) for i in range(sh) for j in range(sw)}
                    if cells & tcells: continue
                    p=_struct_patch(a,r0,c0,sh,sw); vals={v for row in p for v in row}
                    if bg in vals or socket in vals or len(vals)<2: continue
                    if any(a[r0+i][c0+j]!=b[r0+i][c0+j] for i in range(sh) for j in range(sw)): continue
                    names=None
                    for q in targets:
                        qr0,qc0,qr1,qc1=structural_bbox(q); observed=_struct_patch(b,qr0,qc0,th,tw)
                        here={name for name in STRUCTURAL_D4
                              if (lambda tp: len(tp)==th and len(tp[0])==tw and tp==observed)(structural_transform_patch(p,name))}
                        if not here: names=None; break
                        names=here if names is None else names & here
                    if names: sources.append((p,tuple(sorted(names))))
        patterns={p for p,names in sources}
        if len(patterns)!=1: continue
        pattern=next(iter(patterns)); names=set()
        for p,ns in sources:
            if p==pattern: names.update(ns)
        out.append({'socket_colour':socket,'valid_transforms':tuple(sorted(names))})
    return tuple(out)


def structural_patch_transfer(g: Grid, socket_colour: int, transforms):
    a=grid(g); H,W=len(a),len(a[0]); bg=_struct_modal(a)
    rects=[q for q in structural_components(a,socket_colour) if _struct_solid_rect(q)]
    if not rects: return None
    hypotheses=[]
    dims=sorted({(lambda z:(z[2]-z[0]+1,z[3]-z[1]+1))(structural_bbox(q)) for q in rects})
    for th,tw in dims:
        targets=[q for q in rects if (lambda z:(z[2]-z[0]+1,z[3]-z[1]+1))(structural_bbox(q))==(th,tw)]
        tcells=set().union(*(set(q) for q in targets))
        for sh,sw in {(th,tw),(tw,th)}:
            for r0 in range(H-sh+1):
                for c0 in range(W-sw+1):
                    cells={(r0+i,c0+j) for i in range(sh) for j in range(sw)}
                    if cells & tcells: continue
                    p=_struct_patch(a,r0,c0,sh,sw); vals={v for row in p for v in row}
                    if bg in vals or socket_colour in vals or len(vals)<2: continue
                    ok=True
                    for rr,cc in cells:
                        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
                            nr,nc=rr+dr,cc+dc
                            if 0<=nr<H and 0<=nc<W and (nr,nc) not in cells and a[nr][nc]!=bg:
                                ok=False; break
                        if not ok: break
                    if ok: hypotheses.append((p,targets,th,tw))
    rendered=set()
    for p,targets,th,tw in hypotheses:
        for name in transforms:
            tp=structural_transform_patch(p,name)
            if len(tp)!=th or len(tp[0])!=tw: continue
            out=[list(row) for row in a]
            for q in targets:
                r0,c0,_,_=structural_bbox(q)
                for i in range(th):
                    for j in range(tw): out[r0+i][c0+j]=tp[i][j]
            rendered.add(grid(out))
            if len(rendered)>=2: return None
    return next(iter(rendered)) if len(rendered)==1 else None


def structural_colour_count_symbol(g: Grid, background: int, mark: int):
    a=grid(g); h,w=len(a),len(a[0])
    if (h,w)!=(3,3): return None
    n=len({v for row in a for v in row})
    if n not in (1,2,3): return None
    out=[[background]*3 for _ in range(3)]
    for r in range(3):
        for c in range(3):
            if (n==1 and r==0) or (n==2 and r==c) or (n==3 and r+c==2): out[r][c]=mark
    return grid(out)


def structural_arrow_reflection(g: Grid, background: int, source: int, arrow: int):
    a=grid(g); h,w=len(a),len(a[0])
    if {v for row in a for v in row}!={background,source,arrow}: return None
    sp=[(r,c) for r in range(h) for c in range(w) if a[r][c]==source]
    ap=[(r,c) for r in range(h) for c in range(w) if a[r][c]==arrow]
    if not sp or not ap: return None
    r0,r1=min(r for r,c in ap),max(r for r,c in ap); c0,c1=min(c for r,c in ap),max(c for r,c in ap)
    if r1-r0!=2 or c1-c0!=2: return None
    tips=[c for r,c in ap if r==r0]; middle={c for r,c in ap if r==r0+1}; bottom={c for r,c in ap if r==r1}
    if len(tips)!=1 or middle!=set(range(c0,c1+1)) or bottom!={c0+1} or tips[0] not in (c0,c1): return None
    if max(r for r,c in sp)>=r0: return None
    left,right=min(c for r,c in sp),max(c for r,c in sp)
    if left!=c0 or right!=c1: return None
    axis2=2*left-1 if tips[0]==c0 else 2*right+1; out=[list(row) for row in a]
    for r,c in sp:
        cc=axis2-c
        if not 0<=cc<w or out[r][cc]!=background: return None
        out[r][cc]=source
    return grid(out)


@dataclass(frozen=True)
class StructuralComponentProgram:
    kind: str
    parameters: tuple

    def predict(self, value: Grid):
        a=grid(value)
        if self.kind=='component_recolour':
            source,target,predicate=self.parameters
            return structural_component_recolour(a,source,target,predicate)
        if self.kind=='context_patch_transfer':
            socket,transforms=self.parameters
            return structural_patch_transfer(a,socket,transforms)
        if self.kind=='colour_count_orientation':
            return structural_colour_count_symbol(a,*self.parameters)
        if self.kind=='arrow_adjacent_mirror':
            return structural_arrow_reflection(a,*self.parameters)
        raise Inapplicable('unknown structural component program')

    def describe(self):
        operators={
            'component_recolour':['Components','StructuralFeatures','Predicate','Recolour','Emit'],
            'context_patch_transfer':['Components','Socket','D4Transform','PatchTransfer','Emit'],
            'colour_count_orientation':['PaletteCardinality','SymbolConstruct','Emit'],
            'arrow_adjacent_mirror':['MarkerShape','RelativeAxis','ReflectCopy','Emit'],
        }[self.kind]
        return {'language':'shared_scene_v1','family':'shared_structural_components',
                'kind':self.kind,'parameters':self.parameters,'operators':operators,
                'coordinate_frame':'original_pixel_coordinates'}


# V101: shared relational component transport.
# Structural roles select a payload and preserved reference/interface geometry;
# one of four finite relational schemas derives the destination pose.  The
# program contains only semantic role colours and relation parameters learned
# from demonstrations -- never task IDs or example coordinates.
def _rt_components(g: Grid, colour: int):
    return structural_components(grid(g), colour)

def _rt_bbox(cells):
    return structural_bbox(cells)

def _rt_translate(cells, dr, dc):
    return tuple(sorted((r+dr,c+dc) for r,c in cells))

def _rt_upper_open_frame(cells):
    r0,c0,r1,c1=_rt_bbox(cells)
    if r1-r0!=1 or c1-c0<2: return False
    S=set(cells)
    return S==({(r0,c) for c in range(c0,c1+1)}|{(r1,c0),(r1,c1)})

def _rt_lower_open_frame(cells):
    r0,c0,r1,c1=_rt_bbox(cells)
    if r1-r0!=1 or c1-c0<2: return False
    S=set(cells)
    return S==({(r1,c) for c in range(c0,c1+1)}|{(r0,c0),(r0,c1)})

def relational_dual_anchor(g: Grid, anchor_colour: int):
    a=grid(g); H,W=len(a),len(a[0]); bg=_struct_modal(a)
    ac=_rt_components(a,anchor_colour)
    upp=[c for c in ac if _rt_upper_open_frame(c)]
    low=[c for c in ac if _rt_lower_open_frame(c)]
    if len(upp)!=1 or len(low)!=1: return None
    ub,lb=_rt_bbox(upp[0]),_rt_bbox(low[0])
    other=sorted({v for row in a for v in row if v not in (bg,anchor_colour)})
    if len(other)!=1:return None
    payload=other[0]; pcs=_rt_components(a,payload)
    if len(pcs)!=1:return None
    P=pcs[0]; pb=_rt_bbox(P); ph,pw=pb[2]-pb[0]+1,pb[3]-pb[1]+1
    if ub[3]-ub[1]-1!=pw:return None
    tr0,tc0=lb[2]-ph+1,ub[1]+1
    dr,dc=tr0-pb[0],tc0-pb[1]; Q=_rt_translate(P,dr,dc)
    if any(not (0<=r<H and 0<=c<W) for r,c in Q):return None
    src=set(P)
    if any((r,c) not in src and a[r][c]!=bg for r,c in Q):return None
    out=[list(row) for row in a]
    for r,c in P:out[r][c]=bg
    for r,c in Q:out[r][c]=payload
    return grid(out)

def relational_guide_candidates(a: Grid, b: Grid):
    a=grid(a); b=grid(b)
    if not a or len(a)!=len(b) or len(a[0])!=len(b[0]):return ()
    bg=_struct_modal(a)
    if _struct_modal(b)!=bg:return ()
    H,W=len(a),len(a[0]); colours=sorted({v for row in a for v in row if v!=bg}); out=[]
    if len(colours)!=2:return ()
    for guide in colours:
        payload=next(v for v in colours if v!=guide)
        gps=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==guide]
        if len(gps)<4 or any(b[r][c]!=guide for r,c in gps):continue
        same_col=len({c for r,c in gps})==1; same_row=len({r for r,c in gps})==1
        if same_col==same_row:continue
        axis='v' if same_col else 'h'; coords=sorted(r if axis=='v' else c for r,c in gps)
        diffs=[coords[i+1]-coords[i] for i in range(len(coords)-1)]
        if not diffs or min(diffs)<=0 or len(set(diffs))!=1:continue
        step=diffs[0]; pcs=_rt_components(a,payload)
        if len(pcs)!=1:continue
        P=pcs[0]; r0,c0,r1,c1=_rt_bbox(P)
        if (r1-r0)%2 or (c1-c0)%2:continue
        cr,cc=(r0+r1)//2,(c0+c1)//2
        if (cr,cc) not in gps:continue
        expected={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if (r,c)!=(cr,cc)}
        if set(P)!=expected:continue
        for sign in (-1,1):
            dr,dc=(sign*step,0) if axis=='v' else (0,sign*step)
            if (cr+dr,cc+dc) not in gps:continue
            Q=_rt_translate(P,dr,dc); src=set(P)
            if any(not (0<=r<H and 0<=c<W) for r,c in Q):continue
            if any((r,c) not in src and a[r][c]!=bg for r,c in Q):continue
            o=[list(row) for row in a]
            for r,c in P:o[r][c]=bg
            for r,c in Q:o[r][c]=payload
            if grid(o)==b:out.append((guide,payload,step,sign,(r1-r0+1,c1-c0+1)))
    return tuple(out)

def relational_guide_lattice(g: Grid, guide: int, payload: int, step: int, direction: int, payload_shape):
    a=grid(g); H,W=len(a),len(a[0]); bg=_struct_modal(a)
    gps=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==guide]
    if len(gps)<4:return None
    same_col=len({c for r,c in gps})==1; same_row=len({r for r,c in gps})==1
    if same_col==same_row:return None
    axis='v' if same_col else 'h'; coords=sorted(r if axis=='v' else c for r,c in gps)
    diffs=[coords[i+1]-coords[i] for i in range(len(coords)-1)]
    if not diffs or len(set(diffs))!=1 or diffs[0]!=step:return None
    pcs=_rt_components(a,payload)
    if len(pcs)!=1:return None
    P=pcs[0]; r0,c0,r1,c1=_rt_bbox(P)
    if (r1-r0+1,c1-c0+1)!=tuple(payload_shape):return None
    cr,cc=(r0+r1)//2,(c0+c1)//2
    expected={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if (r,c)!=(cr,cc)}
    if set(P)!=expected or (cr,cc) not in gps:return None
    dr,dc=(direction*step,0) if axis=='v' else (0,direction*step)
    if (cr+dr,cc+dc) not in gps:return None
    Q=_rt_translate(P,dr,dc); src=set(P)
    if any(not (0<=r<H and 0<=c<W) for r,c in Q):return None
    if any((r,c) not in src and a[r][c]!=bg for r,c in Q):return None
    out=[list(row) for row in a]
    for r,c in P:out[r][c]=bg
    for r,c in Q:out[r][c]=payload
    return grid(out)

def _rt_hinge_chains(g, anchor, pivot, arm):
    a=grid(g); H,W=len(a),len(a[0]); allowed={anchor,pivot,arm}
    anchors=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==anchor]
    chains=[]; used=set()
    for ar,ac in anchors:
        found=[]
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            cells=[(ar,ac)]; rr,cc=ar+dr,ac+dc
            while 0<=rr<H and 0<=cc<W and a[rr][cc] in allowed:
                cells.append((rr,cc)); rr+=dr;cc+=dc
            vals=[a[r][c] for r,c in cells]
            if len(cells)<3 or vals[0]!=anchor or vals.count(anchor)!=1 or vals.count(pivot)!=1:continue
            pi=vals.index(pivot)
            if pi<1 or pi>=len(vals)-1:continue
            if any(v!=arm for i,v in enumerate(vals) if i not in (0,pi)):continue
            br,bc=ar-dr,ac-dc
            if 0<=br<H and 0<=bc<W and a[br][bc] in allowed:continue
            found.append((tuple(cells),pi,(dr,dc)))
        if len(found)!=1:return None
        cells,pi,d=found[0]
        if any(q in used for q in cells):return None
        used.update(cells);chains.append((cells,pi,d))
    return chains if chains else None

def relational_pivot_hinge(g: Grid, anchor: int, pivot: int, arm: int):
    a=grid(g); H,W=len(a),len(a[0]); bg=_struct_modal(a)
    chains=_rt_hinge_chains(a,anchor,pivot,arm)
    if not chains:return None
    union=set().union(*(set(cells) for cells,_,_ in chains))
    nong={(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=bg}
    if union!=nong:return None
    erase=set();add=set();preserved=set(); center_r=(H-1)/2.0;center_c=(W-1)/2.0
    for cells,pi,(dr,dc) in chains:
        pr,pc=cells[pi]; tail=cells[pi+1:];erase.update(tail);preserved.update(cells[:pi+1]);n=len(tail)
        if dr!=0:
            delta=center_c-pc
            if abs(delta)<1e-12:return None
            rr,cc=0,(1 if delta>0 else -1)
        else:
            delta=center_r-pr
            if abs(delta)<1e-12:return None
            rr,cc=(1 if delta>0 else -1),0
        for k in range(1,n+1):
            q=(pr+rr*k,pc+cc*k)
            if not (0<=q[0]<H and 0<=q[1]<W):return None
            add.add(q)
    for q in add:
        r,c=q
        if q in preserved:return None
        if q not in erase and a[r][c]!=bg:return None
    out=[list(row) for row in a]
    for r,c in erase:out[r][c]=bg
    for r,c in add:out[r][c]=arm
    result=grid(out)
    return result if result!=a else None

def relational_support_candidates(a: Grid, b: Grid):
    a=grid(a);b=grid(b)
    if not a or len(a)!=len(b) or len(a[0])!=len(b[0]):return ()
    H,W=len(a),len(a[0]);bg=_struct_modal(a)
    if _struct_modal(b)!=bg:return ()
    diffs=[(r,c,a[r][c],b[r][c]) for r in range(H) for c in range(W) if a[r][c]!=b[r][c]]
    if not diffs:return ()
    erased={};inserted={}
    for r,c,x,y in diffs:
        if y==bg and x!=bg:erased.setdefault(x,[]).append((r,c))
        if y!=bg and x!=y:inserted.setdefault(y,[]).append((r,c))
    payloads=[v for v in erased if v in inserted and len(erased[v])==len(inserted[v]) and erased[v]]
    out=[]
    for payload in payloads:
        src=tuple(sorted(erased[payload]));dst=tuple(sorted(inserted[payload]));support_cols={a[r][c] for r,c in dst}
        if len(support_cols)!=1:continue
        support=next(iter(support_cols))
        if support in (bg,payload):continue
        deltas={(tr-r,tc-c) for r,c in src for tr,tc in dst}
        for dr,dc in sorted(deltas):
            if dr and dc or (dr==0 and dc==0):continue
            if {(r+dr,c+dc) for r,c in src}!=set(dst):continue
            sr=0 if dr==0 else (1 if dr>0 else -1);sc=0 if dc==0 else (1 if dc>0 else -1);ok=True
            for r,c in src:
                tr,tc=r+dr,c+dc
                if not(0<=tr<H and 0<=tc<W) or a[tr][tc]!=support:ok=False;break
                rr,cc=r+sr,c+sc
                while (rr,cc)!=(tr,tc):
                    if a[rr][cc]!=support:ok=False;break
                    rr+=sr;cc+=sc
                if not ok:break
            if not ok:continue
            allowed=set(src)|set(dst)
            if any((r,c) not in allowed for r,c,_,_ in diffs):continue
            out.append((bg,payload,support,dr,dc))
    return tuple(out)

def relational_support_socket(g: Grid, background: int, payload: int, support: int, dr: int, dc: int):
    a=grid(g);H,W=len(a),len(a[0])
    if _struct_modal(a)!=background:return None
    src=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==payload]
    if not src:return None
    sr=0 if dr==0 else (1 if dr>0 else -1);sc=0 if dc==0 else (1 if dc>0 else -1)
    for r,c in src:
        tr,tc=r+dr,c+dc
        if not(0<=tr<H and 0<=tc<W) or a[tr][tc]!=support:return None
        rr,cc=r+sr,c+sc
        while (rr,cc)!=(tr,tc):
            if a[rr][cc]!=support:return None
            rr+=sr;cc+=sc
    dst={(r+dr,c+dc) for r,c in src};out=[list(row) for row in a]
    for r,c in src:out[r][c]=background
    for r,c in dst:out[r][c]=payload
    return grid(out)


@dataclass(frozen=True)
class TransportEditPlan:
    """Relation-derived pose; execution policy is selected independently."""
    source: tuple
    writes: tuple
    overwrite: tuple
    relation: str
    motion: str


def _apply_transport_plan(value: Grid, plan: TransportEditPlan, source_policy='move'):
    a=grid(value); H,W=len(a),len(a[0]); bg=_struct_modal(a)
    source=set(tuple(q) for q in plan.source); overwrite=set(tuple(q) for q in plan.overwrite)
    writes=tuple((int(r),int(c),int(v)) for r,c,v in plan.writes)
    if source_policy not in ('move','copy') or not writes:return None
    if any(not (0<=r<H and 0<=c<W) for r,c,_ in writes):return None
    clear=(source if source_policy=='move' else set())|overwrite
    for r,c,v in writes:
        if (r,c) not in clear and a[r][c]!=bg and a[r][c]!=v:return None
    out=[list(row) for row in a]
    for r,c in clear:
        if 0<=r<H and 0<=c<W:out[r][c]=bg
    for r,c,v in writes:out[r][c]=v
    result=grid(out)
    return result if result!=a else None


def _dual_anchor_plan(g: Grid, anchor_colour: int):
    a=grid(g); bg=_struct_modal(a)
    ac=_rt_components(a,anchor_colour); upp=[c for c in ac if _rt_upper_open_frame(c)]; low=[c for c in ac if _rt_lower_open_frame(c)]
    if len(upp)!=1 or len(low)!=1:return None
    ub,lb=_rt_bbox(upp[0]),_rt_bbox(low[0])
    other=sorted({v for row in a for v in row if v not in (bg,anchor_colour)})
    if len(other)!=1:return None
    payload=other[0]; pcs=_rt_components(a,payload)
    if len(pcs)!=1:return None
    P=pcs[0]; pb=_rt_bbox(P); ph,pw=pb[2]-pb[0]+1,pb[3]-pb[1]+1
    if ub[3]-ub[1]-1!=pw:return None
    tr0,tc0=lb[2]-ph+1,ub[1]+1; dr,dc=tr0-pb[0],tc0-pb[1]; Q=_rt_translate(P,dr,dc)
    return TransportEditPlan(tuple(P),tuple((r,c,payload) for r,c in Q),(), 'dual_anchor','translate')


def _guide_plan(g: Grid, guide: int, payload: int, step: int, direction: int, payload_shape):
    a=grid(g); gps=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==guide]
    if len(gps)<4:return None
    same_col=len({c for r,c in gps})==1; same_row=len({r for r,c in gps})==1
    if same_col==same_row:return None
    axis='v' if same_col else 'h'; coords=sorted(r if axis=='v' else c for r,c in gps); diffs=[coords[i+1]-coords[i] for i in range(len(coords)-1)]
    if not diffs or len(set(diffs))!=1 or diffs[0]!=step:return None
    pcs=_rt_components(a,payload)
    if len(pcs)!=1:return None
    P=pcs[0]; r0,c0,r1,c1=_rt_bbox(P)
    if (r1-r0+1,c1-c0+1)!=tuple(payload_shape):return None
    cr,cc=(r0+r1)//2,(c0+c1)//2; expected={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if (r,c)!=(cr,cc)}
    if set(P)!=expected or (cr,cc) not in gps:return None
    dr,dc=(direction*step,0) if axis=='v' else (0,direction*step)
    if (cr+dr,cc+dc) not in gps:return None
    Q=_rt_translate(P,dr,dc)
    return TransportEditPlan(tuple(P),tuple((r,c,payload) for r,c in Q),(), 'periodic_guide','translate')


def _pivot_plan(g: Grid, anchor: int, pivot: int, arm: int):
    a=grid(g); H,W=len(a),len(a[0]); chains=_rt_hinge_chains(a,anchor,pivot,arm)
    if not chains:return None
    union=set().union(*(set(cells) for cells,_,_ in chains)); bg=_struct_modal(a); nong={(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=bg}
    if union!=nong:return None
    erase=set();add=set();preserved=set(); center_r=(H-1)/2.0;center_c=(W-1)/2.0
    for cells,pi,(dr,dc) in chains:
        pr,pc=cells[pi]; tail=cells[pi+1:];erase.update(tail);preserved.update(cells[:pi+1]);n=len(tail)
        if dr!=0:
            delta=center_c-pc
            if abs(delta)<1e-12:return None
            rr,cc=0,(1 if delta>0 else -1)
        else:
            delta=center_r-pr
            if abs(delta)<1e-12:return None
            rr,cc=(1 if delta>0 else -1),0
        for k in range(1,n+1):add.add((pr+rr*k,pc+cc*k))
    if any(q in preserved for q in add):return None
    return TransportEditPlan(tuple(sorted(erase)),tuple((r,c,arm) for r,c in sorted(add)),(), 'pivot_hinge','quarter_turn_tail')



def _rt_normalized_shape(cells):
    """Translation-invariant component signature in original pixel coordinates."""
    if not cells:return ()
    r0=min(r for r,c in cells);c0=min(c for r,c in cells)
    return tuple(sorted((r-r0,c-c0) for r,c in cells))


def _rt_touching(a_cells,b_cells,connectivity=4):
    """True when two disjoint components have a topological contact edge."""
    A=set(a_cells);B=set(b_cells)
    if connectivity==4:
        steps=((1,0),(-1,0),(0,1),(0,-1))
    elif connectivity==8:
        steps=tuple((dr,dc) for dr in (-1,0,1) for dc in (-1,0,1) if (dr,dc)!=(0,0))
    else:
        return False
    return any((r+dr,c+dc) in B for r,c in A for dr,dc in steps)


def _homologous_reference_plan(g: Grid, reference: int, payload: int, connectivity: int=4):
    """Transfer a payload between two homologous reference components.

    The relation is graph/topology based rather than coordinate memorisation:
    two same-colour reference components must have identical normalized shape;
    the payload must touch exactly one reference; its relative pose to that
    reference is then reproduced at the homologous reference.
    """
    a=grid(g);H,W=len(a),len(a[0]);bg=_struct_modal(a)
    if reference in (bg,payload) or payload==bg or connectivity not in (4,8):return None
    refs=_rt_components(a,reference);pcs=_rt_components(a,payload)
    if len(refs)!=2 or len(pcs)!=1:return None
    R0,R1=refs;P=pcs[0]
    if _rt_normalized_shape(R0)!=_rt_normalized_shape(R1):return None
    touched=[i for i,R in enumerate((R0,R1)) if _rt_touching(P,R,connectivity)]
    if len(touched)!=1:return None
    si=touched[0];ti=1-si;S=(R0,R1)[si];T=(R0,R1)[ti]
    sb=_rt_bbox(S);tb=_rt_bbox(T)
    dr,dc=tb[0]-sb[0],tb[1]-sb[1]
    Q=_rt_translate(P,dr,dc);src=set(P)
    if any(not (0<=r<H and 0<=c<W) for r,c in Q):return None
    # Preserve the homologous reference itself and reject unrelated collisions.
    if any((r,c) not in src and a[r][c]!=bg for r,c in Q):return None
    return TransportEditPlan(tuple(sorted(P)),tuple((r,c,payload) for r,c in Q),(),
                             'homologous_reference','translate')



@dataclass(frozen=True)
class ComponentGraphNode:
    """A connected monochrome component represented as a graph node."""
    index: int
    colour: int
    cells: tuple
    box: tuple
    shape: tuple


@dataclass(frozen=True)
class ComponentGraphEdge:
    """Typed relation between two component nodes in original coordinates."""
    source: int
    target: int
    relations: tuple


@dataclass(frozen=True)
class ComponentGraph:
    background: int
    nodes: tuple
    edges: tuple

    def neighbours(self, index: int, relation: str | None = None):
        out=[]
        for e in self.edges:
            if e.source==index and (relation is None or relation in e.relations):out.append(e.target)
            elif e.target==index and (relation is None or relation in e.relations):out.append(e.source)
        return tuple(sorted(set(out)))

    def relations(self, source: int, target: int):
        """Relations from source to target, with directional labels inverted as needed."""
        inverse={'contains':'inside','inside':'contains','above':'below','below':'above',
                 'left_of':'right_of','right_of':'left_of'}
        for e in self.edges:
            if e.source==source and e.target==target:
                return e.relations
            if e.source==target and e.target==source:
                return tuple(inverse.get(r,r) for r in e.relations)
        return ()


def _rt_bbox_contains(outer, inner):
    return (outer[0] <= inner[0] and outer[1] <= inner[1] and
            outer[2] >= inner[2] and outer[3] >= inner[3] and outer != inner)


def component_relation_graph(g: Grid, connectivity: int=4):
    """Build a reusable multi-node component graph with typed spatial/topological edges.

    Edges encode only input-derived relations: contact, homologous shape, row/column
    alignment, containment and coarse directional ordering.  No output or task ID is used.
    """
    a=grid(g);bg=_struct_modal(a)
    colours=sorted({v for row in a for v in row if v!=bg})
    nodes=[]
    for colour in colours:
        for cells in _rt_components(a,colour):
            nodes.append(ComponentGraphNode(len(nodes),colour,tuple(cells),_rt_bbox(cells),_rt_normalized_shape(cells)))
    edges=[]
    for i in range(len(nodes)):
        for j in range(i+1,len(nodes)):
            A,B=nodes[i],nodes[j]; rel=[]
            if _rt_touching(A.cells,B.cells,connectivity):rel.append('touch')
            if A.shape==B.shape:rel.append('homologous_shape')
            ar=(A.box[0]+A.box[2]); br=(B.box[0]+B.box[2])
            ac=(A.box[1]+A.box[3]); bc=(B.box[1]+B.box[3])
            if ar==br:rel.append('aligned_row_center')
            if ac==bc:rel.append('aligned_col_center')
            if _rt_bbox_contains(A.box,B.box):rel.append('contains')
            if _rt_bbox_contains(B.box,A.box):rel.append('inside')
            if A.box[2] < B.box[0]:rel.append('above')
            elif B.box[2] < A.box[0]:rel.append('below')
            if A.box[3] < B.box[1]:rel.append('left_of')
            elif B.box[3] < A.box[1]:rel.append('right_of')
            if rel:edges.append(ComponentGraphEdge(i,j,tuple(rel)))
    return ComponentGraph(bg,tuple(nodes),tuple(edges))


def _homologous_reference_set_plan(g: Grid, reference: int, payload: int, connectivity: int=4, minimum_references: int=3):
    """Propagate one payload pose from its source reference to all homologous references.

    This is the first multi-node graph transport relation.  It accepts a set of at least
    `minimum_references` equivalent reference nodes, requires the payload to touch exactly
    one source reference, then instantiates the same relative pose at every other node.
    """
    a=grid(g);H,W=len(a),len(a[0]);bg=_struct_modal(a)
    if reference in (bg,payload) or payload==bg or connectivity not in (4,8):return None
    graph=component_relation_graph(a,connectivity)
    refs=[n for n in graph.nodes if n.colour==reference]
    pays=[n for n in graph.nodes if n.colour==payload]
    if len(refs)<minimum_references or len(pays)!=1:return None
    if len({n.shape for n in refs})!=1:return None
    P=pays[0]
    touched=[n for n in refs if _rt_touching(P.cells,n.cells,connectivity)]
    if len(touched)!=1:return None
    S=touched[0]; sb=S.box; src=set(P.cells); destinations=[]
    for T in refs:
        if T.index==S.index:continue
        dr,dc=T.box[0]-sb[0],T.box[1]-sb[1]
        Q=_rt_translate(P.cells,dr,dc)
        if any(not (0<=r<H and 0<=c<W) for r,c in Q):return None
        destinations.extend(Q)
    if not destinations:return None
    if len(set(destinations))!=len(destinations):return None
    # All destination cells must be free apart from source cells.  References and
    # unrelated objects remain stationary graph nodes and cannot be overwritten.
    if any((r,c) not in src and a[r][c]!=bg for r,c in destinations):return None
    return TransportEditPlan(tuple(sorted(src)),
                             tuple((r,c,payload) for r,c in sorted(destinations)),(),
                             'homologous_reference_set','translate')


def _graph_role_transfer_plan(g: Grid, reference: int, payload: int, bind_relation: str,
                              minimum_references: int=2, connectivity: int=4, relation_name: str='graph_role_transfer'):
    """Transfer one payload pose across homologous references after graph-role binding.

    The binding relation is input-derived (for V106: contains, aligned_row_center,
    or aligned_col_center).  Pose transfer and edit execution remain shared.
    """
    a=grid(g);H,W=len(a),len(a[0]);bg=_struct_modal(a)
    if reference in (bg,payload) or payload==bg or connectivity not in (4,8):return None
    graph=component_relation_graph(a,connectivity)
    refs=[n for n in graph.nodes if n.colour==reference]
    pays=[n for n in graph.nodes if n.colour==payload]
    if len(refs)<minimum_references or len(pays)!=1:return None
    if len({n.shape for n in refs})!=1:return None
    P=pays[0]
    bound=[n for n in refs if bind_relation in graph.relations(n.index,P.index)]
    if len(bound)!=1:return None
    S=bound[0];src=set(P.cells);destinations=[]
    for T in refs:
        if T.index==S.index:continue
        dr,dc=T.box[0]-S.box[0],T.box[1]-S.box[1]
        Q=_rt_translate(P.cells,dr,dc)
        if any(not (0<=r<H and 0<=c<W) for r,c in Q):return None
        destinations.extend(Q)
    if not destinations or len(set(destinations))!=len(destinations):return None
    if any((r,c) not in src and a[r][c]!=bg for r,c in destinations):return None
    return TransportEditPlan(tuple(sorted(src)),
                             tuple((r,c,payload) for r,c in sorted(destinations)),(),
                             relation_name,'translate')


def _contained_reference_set_plan(g: Grid, reference: int, payload: int, minimum_references: int=2):
    """Propagate a payload from the unique containing reference to homologous containers."""
    return _graph_role_transfer_plan(g,reference,payload,'contains',minimum_references,4,
                                     'contained_reference_set')


def _aligned_reference_set_plan(g: Grid, reference: int, payload: int, axis: str,
                                minimum_references: int=2):
    """Propagate a payload from the uniquely center-aligned homologous reference."""
    relation={'row':'aligned_row_center','col':'aligned_col_center'}.get(axis)
    if relation is None:return None
    return _graph_role_transfer_plan(g,reference,payload,relation,minimum_references,4,
                                     'aligned_reference_set')

# Transformation-bearing symmetry closures.  Each group is a reusable finite
# subgroup/action of the square's dihedral geometry rather than a task-specific grid.
_DIHEDRAL_CLOSURE_GROUPS = {
    'mirror_horizontal': ('mirror_h',),
    'mirror_vertical': ('mirror_v',),
    'half_turn': ('rot180',),
    'orthogonal_reflection_closure': ('mirror_h','mirror_v','rot180'),
    'quarter_turn_closure': ('rot90','rot180','rot270'),
    'diagonal_reflection_closure': ('transpose','anti_transpose','rot180'),
    'full_dihedral_closure': ('rot90','rot180','rot270','mirror_h','mirror_v','transpose','anti_transpose'),
}


def _rt_dihedral_transform_grid(g: Grid, transform: str):
    """Apply one D4 transform to the whole grid in original pixel coordinates."""
    a=grid(g);H,W=len(a),len(a[0])
    if transform=='mirror_h':
        return tuple(tuple(row[W-1-c] for c in range(W)) for row in a)
    if transform=='mirror_v':
        return tuple(a[H-1-r] for r in range(H))
    if transform=='rot180':
        return tuple(tuple(a[H-1-r][W-1-c] for c in range(W)) for r in range(H))
    if transform=='rot90':
        return tuple(tuple(a[H-1-r][c] for r in range(H)) for c in range(W))
    if transform=='rot270':
        return tuple(tuple(a[r][W-1-c] for r in range(H)) for c in range(W))
    if transform=='transpose':
        return tuple(tuple(a[r][c] for r in range(H)) for c in range(W))
    if transform=='anti_transpose':
        return tuple(tuple(a[H-1-r][W-1-c] for r in range(H)) for c in range(W))
    raise Inapplicable('unknown dihedral transform')


def _dihedral_completion_plan(g: Grid, closure: str):
    """Complete a pattern by transparent closure under an input-independent D4 group.

    Background is transparent.  Existing non-background cells are preserved, and a
    transformed write is legal only on background or on the same colour.  Thus the
    family cannot erase evidence or resolve colour conflicts by arbitrary overwrite.
    """
    a=grid(g);H,W=len(a),len(a[0]);bg=_struct_modal(a)
    transforms=_DIHEDRAL_CLOSURE_GROUPS.get(closure)
    if not transforms:return None
    source=tuple((r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=bg)
    if not source:return None
    writes={}
    for transform in transforms:
        q=_rt_dihedral_transform_grid(a,transform)
        if len(q)!=H or len(q[0])!=W:return None
        for r,row in enumerate(q):
            for c,v in enumerate(row):
                if v==bg:continue
                old=writes.get((r,c))
                if old is not None and old!=v:return None
                if a[r][c] not in (bg,v):return None
                writes[(r,c)]=v
    if not writes:return None
    return TransportEditPlan(tuple(sorted(source)),
                             tuple((r,c,v) for (r,c),v in sorted(writes.items())),(),
                             'dihedral_completion','dihedral_closure')

def _support_plan(g: Grid, background: int, payload: int, support: int, dr: int, dc: int):
    a=grid(g)
    if _struct_modal(a)!=background:return None
    src=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==payload]
    if not src:return None
    sr=0 if dr==0 else (1 if dr>0 else -1);sc=0 if dc==0 else (1 if dc>0 else -1)
    for r,c in src:
        tr,tc=r+dr,c+dc
        if not(0<=tr<len(a) and 0<=tc<len(a[0])) or a[tr][tc]!=support:return None
        rr,cc=r+sr,c+sc
        while (rr,cc)!=(tr,tc):
            if a[rr][cc]!=support:return None
            rr+=sr;cc+=sc
    dst={(r+dr,c+dc) for r,c in src}
    # destination support is intentionally replaced by payload, so include it
    # in clear to authorize the overwrite in the generic executor.
    clear=tuple(sorted(set(src)|dst))
    return TransportEditPlan(tuple(sorted(src)),tuple((r,c,payload) for r,c in sorted(dst)),tuple(sorted(dst)), 'support_path','translate')


@dataclass(frozen=True)
class TransportRelationSpec:
    """One relation provider in the shared relational-transport grammar.

    The registry separates relation discovery from execution.  A new relation can
    be added without editing RelationalTransportProgram.plan(), which is the
    architectural generalization introduced in V103.
    """
    name: str
    provider: object
    default_motion: str
    kind: str


RELATIONAL_TRANSPORT_RELATIONS = {}


def register_transport_relation(name, provider, default_motion='translate', kind=None):
    if not name or not callable(provider):
        raise ValueError('transport relation requires a name and callable provider')
    RELATIONAL_TRANSPORT_RELATIONS[name] = TransportRelationSpec(
        str(name), provider, str(default_motion), str(kind or name))
    return RELATIONAL_TRANSPORT_RELATIONS[name]


# Built-ins are registered through the same extension point used by future
# generalized relation providers.  No central dispatch edit is then required.
register_transport_relation('dual_anchor', _dual_anchor_plan, 'translate', 'dual_anchor_socket')
register_transport_relation('periodic_guide', _guide_plan, 'translate', 'guide_lattice_step')
register_transport_relation('pivot_hinge', _pivot_plan, 'quarter_turn_tail', 'pivot_hinge_turn')
register_transport_relation('support_path', _support_plan, 'translate', 'support_socket_transfer')
register_transport_relation('homologous_reference', _homologous_reference_plan, 'translate', 'graph_homologous_reference_transfer')
register_transport_relation('homologous_reference_set', _homologous_reference_set_plan, 'translate', 'graph_multi_node_homologous_propagation')
register_transport_relation('contained_reference_set', _contained_reference_set_plan, 'translate', 'graph_containment_pose_propagation')
register_transport_relation('aligned_reference_set', _aligned_reference_set_plan, 'translate', 'graph_alignment_pose_propagation')
register_transport_relation('dihedral_completion', _dihedral_completion_plan, 'dihedral_closure', 'dihedral_symmetry_completion')


@dataclass(frozen=True)
class RelationalTransportProgram:
    relation: str
    parameters: tuple
    motion: str = 'translate'
    source_policy: str = 'move'
    @property
    def kind(self):
        spec=RELATIONAL_TRANSPORT_RELATIONS.get(self.relation)
        return spec.kind if spec else self.relation
    def plan(self,value: Grid):
        spec=RELATIONAL_TRANSPORT_RELATIONS.get(self.relation)
        if spec is None:
            raise Inapplicable('unknown relational transport relation')
        a=grid(value)
        return spec.provider(a,*self.parameters)
    def predict(self,value: Grid):
        plan=self.plan(value)
        if plan is None:return None
        if plan.relation!=self.relation or plan.motion!=self.motion:return None
        return _apply_transport_plan(value,plan,self.source_policy)
    def describe(self):
        if self.motion=='dihedral_closure':
            operators=['Grid','DeriveSymmetryGroup','TransparentOverlay','ConflictCheck','Emit']
        else:
            operators=['Components','SelectPayload','BindReferences','DeriveRelation','SolvePose']
            operators += ['Rotate','Emit'] if self.motion=='quarter_turn_tail' else ['Translate','Emit']
        return {'language':'shared_scene_v2','family':'shared_relational_transport',
                'relation':self.relation,'motion':self.motion,'source_policy':self.source_policy,'kind':self.kind,
                'parameters':self.parameters,'operators':operators,
                'coordinate_frame':'original_pixel_coordinates','execution':'shared_transport_plan',
                'relation_registry':tuple(sorted(RELATIONAL_TRANSPORT_RELATIONS))}

