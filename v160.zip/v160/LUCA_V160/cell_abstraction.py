"""V75: input-derived partitions, cell summaries and one learned projection.

The finite grammar shrinks a whole grid or foreground bounding box, preserving
cell order. All applicable joint programs are retained. No test target, task ID,
numeric-colour tie break, beam or first-fit shortcut is used.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass, asdict
from functools import lru_cache
from itertools import product

from correspondence import grid
from runtime import public_task

from attributes import background

FAMILY = 'cell_abstraction_v75'
COLOUR_REDUCERS = ('uniform', 'majority', 'mode', 'foreground')
SYMBOL_REDUCERS = ('occupancy', 'palette_size', 'foreground_count')
REDUCERS = COLOUR_REDUCERS + SYMBOL_REDUCERS


def runs(indices):
    """Maximal consecutive nonempty index groups; preserves spatial order."""
    out=[]
    for i in indices:
        if not out or i!=out[-1][-1]+1: out.append([i])
        else: out[-1].append(i)
    return tuple(tuple(g) for g in out)


def role(a, rule):
    if rule is None: return None
    return background(a, rule)


@lru_cache(maxsize=512)
def view(a, kind, bg_rule):
    a=grid(a)
    if kind=='whole': return a
    if kind!='foreground_box': raise ValueError('unknown view')
    bg=role(a,bg_rule)
    if bg is None: return None
    pts=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=bg]
    if not pts: return None
    r0=min(r for r,c in pts); r1=max(r for r,c in pts)
    c0=min(c for r,c in pts); c1=max(c for r,c in pts)
    return tuple(row[c0:c1+1] for row in a[r0:r1+1])


@dataclass(frozen=True)
class Partition:
    kind: str
    rows: int=0
    cols: int=0
    separator: int | str | None=None

    def axes(self,a):
        h,w=len(a),len(a[0])
        if self.kind in ('factor','count'):
            if min(self.rows,self.cols)<1: return None
            if self.kind=='factor': rh,cw=self.rows,self.cols
            else:
                if h%self.rows or w%self.cols:return None
                rh,cw=h//self.rows,w//self.cols
            if h%rh or w%cw or rh*cw<=1:return None
            return (tuple(tuple(range(r,r+rh)) for r in range(0,h,rh)),
                    tuple(tuple(range(c,c+cw)) for c in range(0,w,cw)))
        if self.kind=='identical_runs':
            rr=[];cc=[]
            for r in range(h):
                if not rr or a[r]!=a[rr[-1][0]]:rr.append([r])
                else:rr[-1].append(r)
            for c in range(w):
                if not cc or any(a[r][c]!=a[r][cc[-1][0]] for r in range(h)):cc.append([c])
                else:cc[-1].append(c)
            if len(rr)*len(cc)==h*w:return None
            return tuple(map(tuple,rr)),tuple(map(tuple,cc))
        if self.kind=='separators':
            col=role(a,self.separator)
            if col is None:return None
            rs={r for r in range(h) if all(v==col for v in a[r])}
            cs={c for c in range(w) if all(a[r][c]==col for r in range(h))}
            # An internal full line is required. A mere outer frame is not a lattice.
            if not (any(0<r<h-1 for r in rs) or any(0<c<w-1 for c in cs)):return None
            rr=runs(r for r in range(h) if r not in rs)
            cc=runs(c for c in range(w) if c not in cs)
            if not rr or not cc:return None
            return rr,cc
        raise ValueError('unknown partition')


def summarize_cell(values, reducer, bg=None):
    ct=Counter(values)
    if not ct:return None
    if reducer=='uniform':return next(iter(ct)) if len(ct)==1 else None
    if reducer in ('mode','majority'):
        n=max(ct.values());wins=[v for v,k in ct.items() if k==n]
        if len(wins)!=1 or reducer=='majority' and 2*n<=sum(ct.values()):return None
        return wins[0]
    if reducer=='palette_size':return len(ct)
    if bg is None:return None
    fg=set(ct)-{bg}
    if reducer=='foreground':return bg if not fg else next(iter(fg)) if len(fg)==1 else None
    if reducer=='occupancy':return int(bool(fg))
    if reducer=='foreground_count':return sum(n for v,n in ct.items() if v!=bg)
    raise ValueError('unknown reducer')


@lru_cache(maxsize=2048)
def features(a, view_kind, bg_rule, partition, reducer):
    a=grid(a);v=view(a,view_kind,bg_rule)
    if v is None:return None
    axes=partition.axes(v)
    if axes is None:return None
    rr,cc=axes
    # An abstraction must reduce at least one dimension, never expand another.
    if len(rr)>len(a) or len(cc)>len(a[0]) or len(rr)*len(cc)>=len(a)*len(a[0]):return None
    bg=role(a,bg_rule)
    if bg_rule is not None and bg is None:return None
    out=[]
    for rs in rr:
        row=[]
        for cs in cc:
            x=summarize_cell((v[r][c] for r in rs for c in cs),reducer,bg)
            if x is None:return None
            row.append(x)
        out.append(tuple(row))
    return tuple(out)


def infer_map(xs,ys):
    table={}
    for x,y in zip(xs,ys):
        if x is None or len(x)!=len(y) or len(x[0])!=len(y[0]):return None
        for row,truth in zip(x,y):
            for k,v in zip(row,truth):
                if k in table and table[k]!=v:return None
                table[k]=v
    return tuple(sorted(table.items()))


@dataclass(frozen=True)
class CellProgram:
    view_kind: str
    background_rule: int | str | None
    partition: Partition
    reducer: str
    projection: str
    table: tuple[tuple[int,int],...]=()

    def predict(self,a):
        a=grid(a);x=features(a,self.view_kind,self.background_rule,self.partition,self.reducer)
        if x is None:return None
        if self.projection=='preserve':return x
        lookup=dict(self.table)
        if any(k not in lookup for row in x for k in row):return None
        return tuple(tuple(lookup[k] for k in row) for row in x)

    def describe(self):return {'family':FAMILY,**asdict(self)}

    def trace(self,a):
        a=grid(a);v=view(a,self.view_kind,self.background_rule)
        axes=self.partition.axes(v) if v is not None else None
        return {'program':self.describe(),'input_shape':[len(a),len(a[0])],
            'view_shape':[len(v),len(v[0])] if v else None,
            'row_groups':axes[0] if axes else None,'column_groups':axes[1] if axes else None,
            'cell_features':features(a,self.view_kind,self.background_rule,self.partition,self.reducer),
            'prediction':self.predict(a)}


def fit(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or any(len(y)>len(a) or len(y[0])>len(a[0]) or
                        len(y)*len(y[0])>=len(a)*len(a[0]) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    bgs=(None,'modal',*sorted(common));models=[]
    for vk,bg in product(('whole','foreground_box'),bgs):
        if vk=='foreground_box' and bg is None:continue
        vs=tuple(view(a,vk,bg) for a,y in pairs)
        if any(v is None for v in vs):continue
        if vk!='whole' and not any(v!=a for v,(a,y) in zip(vs,pairs)):continue
        # These two regular hypotheses infer size parameters from demonstrations.
        v,y=vs[0],pairs[0][1];h,w=len(v),len(v[0]);oh,ow=len(y),len(y[0])
        parts=[Partition('identical_runs')]
        if h%oh==0 and w%ow==0:
            parts.extend((Partition('factor',h//oh,w//ow),Partition('count',oh,ow)))
        parts.extend(Partition('separators',separator=c) for c in ('modal',*sorted(common)))
        for part in dict.fromkeys(parts):
            axes=tuple(part.axes(v) for v in vs)
            if any(ax is None or len(ax[0])!=len(y) or len(ax[1])!=len(y[0]) for ax,(a,y) in zip(axes,pairs)):continue
            for reducer in REDUCERS:
                needs_bg=reducer in ('foreground','occupancy','foreground_count')
                if needs_bg and bg is None:continue
                if not needs_bg and vk=='whole' and bg is not None:continue
                xs=tuple(features(a,vk,bg,part,reducer) for a,y in pairs)
                if any(x is None for x in xs):continue
                ys=tuple(y for a,y in pairs)
                if reducer in COLOUR_REDUCERS and xs==ys:
                    # Structural colour preservation, not a partial lookup table.
                    models.append(CellProgram(vk,bg,part,reducer,'preserve'));continue
                mapping=infer_map(xs,ys)
                # Symbolic maps require at least two observed feature values. This
                # explicitly excludes single-key constant-output memorization.
                if mapping is None or len(mapping)<2:continue
                models.append(CellProgram(vk,bg,part,reducer,'observed_table',mapping))
    return list(dict.fromkeys(models))


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0
    for m in models:
        ps=tuple(m.predict(t['input']) for t in clean['test'])
        if any(p is None for p in ps):invalid+=1;continue
        groups.setdefault(ps,[]).append(m.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    key=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
       'tests':[{'status':status,'prediction':[list(r) for r in key[i]] if key else None} for i in range(len(clean['test']))],
       'supporting_families':[FAMILY] if key else [],'supporting_laws':groups[key][:20] if key else [],
       'witness_predictions':[[[list(r) for r in y] for y in k] for k in list(groups)[:2]],
       'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer(fold);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
          'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
          'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
          'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


