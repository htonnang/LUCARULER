"""LUCA V137: boundary-graph relation and cross-operator composition.

The family represents sparse coloured cells as graph nodes and derives one of
three shared consequences:

    scene -> boundary relation -> path / projection / cover -> full grid

Inference receives only demonstrations and test inputs. Task identifiers,
official test targets, and stored example coordinates are excluded by
``runtime.public_task``.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _mode, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_boundary_graph_composition"
LANGUAGE = "spinoza_boundary_graph_composition_v137"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation, operator, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "relation": relation,
            "operator": operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _background(value: Grid) -> int:
    try:
        return _mode(value)
    except Inapplicable:
        raise


def _non_background_cells(value: Grid, background: int):
    return [
        (r, c, value[r][c])
        for r in range(len(value))
        for c in range(len(value[0]))
        if value[r][c] != background
    ]


def _changed_output_colours(source: Grid, target: Grid):
    if _shape(source) != _shape(target):
        raise Inapplicable("shape changed")
    colours = set()
    changed = 0
    for r in range(len(source)):
        for c in range(len(source[0])):
            if source[r][c] != target[r][c]:
                colours.add(target[r][c])
                changed += 1
    if not changed:
        raise Inapplicable("identity transformation")
    return colours


# ---------------------------------------------------------------------------
# 1. Role-ordered Manhattan connector.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DirectedManhattanConnectorProgram:
    source_colour: int
    target_colour: int
    path_colour: int
    first_axis: str  # horizontal or vertical

    kind = "role_ordered_manhattan_connector"

    @property
    def schema_key(self):
        return self.kind, self.source_colour, self.target_colour, self.path_colour, self.first_axis

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        by_colour = defaultdict(list)
        for r, c, colour in cells:
            by_colour[colour].append((r, c))
        if len(cells) != 2 or set(by_colour) != {self.source_colour, self.target_colour}:
            raise Inapplicable("requires exactly two role-coloured singleton nodes")
        if any(len(items) != 1 for items in by_colour.values()):
            raise Inapplicable("roles are not singleton nodes")
        if self.path_colour in (background, self.source_colour, self.target_colour):
            raise Inapplicable("path colour is not semantically distinct")
        source = by_colour[self.source_colour][0]
        target = by_colour[self.target_colour][0]
        if source[0] == target[0] or source[1] == target[1]:
            raise Inapplicable("connector requires two-axis displacement")
        return background, source, target

    def predict(self, value):
        value = grid(value)
        background, (sr, sc), (tr, tc) = self.analyse(value)
        out = _array(value)

        def paint(r, c):
            if (r, c) in ((sr, sc), (tr, tc)):
                return
            if out[r][c] != background:
                raise Inapplicable("connector collides with another node")
            out[r][c] = self.path_colour

        if self.first_axis == "horizontal":
            step = 1 if tc > sc else -1
            for c in range(sc + step, tc + step, step):
                paint(sr, c)
            step = 1 if tr > sr else -1
            for r in range(sr + step, tr, step):
                paint(r, tc)
        elif self.first_axis == "vertical":
            step = 1 if tr > sr else -1
            for r in range(sr + step, tr + step, step):
                paint(r, sc)
            step = 1 if tc > sc else -1
            for c in range(sc + step, tc, step):
                paint(tr, c)
        else:
            raise Inapplicable("unknown axis order")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="two_semantic_singleton_nodes_on_an_empty_canvas",
            relation="role_ordered_orthogonal_bend",
            operator="boundary_path_emission",
            parameters={
                "source_colour": self.source_colour,
                "target_colour": self.target_colour,
                "path_colour": self.path_colour,
                "first_axis": self.first_axis,
            },
            definitions={
                "source": "the singleton node whose role starts the ordered path",
                "target": "the singleton node whose role terminates the path",
                "bend": "the coordinate formed after the first-axis displacement",
            },
            propositions=[
                "Node colours identify semantic roles rather than fixed positions.",
                "The first displacement axis is learned from all demonstrations.",
                "The path preserves both endpoints and paints only background cells.",
            ],
            corollary="Emit the unique role-consistent one-bend Manhattan path.",
            common_notions=["graph node", "ordered relation", "orthogonal path", "role invariance"],
        )


def _fit_directed_manhattan(pairs):
    if not pairs:
        return []
    source, target = pairs[0]
    source = grid(source)
    target = grid(target)
    background = _background(source)
    cells = _non_background_cells(source, background)
    if len(cells) != 2:
        return []
    marker_colours = tuple(sorted({colour for _, _, colour in cells}))
    if len(marker_colours) != 2:
        return []
    try:
        changed_colours = _changed_output_colours(source, target)
    except Inapplicable:
        return []
    path_candidates = sorted(changed_colours - set(marker_colours) - {background})
    programs = []
    for source_colour, target_colour in (marker_colours, marker_colours[::-1]):
        for path_colour in path_candidates:
            for axis in ("horizontal", "vertical"):
                program = DirectedManhattanConnectorProgram(source_colour, target_colour, path_colour, axis)
                try:
                    if all(program.predict(x) == grid(y) for x, y in pairs):
                        programs.append(program)
                except Inapplicable:
                    pass
    return programs


# ---------------------------------------------------------------------------
# 2. Opposite-boundary interval partition.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BoundaryMidpointConnectorProgram:
    midpoint_colour: int
    orientation: str  # horizontal or vertical

    kind = "paired_boundary_midpoint_connector"

    @property
    def schema_key(self):
        return self.kind, self.midpoint_colour, self.orientation

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        h, w = _shape(value)
        cells = _non_background_cells(value, background)
        if len(cells) < 2 or len(cells) % 2:
            raise Inapplicable("boundary nodes do not form pairs")
        groups = defaultdict(list)
        if self.orientation == "horizontal":
            if w % 2 != 1:
                raise Inapplicable("horizontal interval has no unique midpoint")
            for r, c, colour in cells:
                groups[r].append((c, colour))
            if any(len(items) != 2 for items in groups.values()):
                raise Inapplicable("row does not contain one boundary pair")
            for items in groups.values():
                items.sort()
                if items[0][0] != 0 or items[1][0] != w - 1:
                    raise Inapplicable("row pair is not on opposite boundaries")
        elif self.orientation == "vertical":
            if h % 2 != 1:
                raise Inapplicable("vertical interval has no unique midpoint")
            for r, c, colour in cells:
                groups[c].append((r, colour))
            if any(len(items) != 2 for items in groups.values()):
                raise Inapplicable("column does not contain one boundary pair")
            for items in groups.values():
                items.sort()
                if items[0][0] != 0 or items[1][0] != h - 1:
                    raise Inapplicable("column pair is not on opposite boundaries")
        else:
            raise Inapplicable("unknown orientation")
        endpoint_colours = {colour for items in groups.values() for _, colour in items}
        if self.midpoint_colour in endpoint_colours or self.midpoint_colour == background:
            raise Inapplicable("midpoint role is not distinct")
        return background, groups

    def predict(self, value):
        value = grid(value)
        _, groups = self.analyse(value)
        h, w = _shape(value)
        out = _array(value)
        if self.orientation == "horizontal":
            midpoint = w // 2
            for r, items in groups.items():
                left, right = sorted(items)
                for c in range(w):
                    out[r][c] = left[1] if c < midpoint else self.midpoint_colour if c == midpoint else right[1]
        else:
            midpoint = h // 2
            for c, items in groups.items():
                top, bottom = sorted(items)
                for r in range(h):
                    out[r][c] = top[1] if r < midpoint else self.midpoint_colour if r == midpoint else bottom[1]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="one_or_more_pairs_of_nodes_on_opposite_canvas_boundaries",
            relation="opposite_boundary_interval_with_unique_midpoint",
            operator="boundary_path_emission",
            parameters={"midpoint_colour": self.midpoint_colour, "orientation": self.orientation},
            definitions={
                "interval": "the complete row or column between paired boundary nodes",
                "midpoint": "the unique central coordinate of an odd-length interval",
            },
            propositions=[
                "Each endpoint colour propagates toward the interval midpoint.",
                "The midpoint receives a learned neutral junction colour.",
                "Multiple independent intervals reuse the same law.",
            ],
            corollary="Partition every paired boundary interval into two endpoint domains and one midpoint.",
            common_notions=["boundary pair", "midpoint", "interval partition", "parallel reuse"],
        )


def _fit_boundary_midpoint(pairs):
    if not pairs:
        return []
    source, target = map(grid, pairs[0])
    background = _background(source)
    input_colours = {colour for _, _, colour in _non_background_cells(source, background)}
    try:
        candidates = sorted(_changed_output_colours(source, target) - input_colours - {background})
    except Inapplicable:
        return []
    programs = []
    for colour in candidates:
        for orientation in ("horizontal", "vertical"):
            program = BoundaryMidpointConnectorProgram(colour, orientation)
            try:
                if all(program.predict(x) == grid(y) for x, y in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 3. Every node emits both of its axes; crossings receive a junction role.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FullCrossProjectionProgram:
    crossing_colour: int

    kind = "full_cross_marker_projection"

    @property
    def schema_key(self):
        return self.kind, self.crossing_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        if not 2 <= len(cells) <= 6:
            raise Inapplicable("requires two to six singleton nodes")
        if len({colour for _, _, colour in cells}) != len(cells):
            raise Inapplicable("marker colours must be unique")
        if len({r for r, _, _ in cells}) != len(cells) or len({c for _, c, _ in cells}) != len(cells):
            raise Inapplicable("marker rows and columns must be unique")
        if self.crossing_colour in {background, *(colour for _, _, colour in cells)}:
            raise Inapplicable("crossing colour is not distinct")
        return background, cells

    def predict(self, value):
        value = grid(value)
        background, cells = self.analyse(value)
        h, w = _shape(value)
        row_roles = {r: colour for r, _, colour in cells}
        column_roles = {c: colour for _, c, colour in cells}
        out = [[background for _ in range(w)] for _ in range(h)]
        for r in range(h):
            for c in range(w):
                row_colour = row_roles.get(r)
                column_colour = column_roles.get(c)
                if row_colour is not None and column_colour is not None:
                    out[r][c] = value[r][c] if value[r][c] != background else self.crossing_colour
                elif row_colour is not None:
                    out[r][c] = row_colour
                elif column_colour is not None:
                    out[r][c] = column_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="distinct_coloured_singleton_nodes_with_unique_rows_and_columns",
            relation="row_column_incidence_graph",
            operator="boundary_axis_projection",
            parameters={"crossing_colour": self.crossing_colour},
            definitions={
                "node axes": "the complete row and column incident to a marker",
                "junction": "an intersection induced by axes of different nodes",
            },
            propositions=[
                "Each node projects its colour along both canvas axes.",
                "Original nodes remain unchanged.",
                "Cross-node intersections receive the common junction role.",
            ],
            corollary="Emit the coloured incidence graph of all marker rows and columns.",
            common_notions=["incidence", "axis projection", "junction", "graph completion"],
        )


def _fit_full_cross(pairs):
    if not pairs:
        return []
    source, target = map(grid, pairs[0])
    background = _background(source)
    input_colours = {colour for _, _, colour in _non_background_cells(source, background)}
    try:
        candidates = sorted(_changed_output_colours(source, target) - input_colours - {background})
    except Inapplicable:
        return []
    programs = []
    for colour in candidates:
        program = FullCrossProjectionProgram(colour)
        try:
            if all(program.predict(x) == grid(y) for x, y in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 4. Marker colour selects one projection axis.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColourAxisProjectionProgram:
    axis_by_colour: tuple[tuple[int, str], ...]
    precedence: str  # row or column

    kind = "colour_axis_projection"

    @property
    def mapping(self):
        return dict(self.axis_by_colour)

    @property
    def schema_key(self):
        return self.kind, self.axis_by_colour, self.precedence

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        mapping = self.mapping
        if len(cells) < 3 or any(colour not in mapping for _, _, colour in cells):
            raise Inapplicable("marker colours do not match the learned axis vocabulary")
        if set(mapping.values()) != {"row", "column"}:
            raise Inapplicable("both projection axes are required")
        row_nodes = [(r, c, colour) for r, c, colour in cells if mapping[colour] == "row"]
        column_nodes = [(r, c, colour) for r, c, colour in cells if mapping[colour] == "column"]
        if len({r for r, _, _ in row_nodes}) != len(row_nodes):
            raise Inapplicable("two row emitters share a row")
        if len({c for _, c, _ in column_nodes}) != len(column_nodes):
            raise Inapplicable("two column emitters share a column")
        row_coordinates = {r for r, _, _ in row_nodes}
        column_coordinates = {c for _, c, _ in column_nodes}
        if any(r in row_coordinates for r, _, _ in column_nodes):
            raise Inapplicable("a column marker lies on an emitted row")
        if any(c in column_coordinates for _, c, _ in row_nodes):
            raise Inapplicable("a row marker lies on an emitted column")
        return background, cells

    def predict(self, value):
        value = grid(value)
        background, cells = self.analyse(value)
        h, w = _shape(value)
        out = [[background for _ in range(w)] for _ in range(h)]
        mapping = self.mapping
        order = ("column", "row") if self.precedence == "row" else ("row", "column")
        for axis in order:
            for r, c, colour in cells:
                if mapping[colour] != axis:
                    continue
                if axis == "row":
                    for cc in range(w):
                        out[r][cc] = colour
                else:
                    for rr in range(h):
                        out[rr][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="repeated_singleton_marker_classes_on_an_empty_canvas",
            relation="marker_colour_to_projection_axis",
            operator="boundary_axis_projection",
            parameters={"axis_by_colour": dict(self.axis_by_colour), "precedence": self.precedence},
            definitions={
                "marker class": "all singleton nodes sharing one colour",
                "axis role": "row or column emission learned for that class",
            },
            propositions=[
                "The same colour class always emits along the same axis.",
                "Several nodes of one class may emit parallel lines.",
                "A demonstrated precedence resolves row-column intersections.",
            ],
            corollary="Project every marker according to its learned colour-to-axis role.",
            common_notions=["class relation", "parallel projection", "axis role", "intersection precedence"],
        )


def _fit_colour_axis(pairs):
    if not pairs:
        return []
    colours = sorted({
        colour
        for source, _ in pairs
        for _, _, colour in _non_background_cells(grid(source), _background(grid(source)))
    })
    if not 2 <= len(colours) <= 5:
        return []
    programs = []
    for axes in product(("row", "column"), repeat=len(colours)):
        if set(axes) != {"row", "column"}:
            continue
        mapping = tuple(zip(colours, axes))
        for precedence in ("row", "column"):
            program = ColourAxisProjectionProgram(mapping, precedence)
            try:
                if all(program.predict(x) == grid(y) for x, y in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 5. Ordered markers induce nearest-row/column boundary slabs.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerVoronoiBoundaryFrameProgram:
    orientation: str  # rows or columns

    kind = "marker_voronoi_boundary_frames"

    @property
    def schema_key(self):
        return self.kind, self.orientation

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        if not 2 <= len(cells) <= 8:
            raise Inapplicable("requires two to eight markers")
        if len({colour for _, _, colour in cells}) != len(cells):
            raise Inapplicable("slab colours must be distinct")
        if self.orientation == "rows":
            if len({r for r, _, _ in cells}) != len(cells):
                raise Inapplicable("marker rows are not unique")
            cells = sorted(cells, key=lambda item: item[0])
        elif self.orientation == "columns":
            if len({c for _, c, _ in cells}) != len(cells):
                raise Inapplicable("marker columns are not unique")
            cells = sorted(cells, key=lambda item: item[1])
        else:
            raise Inapplicable("unknown orientation")
        return background, cells

    def predict(self, value):
        value = grid(value)
        background, cells = self.analyse(value)
        h, w = _shape(value)
        out = [[background for _ in range(w)] for _ in range(h)]
        if self.orientation == "rows":
            owners = [
                min(range(len(cells)), key=lambda index: (abs(r - cells[index][0]), index))
                for r in range(h)
            ]
            for r, owner in enumerate(owners):
                colour = cells[owner][2]
                out[r][0] = colour
                out[r][w - 1] = colour
            for r, _, colour in cells:
                out[r] = [colour] * w
            out[0] = [cells[owners[0]][2]] * w
            out[h - 1] = [cells[owners[-1]][2]] * w
        else:
            owners = [
                min(range(len(cells)), key=lambda index: (abs(c - cells[index][1]), index))
                for c in range(w)
            ]
            for c, owner in enumerate(owners):
                colour = cells[owner][2]
                out[0][c] = colour
                out[h - 1][c] = colour
            for _, c, colour in cells:
                for r in range(h):
                    out[r][c] = colour
            for r in range(h):
                out[r][0] = cells[owners[0]][2]
                out[r][w - 1] = cells[owners[-1]][2]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="ordered_distinct_singleton_markers_on_an_empty_canvas",
            relation="nearest_marker_voronoi_slab",
            operator="boundary_axis_projection",
            parameters={"orientation": self.orientation, "tie_policy": "earlier_ordered_marker"},
            definitions={
                "slab": "the rows or columns nearest to one ordered marker",
                "frame": "the marker axis plus the two side boundaries of its slab",
            },
            propositions=[
                "Every coordinate belongs to its nearest marker along the selected axis.",
                "Ties are resolved by the earlier marker in the ordered axis.",
                "Extreme slabs close against the outer canvas boundaries.",
            ],
            corollary="Emit a coloured boundary frame for each nearest-marker slab.",
            common_notions=["Voronoi relation", "ordered axis", "boundary frame", "nearest role"],
        )


def _fit_voronoi_frames(pairs):
    programs = []
    for orientation in ("rows", "columns"):
        program = MarkerVoronoiBoundaryFrameProgram(orientation)
        try:
            if all(program.predict(x) == grid(y) for x, y in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 6. Two equal nodes project a grid and cover their strict interior.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerRectangleGridCoverProgram:
    fill_colour: int

    kind = "marker_rectangle_grid_cover"

    @property
    def schema_key(self):
        return self.kind, self.fill_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        if len(cells) != 2 or cells[0][2] != cells[1][2]:
            raise Inapplicable("requires two same-role singleton markers")
        (r0, c0, marker_colour), (r1, c1, _) = cells
        if r0 == r1 or c0 == c1:
            raise Inapplicable("markers do not define a rectangle")
        if self.fill_colour in (background, marker_colour):
            raise Inapplicable("fill role is not distinct")
        top, bottom = sorted((r0, r1))
        left, right = sorted((c0, c1))
        if bottom - top < 2 or right - left < 2:
            raise Inapplicable("rectangle has no strict interior")
        return background, marker_colour, (r0, c0), (r1, c1), (top, left, bottom, right)

    def predict(self, value):
        value = grid(value)
        _, marker_colour, first, second, box = self.analyse(value)
        h, w = _shape(value)
        out = _array(value)
        for r in first[0], second[0]:
            for c in range(w):
                out[r][c] = marker_colour
        for c in first[1], second[1]:
            for r in range(h):
                out[r][c] = marker_colour
        top, left, bottom, right = box
        for r in range(top + 1, bottom):
            for c in range(left + 1, right):
                out[r][c] = self.fill_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="two_same_role_singleton_nodes_at_opposite_rectangle_corners",
            relation="paired_marker_bounding_rectangle",
            operator="derived_boundary_cover",
            parameters={"fill_colour": self.fill_colour},
            definitions={
                "projected grid": "the two marker rows and two marker columns extended to the canvas boundary",
                "strict interior": "cells inside the marker-defined rectangle but not on its border",
            },
            propositions=[
                "Both markers project their complete horizontal and vertical axes.",
                "The four projected axes define one interior cover region.",
                "Projection and cover are composed before full-grid emission.",
            ],
            corollary="Emit the marker grid and fill its bounded strict interior.",
            common_notions=["cross-operator composition", "bounding rectangle", "axis projection", "interior cover"],
        )


def _fit_marker_rectangle_grid(pairs):
    if not pairs:
        return []
    source, target = map(grid, pairs[0])
    background = _background(source)
    input_colours = {colour for _, _, colour in _non_background_cells(source, background)}
    try:
        candidates = sorted(_changed_output_colours(source, target) - input_colours - {background})
    except Inapplicable:
        return []
    programs = []
    for colour in candidates:
        program = MarkerRectangleGridCoverProgram(colour)
        try:
            if all(program.predict(x) == grid(y) for x, y in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 7. One marker covers the rectangle to its uniquely nearest corner.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NearestCornerRectangleCoverProgram:
    metric: str = "manhattan"

    kind = "nearest_corner_rectangle_cover"

    @property
    def schema_key(self):
        return self.kind, self.metric

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        if len(cells) != 1:
            raise Inapplicable("requires one singleton marker")
        r, c, colour = cells[0]
        h, w = _shape(value)
        corners = ((0, 0), (0, w - 1), (h - 1, 0), (h - 1, w - 1))
        distances = [abs(r - rr) + abs(c - cc) for rr, cc in corners]
        minimum = min(distances)
        if distances.count(minimum) != 1:
            raise Inapplicable("nearest corner is tied")
        return background, (r, c, colour), corners[distances.index(minimum)]

    def predict(self, value):
        value = grid(value)
        _, (r, c, colour), (rr, cc) = self.analyse(value)
        out = _array(value)
        top, bottom = sorted((r, rr))
        left, right = sorted((c, cc))
        for row in range(top, bottom + 1):
            for column in range(left, right + 1):
                out[row][column] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="one_coloured_singleton_marker_on_a_uniform_canvas",
            relation="unique_nearest_corner_by_manhattan_distance",
            operator="derived_boundary_cover",
            parameters={"metric": self.metric},
            definitions={
                "nearest corner": "the unique canvas corner with minimum Manhattan distance",
                "cover rectangle": "the inclusive rectangle spanned by marker and corner",
            },
            propositions=[
                "The selected corner is derived from current dimensions and marker position.",
                "The marker colour is the cover material.",
                "A distance tie causes safe abstention.",
            ],
            corollary="Cover the rectangle from the marker to its uniquely nearest corner.",
            common_notions=["distance order", "boundary anchor", "rectangle cover", "dimension invariance"],
        )


def _fit_nearest_corner(pairs):
    program = NearestCornerRectangleCoverProgram()
    try:
        return [program] if all(program.predict(x) == grid(y) for x, y in pairs) else []
    except Inapplicable:
        return []


_FITTERS = {
    "role_ordered_manhattan_connector": _fit_directed_manhattan,
    "paired_boundary_midpoint_connector": _fit_boundary_midpoint,
    "full_cross_marker_projection": _fit_full_cross,
    "colour_axis_projection": _fit_colour_axis,
    "marker_voronoi_boundary_frames": _fit_voronoi_frames,
    "marker_rectangle_grid_cover": _fit_marker_rectangle_grid,
    "nearest_corner_rectangle_cover": _fit_nearest_corner,
}


def fit_boundary_graph_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    programs = []
    seen = set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            fitted = fitter(pairs)
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            continue
        for program in fitted:
            if program.schema_key not in seen:
                seen.add(program.schema_key)
                programs.append(program)
    return programs


def _counterfactual(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        passed = False
        detail = {}
        try:
            original = program.predict(source)
            background = _background(source)
            cells = _non_background_cells(source, background)
            if not cells:
                raise Inapplicable("no causal node")
            r, c, _ = cells[0]
            work = _array(source)
            work[r][c] = background
            try:
                passed = program.predict(tuple(tuple(row) for row in work)) != original
            except Inapplicable:
                passed = True
            detail = {"node_removal_changes_or_rejects": bool(passed)}
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **detail})
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_boundary_graph_composition(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_boundary_graph_programs(pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds)
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "boundary_graph_composition": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programs_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = []
    for program in fit_boundary_graph_programs(pairs, minimum_pairs=2, allowed_kinds=allowed):
        try:
            if (
                tuple(program.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(program, pairs).get("passed")
            ):
                programs.append(program)
        except Inapplicable:
            pass
    return expected, programs


def _validate_program(clean, program, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_boundary_graph_programs(remaining, minimum_pairs=1, allowed_kinds=(program.kind,))
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(program, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual.get("passed")
    return {
        "passed": bool(passed),
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_boundary_graph_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programs = _programs_for_expected(clean, full)
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_program(clean, program, expected) for program in programs]
    passed = any(check.get("passed") for check in checks)
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": next((check["folds"] for check in checks if check.get("passed")), checks[0]["folds"]),
        "counterfactuals": [item for check in checks for item in check.get("counterfactuals", [])],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
