"""LUCA V112: proof-carrying relational panel analogy and proposition composition.

V112 separates a panel *relation* from the proposition that produces an output.
It contains three conservative schemas over one shared panel grammar:

* ``boolean_panel_relation`` -- infer a named count predicate over aligned panel
  foreground masks (for example OR or NOR), then emit a two-colour result;
* ``structural_panel_selection`` -- select the unique panel with minimum D4
  symmetry, independent of its position and colour identities;
* ``ordered_panel_overlay`` -- infer a uniquely witnessed panel-priority order
  and compose the first visible value at every aligned cell.

Inference receives demonstrations and test inputs only through
``runtime.public_task``.  Exact training fit is necessary but not sufficient:
full fits require role variation, leave-one-demonstration-out refitting,
causal counterfactuals, prediction consensus, and no task IDs or test targets.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import itertools
import json
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_analogy_proposition_composition"
LANGUAGE = "spinoza_relational_panel_analogy_v1"
SCHEMA_VERSION = "analogy_proposition_schema_v1"


# ---------------------------------------------------------------------------
# Shared panel grammar
# ---------------------------------------------------------------------------


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    ranked = counts.most_common()
    if not ranked:
        raise Inapplicable("empty grid")
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal colour")
    return ranked[0][0]


@dataclass(frozen=True)
class PanelLayout:
    rows: int
    cols: int
    row_separator: int = 0
    col_separator: int = 0

    @property
    def panel_count(self) -> int:
        return self.rows * self.cols

    @property
    def key(self) -> tuple[int, int, int, int]:
        return (self.rows, self.cols, self.row_separator, self.col_separator)

    def to_dict(self):
        return {
            "rows": self.rows,
            "cols": self.cols,
            "row_separator": self.row_separator,
            "col_separator": self.col_separator,
            "panel_count": self.panel_count,
        }

    def panel_shape(self, value: Grid) -> tuple[int, int]:
        height, width = _shape(value)
        hr = height - (self.rows - 1) * self.row_separator
        wr = width - (self.cols - 1) * self.col_separator
        if hr <= 0 or wr <= 0 or hr % self.rows or wr % self.cols:
            raise Inapplicable("grid is incompatible with panel layout")
        return hr // self.rows, wr // self.cols

    def extract(self, value: Grid) -> tuple[Grid, ...]:
        a = grid(value)
        panel_h, panel_w = self.panel_shape(a)
        separator_colours = []
        if self.row_separator:
            for index in range(1, self.rows):
                start = index * panel_h + (index - 1) * self.row_separator
                band = [
                    cell
                    for row in a[start : start + self.row_separator]
                    for cell in row
                ]
                if not band or len(set(band)) != 1:
                    raise Inapplicable("row separator is not uniform")
                separator_colours.append(band[0])
        if self.col_separator:
            for index in range(1, self.cols):
                start = index * panel_w + (index - 1) * self.col_separator
                band = [
                    a[r][c]
                    for r in range(len(a))
                    for c in range(start, start + self.col_separator)
                ]
                if not band or len(set(band)) != 1:
                    raise Inapplicable("column separator is not uniform")
                separator_colours.append(band[0])
        if len(set(separator_colours)) > 1:
            raise Inapplicable("separator colours disagree")
        panels = []
        for pr in range(self.rows):
            r0 = pr * (panel_h + self.row_separator)
            for pc in range(self.cols):
                c0 = pc * (panel_w + self.col_separator)
                panels.append(
                    tuple(
                        tuple(a[r][c0 : c0 + panel_w])
                        for r in range(r0, r0 + panel_h)
                    )
                )
        return tuple(panels)

    def assemble(self, panels: Sequence[Grid], separator_colour: int = 0) -> Grid:
        if len(panels) != self.panel_count:
            raise Inapplicable("wrong panel count")
        panels = tuple(grid(panel) for panel in panels)
        panel_h, panel_w = _shape(panels[0])
        if any(_shape(panel) != (panel_h, panel_w) for panel in panels):
            raise Inapplicable("panel shapes disagree")
        height = self.rows * panel_h + (self.rows - 1) * self.row_separator
        width = self.cols * panel_w + (self.cols - 1) * self.col_separator
        output = [[separator_colour for _ in range(width)] for _ in range(height)]
        for pr in range(self.rows):
            r0 = pr * (panel_h + self.row_separator)
            for pc in range(self.cols):
                c0 = pc * (panel_w + self.col_separator)
                panel = panels[pr * self.cols + pc]
                for r in range(panel_h):
                    output[r0 + r][c0 : c0 + panel_w] = list(panel[r])
        return tuple(tuple(row) for row in output)


def _candidate_layouts(pairs: Sequence[tuple[Grid, Grid]]) -> tuple[PanelLayout, ...]:
    common = None
    for source, target in pairs:
        source_h, source_w = _shape(source)
        target_h, target_w = _shape(target)
        candidates = set()
        for rows in range(1, 6):
            for cols in range(1, 6):
                if rows * cols < 2 or rows * cols > 9:
                    continue
                for raw_row_sep in range(4):
                    for raw_col_sep in range(4):
                        row_sep = 0 if rows == 1 else raw_row_sep
                        col_sep = 0 if cols == 1 else raw_col_sep
                        if rows * target_h + (rows - 1) * row_sep != source_h:
                            continue
                        if cols * target_w + (cols - 1) * col_sep != source_w:
                            continue
                        layout = PanelLayout(rows, cols, row_sep, col_sep)
                        try:
                            layout.extract(source)
                        except Inapplicable:
                            continue
                        candidates.add(layout)
        common = candidates if common is None else common & candidates
        if not common:
            return ()
    return tuple(sorted(common or (), key=lambda layout: layout.key))


def _separator_colour(value: Grid, layout: PanelLayout, fallback: int) -> int:
    a = grid(value)
    panel_h, panel_w = layout.panel_shape(a)
    colours = []
    if layout.row_separator:
        for index in range(1, layout.rows):
            start = index * panel_h + (index - 1) * layout.row_separator
            colours.append(a[start][0])
    if layout.col_separator:
        for index in range(1, layout.cols):
            start = index * panel_w + (index - 1) * layout.col_separator
            colours.append(a[0][start])
    return colours[0] if colours and len(set(colours)) == 1 else fallback


def _named_predicates(panel_count: int):
    raw = {
        "any": lambda count: count >= 1,
        "all": lambda count: count == panel_count,
        "none": lambda count: count == 0,
        "parity": lambda count: count % 2 == 1,
    }
    for threshold in range(panel_count + 1):
        raw[f"exactly_{threshold}"] = lambda count, threshold=threshold: count == threshold
    for threshold in range(1, panel_count + 1):
        raw[f"at_least_{threshold}"] = lambda count, threshold=threshold: count >= threshold
    result = {}
    seen = set()
    for name, predicate in raw.items():
        truth = tuple(bool(predicate(value)) for value in range(panel_count + 1))
        if truth in seen:
            continue
        seen.add(truth)
        result[name] = predicate
    return result


def _rotate_90(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(row) for row in zip(*reversed(a)))


def _d4_symmetry_count(value: Grid) -> int:
    """Return the number of D4 actions that leave a square panel unchanged.

    Using the complete group is essential: a truncated transform list can make
    the score change after a quarter-turn, which would turn a structural role
    into a coordinate-dependent artefact.
    """
    a = grid(value)
    if len(a) != len(a[0]):
        transforms = (
            a,
            tuple(tuple(reversed(row)) for row in a),
            tuple(reversed(a)),
            tuple(tuple(reversed(row)) for row in reversed(a)),
        )
    else:
        r90 = _rotate_90(a)
        r180 = _rotate_90(r90)
        r270 = _rotate_90(r180)
        flip_lr = tuple(tuple(reversed(row)) for row in a)
        flip_ud = tuple(reversed(a))
        transpose = tuple(
            tuple(a[r][c] for r in range(len(a))) for c in range(len(a[0]))
        )
        anti_transpose = _rotate_90(_rotate_90(transpose))
        transforms = (a, r90, r180, r270, flip_lr, flip_ud, transpose, anti_transpose)
    return sum(candidate == a for candidate in transforms)


# ---------------------------------------------------------------------------
# Schema I: aligned panel masks -> named Boolean relation -> two-colour output
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BooleanPanelRelationProgram:
    layout: PanelLayout
    predicate: str
    background: int
    foreground: int
    kind: str = "boolean_panel_relation"

    @property
    def schema_key(self):
        return (
            self.kind,
            *self.layout.key,
            self.predicate,
            self.background,
            self.foreground,
        )

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.layout.panel_count, self.predicate)

    def predict(self, value: Grid) -> Grid:
        panels = self.layout.extract(value)
        if any(self.background not in _palette(panel) for panel in panels):
            raise Inapplicable("background is not witnessed in every panel")
        predicate = _named_predicates(len(panels)).get(self.predicate)
        if predicate is None:
            raise Inapplicable("unknown Boolean predicate")
        height, width = _shape(panels[0])
        output = []
        for r in range(height):
            row = []
            for c in range(width):
                count = sum(panel[r][c] != self.background for panel in panels)
                row.append(self.foreground if predicate(count) else self.background)
            output.append(tuple(row))
        return tuple(output)

    def describe(self, pairs):
        masks = []
        for source, _ in pairs:
            panels = self.layout.extract(source)
            masks.append(
                [sum(cell != self.background for row in panel for cell in row) for panel in panels]
            )
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "layout": self.layout.to_dict(),
                "predicate": self.predicate,
                "background": self.background,
                "foreground": self.foreground,
            },
            "definitions": [
                {"name": "AlignedPanels", "type": "Grid -> PanelSet"},
                {"name": "ForegroundCount", "type": "PanelSet x Cell -> Integer"},
                {"name": "NamedPredicate", "type": "Integer -> Boolean"},
                {"name": "TwoColourEmitter", "type": "Mask -> Grid"},
            ],
            "axioms": [
                "panel geometry is shared by every demonstration",
                "the relation depends on foreground presence, not foreground identity",
                "the named predicate is constant across demonstrations",
                "test targets and task IDs are excluded from inference",
            ],
            "propositions": [
                {"definition": "decompose_aligned_panels", "parameters": self.layout.to_dict()},
                {"definition": "count_foreground_presence", "parameters": {"background": self.background}},
                {"definition": "apply_named_boolean_relation", "parameters": {"predicate": self.predicate}},
                {"definition": "emit_two_colour_grid", "parameters": {"foreground": self.foreground}},
            ],
            "corollary": "panel_decomposition -> Boolean_relation -> canonical_output",
            "adequacy": {
                "proof_carrying": True,
                "shared_relation_primitive": "ForegroundCountPredicate",
                "demonstrations": len(pairs),
                "panel_activity_varies": len({_serial(row) for row in masks}) >= 2,
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Schema II: repeated alternatives -> structural distinction -> selected panel
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StructuralPanelSelectionProgram:
    layout: PanelLayout
    kind: str = "structural_panel_selection"

    @property
    def schema_key(self):
        return (self.kind, *self.layout.key, "minimum_d4_symmetry")

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.layout.panel_count,)

    def analyse(self, value: Grid):
        panels = self.layout.extract(value)
        scores = tuple(_d4_symmetry_count(panel) for panel in panels)
        target = min(scores)
        winners = tuple(index for index, score in enumerate(scores) if score == target)
        if len(winners) != 1:
            raise Inapplicable("minimum-symmetry role is not unique")
        return {"panels": panels, "scores": scores, "selected": winners[0]}

    def predict(self, value: Grid) -> Grid:
        analysis = self.analyse(value)
        return analysis["panels"][analysis["selected"]]

    def describe(self, pairs):
        analyses = [self.analyse(source) for source, _ in pairs]
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "layout": self.layout.to_dict(),
                "metric": "d4_symmetry_count",
                "extremum": "minimum",
            },
            "definitions": [
                {"name": "PanelAlternative", "type": "Grid"},
                {"name": "D4SymmetryCount", "type": "Grid -> Integer"},
                {"name": "UniqueStructuralRole", "type": "PanelSet -> Panel"},
            ],
            "axioms": [
                "the selected role is the unique minimum of a structural metric",
                "panel position and colour identities are particulars, not the law",
                "ties are rejected",
                "test targets and task IDs are excluded from inference",
            ],
            "propositions": [
                {"definition": "decompose_panel_alternatives", "parameters": self.layout.to_dict()},
                {"definition": "measure_d4_symmetry", "parameters": {}},
                {"definition": "select_unique_minimum", "parameters": {}},
            ],
            "corollary": "structural_distinction -> bind_role -> emit_selected_panel",
            "adequacy": {
                "proof_carrying": True,
                "selected_positions": [row["selected"] for row in analyses],
                "selected_positions_vary": len({row["selected"] for row in analyses}) >= 2,
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Schema III: aligned panels -> uniquely witnessed priority -> visible overlay
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OrderedPanelOverlayProgram:
    layout: PanelLayout
    order: tuple[int, ...]
    background: int
    kind: str = "ordered_panel_overlay"

    @property
    def schema_key(self):
        return (self.kind, *self.layout.key, self.order, self.background)

    @property
    def description_length(self):
        return 4 + len(self.order)

    @property
    def permissiveness_cost(self):
        return (len(self.order), self.order)

    def predict(self, value: Grid) -> Grid:
        panels = self.layout.extract(value)
        if len(panels) != len(self.order):
            raise Inapplicable("priority order and panel count disagree")
        height, width = _shape(panels[0])
        output = []
        for r in range(height):
            row = []
            for c in range(width):
                colour = self.background
                for index in self.order:
                    if panels[index][r][c] != self.background:
                        colour = panels[index][r][c]
                        break
                row.append(colour)
            output.append(tuple(row))
        return tuple(output)

    def describe(self, pairs):
        conflict_counts = []
        for source, _ in pairs:
            panels = self.layout.extract(source)
            conflicts = 0
            for r in range(len(panels[0])):
                for c in range(len(panels[0][0])):
                    colours = {
                        panel[r][c]
                        for panel in panels
                        if panel[r][c] != self.background
                    }
                    conflicts += len(colours) >= 2
            conflict_counts.append(conflicts)
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "layout": self.layout.to_dict(),
                "order": list(self.order),
                "background": self.background,
            },
            "definitions": [
                {"name": "AlignedPanels", "type": "Grid -> OrderedPanelSet"},
                {"name": "VisibilityPriority", "type": "OrderedPanelSet -> TotalOrder"},
                {"name": "FirstVisibleEmitter", "type": "OrderedPanelSet x Cell -> Colour"},
            ],
            "axioms": [
                "one total order is uniquely witnessed by training conflicts",
                "background is transparent",
                "the first visible value in the order is emitted",
                "test targets and task IDs are excluded from inference",
            ],
            "propositions": [
                {"definition": "decompose_aligned_panels", "parameters": self.layout.to_dict()},
                {"definition": "infer_unique_visibility_order", "parameters": {"order": list(self.order)}},
                {"definition": "emit_first_visible_colour", "parameters": {"background": self.background}},
            ],
            "corollary": "aligned_evidence -> priority_relation -> composed_overlay",
            "adequacy": {
                "proof_carrying": True,
                "conflict_counts": conflict_counts,
                "every_demonstration_has_conflict": all(count > 0 for count in conflict_counts),
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Fitting and consensus
# ---------------------------------------------------------------------------


def _fit_boolean(pairs, layout):
    programs = []
    panel_count = layout.panel_count
    predicates = _named_predicates(panel_count)
    palettes = []
    for source, target in pairs:
        panels = layout.extract(source)
        target_palette = _palette(target)
        if len(target_palette) != 2:
            return []
        common = set.intersection(*(_palette(panel) for panel in panels), target_palette)
        palettes.append((panels, target, common))
    for background in sorted(set.intersection(*(row[2] for row in palettes))):
        foregrounds = []
        valid = True
        for _, target, _ in palettes:
            remaining = _palette(target) - {background}
            if len(remaining) != 1:
                valid = False
                break
            foregrounds.append(next(iter(remaining)))
        if not valid or len(set(foregrounds)) != 1:
            continue
        foreground = foregrounds[0]
        for name in predicates:
            program = BooleanPanelRelationProgram(layout, name, background, foreground)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                continue
    return programs


def _fit_selection(pairs, layout):
    program = StructuralPanelSelectionProgram(layout)
    try:
        if all(program.predict(source) == target for source, target in pairs):
            return [program]
    except Inapplicable:
        pass
    return []


def _fit_overlay(pairs, layout):
    if layout.panel_count > 4:
        return []
    common_backgrounds = None
    for source, _target in pairs:
        panels = layout.extract(source)
        # A fully covered overlay need not expose the transparent colour in the
        # output.  Infer transparency from the shared panel palettes, not from
        # the emitted grid.
        candidates = set.intersection(*(_palette(panel) for panel in panels))
        common_backgrounds = (
            candidates if common_backgrounds is None else common_backgrounds & candidates
        )
    programs = []
    for background in sorted(common_backgrounds or ()):
        exact_orders = []
        for order in itertools.permutations(range(layout.panel_count)):
            program = OrderedPanelOverlayProgram(layout, tuple(order), background)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    exact_orders.append(program)
            except Inapplicable:
                continue
        # Retain every total order consistent with the witnessed conflicts.
        # Incomplete demonstrations may identify only a partial order; the
        # consensus layer accepts it only when all linear extensions predict
        # the same held and unseen outputs.
        programs.extend(exact_orders)
    return programs


def _role_varies(program, pairs):
    if isinstance(program, BooleanPanelRelationProgram):
        outputs = {_serial(target) for _, target in pairs}
        activities = []
        for source, _ in pairs:
            panels = program.layout.extract(source)
            activities.append(
                tuple(
                    sum(cell != program.background for row in panel for cell in row)
                    for panel in panels
                )
            )
        return len(outputs) >= 2 and len(set(activities)) >= 2
    if isinstance(program, StructuralPanelSelectionProgram):
        selected = [program.analyse(source)["selected"] for source, _ in pairs]
        palettes = [
            tuple(sorted(_palette(program.predict(source)))) for source, _ in pairs
        ]
        return len(set(selected)) >= 2 and len(set(palettes)) >= 2
    if isinstance(program, OrderedPanelOverlayProgram):
        outputs = {_serial(target) for _, target in pairs}
        try:
            laws = program.describe(pairs)
            conflicts = laws["adequacy"]["conflict_counts"]
        except Inapplicable:
            return False
        return len(outputs) >= 2 and all(count > 0 for count in conflicts)
    return False


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    for layout in _candidate_layouts(pairs):
        if allowed is None or "boolean_panel_relation" in allowed:
            programs.extend(_fit_boolean(pairs, layout))
        if allowed is None or "structural_panel_selection" in allowed:
            programs.extend(_fit_selection(pairs, layout))
        if allowed is None or "ordered_panel_overlay" in allowed:
            programs.extend(_fit_overlay(pairs, layout))
    return programs


def fit_analogy_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 4,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (
            program.description_length,
            program.permissiveness_cost,
            repr(program.schema_key),
        ),
    )


def infer_analogy(
    task,
    *,
    minimum_pairs: int = 4,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_analogy_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        predictions = []
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "analogy_schemas": sorted({program.kind for program in programs}),
            "shared_panel_grammar": True,
            "proof_carrying": True,
            "analogy_proposition_composition": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery, counterfactuals and LODO validation
# ---------------------------------------------------------------------------


def _layout_from_parameters(parameters):
    raw = parameters["layout"]
    return PanelLayout(
        int(raw["rows"]),
        int(raw["cols"]),
        int(raw.get("row_separator", 0)),
        int(raw.get("col_separator", 0)),
    )


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    layout = _layout_from_parameters(parameters)
    if kind == "boolean_panel_relation":
        return BooleanPanelRelationProgram(
            layout,
            str(parameters["predicate"]),
            int(parameters["background"]),
            int(parameters["foreground"]),
        )
    if kind == "structural_panel_selection":
        return StructuralPanelSelectionProgram(layout)
    if kind == "ordered_panel_overlay":
        return OrderedPanelOverlayProgram(
            layout,
            tuple(int(value) for value in parameters["order"]),
            int(parameters["background"]),
        )
    raise Inapplicable("unknown analogy schema")


def _first_nonbackground(panel, background):
    for row in panel:
        for cell in row:
            if cell != background:
                return cell
    raise Inapplicable("panel has no foreground witness")


def _boolean_counterfactuals(program, pairs):
    rows = []
    predicate = _named_predicates(program.layout.panel_count)[program.predicate]
    for index, (source, _) in enumerate(pairs):
        panels = list(program.layout.extract(source))
        original = program.predict(source)
        separator = _separator_colour(source, program.layout, program.background)

        reversed_grid = program.layout.assemble(tuple(reversed(panels)), separator)
        permutation_invariant = program.predict(reversed_grid) == original

        palette = _palette(source) | {program.foreground, program.background}
        available = [colour for colour in range(10) if colour not in palette]
        recoloured = []
        for panel_index, panel in enumerate(panels):
            replacement = available[panel_index % len(available)] if available else (program.foreground + panel_index + 1) % 10
            recoloured.append(
                tuple(
                    tuple(program.background if cell == program.background else replacement for cell in row)
                    for row in panel
                )
            )
        recoloured_grid = program.layout.assemble(recoloured, separator)
        recolour_invariant = program.predict(recoloured_grid) == original

        toggle_changes = False
        mutable = [[list(row) for row in panel] for panel in panels]
        height, width = _shape(panels[0])
        for r in range(height):
            if toggle_changes:
                break
            for c in range(width):
                count = sum(panel[r][c] != program.background for panel in panels)
                for panel_index, panel in enumerate(panels):
                    present = panel[r][c] != program.background
                    next_count = count - 1 if present else count + 1
                    if bool(predicate(count)) == bool(predicate(next_count)):
                        continue
                    changed = [[list(row) for row in item] for item in panels]
                    changed[panel_index][r][c] = (
                        program.background
                        if present
                        else _first_nonbackground(panel, program.background)
                    )
                    changed_grid = program.layout.assemble(
                        [tuple(tuple(row) for row in item) for item in changed], separator
                    )
                    changed_prediction = program.predict(changed_grid)
                    toggle_changes = changed_prediction[r][c] != original[r][c]
                    if toggle_changes:
                        break
                if toggle_changes:
                    break
        rows.append(
            {
                "demonstration": index,
                "panel_permutation_invariant": permutation_invariant,
                "foreground_recolour_invariant": recolour_invariant,
                "causal_presence_toggle_changes_effect": toggle_changes,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["panel_permutation_invariant"]
            and row["foreground_recolour_invariant"]
            and row["causal_presence_toggle_changes_effect"]
            for row in rows
        ),
    }


def _selection_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        analysis = program.analyse(source)
        panels = list(analysis["panels"])
        separator = _separator_colour(source, program.layout, _unique_modal(source))
        selected = analysis["selected"]
        original = program.predict(source)

        reversed_grid = program.layout.assemble(tuple(reversed(panels)), separator)
        position_invariant = program.predict(reversed_grid) == original

        rotated_panels = tuple(_rotate_90(panel) for panel in panels)
        rotated_grid = program.layout.assemble(rotated_panels, separator)
        rotation_equivariant = program.predict(rotated_grid) == _rotate_90(original)

        duplicate = list(panels)
        duplicate[(selected + 1) % len(duplicate)] = panels[selected]
        duplicate_grid = program.layout.assemble(duplicate, separator)
        try:
            program.predict(duplicate_grid)
            tie_rejected = False
        except Inapplicable:
            tie_rejected = True
        rows.append(
            {
                "demonstration": index,
                "panel_position_invariant": position_invariant,
                "rotation_equivariant": rotation_equivariant,
                "duplicated_minimum_tie_rejected": tie_rejected,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["panel_position_invariant"]
            and row["rotation_equivariant"]
            and row["duplicated_minimum_tie_rejected"]
            for row in rows
        ),
    }


def _overlay_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        panels = list(program.layout.extract(source))
        separator = _separator_colour(source, program.layout, program.background)
        original = program.predict(source)
        witness = None
        height, width = _shape(panels[0])
        for r in range(height):
            for c in range(width):
                visible = [
                    panel_index
                    for panel_index in program.order
                    if panels[panel_index][r][c] != program.background
                ]
                colours = {panels[item][r][c] for item in visible}
                if len(visible) >= 2 and len(colours) >= 2:
                    witness = (r, c, visible)
                    break
            if witness is not None:
                break
        if witness is None:
            rows.append({"demonstration": index, "passed": False, "reason": "no_priority_conflict"})
            continue
        r, c, visible = witness
        winner = visible[0]
        runner = visible[1]

        removed = [[list(row) for row in panel] for panel in panels]
        removed[winner][r][c] = program.background
        removed_grid = program.layout.assemble(
            [tuple(tuple(row) for row in panel) for panel in removed], separator
        )
        removed_prediction = program.predict(removed_grid)
        falls_through = removed_prediction[r][c] == panels[runner][r][c]

        palette = _palette(source)
        fresh = next((colour for colour in range(10) if colour not in palette), None)
        recolour_follows = False
        if fresh is not None:
            recoloured = [[list(row) for row in panel] for panel in panels]
            recoloured[winner][r][c] = fresh
            recoloured_grid = program.layout.assemble(
                [tuple(tuple(row) for row in panel) for panel in recoloured], separator
            )
            recolour_follows = program.predict(recoloured_grid)[r][c] == fresh

        swapped = list(panels)
        swapped[winner], swapped[runner] = swapped[runner], swapped[winner]
        swapped_grid = program.layout.assemble(swapped, separator)
        position_priority_changes_effect = program.predict(swapped_grid)[r][c] != original[r][c]
        rows.append(
            {
                "demonstration": index,
                "removing_winner_exposes_runner": falls_through,
                "winner_recolour_propagates": recolour_follows,
                "swapping_priority_roles_changes_effect": position_priority_changes_effect,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row.get("removing_winner_exposes_runner")
            and row.get("winner_recolour_propagates")
            and row.get("swapping_priority_roles_changes_effect")
            for row in rows
        ),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, BooleanPanelRelationProgram):
        return _boolean_counterfactuals(program, pairs)
    if isinstance(program, StructuralPanelSelectionProgram):
        return _selection_counterfactuals(program, pairs)
    if isinstance(program, OrderedPanelOverlayProgram):
        return _overlay_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_analogy(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 4:
        return {"passed": False, "reason": "requires_four_demonstrations", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_analogy(
            fold,
            minimum_pairs=3,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append(
            {
                "held_index": held,
                "status": result["status"],
                "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
                "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
                "joint_hypotheses": result["joint_hypotheses"],
            }
        )

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": (
            "passed"
            if passed
            else "leave_one_demonstration_out_failure"
            if not folds_passed
            else "causal_counterfactual_failure"
        ),
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def analogy_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_analogy_programs(pairs)}))


# Engine-compatible aliases.
infer = infer_analogy
validate = validate_analogy
