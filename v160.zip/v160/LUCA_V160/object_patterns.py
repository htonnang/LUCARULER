"""V43 reusable family induction, without task IDs or hardcoded ARC examples.
Distinct programs fitting demos but disagreeing on tests -> abstain.
"""
from dataclasses import dataclass
from collections import deque
from itertools import product
from geometry import grid

@dataclass(frozen=True)
class PatternLaw:
    mode: str
    axis: str
    background: int
    period: int=0
    def predict(self,raw):
        a=grid(raw); h=len(a);w=len(a[0]); out=[list(r) for r in a]
        if self.mode=='mirror_fill':
            for r in range(h):
                for c in range(w):
                    if a[r][c]!=self.background:continue
                    rr,cc=(h-1-r,c) if self.axis=='vertical' else (r,w-1-c)
                    v=a[rr][cc]
                    if v!=self.background:out[r][c]=v
        elif self.mode=='period_fill':
            for r in range(h):
                for c in range(w):
                    if a[r][c]!=self.background:continue
                    matches=[a[i][j] for i in range(h) for j in range(w) if (i%self.period==r%self.period if self.axis=='vertical' else j%self.period==c%self.period) and a[i][j]!=self.background and (j==c if self.axis=='vertical' else i==r)]
                    if matches and len(set(matches))==1:out[r][c]=matches[0]
        return grid(out)

@dataclass(frozen=True)
class ObjectLaw:
    selection:str
    connectivity:int
    background:int
    output_mode:str='crop'
    def predict(self,raw):
        a=grid(raw);h=len(a);w=len(a[0]);seen=set();objects=[]
        dirs=((-1,0),(1,0),(0,-1),(0,1)) + (((-1,-1),(-1,1),(1,-1),(1,1)) if self.connectivity==8 else ())
        for r in range(h):
            for c in range(w):
                if (r,c) in seen or a[r][c]==self.background:continue
                q=deque([(r,c)]);seen.add((r,c));cells=[]
                while q:
                    x,y=q.popleft();cells.append((x,y))
                    for dr,dc in dirs:
                        nx,ny=x+dr,y+dc
                        if 0<=nx<h and 0<=ny<w and (nx,ny) not in seen and a[nx][ny]!=self.background:
                            seen.add((nx,ny));q.append((nx,ny))
                objects.append(cells)
        if not objects:return a
        scores=[len(obj) for obj in objects]
        target=max(scores) if self.selection=='largest' else min(scores)
        matches=[obj for obj,s in zip(objects,scores) if s==target]
        if len(matches)!=1:return a # Tie means no uniquely selected object.
        obj=matches[0]; r0=min(r for r,c in obj);r1=max(r for r,c in obj);c0=min(c for r,c in obj);c1=max(c for r,c in obj)
        if self.output_mode=='crop':
            return grid([[a[r][c] if (r,c) in obj else self.background for c in range(c0,c1+1)] for r in range(r0,r1+1)])
        return grid([[a[r][c] if (r,c) in obj else self.background for c in range(w)] for r in range(h)])

def candidate_laws():
    for bg in range(10):
        for axis in ('vertical','horizontal'):
            yield PatternLaw('mirror_fill',axis,bg)
            for period in (2,3,4,5,6):yield PatternLaw('period_fill',axis,bg,period)
        for selection,conn,mode in product(('largest','smallest'),(4,8),('crop','mask')):
            yield ObjectLaw(selection,conn,bg,mode)


