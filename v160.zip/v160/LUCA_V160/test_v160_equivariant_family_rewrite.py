from __future__ import annotations

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import pytest

import engine
import equivariant_family_rewrite_reasoning as rewrite

HERE = Path(__file__).resolve().parent
META = json.loads((HERE / "example_v160_metadata.json").read_text())
META_BY_ID = {row["task_id"]: row for row in META["examples"]}

FAMILY_API = {
    "anchor": (
        rewrite.infer_equivariant_anchor_transport_rewrite,
        rewrite.validate_equivariant_anchor_transport_rewrite,
        "--equivariant-anchor-transport-only",
    ),
    "transport": (
        rewrite.infer_equivariant_transport_rewrite,
        rewrite.validate_equivariant_transport_rewrite,
        "--equivariant-transport-only",
    ),
    "ordered_phase": (
        rewrite.infer_equivariant_ordered_phase_rewrite,
        rewrite.validate_equivariant_ordered_phase_rewrite,
        "--equivariant-ordered-phase-only",
    ),
    "reference_transfer": (
        rewrite.infer_equivariant_reference_transfer_rewrite,
        rewrite.validate_equivariant_reference_transfer_rewrite,
        "--equivariant-reference-transfer-only",
    ),
}

NEW_TRANSFER_IDS = ("dc433765", "4364c1c4", "b457fec5", "e681b708")


def load_task(task_id: str) -> dict:
    return json.loads((HERE / f"example_v160_{task_id}_task.json").read_text())


def prediction_tuple(result: dict) -> list[list[list[int]]]:
    assert result["status"] == "unique"
    return [test["prediction"] for test in result["tests"]]


def prediction_hash(result: dict) -> str:
    return hashlib.sha256(
        json.dumps(
            prediction_tuple(result),
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()


def rotate_grid(value: list[list[int]], turns: int) -> list[list[int]]:
    output = [row[:] for row in value]
    for _ in range(turns % 4):
        output = [list(row) for row in zip(*output[::-1])]
    return output


def recolour_grid(value: list[list[int]]) -> list[list[int]]:
    mapping = {colour: 9 - colour for row in value for colour in row}
    return [[mapping[colour] for colour in row] for row in value]


def transform_task(task: dict, turns: int, recolour: bool) -> dict:
    def transform(value):
        output = rotate_grid(value, turns)
        return recolour_grid(output) if recolour else output

    return {
        "train": [
            {
                "input": transform(demo["input"]),
                "output": transform(demo["output"]),
            }
            for demo in task["train"]
        ],
        "test": [{"input": transform(case["input"])} for case in task["test"]],
    }


def transform_prediction(prediction, turns: int, recolour: bool):
    output = [rotate_grid(grid, turns) for grid in prediction]
    return [recolour_grid(grid) for grid in output] if recolour else output


@pytest.mark.parametrize("record", META["examples"], ids=lambda row: row["task_id"])
def test_rewrite_preserves_or_adds_exact_coverage(record):
    infer, validate, _ = FAMILY_API[record["rewrite_family"]]
    task = load_task(record["task_id"])
    result = infer(task)
    check = validate(task, result)
    assert result["status"] == "unique"
    assert check["passed"] is True
    assert prediction_hash(result) == record["prediction_hash"]


@pytest.mark.parametrize("task_id", NEW_TRANSFER_IDS)
@pytest.mark.parametrize("turns", range(4))
def test_new_transfer_is_rotation_equivariant(task_id, turns):
    record = META_BY_ID[task_id]
    infer, validate, _ = FAMILY_API[record["rewrite_family"]]
    original = load_task(task_id)
    base_result = infer(original)
    assert validate(original, base_result)["passed"] is True
    transformed = transform_task(original, turns, False)
    transformed_result = infer(transformed)
    transformed_check = validate(transformed, transformed_result)
    assert transformed_check["passed"] is True
    assert prediction_tuple(transformed_result) == transform_prediction(
        prediction_tuple(base_result), turns, False
    )


@pytest.mark.parametrize("task_id", NEW_TRANSFER_IDS)
def test_new_transfer_is_colour_equivariant(task_id):
    record = META_BY_ID[task_id]
    infer, validate, _ = FAMILY_API[record["rewrite_family"]]
    original = load_task(task_id)
    base_result = infer(original)
    assert validate(original, base_result)["passed"] is True
    transformed = transform_task(original, 0, True)
    transformed_result = infer(transformed)
    transformed_check = validate(transformed, transformed_result)
    assert transformed_check["passed"] is True
    assert prediction_tuple(transformed_result) == transform_prediction(
        prediction_tuple(base_result), 0, True
    )


def test_every_rewrite_adds_a_real_training_transfer():
    by_family = {}
    for row in META["examples"]:
        by_family.setdefault(row["rewrite_family"], []).append(row)
    assert set(by_family) == set(FAMILY_API)
    for rows in by_family.values():
        assert sum(row["role"] == "retained_predecessor" for row in rows) == 3
        assert sum(row["role"] == "new_transfer" for row in rows) == 1
    assert META["rewritten_union_exact"] == 16
    assert META["original_union_exact"] == 12
    assert META["new_transfer_gains"] == 4


def test_active_registry_contains_four_rewrites_without_changing_stable_registry():
    assert len(engine.FAMILIES) == 31
    assert len(engine.RESEARCH_FAMILIES) == 56
    assert len(engine.ACTIVE_FAMILIES) == 87
    names = {family.name for family in engine.ACTIVE_FAMILIES}
    assert {
        rewrite.ANCHOR_FAMILY,
        rewrite.TRANSPORT_FAMILY,
        rewrite.PHASE_FAMILY,
        rewrite.REFERENCE_FAMILY,
    } <= names


def test_source_is_task_id_blind():
    source = (HERE / "equivariant_family_rewrite_reasoning.py").read_text()
    for row in META["examples"]:
        assert row["task_id"] not in source


def test_rejected_ordered_legend_candidate_is_not_active():
    source = (HERE / "equivariant_family_rewrite_reasoning.py").read_text()
    active_line = "candidates = [PartitionMarkerMajorityTransferProgram()]"
    assert active_line in source


@pytest.mark.parametrize("task_id", NEW_TRANSFER_IDS)
def test_dedicated_cli_matches_frozen_prediction(task_id, tmp_path):
    record = META_BY_ID[task_id]
    _, _, flag = FAMILY_API[record["rewrite_family"]]
    output = tmp_path / f"{task_id}.json"
    completed = subprocess.run(
        [
            sys.executable,
            str(HERE / "run.py"),
            str(HERE / f"example_v160_{task_id}_task.json"),
            flag,
            "--output",
            str(output),
        ],
        cwd=HERE,
        check=False,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    result = json.loads(output.read_text())
    assert result["status"] == "unique"
    assert hashlib.sha256(
        json.dumps(
            [test["prediction"] for test in result["tests"]],
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest() == record["prediction_hash"]


def test_negative_controls_abstain():
    # One-step anchor move is impossible when the two points are adjacent.
    anchor_pairs = (
        (((0, 0, 0, 1, 2, 0, 0),), ((0, 0, 0, 1, 2, 0, 0),)),
        (((0, 0, 0, 1, 2, 0, 0),), ((0, 0, 0, 1, 2, 0, 0),)),
    )
    assert rewrite.fit_equivariant_anchor_custom(anchor_pairs) == ()

    # An odd number of payload components cannot form complete adjacent pairs.
    transport_source = ((0, 1, 0, 2, 0, 3, 0),)
    transport_pairs = ((transport_source, transport_source),) * 2
    assert rewrite.fit_equivariant_transport_custom(transport_pairs) == ()

    # No singleton palette line means no diagonal palette propagation.
    phase_source = ((0, 5, 5), (0, 5, 5), (0, 0, 0))
    phase_pairs = ((phase_source, phase_source),) * 2
    assert rewrite.fit_equivariant_phase_custom(phase_pairs) == ()

    # No partition markers means no partition ownership programme.
    reference_source = ((0, 0, 3, 0, 0), (0, 0, 3, 0, 0), (3, 3, 3, 3, 3), (0, 0, 3, 0, 0), (0, 0, 3, 0, 0))
    reference_pairs = ((reference_source, reference_source),) * 2
    assert rewrite.fit_equivariant_reference_custom(reference_pairs) == ()
