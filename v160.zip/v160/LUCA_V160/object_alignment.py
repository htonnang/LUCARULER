"""Align input-derived objects to a stationary reference coordinate.

The same selector, anchor arithmetic and transactional renderer serve every task.
No demonstration output patches or absolute coordinates are stored. This is rigid
endpoint placement, not a simulation or proof of a collision-free movement path.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass, replace
from itertools import product

from attributes import perceive
from attribute_selection import Selector, selector_candidates
from correspondence import Grid, grid
from runtime import public_task, joint_result

FAMILY = 'object_alignment'
ANCHORS = ('low', 'center', 'high')


def anchor2(box, axis: int, anchor: str) -> int:
    """Twice the anchor coordinate: exact integers, including half-cell centres."""
    lo, hi = box[axis], box[axis+2]
    if anchor == 'low': return 2*lo
    if anchor == 'high': return 2*hi
    if anchor == 'center': return lo+hi
    raise ValueError('unknown anchor')


@dataclass(frozen=True)
class Reference:
    selector: Selector | None = None
    colour: int | str | None = None

    def indices(self, a, scene):
        if self.selector is not None:
            return self.selector.indices(scene[2])
        bg, objects, _ = scene
        counts = Counter(v for row in a for v in row if v != bg)
        if self.colour in ('rarest','commonest'):
            if not counts: return ()
            goal = min(counts.values()) if self.colour == 'rarest' else max(counts.values())
            choices = [c for c,n in counts.items() if n == goal]
            if len(choices) != 1: return ()
            colour = choices[0]
        else:
            colour = self.colour
            if type(colour) is not int or colour not in counts: return ()
        # A colour role binds entire monochrome components, not fragments of a
        # multicolour body. There is no implicit erasure/resegmentation by role.
        return tuple(i for i,o in enumerate(objects) if all(a[r][c] == colour for r,c in o.cells))

    def describe(self):
        return {'kind':'attribute','selector':self.selector.describe()} if self.selector is not None else {'kind':'colour_role','colour_rule':self.colour}


def render_alignment(a: Grid, scene, references, axis: int, source_anchor: str, reference_anchor: str):
    """Transactionally construct all endpoint placements; return trace or None."""
    if axis not in (0,1): raise ValueError('axis must be 0 or 1')
    bg,objects,features = scene
    refs = set(references)
    if not refs or len(refs) == len(objects): return None
    if any(type(i) is not int or i<0 or i>=len(objects) for i in refs): raise ValueError('invalid reference index')
    anchors = {anchor2(objects[i].box,axis,reference_anchor) for i in refs}
    if len(anchors) != 1: return None
    target = next(iter(anchors))
    h,w=len(a),len(a[0]);writes={};details=[];moved=False
    for i,obj in enumerate(objects):
        delta2 = 0 if i in refs else target-anchor2(obj.box,axis,source_anchor)
        if delta2 % 2: return None
        shift = delta2//2
        dr,dc=(shift,0) if axis==0 else (0,shift)
        dest=[]
        for r,c in obj.cells:
            p=(r+dr,c+dc)
            if not (0<=p[0]<h and 0<=p[1]<w) or p in writes:
                # Reject even same-colour overlap: foreground count is conserved.
                return None
            writes[p]=a[r][c];dest.append([p[0],p[1],a[r][c]])
        moved |= i not in refs and len(obj.cells)>1 and shift != 0
        details.append({'index':i,'reference':i in refs,'box':list(obj.box),
            'displacement':[dr,dc], 'source_cells':[[r,c,a[r][c]] for r,c in obj.cells],
            'destination_cells':dest})
    out=[[bg]*w for _ in range(h)]
    for (r,c),v in writes.items():out[r][c]=v
    return grid(out),moved,{'background':bg,'reference_anchor_twice':target,
        'reference_indices':sorted(refs),'objects':details}


@dataclass(frozen=True)
class AlignmentProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    reference: Reference
    axis: int
    source_anchor: str
    reference_anchor: str

    def describe(self):
        return {'family':FAMILY,'background_rule':self.background_rule,
            'connectivity':self.connectivity,'monochrome':self.monochrome,
            'reference':self.reference.describe(),'axis':'row' if self.axis==0 else 'column',
            'source_anchor':self.source_anchor,'reference_anchor':self.reference_anchor,
            'construction':'simultaneous rigid endpoint alignment; no path assumption',
            'ties':'all reference matches retained; coordinate consensus required'}

    def execute(self,value):
        a=grid(value);scene=perceive(a,self.background_rule,self.connectivity,self.monochrome)
        if scene is None:return None
        refs=self.reference.indices(a,scene)
        return render_alignment(a,scene,refs,self.axis,self.source_anchor,self.reference_anchor)

    def predict(self,value):
        result=self.execute(value)
        return None if result is None else result[0]

    def trace(self,value):
        result=self.execute(value)
        return None if result is None else {'program':self.describe(),**result[2],'prediction':result[0]}


def fit(pairs) -> list[AlignmentProgram]:
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any((len(a),len(a[0]))!=(len(y),len(y[0])) or
           Counter(v for row in a for v in row)!=Counter(v for row in y for v in row)
           for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    models=[]
    for bg,conn,mono in product(('modal',*sorted(common)),(4,8),(True,False)):
        scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
        if any(s is None or len(s[1])<2 for s in scenes):continue
        refs=[Reference(selector=s) for s in selector_candidates(scenes)]
        refs += [Reference(colour=c) for c in (*sorted(common),'rarest','commonest')]
        groups=defaultdict(list)
        for ref in refs:
            selections=tuple(ref.indices(a,s) for (a,y),s in zip(pairs,scenes))
            if any(not ids or len(ids)==len(s[1]) for ids,s in zip(selections,scenes)):continue
            if any(any(a[r][c]!=y[r][c] for i in ids for r,c in s[1][i].cells)
                   for (a,y),s,ids in zip(pairs,scenes,selections)):continue
            groups[selections].append(ref)
        for refs in groups.values():
            for axis,src_anchor,ref_anchor in product((0,1),ANCHORS,ANCHORS):
                model=AlignmentProgram(bg,conn,mono,refs[0],axis,src_anchor,ref_anchor)
                moved=False;fits=True
                for a,y in pairs:
                    result=model.execute(a)
                    if result is None or result[0]!=y:
                        fits=False;break
                    moved |= result[1]
                if fits and moved:
                    # Preserve semantically different selectors sharing training
                    # behavior: they may disagree on the ordinary test inputs.
                    models.extend(replace(model,reference=ref) for ref in refs)
    return models


def infer(task: dict) -> dict:
    clean=public_task(task)
    models=fit((d['input'],d['output']) for d in clean['train'])
    groups,invalid={},0
    for program in models:
        predictions=tuple(program.predict(t['input']) for t in clean['test'])
        if any(p is None for p in predictions):invalid+=1;continue
        groups.setdefault(predictions,[]).append(program.describe())
    result=joint_result(groups,len(clean['test']))
    result.update(joint_hypotheses_is_exact=True,
        witness_predictions=[[[list(row) for row in g] for g in key] for key in groups],
        stats={'fitted_programs':len(models),'inapplicable_programs':invalid,
               'all_complete_joint_alternatives_retained':True})
    return result


def validate(task: dict,full: dict) -> dict:
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        result=infer(fold);predictions=[t['prediction'] for t in result['tests']]
        folds.append({'held_index':held,'status':result['status'],
            'held_example_exact':result['status']=='unique' and predictions[0]==demo['output'],
            'test_prediction_stable':result['status']=='unique' and predictions[1:]==expected,
            'joint_hypotheses':result['joint_hypotheses']})
    passed=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':passed,'reason':'passed' if passed else 'held_example_or_stability_failure','folds':folds}
