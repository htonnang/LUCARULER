"""Stable transport of pixels or full bands in a finite input-derived scene.

One compaction operator preserves order and multiplicity. Optional fixed-colour
barriers divide a lane into independent intervals. No task IDs, stored outputs,
per-task coordinates, recolouring or collision tie-breakers are used.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from itertools import product
from typing import Iterable, TypeVar
from attributes import background
from correspondence import Grid, grid
from runtime import public_task, joint_result

FAMILY = 'stable_transport'
T = TypeVar('T')


def compact(items: tuple[T, ...], empty: T, toward: str,
            is_barrier) -> tuple[T, ...]:
    """Pack each barrier-bounded interval, preserving payload order exactly."""
    if toward not in ('low', 'high'):
        raise ValueError('toward must be low or high')
    output = list(items)
    stops = [-1] + [i for i, value in enumerate(items) if is_barrier(value)] + [len(items)]
    for left, right in zip(stops, stops[1:]):
        content = [value for value in items[left + 1:right] if value != empty]
        padding = [empty] * (right - left - 1 - len(content))
        output[left + 1:right] = content + padding if toward == 'low' else padding + content
    return tuple(output)


def transpose(a: Grid) -> Grid:
    return tuple(tuple(row) for row in zip(*a))


@dataclass(frozen=True)
class TransportProgram:
    background_rule: str | int
    axis: str
    toward: str
    unit: str
    barrier_colour: int | None = None

    def describe(self) -> dict:
        return {'family': FAMILY, 'background_rule': self.background_rule,
                'axis': self.axis, 'toward': self.toward, 'unit': self.unit,
                'barrier_colour': self.barrier_colour,
                'order': 'stable; never colour-sorted',
                'conservation': 'grid shape and all colour multiplicities',
                'boundary': 'input edges or fixed-colour barriers'}

    def predict(self, value: Grid) -> Grid | None:
        a = grid(value)
        if self.axis not in ('horizontal', 'vertical') or self.unit not in ('pixels', 'bands'):
            raise ValueError('invalid axis or transport unit')
        bg = background(a, self.background_rule)
        if bg is None or bg == self.barrier_colour:
            return None
        if self.barrier_colour is not None:
            if type(self.barrier_colour) is not int or not 0 <= self.barrier_colour <= 9:
                raise ValueError('invalid barrier colour')
            if self.barrier_colour not in {v for row in a for v in row}:
                return None
        if self.unit == 'pixels':
            # Horizontal lanes are rows; vertical lanes are columns.
            lanes = a if self.axis == 'horizontal' else transpose(a)
            out = tuple(compact(row, bg, self.toward,
                                lambda value: value == self.barrier_colour) for row in lanes)
            return out if self.axis == 'horizontal' else transpose(out)
        # Whole rows move vertically; whole columns move horizontally.
        bands = a if self.axis == 'vertical' else transpose(a)
        empty = tuple(bg for _ in bands[0])
        if self.barrier_colour is not None:
            # A band barrier is an entire uniform band. A partial barrier cannot
            # silently be moved, erased or interpreted as a full-wall obstacle.
            if any(self.barrier_colour in row and
                   any(v != self.barrier_colour for v in row) for row in bands):
                return None
        out = compact(bands, empty, self.toward,
                      lambda row: self.barrier_colour is not None and
                                  all(v == self.barrier_colour for v in row))
        return out if self.axis == 'vertical' else transpose(out)

    def trace(self, value: Grid) -> dict | None:
        a = grid(value); y = self.predict(a)
        if y is None:
            return None
        return {'program': self.describe(), 'background': background(a, self.background_rule),
                'changed_cells': [[r, c, a[r][c], y[r][c]] for r in range(len(a))
                                  for c in range(len(a[0])) if a[r][c] != y[r][c]],
                'input_counts': dict(Counter(v for row in a for v in row)),
                'output_counts': dict(Counter(v for row in y for v in row)),
                'prediction': y}


def fit(pairs: Iterable[tuple[Grid, Grid]]) -> list[TransportProgram]:
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    if any((len(a), len(a[0])) != (len(y), len(y[0])) or
           Counter(v for row in a for v in row) != Counter(v for row in y for v in row)
           for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, _ in pairs))
    models = []
    for bg_rule, axis, toward, unit, barrier in product(
            ('modal', *sorted(common)), ('horizontal', 'vertical'),
            ('low', 'high'), ('pixels', 'bands'), (None, *sorted(common))):
        program = TransportProgram(bg_rule, axis, toward, unit, barrier)
        if all(program.predict(a) == y for a, y in pairs):
            models.append(program)
    return models


def infer(task: dict) -> dict:
    clean = public_task(task)
    models = fit((d['input'], d['output']) for d in clean['train'])
    groups, invalid = {}, 0
    for program in models:
        predictions = tuple(program.predict(t['input']) for t in clean['test'])
        if any(p is None for p in predictions):
            invalid += 1
            continue
        groups.setdefault(predictions, []).append(program.describe())
    result = joint_result(groups, len(clean['test']))
    result.update(joint_hypotheses_is_exact=True,
                  witness_predictions=[[[list(row) for row in g] for g in key] for key in groups],
                  stats={'fitted_programs': len(models), 'inapplicable_programs': invalid,
                         'all_complete_joint_alternatives_retained': True})
    return result


def validate(task: dict, full: dict) -> dict:
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [t['prediction'] for t in full['tests']]
    folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': demo['input']}] + clean['test']}
        result = infer(fold)
        predictions = [t['prediction'] for t in result['tests']]
        folds.append({'held_index': held, 'status': result['status'],
                      'held_example_exact': result['status'] == 'unique' and predictions[0] == demo['output'],
                      'test_prediction_stable': result['status'] == 'unique' and predictions[1:] == expected,
                      'joint_hypotheses': result['joint_hypotheses']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure',
            'folds': folds}
