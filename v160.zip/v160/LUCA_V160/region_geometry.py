"""Shared foreground-preserving region geometry; no task-specific rules.

Programs derive a region from input objects, then paint only existing background
cells. Region and paint choices must fit every demonstration. Locally conflicting
writes reject the whole program; no iteration order is a tie-breaker.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from typing import Iterable
from attributes import background, components, D4, D8
from correspondence import Grid, grid
from runtime import public_task, joint_result

FAMILY = 'region_geometry'
REGIONS = ('box', 'box_boundary', 'box_interior', 'holes', 'row_spans',
           'column_spans', 'axial_spans', 'neighbours4', 'neighbours8')
GROUPS = (('monochrome', 4), ('monochrome', 8), ('multicolour', 4),
          ('multicolour', 8), ('colour_classes', 4), ('all_selected', 4))
SOURCE_COLOUR = 'source'


def resolve_source(a: Grid, bg: int, role: str | int) -> frozenset[int] | None:
    counts = Counter(v for row in a for v in row if v != bg)
    if not counts:
        return None
    if role == 'all':
        return frozenset(counts)
    if type(role) is int:
        return frozenset((role,)) if role in counts else None
    if role not in ('rarest', 'commonest'):
        raise ValueError('unknown source role')
    n = (min if role == 'rarest' else max)(counts.values())
    choices = frozenset(v for v, count in counts.items() if count == n)
    return choices if len(choices) == 1 else None


@lru_cache(maxsize=256)
def source_groups(a: Grid, bg: int, role: str | int, grouping: str,
                  connectivity: int) -> tuple[tuple[tuple[int, int], ...], ...] | None:
    colours = resolve_source(a, bg, role)
    if colours is None:
        return None
    selected = tuple((r, c) for r, row in enumerate(a) for c, v in enumerate(row) if v in colours)
    if grouping == 'all_selected':
        return (selected,)
    if grouping == 'colour_classes':
        return tuple(tuple(p for p in selected if a[p[0]][p[1]] == v) for v in sorted(colours))
    if grouping not in ('monochrome', 'multicolour'):
        raise ValueError('unknown grouping')
    masked = tuple(tuple(v if v in colours else bg for v in row) for row in a)
    return tuple(o.cells for o in components(masked, bg, connectivity, grouping == 'monochrome'))


@lru_cache(maxsize=1024)
def region(cells: tuple[tuple[int, int], ...], kind: str, h: int, w: int) -> frozenset[tuple[int, int]]:
    """Input-derived masks on a finite canvas. Holes use 4-neighbour reachability.

    Neighbour expansion is intersected with the canvas, not a copied pattern
    with a guessed off-canvas placement. Other regions lie in the input box.
    """
    if not cells:
        return frozenset()
    if kind not in REGIONS:
        raise ValueError('unknown region')
    pts = set(cells)
    r0 = min(r for r, c in pts); r1 = max(r for r, c in pts)
    c0 = min(c for r, c in pts); c1 = max(c for r, c in pts)
    if kind in ('box', 'box_boundary', 'box_interior'):
        return frozenset((r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
                         if kind == 'box' or
                         (kind == 'box_boundary' and (r in (r0, r1) or c in (c0, c1))) or
                         (kind == 'box_interior' and r0 < r < r1 and c0 < c < c1))
    if kind == 'holes':
        empty = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)} - pts
        exterior = {p for p in empty if p[0] in (r0, r1) or p[1] in (c0, c1)}
        stack = list(exterior)
        while stack:
            r, c = stack.pop()
            for dr, dc in D4:
                p = (r + dr, c + dc)
                if p in empty and p not in exterior:
                    exterior.add(p); stack.append(p)
        return frozenset(empty - exterior)
    if kind in ('row_spans', 'column_spans', 'axial_spans'):
        result = set()
        if kind in ('row_spans', 'axial_spans'):
            rows = {}
            for r, c in pts: rows.setdefault(r, []).append(c)
            for r, cs in rows.items(): result.update((r, c) for c in range(min(cs), max(cs) + 1))
        if kind in ('column_spans', 'axial_spans'):
            cols = {}
            for r, c in pts: cols.setdefault(c, []).append(r)
            for c, rs in cols.items(): result.update((r, c) for r in range(min(rs), max(rs) + 1))
        return frozenset(result)
    dirs = D4 if kind == 'neighbours4' else D8
    return frozenset((r + dr, c + dc) for r, c in pts for dr, dc in dirs
                     if 0 <= r + dr < h and 0 <= c + dc < w) - pts


@dataclass(frozen=True)
class RegionProgram:
    background_rule: str | int
    source_role: str | int
    grouping: str
    connectivity: int
    region_kind: str
    paint: str | int

    def describe(self) -> dict:
        return {'family': FAMILY, 'background_rule': self.background_rule,
                'source_role': self.source_role, 'grouping': self.grouping,
                'connectivity': self.connectivity, 'region': self.region_kind,
                'paint': self.paint, 'foreground_preserved': True,
                'overlap_policy': 'reject unequal writes', 'canvas_policy': 'finite domain'}

    def predict(self, value: Grid) -> Grid | None:
        a = grid(value)
        bg = background(a, self.background_rule)
        if bg is None:
            return None
        groups = source_groups(a, bg, self.source_role, self.grouping, self.connectivity)
        if not groups:
            return None
        writes = {}
        for cells in groups:
            if self.paint == SOURCE_COLOUR:
                palette = {a[r][c] for r, c in cells}
                if len(palette) != 1:
                    return None
                colour = next(iter(palette))
            else:
                colour = int(self.paint)
                if not 0 <= colour <= 9:
                    raise ValueError('paint must be a grid colour')
            for r, c in region(cells, self.region_kind, len(a), len(a[0])):
                if a[r][c] != bg:
                    continue
                if (r, c) in writes and writes[r, c] != colour:
                    return None
                writes[r, c] = colour
        out = [list(row) for row in a]
        for (r, c), colour in writes.items(): out[r][c] = colour
        return tuple(tuple(row) for row in out)


def fit(pairs: Iterable[tuple[Grid, Grid]]) -> list[RegionProgram]:
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    if any(len(a) != len(y) or len(a[0]) != len(y[0]) for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, y in pairs))
    targets = {y[r][c] for a, y in pairs for r in range(len(a)) for c in range(len(a[0])) if a[r][c] != y[r][c]}
    # A constant fits additions only if every changed output cell has that value.
    paints = (SOURCE_COLOUR, *sorted(targets)) if len(targets) == 1 else (SOURCE_COLOUR,)
    roles = ('all', 'rarest', 'commonest', *sorted(common))
    fitted = []
    for bg_rule in ('modal', *sorted(common)):
        bgs = tuple(background(a, bg_rule) for a, y in pairs)
        if any(bg is None or any(a[r][c] != bg and a[r][c] != y[r][c]
                for r in range(len(a)) for c in range(len(a[0])))
                for (a, y), bg in zip(pairs, bgs)):
            continue
        for role, (grouping, conn) in product(roles, GROUPS):
            if any(source_groups(a, bg, role, grouping, conn) is None for (a, _), bg in zip(pairs, bgs)):
                continue
            for kind, paint in product(REGIONS, paints):
                p = RegionProgram(bg_rule, role, grouping, conn, kind, paint)
                if all(p.predict(a) == y for a, y in pairs):
                    fitted.append(p)
    return fitted


def infer(task: dict) -> dict:
    clean = public_task(task)
    models = fit((d['input'], d['output']) for d in clean['train'])
    inputs = tuple(grid(t['input']) for t in clean['test'])
    groups, invalid = {}, 0
    for model in models:
        predicted = tuple(model.predict(a) for a in inputs)
        if any(p is None for p in predicted):
            invalid += 1
            continue
        groups.setdefault(predicted, []).append(model.describe())
    result = joint_result(groups, len(inputs))
    result['joint_hypotheses_is_exact'] = True
    result['witness_predictions'] = [[[list(row) for row in a] for a in key] for key in groups]
    result['stats'] = {'fitted_programs': len(models), 'inapplicable_programs': invalid,
                       'all_complete_joint_alternatives_retained': True}
    return result


def validate(task: dict, full: dict) -> dict:
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [t['prediction'] for t in full['tests']]
    folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': demo['input']}] + clean['test']}
        r = infer(fold)
        preds = [t['prediction'] for t in r['tests']]
        folds.append({'held_index': held, 'status': r['status'],
                      'held_example_exact': r['status'] == 'unique' and preds[0] == demo['output'],
                      'test_prediction_stable': r['status'] == 'unique' and preds[1:] == expected,
                      'joint_hypotheses': r['joint_hypotheses']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure', 'folds': folds}
