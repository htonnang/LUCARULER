"""LUCA V138: dynamic graph-constructor composition.

This proof-carrying family constructs typed relation graphs from the current
input, then reuses one of three shared consequences::

    scene -> graph constructor -> relation chain -> shared operator -> grid

The family contains no task identifiers, official test targets, or stored
absolute demonstration coordinates.  All nodes, edges, roles, colours, axes,
frames, apertures, and path schedules are inferred from demonstrations and the
current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations, product

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _mode, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_dynamic_graph_constructor_composition"
LANGUAGE = "spinoza_dynamic_graph_constructor_composition_v138"
SCHEMA_VERSION = 1


def _law(
    program,
    *,
    scene,
    relation,
    operator,
    parameters,
    definitions,
    propositions,
    corollary,
    common_notions,
):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "relation": relation,
            "operator": operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "dynamic_graph_constructor": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _background(value: Grid) -> int:
    return _mode(grid(value))


def _non_background_cells(value: Grid, background: int):
    value = grid(value)
    return [
        (r, c, value[r][c])
        for r in range(len(value))
        for c in range(len(value[0]))
        if value[r][c] != background
    ]


def _changed_output_colours(source: Grid, target: Grid):
    source = grid(source)
    target = grid(target)
    if _shape(source) != _shape(target):
        raise Inapplicable("shape changed")
    colours = set()
    changes = 0
    for r in range(len(source)):
        for c in range(len(source[0])):
            if source[r][c] != target[r][c]:
                colours.add(target[r][c])
                changes += 1
    if not changes:
        raise Inapplicable("identity transformation")
    return colours


def _single_paint_colour(pairs) -> int:
    paint = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        background = _background(source)
        colours = _changed_output_colours(source, target)
        if len(colours) != 1:
            raise Inapplicable("changes do not share one consequence colour")
        current = next(iter(colours))
        if current == background:
            raise Inapplicable("consequence colour equals background")
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] != target[r][c]:
                    if source[r][c] != background or target[r][c] != current:
                        raise Inapplicable("transformation is not background-only emission")
        if paint is None:
            paint = current
        elif paint != current:
            raise Inapplicable("consequence colour changes between demonstrations")
    if paint is None:
        raise Inapplicable("missing consequence colour")
    return int(paint)


def _paint(out, r, c, colour, background):
    if not (0 <= r < len(out) and 0 <= c < len(out[0])):
        raise Inapplicable("emission leaves the canvas")
    if out[r][c] == background:
        out[r][c] = colour
    elif out[r][c] == colour:
        return
    # Existing structural nodes, frames, and endpoints are preserved.


def _bbox(cells):
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _canonical_shape(cells):
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _monochrome_components(value: Grid, background: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        directions += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or value[r][c] == background:
                continue
            colour = value[r][c]
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and (nr, nc) not in seen
                        and value[nr][nc] == colour
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            components.append((colour, tuple(sorted(cells))))
    return components


# ---------------------------------------------------------------------------
# Shared operator I: orthogonal graph-path emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RoleStarGraphProgram:
    root_colour: int
    target_orders: tuple  # ((target_colour, "vh" | "hv"), ...)
    path_colour: int

    kind = "role_star_graph_connector"

    @property
    def schema_key(self):
        return self.kind, self.root_colour, self.target_orders, self.path_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        by_colour = defaultdict(list)
        for r, c, colour in cells:
            by_colour[colour].append((r, c))
        roles = {self.root_colour, *(colour for colour, _ in self.target_orders)}
        if len(cells) != len(roles) or set(by_colour) != roles:
            raise Inapplicable("requires one singleton node for each semantic role")
        if any(len(items) != 1 for items in by_colour.values()):
            raise Inapplicable("semantic roles are not singleton nodes")
        if self.path_colour in roles or self.path_colour == background:
            raise Inapplicable("path colour is not distinct")
        return value, background, by_colour

    def predict(self, value):
        value, background, by_colour = self.analyse(value)
        rr, rc = by_colour[self.root_colour][0]
        out = _array(value)
        for target_colour, order in self.target_orders:
            tr, tc = by_colour[target_colour][0]
            if tr == rr or tc == rc:
                raise Inapplicable("role edge must require a two-axis route")
            if order == "vh":
                sr = 1 if tr > rr else -1
                for r in range(rr + sr, tr + sr, sr):
                    if (r, rc) != (tr, tc):
                        _paint(out, r, rc, self.path_colour, background)
                sc = 1 if tc > rc else -1
                for c in range(rc + sc, tc + sc, sc):
                    if (tr, c) != (tr, tc):
                        _paint(out, tr, c, self.path_colour, background)
            elif order == "hv":
                sc = 1 if tc > rc else -1
                for c in range(rc + sc, tc + sc, sc):
                    if (rr, c) != (tr, tc):
                        _paint(out, rr, c, self.path_colour, background)
                sr = 1 if tr > rr else -1
                for r in range(rr + sr, tr + sr, sr):
                    if (r, tc) != (tr, tc):
                        _paint(out, r, tc, self.path_colour, background)
            else:
                raise Inapplicable("unknown edge order")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="three_distinct_role_coloured_singleton_nodes",
            relation="rooted_star_with_role_specific_ordered_orthogonal_edges",
            operator="orthogonal_graph_path_emission",
            parameters={
                "root_colour": self.root_colour,
                "target_orders": [list(row) for row in self.target_orders],
                "path_colour": self.path_colour,
            },
            definitions={
                "root": "the role-coloured node incident to every inferred edge",
                "target": "a singleton role node with a learned axis order",
                "edge": "a one-bend orthogonal path derived from current coordinates",
            },
            propositions=[
                "Node colours denote roles while coordinates remain input-derived.",
                "Each target role has one demonstration-consistent vertical/horizontal order.",
                "All role edges are emitted jointly and existing nodes are preserved.",
            ],
            corollary="Construct the role-labelled star graph and emit its ordered orthogonal edges.",
            common_notions=["typed node", "rooted graph", "ordered path", "role invariance"],
        )


@dataclass(frozen=True)
class RepeatedAxisSpineProgram:
    marker_colour: int
    path_colour: int

    kind = "repeated_axis_spine"

    @property
    def schema_key(self):
        return self.kind, self.marker_colour, self.path_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        if not cells or any(colour != self.marker_colour for _, _, colour in cells):
            raise Inapplicable("requires one marker class")
        coordinates = [(r, c) for r, c, _ in cells]
        occupied = set(coordinates)
        if any(
            any((r + dr, c + dc) in occupied for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)))
            for r, c in occupied
        ):
            raise Inapplicable("markers must be disconnected singleton nodes")
        rows = Counter(r for r, _ in coordinates)
        columns = Counter(c for _, c in coordinates)
        repeated_rows = [r for r, count in rows.items() if count >= 2]
        repeated_columns = [c for c, count in columns.items() if count >= 2]
        if len(repeated_rows) == 1 and not repeated_columns:
            return value, background, coordinates, "horizontal", repeated_rows[0]
        if len(repeated_columns) == 1 and not repeated_rows:
            return value, background, coordinates, "vertical", repeated_columns[0]
        raise Inapplicable("repeated alignment axis is not unique")

    def predict(self, value):
        value, background, coordinates, orientation, axis = self.analyse(value)
        out = _array(value)
        if orientation == "horizontal":
            left = min(c for _, c in coordinates)
            right = max(c for _, c in coordinates)
            for c in range(left, right + 1):
                _paint(out, axis, c, self.path_colour, background)
            for r, c in coordinates:
                step = 1 if axis > r else -1
                for rr in range(r + step, axis, step):
                    _paint(out, rr, c, self.path_colour, background)
        else:
            top = min(r for r, _ in coordinates)
            bottom = max(r for r, _ in coordinates)
            for r in range(top, bottom + 1):
                _paint(out, r, axis, self.path_colour, background)
            for r, c in coordinates:
                step = 1 if axis > c else -1
                for cc in range(c + step, axis, step):
                    _paint(out, r, cc, self.path_colour, background)
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="disconnected_monochrome_marker_nodes",
            relation="unique_repeated_row_or_column_defines_a_spine",
            operator="orthogonal_graph_path_emission",
            parameters={"marker_colour": self.marker_colour, "path_colour": self.path_colour},
            definitions={
                "spine": "the unique row or column occupied by at least two markers",
                "branch": "the orthogonal interval from a marker to the spine",
            },
            propositions=[
                "The spine orientation and coordinate are inferred anew from each input.",
                "The spine spans the extremal marker coordinates on its transverse axis.",
                "Every off-spine marker contributes one shortest orthogonal branch.",
            ],
            corollary="Emit the unique repeated-axis spine and all marker-to-spine branches.",
            common_notions=["alignment", "shared axis", "graph spine", "coordinate-free construction"],
        )


@dataclass(frozen=True)
class AlignedHollowPlusGraphProgram:
    marker_colour: int
    path_colour: int

    kind = "aligned_hollow_plus_graph"

    @property
    def schema_key(self):
        return self.kind, self.marker_colour, self.path_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        h, w = _shape(value)
        cells = _non_background_cells(value, background)
        if not cells or any(colour != self.marker_colour for _, _, colour in cells):
            raise Inapplicable("requires one marker class")
        centres = []
        used = set()
        for r in range(1, h - 1):
            for c in range(1, w - 1):
                arms = {(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)}
                diagonals = {(r - 1, c - 1), (r - 1, c + 1), (r + 1, c - 1), (r + 1, c + 1)}
                if (
                    value[r][c] == background
                    and all(value[rr][cc] == self.marker_colour for rr, cc in arms)
                    and all(value[rr][cc] == background for rr, cc in diagonals)
                ):
                    centres.append((r, c))
                    used |= arms
        occupied = {(r, c) for r, c, _ in cells}
        if not centres or used != occupied:
            raise Inapplicable("foreground is not a complete set of hollow-plus nodes")
        if not any(a[0] == b[0] or a[1] == b[1] for a, b in combinations(centres, 2)):
            raise Inapplicable("no aligned graph edge exists")
        return value, background, centres

    def predict(self, value):
        value, background, centres = self.analyse(value)
        out = _array(value)
        protected = set(centres)
        by_row = defaultdict(list)
        by_column = defaultdict(list)
        for r, c in centres:
            by_row[r].append(c)
            by_column[c].append(r)
        for r, columns in by_row.items():
            columns = sorted(columns)
            for left, right in zip(columns, columns[1:]):
                for c in range(left + 1, right):
                    if (r, c) not in protected:
                        _paint(out, r, c, self.path_colour, background)
        for c, rows in by_column.items():
            rows = sorted(rows)
            for top, bottom in zip(rows, rows[1:]):
                for r in range(top + 1, bottom):
                    if (r, c) not in protected:
                        _paint(out, r, c, self.path_colour, background)
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="hollow_plus_glyphs_whose_empty_centres_are_graph_nodes",
            relation="consecutive_centres_aligned_on_rows_or_columns",
            operator="orthogonal_graph_path_emission",
            parameters={"marker_colour": self.marker_colour, "path_colour": self.path_colour},
            definitions={
                "node": "the empty centre enclosed by four orthogonal marker arms",
                "edge": "the open interval between consecutive aligned node centres",
            },
            propositions=[
                "Every foreground marker belongs to exactly one hollow-plus node.",
                "Edges are inferred from row/column alignment of centres.",
                "Node holes remain empty while the intervals between them are emitted.",
            ],
            corollary="Construct the centre-alignment graph and emit each orthogonal edge.",
            common_notions=["latent node", "glyph decomposition", "alignment graph", "hole preservation"],
        )


def _hollow_frames(value: Grid, background: int):
    components = _monochrome_components(value, background, connectivity=4)
    frames = []
    for colour, cells in components:
        r0, c0, r1, c1 = _bbox(cells)
        if r1 - r0 < 2 or c1 - c0 < 2:
            continue
        expected = {
            (r, c)
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if r in (r0, r1) or c in (c0, c1)
        }
        if set(cells) == expected:
            frames.append((colour, (r0, c0, r1, c1), set(cells)))
    return frames, components


@dataclass(frozen=True)
class FrameCentreCrossProgram:
    path_colour: int

    kind = "frame_centre_cross_projection"

    @property
    def schema_key(self):
        return self.kind, self.path_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        frames, components = _hollow_frames(value, background)
        if not frames or len(frames) != len(components):
            raise Inapplicable("all foreground components must be hollow frames")
        if len({colour for colour, _, _ in frames}) != 1:
            raise Inapplicable("frame class is not uniform")
        centres = []
        for _, (r0, c0, r1, c1), _ in frames:
            if (r0 + r1) % 2 or (c0 + c1) % 2:
                raise Inapplicable("frame lacks a unique integral centre")
            centres.append(((r0 + r1) // 2, (c0 + c1) // 2))
        return value, background, centres

    def predict(self, value):
        value, background, centres = self.analyse(value)
        h, w = _shape(value)
        out = _array(value)
        for r, c in centres:
            for cc in range(w):
                _paint(out, r, cc, self.path_colour, background)
            for rr in range(h):
                _paint(out, rr, c, self.path_colour, background)
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="one_or_more_monochrome_hollow_rectangular_frames",
            relation="unique_integral_frame_centres_define_canvas_axes",
            operator="orthogonal_graph_path_emission",
            parameters={"path_colour": self.path_colour},
            definitions={
                "centre node": "the unique midpoint of an odd-by-odd frame bounding box",
                "axis edge": "a full canvas row or column incident to the centre node",
            },
            propositions=[
                "Frames are detected structurally rather than by stored coordinates.",
                "Each frame must have a unique integral centre.",
                "The row and column through every centre are emitted jointly while frames persist.",
            ],
            corollary="Project a full orthogonal cross through every inferred frame centre.",
            common_notions=["frame", "centre", "axis projection", "multi-node graph union"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: aperture fill and escape emission.
# ---------------------------------------------------------------------------


def _open_rectangles(value: Grid, background: int):
    components = _monochrome_components(value, background, connectivity=4)
    openings = []
    for colour, cells_tuple in components:
        cells = set(cells_tuple)
        r0, c0, r1, c1 = _bbox(cells)
        if r1 - r0 < 2 or c1 - c0 < 2:
            continue
        perimeter = {
            (r, c)
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if r in (r0, r1) or c in (c0, c1)
        }
        missing = perimeter - cells
        extra = cells - perimeter
        if len(missing) != 1 or extra:
            continue
        gap = next(iter(missing))
        if gap in {(r0, c0), (r0, c1), (r1, c0), (r1, c1)}:
            continue
        openings.append((colour, (r0, c0, r1, c1), gap, cells))
    return openings, components


def _gap_side(box, gap):
    r0, c0, r1, c1 = box
    r, c = gap
    if r == r0:
        return "top"
    if r == r1:
        return "bottom"
    if c == c0:
        return "left"
    if c == c1:
        return "right"
    raise Inapplicable("gap is not on the boundary")


@dataclass(frozen=True)
class ApertureEscapeProgram:
    paint_colour: int
    mode: str  # straight or turn_longer

    kind = "near_closed_frame_aperture_escape"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.mode

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        openings, components = _open_rectangles(value, background)
        if not openings or len(openings) != len(components):
            raise Inapplicable("all foreground components must be one-gap rectangular frames")
        if len({colour for colour, _, _, _ in openings}) != 1:
            raise Inapplicable("aperture frames do not share one structural class")
        if self.paint_colour == background or self.paint_colour == openings[0][0]:
            raise Inapplicable("paint colour is not semantically distinct")
        return value, background, openings

    def predict(self, value):
        value, background, openings = self.analyse(value)
        h, w = _shape(value)
        out = _array(value)
        for _, box, gap, _ in openings:
            r0, c0, r1, c1 = box
            gr, gc = gap
            for r in range(r0 + 1, r1):
                for c in range(c0 + 1, c1):
                    _paint(out, r, c, self.paint_colour, background)
            _paint(out, gr, gc, self.paint_colour, background)
            side = _gap_side(box, gap)
            if self.mode == "straight":
                if side == "top":
                    for r in range(gr - 1, -1, -1):
                        _paint(out, r, gc, self.paint_colour, background)
                elif side == "bottom":
                    for r in range(gr + 1, h):
                        _paint(out, r, gc, self.paint_colour, background)
                elif side == "left":
                    for c in range(gc - 1, -1, -1):
                        _paint(out, gr, c, self.paint_colour, background)
                else:
                    for c in range(gc + 1, w):
                        _paint(out, gr, c, self.paint_colour, background)
            elif self.mode == "turn_longer":
                if side in ("top", "bottom"):
                    rr = gr - 1 if side == "top" else gr + 1
                    if not 0 <= rr < h:
                        raise Inapplicable("no outward cell exists")
                    left_extent = gc - c0
                    right_extent = c1 - gc
                    if left_extent == right_extent:
                        raise Inapplicable("longer tangential side is tied")
                    columns = range(gc, -1, -1) if left_extent > right_extent else range(gc, w)
                    for c in columns:
                        _paint(out, rr, c, self.paint_colour, background)
                else:
                    cc = gc - 1 if side == "left" else gc + 1
                    if not 0 <= cc < w:
                        raise Inapplicable("no outward cell exists")
                    top_extent = gr - r0
                    bottom_extent = r1 - gr
                    if top_extent == bottom_extent:
                        raise Inapplicable("longer tangential side is tied")
                    rows = range(gr, -1, -1) if top_extent > bottom_extent else range(gr, h)
                    for r in rows:
                        _paint(out, r, cc, self.paint_colour, background)
            else:
                raise Inapplicable("unknown escape mode")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        relation = (
            "aperture_normal_ray_to_canvas_boundary"
            if self.mode == "straight"
            else "aperture_outward_step_then_longer_tangential_ray"
        )
        return _law(
            self,
            scene="monochrome_near_closed_rectangular_frames_with_one_noncorner_aperture",
            relation=relation,
            operator="aperture_fill_escape_emission",
            parameters={"paint_colour": self.paint_colour, "mode": self.mode},
            definitions={
                "aperture": "the unique missing non-corner perimeter cell",
                "interior": "the strict rectangle enclosed by the frame",
                "escape": "an input-derived outward ray, optionally followed by a longer-side turn",
            },
            propositions=[
                "Every foreground component must be exactly one perimeter cell short of a rectangle.",
                "The strict interior and the aperture receive one learned consequence colour.",
                "The escape direction is derived from aperture side, canvas boundary, and local side lengths.",
            ],
            corollary="Fill each frame interior and emit the demonstration-consistent aperture escape path.",
            common_notions=["near-closure", "aperture", "inside/outside", "boundary-directed path"],
        )


# ---------------------------------------------------------------------------
# Shared operator III: diagonal lattice-path emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DiagonalObjectConnectorProgram:
    path_colour: int

    kind = "diagonal_identical_object_connector"

    @property
    def schema_key(self):
        return self.kind, self.path_colour

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        components = _monochrome_components(value, background, connectivity=4)
        if len(components) < 2:
            raise Inapplicable("requires multiple components")
        if len({colour for colour, _ in components}) != 1:
            raise Inapplicable("components do not share one class")
        if len({_canonical_shape(cells) for _, cells in components}) != 1:
            raise Inapplicable("components are not translation-equivalent")
        centres = []
        for _, cells in components:
            r0, c0, r1, c1 = _bbox(cells)
            if (r0 + r1) % 2 or (c0 + c1) % 2:
                raise Inapplicable("component lacks an integral centre")
            centre = ((r0 + r1) // 2, (c0 + c1) // 2)
            if centre not in cells:
                raise Inapplicable("component centre is not occupied")
            centres.append(centre)
        if not any(
            abs(a[0] - b[0]) == abs(a[1] - b[1]) and a != b
            for a, b in combinations(centres, 2)
        ):
            raise Inapplicable("no 45-degree centre relation exists")
        return value, background, centres

    def predict(self, value):
        value, background, centres = self.analyse(value)
        out = _array(value)
        for source, target in combinations(centres, 2):
            dr = target[0] - source[0]
            dc = target[1] - source[1]
            if not dr or abs(dr) != abs(dc):
                continue
            sr = 1 if dr > 0 else -1
            sc = 1 if dc > 0 else -1
            for step in range(1, abs(dr)):
                _paint(
                    out,
                    source[0] + sr * step,
                    source[1] + sc * step,
                    self.path_colour,
                    background,
                )
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="multiple_translation_equivalent_monochrome_objects_with_occupied_centres",
            relation="forty_five_degree_alignment_between_object_centres",
            operator="diagonal_lattice_path_emission",
            parameters={"path_colour": self.path_colour},
            definitions={
                "object node": "the occupied integral centre of a translation-equivalent component",
                "diagonal edge": "the open 45-degree lattice interval between two centres",
            },
            propositions=[
                "Object identity is established through normalized shape equality.",
                "Only centre pairs with equal absolute row and column displacement form edges.",
                "All qualifying diagonal intervals are emitted while source objects remain unchanged.",
            ],
            corollary="Construct the object-centre diagonal graph and emit all qualifying edges.",
            common_notions=["object equivalence", "centre relation", "diagonal lattice", "graph edge"],
        )


@dataclass(frozen=True)
class RoleBiasedChebyshevProgram:
    source_colour: int
    target_colour: int
    path_colour: int
    schedule: str = "diagonal_then_cardinal_then_final_diagonal"

    kind = "role_biased_chebyshev_connector"

    @property
    def schema_key(self):
        return self.kind, self.source_colour, self.target_colour, self.path_colour, self.schedule

    def analyse(self, value):
        value = grid(value)
        background = _background(value)
        cells = _non_background_cells(value, background)
        by_colour = defaultdict(list)
        for r, c, colour in cells:
            by_colour[colour].append((r, c))
        if set(by_colour) != {self.source_colour, self.target_colour}:
            raise Inapplicable("requires exactly two semantic role colours")
        if any(len(items) != 1 for items in by_colour.values()):
            raise Inapplicable("roles are not singleton nodes")
        source = by_colour[self.source_colour][0]
        target = by_colour[self.target_colour][0]
        if source[0] == target[0] or source[1] == target[1]:
            raise Inapplicable("two-axis displacement required")
        return value, background, source, target

    def predict(self, value):
        value, background, (r, c), (tr, tc) = self.analyse(value)
        out = _array(value)
        dr, dc = tr - r, tc - c
        ar, ac = abs(dr), abs(dc)
        sr = 1 if dr > 0 else -1
        sc = 1 if dc > 0 else -1
        minor = min(ar, ac)
        major = max(ar, ac)
        if minor < 1:
            raise Inapplicable("diagonal phase is empty")
        diagonal_count = minor - 1
        steps = [(sr, sc)] * diagonal_count
        if ar >= ac:
            steps += [(sr, 0)] * (major - minor)
        else:
            steps += [(0, sc)] * (major - minor)
        steps += [(sr, sc)]
        for rr, cc in steps:
            r += rr
            c += cc
            if (r, c) != (tr, tc):
                _paint(out, r, c, self.path_colour, background)
        if (r, c) != (tr, tc):
            raise Inapplicable("path does not terminate at target")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="two_distinct_role_coloured_singleton_nodes",
            relation="role_ordered_monotone_chebyshev_path_with_terminal_diagonal",
            operator="diagonal_lattice_path_emission",
            parameters={
                "source_colour": self.source_colour,
                "target_colour": self.target_colour,
                "path_colour": self.path_colour,
                "schedule": self.schedule,
            },
            definitions={
                "source": "the semantic role from which the schedule begins",
                "target": "the semantic role reached by the last diagonal step",
                "schedule": "minor-minus-one diagonals, major-minus-minor cardinals, final diagonal",
            },
            propositions=[
                "Role colours determine direction independently of absolute placement.",
                "The step counts are computed from current row and column distances.",
                "The monotone schedule terminates exactly at the target and preserves both endpoints.",
            ],
            corollary="Emit the role-biased monotone Chebyshev path derived from current distances.",
            common_notions=["typed endpoint", "monotone path", "Chebyshev geometry", "distance-derived schedule"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and proof obligations.
# ---------------------------------------------------------------------------


def _fit_role_star(pairs):
    source = grid(pairs[0][0])
    background = _background(source)
    cells = _non_background_cells(source, background)
    colours = sorted({colour for _, _, colour in cells})
    if len(cells) != 3 or len(colours) != 3:
        return []
    try:
        path_colour = _single_paint_colour(pairs)
    except Inapplicable:
        return []
    programs = []
    for root_colour in colours:
        targets = [colour for colour in colours if colour != root_colour]
        for orders in product(("vh", "hv"), repeat=2):
            program = RoleStarGraphProgram(
                root_colour,
                tuple(zip(targets, orders)),
                path_colour,
            )
            try:
                if all(program.predict(x) == grid(y) for x, y in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


def _fit_repeated_axis_spine(pairs):
    source = grid(pairs[0][0])
    background = _background(source)
    cells = _non_background_cells(source, background)
    if not cells or len({colour for _, _, colour in cells}) != 1:
        return []
    try:
        program = RepeatedAxisSpineProgram(cells[0][2], _single_paint_colour(pairs))
        return [program] if all(program.predict(x) == grid(y) for x, y in pairs) else []
    except Inapplicable:
        return []


def _fit_hollow_plus_graph(pairs):
    source = grid(pairs[0][0])
    background = _background(source)
    cells = _non_background_cells(source, background)
    if not cells or len({colour for _, _, colour in cells}) != 1:
        return []
    try:
        program = AlignedHollowPlusGraphProgram(cells[0][2], _single_paint_colour(pairs))
        return [program] if all(program.predict(x) == grid(y) for x, y in pairs) else []
    except Inapplicable:
        return []


def _fit_frame_centre_cross(pairs):
    try:
        program = FrameCentreCrossProgram(_single_paint_colour(pairs))
        return [program] if all(program.predict(x) == grid(y) for x, y in pairs) else []
    except Inapplicable:
        return []


def _fit_aperture_escape(pairs):
    try:
        paint_colour = _single_paint_colour(pairs)
    except Inapplicable:
        return []
    programs = []
    for mode in ("straight", "turn_longer"):
        program = ApertureEscapeProgram(paint_colour, mode)
        try:
            if all(program.predict(x) == grid(y) for x, y in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


def _fit_diagonal_objects(pairs):
    try:
        program = DiagonalObjectConnectorProgram(_single_paint_colour(pairs))
        return [program] if all(program.predict(x) == grid(y) for x, y in pairs) else []
    except Inapplicable:
        return []


def _fit_role_biased_chebyshev(pairs):
    source = grid(pairs[0][0])
    background = _background(source)
    cells = _non_background_cells(source, background)
    colours = sorted({colour for _, _, colour in cells})
    if len(cells) != 2 or len(colours) != 2:
        return []
    try:
        path_colour = _single_paint_colour(pairs)
    except Inapplicable:
        return []
    programs = []
    for source_colour, target_colour in (tuple(colours), tuple(reversed(colours))):
        program = RoleBiasedChebyshevProgram(source_colour, target_colour, path_colour)
        try:
            if all(program.predict(x) == grid(y) for x, y in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


_FITTERS = {
    "role_star_graph_connector": _fit_role_star,
    "repeated_axis_spine": _fit_repeated_axis_spine,
    "aligned_hollow_plus_graph": _fit_hollow_plus_graph,
    "frame_centre_cross_projection": _fit_frame_centre_cross,
    "near_closed_frame_aperture_escape": _fit_aperture_escape,
    "diagonal_identical_object_connector": _fit_diagonal_objects,
    "role_biased_chebyshev_connector": _fit_role_biased_chebyshev,
}


def fit_dynamic_graph_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    programs = []
    seen = set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            fitted = fitter(pairs)
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            continue
        for program in fitted:
            if program.schema_key not in seen:
                seen.add(program.schema_key)
                programs.append(program)
    return programs


def _counterfactual(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        passed = False
        detail = {}
        try:
            original = program.predict(source)
            background = _background(source)
            cells = _non_background_cells(source, background)
            if not cells:
                raise Inapplicable("no causal graph node")
            r, c, _ = cells[0]
            work = _array(source)
            work[r][c] = background
            try:
                passed = program.predict(tuple(tuple(row) for row in work)) != original
            except Inapplicable:
                passed = True
            detail = {"node_removal_changes_or_rejects": bool(passed)}
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **detail})
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_dynamic_graph_constructor(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_dynamic_graph_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "dynamic_graph_constructor": True,
            "relation_chain_composition": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programs_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = []
    for program in fit_dynamic_graph_programs(pairs, minimum_pairs=2, allowed_kinds=allowed):
        try:
            if (
                tuple(program.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(program, pairs).get("passed")
            ):
                programs.append(program)
        except Inapplicable:
            pass
    return expected, programs


def _validate_program(clean, program, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_dynamic_graph_programs(
            remaining,
            minimum_pairs=1,
            allowed_kinds=(program.kind,),
        )
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(program, full_pairs)
    passed = (
        all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds)
        and counterfactual.get("passed")
    )
    return {
        "passed": bool(passed),
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_dynamic_graph_constructor(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programs = _programs_for_expected(clean, full)
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_program(clean, program, expected) for program in programs]
    passed = any(check.get("passed") for check in checks)
    selected = next((check for check in checks if check.get("passed")), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check.get("counterfactuals", [])],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
