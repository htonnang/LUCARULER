from __future__ import annotations
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/LUCA_V160_EQUIVARIANT_FAMILY_REWRITE.zip')
VERIFY=Path('/mnt/data/LUCA_V160_SOURCE_MANIFEST_VERIFICATION.json')
FIXED=(2026,10,29,12,0,0)

def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def add(zf,path,name):
 info=zipfile.ZipInfo(name,FIXED);info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16;zf.writestr(info,path.read_bytes())

files=[]
# Runtime modules and focused test.
for p in sorted(ROOT.glob('*.py')):
    files.append((p,p.name))
# Release docs and examples.
for name in ['README.md','README_V160.md','RUN_V160.txt','RELEASE_METADATA.json','SPINOZA_ARCHITECTURE.md']:
    p=ROOT/name
    if p.exists():files.append((p,name))
for p in sorted(ROOT.glob('example_v160_*.json')):files.append((p,p.name))
# V160 tools needed for reproduction.
for p in sorted((ROOT/'tools').glob('*v160.py')):files.append((p,f'tools/{p.name}'))
# Build manifest over payloads, excluding the manifest itself.
manifest={'release':'LUCA_V160_EQUIVARIANT_FAMILY_REWRITE','entries':{}}
for p,name in files:
 data=p.read_bytes();manifest['entries'][name]={'sha256':sha_bytes(data),'size_bytes':len(data)}
manifest['entry_count']=len(manifest['entries'])
manifest_path=ROOT/'SOURCE_MANIFEST.json';manifest_path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
files.append((manifest_path,'SOURCE_MANIFEST.json'))
with zipfile.ZipFile(OUT,'w') as zf:
 for p,name in sorted(files,key=lambda x:x[1]):add(zf,p,name)
# Verify archive and manifest.
with zipfile.ZipFile(OUT,'r') as zf:
 corrupt=zf.testzip();names=zf.namelist();inside=json.loads(zf.read('SOURCE_MANIFEST.json'))
 failures=[]
 for name,rec in inside['entries'].items():
  data=zf.read(name)
  if sha_bytes(data)!=rec['sha256'] or len(data)!=rec['size_bytes']:failures.append(name)
 forbidden=[n for n in names if any(token in n.lower() for token in ('arc-agi','training_challenges','training_solutions','evaluation_solutions','sample_submission'))]
 result={'all_verified':not corrupt and not failures and not forbidden,'archive':OUT.name,'archive_sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'archive_size_bytes':OUT.stat().st_size,'archive_members':len(names),'manifest_entries':inside['entry_count'],'manifest_sha256':hashlib.sha256(zf.read('SOURCE_MANIFEST.json')).hexdigest(),'corrupt_member':corrupt,'checksum_failures':failures,'dataset_files_in_executable':forbidden}
VERIFY.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
raise SystemExit(0 if result['all_verified'] else 1)
