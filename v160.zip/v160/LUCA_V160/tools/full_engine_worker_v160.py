from __future__ import annotations
import argparse, hashlib, json, os, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import engine

def digest(result):
    return hashlib.sha256(json.dumps([x['prediction'] for x in result['tests']],sort_keys=True,separators=(',',':')).encode()).hexdigest()
parser=argparse.ArgumentParser(); parser.add_argument('task_id'); parser.add_argument('output',type=Path); args=parser.parse_args()
task=json.loads((ROOT/f'example_v160_{args.task_id}_task.json').read_text())
start=time.time(); bundle=engine.infer_bundle(task,include_research=True); seconds=time.time()-start
result=bundle['result']
record={
 'task_id':args.task_id,'status':result['status'],'prediction_hash':digest(result) if result['status']=='unique' else None,
 'seconds':seconds,'stable_families':len(engine.FAMILIES),'research_families':len(engine.RESEARCH_FAMILIES),'active_families':len(engine.ACTIVE_FAMILIES),
 'rewrite_registry':{k:{'raw_status':v['raw']['status'],'validated_status':v['validated']['status'],'passed':v['validated'].get('validation',{}).get('passed',False)} for k,v in bundle['registry'].items() if 'equivariant_' in k},
}
args.output.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,sort_keys=True),flush=True)
sys.stdout.flush();sys.stderr.flush();os._exit(0)
