from __future__ import annotations
import json, py_compile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; REPORTS=ROOT/'reports_v160_full'; REPORTS.mkdir(exist_ok=True)
files=sorted([p for p in ROOT.glob('*.py')]+[p for p in (ROOT/'tools').glob('*.py')])
fail=[]
for path in files:
 try: py_compile.compile(str(path),doraise=True)
 except Exception as exc: fail.append({'file':str(path.relative_to(ROOT)),'error':f'{type(exc).__name__}: {exc}'})
out={'files':len(files),'passed':len(files)-len(fail),'failed':len(fail),'failures':fail}
(REPORTS/'compilation_v160.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(1 if fail else 0)
