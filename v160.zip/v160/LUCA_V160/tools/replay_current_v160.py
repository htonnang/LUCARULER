from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; REPORTS=ROOT/'reports_v160_full'; EVID=Path('/mnt/data/v160_work/v159_evidence/reports_v159_full/current_tests_v159.json')
hist=json.loads(EVID.read_text()); focused=json.loads((REPORTS/'focused_tests_v160.json').read_text())
out={'scope':'historical V104-V159 evidence inherited from independently verified V159 release; V160 focused suite freshly executed in bounded shards','historical_tests_passed':hist['tests_passed'],'historical_tests_skipped':hist['tests_skipped'],'focused_v160_tests_passed':focused['tests_passed'],'focused_v160_tests_expected':focused['tests_expected'],'tests_passed':hist['tests_passed']+focused['tests_passed'],'tests_skipped':hist['tests_skipped'],'preexisting_skip':hist.get('preexisting_skip'),'all_passed':focused['all_passed'],'focused_v160_replay':focused}
(REPORTS/'current_tests_v160.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='focused_v160_replay'},indent=2))
