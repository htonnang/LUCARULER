from __future__ import annotations
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; BASE=Path('/mnt/data/v160_work/base'); REPORTS=ROOT/'reports_v160_full'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def runtime_files(folder): return {p.name:p for p in folder.glob('*.py') if not p.name.startswith('test_')}
cur=runtime_files(ROOT); old=runtime_files(BASE)
added=sorted(set(cur)-set(old)); removed=sorted(set(old)-set(cur)); changed=sorted(n for n in set(cur)&set(old) if sha(cur[n])!=sha(old[n])); unchanged=sorted(n for n in set(cur)&set(old) if sha(cur[n])==sha(old[n]))
out={'runtime_modules':len(cur),'prior_runtime_modules':len(old),'added':added,'removed':removed,'changed':changed,'unchanged_count':len(unchanged),'unchanged':unchanged}
(REPORTS/'source_audit_v160.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='unchanged'},indent=2))
