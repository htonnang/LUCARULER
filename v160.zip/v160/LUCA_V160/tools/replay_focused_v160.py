from __future__ import annotations
import json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TEST='test_v160_equivariant_family_rewrite.py'
shards=[
 ('coverage',['-k','test_rewrite_preserves_or_adds_exact_coverage'],16,120),
 ('rotation_anchor',['-k','test_new_transfer_is_rotation_equivariant and dc433765'],4,120),
 ('rotation_transport',['-k','test_new_transfer_is_rotation_equivariant and 4364c1c4'],4,120),
 ('rotation_phase',['-k','test_new_transfer_is_rotation_equivariant and b457fec5'],4,120),
 ('rotation_reference',['-k','test_new_transfer_is_rotation_equivariant and e681b708'],4,120),
 ('colour_anchor',[f'{TEST}::test_new_transfer_is_colour_equivariant[dc433765]'],1,120),
 ('colour_transport',[f'{TEST}::test_new_transfer_is_colour_equivariant[4364c1c4]'],1,120),
 ('colour_phase',[f'{TEST}::test_new_transfer_is_colour_equivariant[b457fec5]'],1,120),
 ('colour_reference',[f'{TEST}::test_new_transfer_is_colour_equivariant[e681b708]'],1,120),
 ('general',['-k','test_every_rewrite or test_active_registry or test_source_is or test_rejected_ordered or test_negative_controls'],5,120),
]
for tid in ['dc433765','4364c1c4','b457fec5','e681b708']:
 shards.append((f'cli_{tid}',[f'{TEST}::test_dedicated_cli_matches_frozen_prediction[{tid}]'],1,120))
records=[]; all_pass=True
for name,args,expected,timeout in shards:
 cmd=[sys.executable,'-m','pytest','-q',TEST,*args]
 env=dict(os.environ);env['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
 start=time.time()
 try:
  p=subprocess.run(cmd,cwd=ROOT,env=env,capture_output=True,text=True,timeout=timeout)
  output=(p.stdout+'\n'+p.stderr).strip()
  passed=p.returncode==0
 except subprocess.TimeoutExpired as exc:
  output=((exc.stdout or '')+(exc.stderr or '')).strip() if isinstance(exc.stdout,str) else 'timeout'
  p=type('P',(),{'returncode':124})()
  passed=False
 records.append({'name':name,'expected_tests':expected,'passed':passed,'returncode':p.returncode,'seconds':time.time()-start,'output':output[-3000:]})
 print(name,'PASS' if passed else 'FAIL',round(time.time()-start,2),flush=True)
 all_pass &= passed
result={'all_passed':all_pass,'tests_passed':sum(r['expected_tests'] for r in records if r['passed']),'tests_expected':sum(r['expected_tests'] for r in records),'shards':records}
out=ROOT/'reports_v160_full'/'focused_tests_v160.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'all_passed':all_pass,'tests_passed':result['tests_passed'],'tests_expected':result['tests_expected']},indent=2),flush=True)
sys.stdout.flush();sys.stderr.flush();os._exit(0 if all_pass else 1)
