from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / "reports_v160_full"
NEW_TASKS = ["4364c1c4", "b457fec5", "dc433765", "e681b708"]


def _stop_process_group(process: subprocess.Popen) -> None:
    """Terminate a worker and any search descendants that inherited its group."""
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=2.0)
        return
    except subprocess.TimeoutExpired:
        pass
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=2.0)
    except subprocess.TimeoutExpired:
        pass


def _load_complete_json(path: Path) -> dict | None:
    if not path.exists() or path.stat().st_size == 0:
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Replay complete-engine parity for the four V160 transfer gains."
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=REPORTS / "engine_parity_v160.json",
    )
    parser.add_argument(
        "--per-task-timeout",
        type=float,
        default=120.0,
        help="Maximum seconds to wait for each worker evidence record.",
    )
    args = parser.parse_args()

    metadata = json.loads((ROOT / "example_v160_metadata.json").read_text())
    expected = {
        record["task_id"]: record["prediction_hash"]
        for record in metadata["examples"]
        if record["task_id"] in NEW_TASKS
    }

    records: list[dict] = []
    timeouts = 0
    with tempfile.TemporaryDirectory(prefix="v160_parity_") as temp_dir:
        temp = Path(temp_dir)
        for task_id in NEW_TASKS:
            worker_output = temp / f"{task_id}.json"
            command = [
                sys.executable,
                str(ROOT / "tools" / "full_engine_worker_v160.py"),
                task_id,
                str(worker_output),
            ]
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            deadline = time.monotonic() + args.per_task_timeout
            record = None
            while time.monotonic() < deadline:
                record = _load_complete_json(worker_output)
                if record is not None:
                    break
                time.sleep(0.2)

            _stop_process_group(process)

            if record is None:
                timeouts += 1
                records.append(
                    {
                        "task_id": task_id,
                        "status": "timeout",
                        "match": False,
                        "seconds": args.per_task_timeout,
                    }
                )
                continue

            record["match"] = (
                record.get("status") == "unique"
                and record.get("prediction_hash") == expected[task_id]
            )
            records.append(record)

    first_with_counts = next(
        (record for record in records if "active_families" in record),
        {},
    )
    output = {
        "stable_families": first_with_counts.get("stable_families"),
        "research_families": first_with_counts.get("research_families"),
        "active_families": first_with_counts.get("active_families"),
        "full_engine_completed": sum(bool(record.get("match")) for record in records),
        "full_engine_timeouts": timeouts,
        "all_match": len(records) == len(NEW_TASKS)
        and all(bool(record.get("match")) for record in records),
        "records": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["all_match"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
