from __future__ import annotations
import argparse,hashlib,importlib,json,py_compile,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path

def digest(value): return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def rotate(g,k):
 out=[list(r) for r in g]
 for _ in range(k):out=[list(r) for r in zip(*out[::-1])]
 return out
def recolour(g):return [[9-x for x in r] for r in g]

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--archive',type=Path,default=Path('/mnt/data/LUCA_V160_EQUIVARIANT_FAMILY_REWRITE.zip'));parser.add_argument('--output',type=Path,default=Path('/mnt/data/LUCA_V160_FRESH_EXTRACTION_VERIFICATION.json'));args=parser.parse_args()
 tmp=Path(tempfile.mkdtemp(prefix='luca_v160_fresh_')); failures=[]; records=[]
 try:
  with zipfile.ZipFile(args.archive,'r') as zf:
   corrupt=zf.testzip();zf.extractall(tmp);manifest=json.loads(zf.read('SOURCE_MANIFEST.json'))
   if corrupt:failures.append('corrupt:'+str(corrupt))
  for name,rec in manifest['entries'].items():
   p=tmp/name
   if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=rec['sha256'] or p.stat().st_size!=rec['size_bytes']:failures.append('manifest:'+name)
  pyfiles=sorted(tmp.glob('*.py'))+sorted((tmp/'tools').glob('*.py'))
  compile_fail=[]
  for p in pyfiles:
   try:py_compile.compile(str(p),doraise=True)
   except Exception as exc:compile_fail.append(f'{p.relative_to(tmp)}:{exc}')
  failures.extend('compile:'+x for x in compile_fail)
  sys.path.insert(0,str(tmp))
  engine=importlib.import_module('engine');rewrite=importlib.import_module('equivariant_family_rewrite_reasoning')
  meta=json.loads((tmp/'example_v160_metadata.json').read_text())
  api={'anchor':(rewrite.infer_equivariant_anchor_transport_rewrite,rewrite.validate_equivariant_anchor_transport_rewrite),'transport':(rewrite.infer_equivariant_transport_rewrite,rewrite.validate_equivariant_transport_rewrite),'ordered_phase':(rewrite.infer_equivariant_ordered_phase_rewrite,rewrite.validate_equivariant_ordered_phase_rewrite),'reference_transfer':(rewrite.infer_equivariant_reference_transfer_rewrite,rewrite.validate_equivariant_reference_transfer_rewrite)}
  for rec in meta['examples']:
   task=json.loads((tmp/f"example_v160_{rec['task_id']}_task.json").read_text());infer,validate=api[rec['rewrite_family']];res=infer(task);check=validate(task,res);h=digest([x['prediction'] for x in res['tests']]) if res['status']=='unique' else None;ok=res['status']=='unique' and check.get('passed') and h==rec['prediction_hash'];records.append({'task_id':rec['task_id'],'status':res['status'],'validated':check.get('passed'),'prediction_hash':h,'match':ok});
   if not ok:failures.append('prediction:'+rec['task_id'])
  # One colour-permutation and one 90-degree rotation control per new transfer.
  transforms=[]
  for rec in [r for r in meta['examples'] if r['role']=='new_transfer']:
   task=json.loads((tmp/f"example_v160_{rec['task_id']}_task.json").read_text());infer,validate=api[rec['rewrite_family']];base=infer(task);basepred=[x['prediction'] for x in base['tests']]
   for kind in ('rotate90','recolour'):
    fn=(lambda g:rotate(g,1)) if kind=='rotate90' else recolour
    transformed={'train':[{'input':fn(x['input']),'output':fn(x['output'])} for x in task['train']],'test':[{'input':fn(x['input'])} for x in task['test']]};res=infer(transformed);check=validate(transformed,res);expected=[fn(g) for g in basepred];ok=res['status']=='unique' and check.get('passed') and [x['prediction'] for x in res['tests']]==expected;transforms.append({'task_id':rec['task_id'],'control':kind,'passed':ok});
    if not ok:failures.append(f'transform:{rec["task_id"]}:{kind}')
  # Representative complete-engine path.
  task=json.loads((tmp/'example_v160_dc433765_task.json').read_text());bundle=engine.infer_bundle(task,include_research=True);full=bundle['result'];full_ok=full['status']=='unique' and digest([x['prediction'] for x in full['tests']])==next(r['prediction_hash'] for r in meta['examples'] if r['task_id']=='dc433765')
  if not full_ok:failures.append('full_engine:dc433765')
  out={'all_passed':not failures,'archive':args.archive.name,'archive_sha256':hashlib.sha256(args.archive.read_bytes()).hexdigest(),'manifest_entries':manifest['entry_count'],'compiled_python_files':len(pyfiles),'compile_failures':compile_fail,'stable_families':len(engine.FAMILIES),'research_families':len(engine.RESEARCH_FAMILIES),'active_families':len(engine.ACTIVE_FAMILIES),'prediction_records':records,'transform_controls':transforms,'full_engine_smoke':{'task_id':'dc433765','passed':full_ok,'status':full['status']},'failures':failures}
  args.output.write_text(json.dumps(out,indent=2,sort_keys=True)+'\n');print(json.dumps(out,indent=2,sort_keys=True));return 0 if not failures else 1
 finally:shutil.rmtree(tmp,ignore_errors=True)
if __name__=='__main__':raise SystemExit(main())
