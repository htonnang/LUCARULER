from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import equivariant_family_rewrite_reasoning as rewrite


FAMILIES = {
    "equivariant_anchor_transport": (
        rewrite.infer_equivariant_anchor_transport_rewrite,
        rewrite.validate_equivariant_anchor_transport_rewrite,
    ),
    "equivariant_transport": (
        rewrite.infer_equivariant_transport_rewrite,
        rewrite.validate_equivariant_transport_rewrite,
    ),
    "equivariant_ordered_phase": (
        rewrite.infer_equivariant_ordered_phase_rewrite,
        rewrite.validate_equivariant_ordered_phase_rewrite,
    ),
    "equivariant_reference_transfer": (
        rewrite.infer_equivariant_reference_transfer_rewrite,
        rewrite.validate_equivariant_reference_transfer_rewrite,
    ),
}


def _predictions(result: dict) -> list | None:
    if result.get("status") != "unique":
        return None
    return [record.get("prediction") for record in result.get("tests", [])]


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Screen the four V160 equivariant rewrites on an ARC training corpus."
    )
    parser.add_argument("challenges", type=Path)
    parser.add_argument("solutions", type=Path)
    parser.add_argument("--prior-ledger", type=Path, default=None)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("reports_v160_replay"),
    )
    args = parser.parse_args()

    challenges = json.loads(args.challenges.read_text())
    solutions = json.loads(args.solutions.read_text())
    args.output_dir.mkdir(parents=True, exist_ok=True)

    output: dict = {
        "release": "LUCA_V160_EQUIVARIANT_FAMILY_REWRITE",
        "families": {},
        "union_exact": [],
        "union_validated_unique": [],
        "wrong_unique": [],
        "ambiguous": [],
        "validation_rejected": [],
        "crashes": [],
    }
    union_exact: set[str] = set()
    union_validated: set[str] = set()

    for family_name, (infer, validate) in FAMILIES.items():
        started = time.perf_counter()
        records: list[dict] = []
        exact_ids: list[str] = []
        unique_ids: list[str] = []
        no_fit_count = 0
        wrong_ids: list[str] = []
        ambiguous_ids: list[str] = []
        rejected_ids: list[str] = []
        crash_ids: list[str] = []

        for task_id in sorted(challenges):
            challenge = challenges[task_id]
            task = {"train": challenge["train"], "test": challenge["test"]}
            try:
                result = infer(task)
                validation = validate(task, result)
                status = result.get("status", "no_fit")
                passed = bool(validation.get("passed"))
                prediction = _predictions(result)
                exact = prediction == solutions[task_id] if prediction is not None else False
                record = {
                    "task_id": task_id,
                    "status": status,
                    "validated": passed,
                    "exact": exact,
                    "schemas": result.get("stats", {}).get("schemas", []),
                    "reason": validation.get("reason"),
                }
                records.append(record)

                if status == "unique":
                    unique_ids.append(task_id)
                    if passed:
                        union_validated.add(task_id)
                    else:
                        rejected_ids.append(task_id)
                        output["validation_rejected"].append([family_name, task_id])
                    if exact and passed:
                        exact_ids.append(task_id)
                        union_exact.add(task_id)
                    elif not exact:
                        wrong_ids.append(task_id)
                        output["wrong_unique"].append([family_name, task_id])
                elif status == "ambiguous":
                    ambiguous_ids.append(task_id)
                    output["ambiguous"].append([family_name, task_id])
                else:
                    no_fit_count += 1
            except Exception as exc:  # pragma: no cover - replay diagnostic
                crash_ids.append(task_id)
                output["crashes"].append(
                    [family_name, task_id, f"{type(exc).__name__}: {exc}"]
                )
                records.append(
                    {
                        "task_id": task_id,
                        "status": "crash",
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

        output["families"][family_name] = {
            "exact": exact_ids,
            "unique": unique_ids,
            "no_fit_count": no_fit_count,
            "wrong_unique": wrong_ids,
            "ambiguous": ambiguous_ids,
            "validation_rejected": rejected_ids,
            "crashes": crash_ids,
            "records": records,
            "elapsed_seconds": time.perf_counter() - started,
        }

    output["union_exact"] = sorted(union_exact)
    output["union_validated_unique"] = sorted(union_validated)
    output["tasks"] = len(challenges)
    output["test_inputs"] = sum(len(value["test"]) for value in challenges.values())
    output["prior_ledger_supplied"] = bool(args.prior_ledger)

    raw_path = args.output_dir / "raw_target_free_screen_v160.json"
    raw_path.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")

    summary = {
        "release": output["release"],
        "tasks": output["tasks"],
        "test_inputs": output["test_inputs"],
        "per_family_exact": {
            name: len(record["exact"])
            for name, record in output["families"].items()
        },
        "rewritten_four_family_union_exact": len(output["union_exact"]),
        "incorrect_unique_predictions": len(output["wrong_unique"]),
        "ambiguous_predictions": len(output["ambiguous"]),
        "validation_rejected": len(output["validation_rejected"]),
        "crashes": len(output["crashes"]),
    }
    (args.output_dir / "screen_summary_v160.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if not any(
        [
            summary["incorrect_unique_predictions"],
            summary["ambiguous_predictions"],
            summary["validation_rejected"],
            summary["crashes"],
        ]
    ) else 1


if __name__ == "__main__":
    raise SystemExit(main())
