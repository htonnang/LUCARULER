from __future__ import annotations
import json
from pathlib import Path
from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE=Path('/mnt/data')
ROOT=Path(__file__).resolve().parents[1]
REPORTS=ROOT/'reports_v160_full'
OUT=BASE/'LUCA_V160_Progress_Report.docx'
summary=json.loads((REPORTS/'screen_summary_v160.json').read_text())
comparison=json.loads((REPORTS/'rewrite_comparison_v160.json').read_text())
gains=json.loads((REPORTS/'gain_spotchecks_v160.json').read_text())
validation=json.loads((REPORTS/'validation_summary_v160.json').read_text())
parity=json.loads((REPORTS/'engine_parity_v160.json').read_text())
source=json.loads((REPORTS/'source_audit_v160.json').read_text())
manifest=json.loads((BASE/'LUCA_V160_SOURCE_MANIFEST_VERIFICATION.json').read_text())
fresh=json.loads((BASE/'LUCA_V160_FRESH_EXTRACTION_VERIFICATION.json').read_text())

def shade(cell, fill):
    tcPr=cell._tc.get_or_add_tcPr(); shd=tcPr.find(qn('w:shd'))
    if shd is None: shd=OxmlElement('w:shd');tcPr.append(shd)
    shd.set(qn('w:fill'),fill)

def set_repeat_table_header(row):
    trPr=row._tr.get_or_add_trPr(); tblHeader=OxmlElement('w:tblHeader');tblHeader.set(qn('w:val'),'true');trPr.append(tblHeader)

def set_cell_text(cell,text,bold=False,color=None,size=8.5):
    cell.text='';p=cell.paragraphs[0];r=p.add_run(str(text));r.bold=bold;r.font.name='Aptos';r.font.size=Pt(size)
    if color:r.font.color.rgb=RGBColor(*color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def add_table(doc,headers,rows,widths=None):
    table=doc.add_table(rows=1,cols=len(headers));table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.style='Table Grid'
    hdr=table.rows[0];set_repeat_table_header(hdr)
    for i,h in enumerate(headers):shade(hdr.cells[i],'17324D');set_cell_text(hdr.cells[i],h,True,(255,255,255),8)
    for row in rows:
        cells=table.add_row().cells
        for i,value in enumerate(row):set_cell_text(cells[i],value,False,None,8)
    if widths:
        for row in table.rows:
            for i,w in enumerate(widths):row.cells[i].width=Inches(w)
    return table

def add_heading(doc,text,level=1):
    p=doc.add_heading(text,level=level)
    return p

def add_bullets(doc,items):
    for item in items:
        p=doc.add_paragraph(style='List Bullet');p.paragraph_format.space_after=Pt(2);p.add_run(item)

def set_alt_text(inline_shape,title,description):
    docPr=inline_shape._inline.docPr;docPr.set('title',title);docPr.set('descr',description)

doc=Document()
sec=doc.sections[0];sec.top_margin=Inches(.58);sec.bottom_margin=Inches(.55);sec.left_margin=Inches(.65);sec.right_margin=Inches(.65)
styles=doc.styles
styles['Normal'].font.name='Aptos';styles['Normal'].font.size=Pt(9.5)
styles['Normal'].paragraph_format.space_after=Pt(4)
for name,size,color in [('Title',25,(23,50,77)),('Heading 1',16,(23,50,77)),('Heading 2',12,(45,95,139)),('Heading 3',10,(45,95,139))]:
    styles[name].font.name='Aptos Display' if name!='Normal' else 'Aptos';styles[name].font.size=Pt(size);styles[name].font.color.rgb=RGBColor(*color)
# Header/footer
header=sec.header.paragraphs[0];header.text='LUCA / GENERALIZED FAMILY SOLVER';header.alignment=WD_ALIGN_PARAGRAPH.LEFT
for r in header.runs:r.font.name='Aptos';r.font.size=Pt(7);r.font.bold=True;r.font.color.rgb=RGBColor(45,95,139)
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run('LUCA V160 | Research and validation report | 29 October 2026');r.font.name='Aptos';r.font.size=Pt(7);r.font.color.rgb=RGBColor(71,84,103)

# Cover
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_before=Pt(12)
r=p.add_run('LUCA V160');r.bold=True;r.font.name='Aptos Display';r.font.size=Pt(30);r.font.color.rgb=RGBColor(23,50,77)
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Equivariant Four-Family Rewrite');r.bold=True;r.font.name='Aptos Display';r.font.size=Pt(20);r.font.color.rgb=RGBColor(45,95,139)
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Generalizing direction, colour, and structural roles for cross-task transfer');r.italic=True;r.font.size=Pt(11);r.font.color.rgb=RGBColor(71,84,103)

img=doc.add_picture(str(BASE/'LUCA_V160_Benchmark_Dashboard.png'),width=Inches(6.9));set_alt_text(img,'LUCA V160 benchmark dashboard','Dashboard comparing original and rewritten family coverage and protected exact results.')
doc.paragraphs[-1].alignment=WD_ALIGN_PARAGRAPH.CENTER

add_table(doc,['Measure','Original','V160 Rewrite','Change'],[
    ['Four-family exact coverage','12','16','+4 (+33.3%)'],
    ['Families with a real transfer gain','0','4 of 4','+4'],
    ['Wrong unique predictions','0','0','0'],
    ['Protected integrated exact','478','482','+4'],
],widths=[2.4,1.2,1.4,1.3])
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Prepared as a proof-carrying research release; no sealed unseen-task score is claimed.');r.bold=True;r.font.size=Pt(9);r.font.color.rgb=RGBColor(122,75,0)

doc.add_page_break()

# 1 Executive summary
add_heading(doc,'1. Executive Summary',1)
doc.add_paragraph(
    'V160 directly addresses the request to take several recent one-family mechanisms and rewrite them so that they operate through relative direction, inferred colour roles, and reusable structural relations. Four predecessor families were selected because each already had three validated training-task witnesses and a clear opportunity for transfer.'
)
add_bullets(doc,[
    'All 12 predecessor exact applications are retained.',
    'Each of the four rewrites adds one task that was not used as predecessor support.',
    'Combined exact coverage rises from 12 to 16 applications, a 33.3% increase.',
    'Every new programme works under 0°, 90°, 180°, and 270° rotations and under an arbitrary colour permutation.',
    'The complete 1,000-task screen records zero incorrect unique predictions, zero ambiguity, and zero validation rejection.',
    'The four new gains raise the protected integrated ledger from 478 to 482 exact training tasks.',
])
add_table(doc,['Rewritten family','Original exact','Rewritten exact','New transfer','Increase'],[
    ['Equivariant anchor transport','3','4','dc433765','33.3%'],
    ['Equivariant transport','3','4','4364c1c4','33.3%'],
    ['Equivariant ordered phase','3','4','b457fec5','33.3%'],
    ['Equivariant reference transfer','3','4','e681b708','33.3%'],
],widths=[2.2,1,1,1.1,1])

add_heading(doc,'1.1 What “unseen transfer” means in this release',2)
doc.add_paragraph(
    'The four added tasks are held-out transfer tasks relative to the predecessor-family support sets: they were not among the three tasks used to establish each original family. V160 also uses synthetic rotated and recoloured variants as transformation controls. These are meaningful transfer tests, but they are not a sealed competition evaluation; that distinction is preserved throughout the release.'
)

# 2 Methods
add_heading(doc,'2. Rewrite Methodology',1)
add_table(doc,['Stage','Action','Promotion gate'],[
    ['1. Preserve','Delegate every validated predecessor programme inside the rewrite','All 12 predecessor predictions remain exact'],
    ['2. Relativize','Replace fixed direction and colour assumptions with structural roles','D4 and colour controls pass'],
    ['3. Transfer','Mine a new training task requiring the same abstract relation','At least one new witness per family'],
    ['4. Validate','Leave one demonstration out and refit from the remainder','Every held example exact; test prediction stable'],
    ['5. Challenge','Mutate structural witnesses and poison metadata','Prediction changes/rejects; metadata has no effect'],
    ['6. Screen','Run each rewrite against all 1,000 tasks','Zero wrong unique, ambiguity, rejection, or crash'],
],widths=[1.2,3.1,2.7])
doc.add_paragraph(
    'The rewrite does not discard earlier reasoning. A predecessor programme is wrapped in a common typed interface, while each family receives one new structural programme. Predictions are grouped by complete test output. If two exact training explanations disagree on a test prediction, the family returns ambiguity rather than selecting one opportunistically.'
)

add_heading(doc,'2.1 Shared proof boundary',2)
add_bullets(doc,[
    'No task identifier participates in inference.',
    'No official test output participates in inference or validation.',
    'No absolute demonstration coordinate is stored as a programme constant.',
    'Every accepted programme emits the complete output grid.',
    'Training solutions are consulted only after target-free predictions and validation records are frozen.',
])

# 3 Families
add_heading(doc,'3. The Four Rewritten Families',1)
for number,row in enumerate(comparison['families'],start=1):
    key=row['rewrite_family']
    gain=next(item for item in gains['records'] if item['rewrite_family']==key)
    add_heading(doc,f'3.{number} {key.replace("_"," ").title()}',2)
    doc.add_paragraph(f"Retained tasks: {', '.join(row['retained_task_ids'])}. New transfer: {gain['task_id']}.")
    add_table(doc,['Element','Generalized content'],[
        ['Schema',gain['schema']],['Scene',gain['scene']],['Relation',gain['relation']],['Operator',gain['operator']],['Nodes',gain['nodes']],['Edges',gain['edges']],
    ],widths=[1.2,5.8])
    if gain['task_id']=='dc433765':
        doc.add_paragraph('New transfer: one singleton payload advances one Chebyshev step toward a stationary singleton anchor. The signed row/column vector is input-derived, so all eight relative directions are supported.')
    elif gain['task_id']=='4364c1c4':
        doc.add_paragraph('New transfer: uniquely paired adjacent components separate one cell in opposite perpendicular directions. Pair orientation and chirality are learned; colours and component shapes are preserved.')
    elif gain['task_id']=='b457fec5':
        doc.add_paragraph('New transfer: a contiguous palette line provides an ordered colour sequence for a diagonal chain of overlapping square stamps. Palette direction, endpoint choice, phase, and overlay order are inferred.')
    else:
        doc.add_paragraph('New transfer: orthogonal partition lines define regions. Boundary/intersection marker evidence determines a unique owner colour for each region, and isolated payload dots inherit that ownership.')

# 4 transfer evidence
add_heading(doc,'4. Direction and Colour Transfer Evidence',1)
add_table(doc,['Family','0°','90°','180°','270°','Arbitrary colours'],[
    [row['rewrite_family'],'PASS','PASS','PASS','PASS','PASS'] for row in comparison['families']
],widths=[2.7,.7,.7,.7,.7,1.3])
doc.add_paragraph(
    'The transformed tasks are generated from the current task itself, including every demonstration input, demonstration output, and test input. The predicted transformed test output must equal the same transformation applied to the frozen base prediction. This tests equivariance rather than simple training replay.'
)
add_heading(doc,'4.1 Rejected experiment',2)
doc.add_paragraph(
    'An ordered-legend rewrite was explored for the reference-transfer family. It fitted the simple demonstrations but did not identify the held-out test structure uniquely. It was removed from the active fitter. The promoted reference rewrite therefore relies only on the partition-ownership transfer, preserving the zero-error boundary.'
)

# 5 corpus and validation
add_heading(doc,'5. Full-Corpus and Validation Evidence',1)
add_table(doc,['Check','Scope','Result','Interpretation'],[
    ['Four rewrite screens','4 × 1,000 tasks','16 exact; 3,984 no-fit','Complete and conservative'],
    ['New transfer gains','4 tasks','4/4 exact and validated','One gain per family'],
    ['LODO refitting','4 tasks / 16 folds','16/16 PASS','Programme reconstruction is stable'],
    ['Counterfactual suites','4 programmes','4/4 PASS','Structural witnesses are causally necessary'],
    ['Metadata poisoning','4 programmes','4/4 PASS','Task metadata cannot force an answer'],
    ['D4 controls','4 families / 16 rotations','16/16 PASS','All four directions supported'],
    ['Colour controls','4 families','4/4 PASS','Colours are inferred roles'],
    ['Focused V160 tests','45 tests','45/45 PASS','Bounded subprocess shards'],
    ['Complete-engine parity','4 gains','4/4 MATCH','Isolated, registry, CLI, and 87-family engine agree'],
    ['Corpus errors','1,000 tasks','0 wrong, 0 ambiguous, 0 rejected, 0 crashes','Zero-error promotion result'],
],widths=[1.5,1.7,1.5,3])

doc.add_paragraph(
    'Complete-engine runtimes for the four gains were approximately 0.8 s, 1.7 s, 9.2 s, and 34.7 s. The slower partition-transfer path is reported explicitly; it is not hidden as a timeout or counted as faster than observed.'
)
add_table(doc,['Task','Complete-engine seconds','Status','Prediction match'],[
    [r['task_id'],f"{r['seconds']:.2f}",r['status'],'PASS' if r['match'] else 'FAIL'] for r in parity['records']
],widths=[1.2,1.8,1.2,1.5])

add_heading(doc,'5.1 Protected ledger',2)
add_table(doc,['Final grade','V159','V160','Change'],[
    ['Exact','478','482','+4'],['No fit','522','518','−4'],['Ambiguous','0','0','0'],['Total','1,000','1,000','0'],
],widths=[1.4,1.1,1.1,1.1])

# 6 architecture
add_heading(doc,'6. Source and Runtime Architecture',1)
add_table(doc,['Measure','V159','V160'],[
    ['Runtime Python modules',source['prior_runtime_modules'],source['runtime_modules']],
    ['Inherited runtime modules unchanged',source['unchanged_count'],source['unchanged_count']],
    ['Inherited runtime modules changed','—',', '.join(source['changed'])],
    ['New runtime modules','—',', '.join(source['added'])],
    ['Stable / research / active families','31 / 52 / 83','31 / 56 / 87'],
    ['Compiled development Python files','—',validation['compilation_v160']['passed']],
    ['Executable source-manifest entries','—',manifest['manifest_entries']],
],widths=[2.6,1.7,2.8])
doc.add_paragraph(
    'The production registry remains fixed at 31 stable families. The four rewrites are added to the research registry, increasing active coverage without shifting historical stable-family positions.'
)

add_heading(doc,'6.1 Fresh-extraction verification',2)
add_bullets(doc,[
    f"{fresh['manifest_entries']}/{fresh['manifest_entries']} manifest entries verified.",
    f"{fresh['compiled_python_files']} extracted Python files compiled without error.",
    'All 16 original-and-transfer applications reproduced their frozen prediction hashes.',
    'Rotation and colour controls reproduced on all four new transfer tasks.',
    'A representative complete 87-family engine prediction reproduced exactly.',
    'No ARC challenge, solution, submission, or evaluation dataset is bundled in the executable.',
])

add_heading(doc,'6.2 Reproduction commands',2)
add_table(doc,['Command','Purpose'],[
    ['python run.py task.json --output prediction.json','Run the complete 87-family solver'],
    ['python run.py task.json --equivariant-anchor-transport-only --output prediction.json','Run anchor rewrite alone'],
    ['python run.py task.json --equivariant-transport-only --output prediction.json','Run transport rewrite alone'],
    ['python run.py task.json --equivariant-ordered-phase-only --output prediction.json','Run ordered-phase rewrite alone'],
    ['python run.py task.json --equivariant-reference-transfer-only --output prediction.json','Run reference rewrite alone'],
    ['python tools/fresh_verify_v160.py','Repeat the independent executable audit'],
],widths=[4.9,2.1])

doc.add_page_break()

# 7 limitations and roadmap
add_heading(doc,'7. Limitations and V161 Direction',1)
add_heading(doc,'7.1 Current limitations',2)
add_bullets(doc,[
    'The 482-task result is a protected-ledger union rather than a fresh full-engine rerun of every historical family on every task.',
    'The new gains are held-out transfers within the training corpus, not sealed unseen evaluation tasks.',
    'The four rewrites still have separate front-end extractors; a common role-extraction algebra is not yet implemented.',
    'The diagonal palette programme is computationally heavier than the other three rewrites.',
    'The partition-transfer case produces a slower complete-engine path of roughly 35 seconds.',
])
add_heading(doc,'7.2 Recommended V161 programme',2)
add_table(doc,['Priority','Research objective','Acceptance gate'],[
    ['1','Anti-unify anchor, pair, palette, and partition role extractors','Cross-family refit or abstain'],
    ['2','Compose selection, transport, recolouring, and reference transfer','Complete-output consensus'],
    ['3','Learn global assignment under collision and ownership constraints','Unique assignment or explicit ambiguity'],
    ['4','Extend D4, colour, scale, count, and spacing controls','Equivariant outputs and stable held folds'],
    ['5','Introduce runtime-aware routing for expensive families','Faster engine with no evidence loss'],
    ['6','Replay the protected corpus','Zero regressions and at least 482 exact'],
],widths=[.7,4.1,2.1])

add_heading(doc,'8. Conclusion',1)
doc.add_paragraph(
    'V160 demonstrates the requested generalization step with measured transfer rather than only refactoring. Four recent three-task families are rewritten around relative directions and inferred colour roles; all 12 predecessor solutions remain exact, and each family adds one previously unsupported task. The combined coverage rises to 16 exact applications, every rotation and colour control passes, and the full corpus remains zero-error. The result supports promoting V160 as the new protected baseline while moving next to cross-family composition rather than adding isolated task mechanisms.'
)
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=p.add_run('Recommended decision: promote V160 and continue to V161 with compositional transfer and global assignment.');r.bold=True;r.font.color.rgb=RGBColor(45,95,139);r.font.size=Pt(10)

doc.core_properties.title='LUCA V160 Equivariant Four-Family Rewrite'
doc.core_properties.subject='Generalized family transfer and validation report'
doc.core_properties.author='LUCA Research Programme'
doc.core_properties.keywords='ARC-AGI, generalized reasoning, equivariance, transfer, validation'
doc.save(OUT)
print(OUT)
