"""LUCA V118: relational projection algebra.

This proof-carrying research family turns structural relations into compact
queries, crops, and local completions.  Six schemas share one programme form:

    scene -> structural abstraction -> unique role -> projected consequence

The schemas are:

* ``dominant_signal_component_crop`` — extract the unique largest exclusive
  signal component from a field of disconnected noise;
* ``repeated_class_outlier_crop`` — group objects by translation-invariant
  coloured pattern and extract the only singleton class;
* ``ring_center_colour_query`` — read the centre colour of a unique 3x3
  monochrome ring;
* ``holed_frame_colour_query`` — read the colour of the unique closed
  monochrome frame containing a background hole;
* ``marker_context_majority_query`` — count isolated markers by their uniform
  local context and return the uniquely most frequent context colour;
* ``local_dihedral_orbit_completion`` — complete a local object-centred
  symmetry orbit rather than using the canvas centre.

Programs use no task identifiers, stored demonstration coordinates, or test
outputs.  Exact demonstration fit is necessary but not sufficient: accepted
predictions must survive leave-one-demonstration-out refitting,
schema-specific counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_relational_projection_algebra"
LANGUAGE = "spinoza_relational_projection_algebra_v1"
SCHEMA_VERSION = "relational_projection_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _rot180(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(reversed(row)) for row in reversed(a))


def _normalise(points: Iterable[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    points = tuple(points)
    if not points:
        return ()
    r0 = min(r for r, _ in points)
    c0 = min(c for _, c in points)
    return tuple(sorted((r - r0, c - c0) for r, c in points))


@dataclass(frozen=True)
class _Component:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    colours: tuple[int, ...]
    matrix: Grid

    @property
    def area(self) -> int:
        return len(self.cells)

    @property
    def height(self) -> int:
        return self.box[2] - self.box[0] + 1

    @property
    def width(self) -> int:
        return self.box[3] - self.box[1] + 1


def _components(value: Grid, background: int, connectivity: int = 4) -> tuple[_Component, ...]:
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    a = grid(value)
    h, w = _shape(a)
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions.extend([(1, 1), (1, -1), (-1, 1), (-1, -1)])
    seen: set[tuple[int, int]] = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or a[r][c] == background:
                continue
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or a[nr][nc] == background:
                        continue
                    seen.add((nr, nc))
                    queue.append((nr, nc))
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            cell_set = set(cells)
            matrix = tuple(
                tuple(a[rr][cc] if (rr, cc) in cell_set else background for cc in range(c0, c1 + 1))
                for rr in range(r0, r1 + 1)
            )
            result.append(_Component(
                tuple(sorted(cells)),
                (r0, c0, r1, c1),
                tuple(sorted({a[rr][cc] for rr, cc in cells})),
                matrix,
            ))
    return tuple(result)


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused counterfactual colour")


# ---------------------------------------------------------------------------
# Schema I: unique signal component among disconnected noise
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DominantSignalComponentCropProgram:
    connectivity: int = 4
    noise_ratio: int = 2
    kind: str = "dominant_signal_component_crop"

    @property
    def schema_key(self):
        return (self.kind, self.connectivity, self.noise_ratio)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.connectivity, -self.noise_ratio)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        components = _components(a, background, self.connectivity)
        if len(components) < 3:
            raise Inapplicable("requires a signal and disconnected noise")
        largest_area = max(component.area for component in components)
        winners = [component for component in components if component.area == largest_area]
        if len(winners) != 1:
            raise Inapplicable("largest signal is not unique")
        signal = winners[0]
        if signal.area < 4 or len(components) - 1 < self.noise_ratio * signal.area:
            raise Inapplicable("noise field is not sufficiently richer than the signal")
        signal_cells = set(signal.cells)
        signal_palette = set(signal.colours)
        for r, row in enumerate(a):
            for c, colour in enumerate(row):
                if (r, c) not in signal_cells and colour in signal_palette:
                    raise Inapplicable("signal colours also occur in the noise field")
        return background, signal, components, signal.matrix

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, signal, components, _ = self._analyse(source)
            evidence.append({
                "signal_box": list(signal.box),
                "signal_area": signal.area,
                "signal_colours": list(signal.colours),
                "noise_component_count": len(components) - 1,
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "connectivity": self.connectivity,
                "noise_ratio": self.noise_ratio,
                "exclusive_signal_palette": True,
            },
            "definitions": [
                {"name": "SignalComponent", "type": "Scene -> UniqueLargestExclusiveComponent"},
                {"name": "NoiseField", "type": "Scene -> DisconnectedComponentSet"},
                {"name": "CanonicalCrop", "type": "Component -> Grid"},
            ],
            "propositions": [
                {"index": 1, "definition": "BindSignal", "effect": "select the unique largest exclusive component"},
                {"index": 2, "definition": "RejectNoise", "effect": "treat remaining disconnected components as irrelevant"},
                {"index": 3, "definition": "ProjectSignal", "effect": "emit the signal bounding-box crop"},
            ],
            "corollary": "a unique coherent object can be projected from a substantially richer field of disconnected noise",
            "common_notions": [{"name": "signal_noise_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema II: singleton equivalence class among repeated object classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RepeatedClassOutlierCropProgram:
    connectivity: int = 4
    minimum_repeated_classes: int = 2
    kind: str = "repeated_class_outlier_crop"

    @property
    def schema_key(self):
        return (self.kind, self.connectivity, self.minimum_repeated_classes)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.connectivity, -self.minimum_repeated_classes)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        components = _components(a, background, self.connectivity)
        groups = defaultdict(list)
        for component in components:
            groups[component.matrix].append(component)
        singleton_groups = [members for members in groups.values() if len(members) == 1]
        repeated_groups = [members for members in groups.values() if len(members) >= 2]
        if len(singleton_groups) != 1 or len(repeated_groups) < self.minimum_repeated_classes:
            raise Inapplicable("requires one singleton class and multiple repeated classes")
        if any(len(members) != 2 for members in repeated_groups):
            raise Inapplicable("repeated classes must form pairs")
        outlier = singleton_groups[0][0]
        return background, outlier, tuple(tuple(group) for group in repeated_groups), outlier.matrix

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, outlier, repeated, _ = self._analyse(source)
            evidence.append({
                "outlier_box": list(outlier.box),
                "outlier_colours": list(outlier.colours),
                "repeated_class_count": len(repeated),
                "repeated_multiplicities": [len(group) for group in repeated],
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "connectivity": self.connectivity,
                "minimum_repeated_classes": self.minimum_repeated_classes,
                "equivalence": "translation_invariant_coloured_crop",
            },
            "definitions": [
                {"name": "ObjectClass", "type": "Component -> ColouredPatternSignature"},
                {"name": "RepeatedClass", "type": "ObjectClass -> MultiplicityTwo"},
                {"name": "OutlierClass", "type": "ObjectClass -> MultiplicityOne"},
            ],
            "propositions": [
                {"index": 1, "definition": "PartitionObjects", "effect": "group components by exact coloured pattern"},
                {"index": 2, "definition": "BindOutlier", "effect": "select the only singleton equivalence class"},
                {"index": 3, "definition": "ProjectOutlier", "effect": "emit the outlier canonical crop"},
            ],
            "corollary": "paired object classes define the unique unpaired object as the requested projection",
            "common_notions": [{"name": "object_class_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema III: centre colour of a unique 3x3 ring
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RingCenterColourQueryProgram:
    kind: str = "ring_center_colour_query"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return ()

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        h, w = _shape(a)
        matches = []
        perimeter_offsets = ((0, 0), (0, 1), (0, 2), (1, 0), (1, 2), (2, 0), (2, 1), (2, 2))
        for r in range(h - 2):
            for c in range(w - 2):
                perimeter = [a[r + dr][c + dc] for dr, dc in perimeter_offsets]
                outer = perimeter[0]
                centre = a[r + 1][c + 1]
                if outer == background or centre in (background, outer):
                    continue
                if all(colour == outer for colour in perimeter):
                    matches.append((r, c, outer, centre))
        if len(matches) != 1:
            raise Inapplicable("requires one unique monochrome 3x3 ring with a coloured centre")
        r, c, outer, centre = matches[0]
        return background, (r, c), outer, centre, ((centre,),)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, origin, outer, centre, _ = self._analyse(source)
            evidence.append({"ring_origin": list(origin), "outer_colour": outer, "centre_colour": centre})
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {"kind": self.kind, "window": [3, 3], "query_role": "centre"},
            "definitions": [
                {"name": "MonochromeRing", "type": "Window3x3 -> Boolean"},
                {"name": "CentreRole", "type": "MonochromeRing -> Colour"},
            ],
            "propositions": [
                {"index": 1, "definition": "DetectRing", "effect": "find the unique uniform perimeter"},
                {"index": 2, "definition": "QueryCentre", "effect": "return the enclosed centre colour"},
            ],
            "corollary": "a unique ring identifies its centre colour as the requested scalar answer",
            "common_notions": [{"name": "ring_query_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema IV: colour of the unique closed monochrome frame with a hole
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HoledFrameColourQueryProgram:
    connectivity: int = 4
    kind: str = "holed_frame_colour_query"

    @property
    def schema_key(self):
        return (self.kind, self.connectivity)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        matches = []
        for component in _components(a, background, self.connectivity):
            if len(component.colours) != 1 or component.height < 3 or component.width < 3:
                continue
            colour = component.colours[0]
            r0, c0, r1, c1 = component.box
            perimeter = (
                [a[r0][c] for c in range(c0, c1 + 1)]
                + [a[r1][c] for c in range(c0, c1 + 1)]
                + [a[r][c0] for r in range(r0 + 1, r1)]
                + [a[r][c1] for r in range(r0 + 1, r1)]
            )
            if not all(value == colour for value in perimeter):
                continue
            interior = [a[r][c] for r in range(r0 + 1, r1) for c in range(c0 + 1, c1)]
            if background not in interior:
                continue
            matches.append(component)
        if len(matches) != 1:
            raise Inapplicable("requires one unique closed monochrome frame containing a hole")
        frame = matches[0]
        colour = frame.colours[0]
        return background, frame, colour, ((colour,),)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, frame, colour, _ = self._analyse(source)
            evidence.append({"frame_box": list(frame.box), "frame_colour": colour, "frame_area": frame.area})
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {"kind": self.kind, "connectivity": self.connectivity, "query_role": "frame"},
            "definitions": [
                {"name": "ClosedFrame", "type": "Component -> Boolean"},
                {"name": "InteriorHole", "type": "ClosedFrame -> BackgroundRegion"},
                {"name": "FrameRole", "type": "ClosedFrame -> Colour"},
            ],
            "propositions": [
                {"index": 1, "definition": "DetectClosedFrame", "effect": "find the unique component whose bounding perimeter is closed"},
                {"index": 2, "definition": "VerifyHole", "effect": "require background strictly inside the frame"},
                {"index": 3, "definition": "QueryFrame", "effect": "return the frame colour"},
            ],
            "corollary": "a unique holed frame identifies its enclosing colour as the requested scalar answer",
            "common_notions": [{"name": "frame_query_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema V: repeated isolated markers query the most frequent local context
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerContextMajorityQueryProgram:
    kind: str = "marker_context_majority_query"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return ()

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        candidates = []
        for marker in sorted(_palette(a)):
            coordinates = [(r, c) for r in range(h) for c in range(w) if a[r][c] == marker]
            if len(coordinates) < 3:
                continue
            if any(
                0 <= r + dr < h and 0 <= c + dc < w and a[r + dr][c + dc] == marker
                for r, c in coordinates
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))
            ):
                continue
            contexts = Counter()
            valid = True
            for r, c in coordinates:
                neighbours = [
                    a[nr][nc]
                    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))
                    if 0 <= (nr := r + dr) < h and 0 <= (nc := c + dc) < w and a[nr][nc] != marker
                ]
                if not neighbours or len(set(neighbours)) != 1:
                    valid = False
                    break
                contexts[neighbours[0]] += 1
            if not valid or len(contexts) < 2:
                continue
            top = max(contexts.values())
            winners = [colour for colour, count in contexts.items() if count == top]
            if len(winners) != 1:
                continue
            candidates.append((marker, contexts, winners[0]))
        if len(candidates) != 1:
            raise Inapplicable("requires one isolated marker colour with a unique majority context")
        marker, contexts, winner = candidates[0]
        return marker, contexts, winner, ((winner,),)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            marker, contexts, winner, _ = self._analyse(source)
            evidence.append({
                "marker_colour": marker,
                "marker_count": sum(contexts.values()),
                "context_counts": dict(sorted(contexts.items())),
                "winning_context": winner,
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {"kind": self.kind, "neighbourhood": "orthogonal", "aggregation": "unique_argmax"},
            "definitions": [
                {"name": "IsolatedMarker", "type": "Cell -> Boolean"},
                {"name": "UniformContext", "type": "Marker -> Colour"},
                {"name": "ContextHistogram", "type": "MarkerSet -> ColourCountMap"},
            ],
            "propositions": [
                {"index": 1, "definition": "BindMarkerType", "effect": "find the repeated isolated marker colour"},
                {"index": 2, "definition": "ReadContexts", "effect": "assign each marker its uniform orthogonal context"},
                {"index": 3, "definition": "QueryMajority", "effect": "return the uniquely most frequent context colour"},
            ],
            "corollary": "repeated identical markers vote over their structural contexts, and the unique majority is the scalar answer",
            "common_notions": [{"name": "marker_context_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema VI: local, object-centred dihedral closure
# ---------------------------------------------------------------------------


_TRANSFORM_GROUPS = {
    "mirror_horizontal": ("identity", "mirror_horizontal"),
    "mirror_vertical": ("identity", "mirror_vertical"),
    "half_turn": ("identity", "half_turn"),
    "orthogonal_reflection_closure": ("identity", "mirror_horizontal", "mirror_vertical", "half_turn"),
    "quarter_turn_closure": ("identity", "quarter_turn", "half_turn", "three_quarter_turn"),
    "diagonal_reflection_closure": ("identity", "main_diagonal", "anti_diagonal", "half_turn"),
    "full_dihedral_closure": (
        "identity", "mirror_horizontal", "mirror_vertical", "half_turn",
        "quarter_turn", "three_quarter_turn", "main_diagonal", "anti_diagonal",
    ),
}


def _nonbackground_box(value: Grid, background: int) -> tuple[int, int, int, int]:
    points = [(r, c) for r, row in enumerate(grid(value)) for c, colour in enumerate(row) if colour != background]
    if not points:
        raise Inapplicable("empty foreground")
    return min(r for r, _ in points), min(c for _, c in points), max(r for r, _ in points), max(c for _, c in points)


def _transform_local(r: int, c: int, h: int, w: int, transform: str) -> tuple[int, int]:
    if transform == "identity":
        return r, c
    if transform == "mirror_horizontal":
        return r, w - 1 - c
    if transform == "mirror_vertical":
        return h - 1 - r, c
    if transform == "half_turn":
        return h - 1 - r, w - 1 - c
    if h != w:
        raise Inapplicable("quarter-turn and diagonal closure require a square local box")
    n = h
    if transform == "quarter_turn":
        return c, n - 1 - r
    if transform == "three_quarter_turn":
        return n - 1 - c, r
    if transform == "main_diagonal":
        return c, r
    if transform == "anti_diagonal":
        return n - 1 - c, n - 1 - r
    raise Inapplicable("unknown local transform")


@dataclass(frozen=True)
class LocalDihedralOrbitCompletionProgram:
    closure_group: str
    kind: str = "local_dihedral_orbit_completion"

    @property
    def schema_key(self):
        return (self.kind, self.closure_group)

    @property
    def description_length(self):
        return 4 + len(_TRANSFORM_GROUPS[self.closure_group])

    @property
    def permissiveness_cost(self):
        return (-len(_TRANSFORM_GROUPS[self.closure_group]),)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        r0, c0, r1, c1 = _nonbackground_box(a, background)
        h, w = r1 - r0 + 1, c1 - c0 + 1
        writes = {}
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                colour = a[r][c]
                if colour == background:
                    continue
                lr, lc = r - r0, c - c0
                for transform in _TRANSFORM_GROUPS[self.closure_group]:
                    rr, cc = _transform_local(lr, lc, h, w, transform)
                    target = (r0 + rr, c0 + cc)
                    if target in writes and writes[target] != colour:
                        raise Inapplicable("two orbit members demand different colours")
                    existing = a[target[0]][target[1]]
                    if existing != background and existing != colour:
                        raise Inapplicable("closure conflicts with an observed orbit member")
                    writes[target] = colour
        output = _array(a)
        additions = 0
        for (r, c), colour in writes.items():
            if output[r][c] == background:
                additions += 1
            output[r][c] = colour
        if additions == 0:
            raise Inapplicable("local orbit is already closed")
        return background, (r0, c0, r1, c1), additions, tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, box, additions, _ = self._analyse(source)
            evidence.append({"local_box": list(box), "added_orbit_cells": additions})
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "closure_group": self.closure_group,
                "transforms": list(_TRANSFORM_GROUPS[self.closure_group]),
                "centre": "foreground_bounding_box_centre",
            },
            "definitions": [
                {"name": "LocalObjectFrame", "type": "Foreground -> BoundingBox"},
                {"name": "DihedralOrbit", "type": "Cell x TransformGroup -> CellSet"},
                {"name": "TransparentClosure", "type": "OrbitSet -> GridEdit"},
            ],
            "propositions": [
                {"index": 1, "definition": "BindLocalFrame", "effect": "derive the object-centred coordinate system"},
                {"index": 2, "definition": "GenerateOrbits", "effect": "apply the fitted local symmetry group"},
                {"index": 3, "definition": "CompleteMissingMembers", "effect": "write nonconflicting missing orbit cells"},
            ],
            "corollary": "an object-centred symmetry group completes missing orbit members independently of the canvas centre",
            "common_notions": [{"name": "local_orbit_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Fitting and consensus inference
# ---------------------------------------------------------------------------


def _fit_simple(programs, pairs):
    result = []
    for program in programs:
        try:
            if all(program.predict(source) == target for source, target in pairs):
                result.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError, KeyError):
            continue
    return result


def _fit_signal(pairs):
    return _fit_simple(
        [DominantSignalComponentCropProgram(connectivity, 2) for connectivity in (4, 8)],
        pairs,
    )


def _fit_outlier(pairs):
    return _fit_simple(
        [RepeatedClassOutlierCropProgram(connectivity, 2) for connectivity in (4, 8)],
        pairs,
    )


def _fit_ring(pairs):
    return _fit_simple([RingCenterColourQueryProgram()], pairs)


def _fit_frame(pairs):
    return _fit_simple([HoledFrameColourQueryProgram(connectivity) for connectivity in (4, 8)], pairs)


def _fit_marker_context(pairs):
    return _fit_simple([MarkerContextMajorityQueryProgram()], pairs)


def _fit_local_closure(pairs):
    fitted = _fit_simple(
        [LocalDihedralOrbitCompletionProgram(group) for group in _TRANSFORM_GROUPS],
        pairs,
    )
    if not fitted:
        return []
    maximum = max(len(_TRANSFORM_GROUPS[program.closure_group]) for program in fitted)
    return [program for program in fitted if len(_TRANSFORM_GROUPS[program.closure_group]) == maximum]


def _role_signature(program, source):
    if isinstance(program, DominantSignalComponentCropProgram):
        _, signal, components, _ = program._analyse(source)
        return (signal.box, signal.colours, signal.area, len(components))
    if isinstance(program, RepeatedClassOutlierCropProgram):
        _, outlier, repeated, _ = program._analyse(source)
        return (outlier.box, outlier.colours, outlier.matrix, tuple(len(group) for group in repeated))
    if isinstance(program, RingCenterColourQueryProgram):
        _, origin, outer, centre, _ = program._analyse(source)
        return (origin, outer, centre)
    if isinstance(program, HoledFrameColourQueryProgram):
        _, frame, colour, _ = program._analyse(source)
        return (frame.box, colour, frame.area)
    if isinstance(program, MarkerContextMajorityQueryProgram):
        marker, contexts, winner, _ = program._analyse(source)
        return (marker, tuple(sorted(contexts.items())), winner)
    if isinstance(program, LocalDihedralOrbitCompletionProgram):
        _, box, additions, _ = program._analyse(source)
        return (box, additions, tuple(sorted(_palette(source))))
    raise Inapplicable("unknown projection programme")


def _role_varies(program, pairs):
    try:
        evidence = [_role_signature(program, source) for source, _ in pairs]
    except (Inapplicable, ValueError, IndexError, TypeError, KeyError):
        return False
    return len({_serial(item) for item in evidence}) >= 2


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "dominant_signal_component_crop" in allowed:
        programs.extend(_fit_signal(pairs))
    if allowed is None or "repeated_class_outlier_crop" in allowed:
        programs.extend(_fit_outlier(pairs))
    if allowed is None or "ring_center_colour_query" in allowed:
        programs.extend(_fit_ring(pairs))
    if allowed is None or "holed_frame_colour_query" in allowed:
        programs.extend(_fit_frame(pairs))
    if allowed is None or "marker_context_majority_query" in allowed:
        programs.extend(_fit_marker_context(pairs))
    if allowed is None or "local_dihedral_orbit_completion" in allowed:
        programs.extend(_fit_local_closure(pairs))
    return programs


def fit_relational_projection_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError, KeyError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_relational_projection(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_relational_projection_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError, KeyError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:30] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "relational_projection_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "relational_projection_algebra": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery and counterfactual validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "dominant_signal_component_crop":
        return DominantSignalComponentCropProgram(int(parameters["connectivity"]), int(parameters["noise_ratio"]))
    if kind == "repeated_class_outlier_crop":
        return RepeatedClassOutlierCropProgram(int(parameters["connectivity"]), int(parameters["minimum_repeated_classes"]))
    if kind == "ring_center_colour_query":
        return RingCenterColourQueryProgram()
    if kind == "holed_frame_colour_query":
        return HoledFrameColourQueryProgram(int(parameters["connectivity"]))
    if kind == "marker_context_majority_query":
        return MarkerContextMajorityQueryProgram()
    if kind == "local_dihedral_orbit_completion":
        return LocalDihedralOrbitCompletionProgram(str(parameters["closure_group"]))
    raise Inapplicable("unknown relational projection schema")


def _signal_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, signal, components, _ = program._analyse(a)
        noise = next(component for component in components if component != signal)
        without_noise = _array(a)
        for r, c in noise.cells:
            without_noise[r][c] = background
        try:
            noise_invariant = program.predict(tuple(tuple(row) for row in without_noise)) == original
        except Inapplicable:
            noise_invariant = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "noise_invariant": noise_invariant,
            "rotation_equivariant": rotation_equivariant,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _outlier_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, _, repeated, _ = program._analyse(a)
        removed = _array(a)
        for r, c in repeated[0][0].cells:
            removed[r][c] = background
        try:
            pairing_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            pairing_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "pairing_necessary": pairing_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _ring_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        _, (r, c), outer, _, _ = program._analyse(a)
        replacement = _fresh_colour(a, (outer,))
        recoloured = _array(a)
        recoloured[r + 1][c + 1] = replacement
        try:
            changed = program.predict(tuple(tuple(row) for row in recoloured))
            centre_controls_answer = changed == ((replacement,),)
        except Inapplicable:
            centre_controls_answer = False
        broken = _array(a)
        broken[r][c] = _unique_modal(a)
        try:
            ring_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            ring_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "centre_controls_answer": centre_controls_answer,
            "ring_necessary": ring_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _frame_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, frame, colour, _ = program._analyse(a)
        r0, c0, r1, c1 = frame.box
        filled = _array(a)
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                if filled[r][c] == background:
                    filled[r][c] = colour
        try:
            hole_necessary = program.predict(tuple(tuple(row) for row in filled)) != original
        except Inapplicable:
            hole_necessary = True
        replacement = _fresh_colour(a, (background,))
        recoloured = _array(a)
        for r, c in frame.cells:
            recoloured[r][c] = replacement
        try:
            recolour_propagates = program.predict(tuple(tuple(row) for row in recoloured)) == ((replacement,),)
        except Inapplicable:
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "hole_necessary": hole_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _marker_context_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        marker, _, _, _ = program._analyse(a)
        background = _unique_modal(a)
        removed = _array(a)
        for r, row in enumerate(a):
            for c, colour in enumerate(row):
                if colour == marker:
                    removed[r][c] = background
        try:
            markers_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            markers_necessary = True
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        for r, row in enumerate(a):
            for c, colour in enumerate(row):
                if colour == marker:
                    recoloured[r][c] = replacement
        try:
            marker_identity_invariant = program.predict(tuple(tuple(row) for row in recoloured)) == original
        except Inapplicable:
            marker_identity_invariant = False
        rotation_equivariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "markers_necessary": markers_necessary,
            "marker_identity_invariant": marker_identity_invariant,
            "rotation_equivariant": rotation_equivariant,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _local_closure_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        idempotent = False
        try:
            program.predict(original)
        except Inapplicable:
            idempotent = True
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        background, box, _, _ = program._analyse(a)
        r0, c0, r1, c1 = box
        conflict = _array(a)
        replacement = _fresh_colour(a)
        injected = False
        transforms = _TRANSFORM_GROUPS[program.closure_group]
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if a[r][c] == background:
                    continue
                lr, lc = r - r0, c - c0
                for transform in transforms[1:]:
                    rr, cc = _transform_local(lr, lc, r1 - r0 + 1, c1 - c0 + 1, transform)
                    gr, gc = r0 + rr, c0 + cc
                    if a[gr][gc] == background:
                        conflict[gr][gc] = replacement
                        injected = True
                        break
                if injected:
                    break
            if injected:
                break
        if not injected:
            conflict_rejected = True
        else:
            try:
                program.predict(tuple(tuple(row) for row in conflict))
                conflict_rejected = False
            except Inapplicable:
                conflict_rejected = True
        rows.append({
            "demonstration": index,
            "closure_idempotent": idempotent,
            "rotation_equivariant": rotation_equivariant,
            "conflict_rejected": conflict_rejected,
        })
    return {"kind": program.kind, "rows": rows, "passed": all(all(value for key, value in row.items() if key != "demonstration") for row in rows)}


def _counterfactual_validation(program, pairs):
    if isinstance(program, DominantSignalComponentCropProgram):
        return _signal_counterfactuals(program, pairs)
    if isinstance(program, RepeatedClassOutlierCropProgram):
        return _outlier_counterfactuals(program, pairs)
    if isinstance(program, RingCenterColourQueryProgram):
        return _ring_counterfactuals(program, pairs)
    if isinstance(program, HoledFrameColourQueryProgram):
        return _frame_counterfactuals(program, pairs)
    if isinstance(program, MarkerContextMajorityQueryProgram):
        return _marker_context_counterfactuals(program, pairs)
    if isinstance(program, LocalDihedralOrbitCompletionProgram):
        return _local_closure_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_relational_projection(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_relational_projection(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError, StopIteration, KeyError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def relational_projection_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_relational_projection_programs(pairs)}))


infer = infer_relational_projection
validate = validate_relational_projection
