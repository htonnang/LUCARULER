"""LUCA V136: anti-unified transfer and cover algebra.

The family factors completion and correspondence reasoning into reusable stages:

    scene -> relation -> operator -> full-grid emission

No task identifier, official test target, or stored demonstration coordinate is
available to inference.  All legends, regions, ranks, scales, and dictionaries
are reconstructed from the current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import (
    Inapplicable,
    _array,
    _bbox,
    _canonical_d4,
    _dirs,
    _foreground_components,
    _mode,
    _palette,
    _shape,
    grid,
)

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anti_unified_transfer_cover_algebra"
LANGUAGE = "spinoza_transfer_cover_algebra_v136"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation, operator, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "relation": relation,
            "operator": operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_correspondence": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _non_background_components(value: Grid, background: int, connectivity: int = 4):
    return _foreground_components(value, background, connectivity)


def _box_cells(box):
    r0, c0, r1, c1 = box
    return {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}


def _extract(value: Grid, box):
    r0, c0, r1, c1 = box
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_cells(cells):
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _unique_mode(value: Grid):
    try:
        return _mode(value)
    except Inapplicable:
        raise


# ---------------------------------------------------------------------------
# 1. Compact legend -> palette involution.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LegendPairPermutationProgram:
    pair_axis: str  # rows: adjacent horizontal pairs; columns: vertical pairs

    kind = "legend_pair_palette_permutation"

    @property
    def schema_key(self):
        return self.kind, self.pair_axis

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        background = _unique_mode(value)
        candidates = []
        for component in _non_background_components(value, background, 4):
            box = _bbox(component)
            r0, c0, r1, c1 = box
            hh, ww = r1 - r0 + 1, c1 - c0 + 1
            if set(component) != _box_cells(box):
                continue
            if not ((r0 == 0 or r1 == h - 1) and (c0 == 0 or c1 == w - 1)):
                continue
            if self.pair_axis == "rows":
                if ww != 2 or hh < 2 or hh > 4:
                    continue
            elif self.pair_axis == "columns":
                if hh != 2 or ww < 2 or ww > 4:
                    continue
            else:
                raise Inapplicable("unknown pair axis")
            cells = [(r, c, value[r][c]) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)]
            colours = [colour for _, _, colour in cells]
            if len(set(colours)) != len(colours):
                continue
            mapping = {}
            if self.pair_axis == "rows":
                for r in range(r0, r1 + 1):
                    left, right = value[r][c0], value[r][c1]
                    mapping[left] = right
                    mapping[right] = left
            else:
                for c in range(c0, c1 + 1):
                    top, bottom = value[r0][c], value[r1][c]
                    mapping[top] = bottom
                    mapping[bottom] = top
            if len(mapping) != len(colours) or any(mapping.get(mapping[colour]) != colour for colour in mapping):
                continue
            outside = [
                value[r][c]
                for r in range(h)
                for c in range(w)
                if not (r0 <= r <= r1 and c0 <= c <= c1) and value[r][c] != background
            ]
            if len(outside) < 4 or set(outside) != set(mapping):
                continue
            candidates.append((box, background, mapping))
        if len(candidates) != 1:
            raise Inapplicable("palette-pair legend not unique")
        return candidates[0]

    def predict(self, value):
        value = grid(value)
        box, _, mapping = self.analyse(value)
        r0, c0, r1, c1 = box
        out = _array(value)
        changed = 0
        for r, row in enumerate(value):
            for c, colour in enumerate(row):
                if r0 <= r <= r1 and c0 <= c <= c1:
                    continue
                if colour in mapping:
                    out[r][c] = mapping[colour]
                    changed += int(mapping[colour] != colour)
        if changed < 2:
            raise Inapplicable("palette permutation has no material consequence")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="corner_compact_palette_legend_plus_coloured_scene",
            relation="pairwise_legend_correspondence",
            operator="correspondence_transfer",
            parameters={"pair_axis": self.pair_axis},
            definitions={
                "legend": "a filled, distinct-colour corner block",
                "pair": "two colours sharing one legend row or column",
            },
            propositions=[
                "Legend colours are paired by structural position rather than identity.",
                "The legend remains fixed while every outside occurrence is exchanged with its mate.",
            ],
            corollary="Apply the input-derived palette involution to the scene outside the legend.",
            common_notions=["correspondence", "involution", "palette role", "structural legend"],
        )


def _fit_legend_pair_permutation(pairs):
    programs = []
    for axis in ("rows", "columns"):
        program = LegendPairPermutationProgram(axis)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 2. Border legend -> exact coordinate projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AxisLegendProjectionProgram:
    orientation: str  # column maps rows; row maps columns

    kind = "axis_legend_coordinate_projection"

    @property
    def schema_key(self):
        return self.kind, self.orientation

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        background = _unique_mode(value)
        candidates = []
        if self.orientation == "column":
            lines = [("left", 0), ("right", w - 1)]
            for side, column in lines:
                legend = {r: value[r][column] for r in range(h) if value[r][column] != background}
                if len(legend) < 2 or len(set(legend.values())) < 2:
                    continue
                outside = [
                    value[r][c]
                    for r in range(h)
                    for c in range(w)
                    if c != column and value[r][c] != background
                ]
                colours = set(outside)
                if len(colours) != 1:
                    continue
                source = next(iter(colours))
                cells = [(r, c) for r in range(h) for c in range(w) if c != column and value[r][c] == source]
                if not cells or {r for r, _ in cells} != set(legend):
                    continue
                candidates.append((side, column, background, source, legend, tuple(cells)))
        elif self.orientation == "row":
            lines = [("top", 0), ("bottom", h - 1)]
            for side, row in lines:
                legend = {c: value[row][c] for c in range(w) if value[row][c] != background}
                if len(legend) < 2 or len(set(legend.values())) < 2:
                    continue
                outside = [
                    value[r][c]
                    for r in range(h)
                    for c in range(w)
                    if r != row and value[r][c] != background
                ]
                colours = set(outside)
                if len(colours) != 1:
                    continue
                source = next(iter(colours))
                cells = [(r, c) for r in range(h) for c in range(w) if r != row and value[r][c] == source]
                if not cells or {c for _, c in cells} != set(legend):
                    continue
                candidates.append((side, row, background, source, legend, tuple(cells)))
        else:
            raise Inapplicable("unknown legend orientation")
        if len(candidates) != 1:
            raise Inapplicable("axis legend not unique")
        return candidates[0]

    def predict(self, value):
        value = grid(value)
        _, _, _, _, legend, cells = self.analyse(value)
        out = _array(value)
        for r, c in cells:
            out[r][c] = legend[r if self.orientation == "column" else c]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="border_legend_and_monochrome_recipient_support",
            relation="shared_axis_coordinate",
            operator="correspondence_transfer",
            parameters={"orientation": self.orientation},
            definitions={
                "legend_coordinate": "one coloured border entry indexed by row or column",
                "recipient": "a source-colour cell sharing that coordinate",
            },
            propositions=[
                "Every recipient coordinate has one legend colour.",
                "Legend colours are projected along the orthogonal axis without moving material.",
            ],
            corollary="Recolour each recipient from the border legend at the same axis coordinate.",
            common_notions=["alignment", "coordinate role", "projection", "legend"],
        )


def _fit_axis_legend_projection(pairs):
    programs = []
    for orientation in ("column", "row"):
        program = AxisLegendProjectionProgram(orientation)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 3. Corner matrix legend -> normalized spatial bins.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SpatialBinLegendTransferProgram:
    legend_size: int

    kind = "spatial_bin_legend_transfer"

    @property
    def schema_key(self):
        return self.kind, self.legend_size

    @staticmethod
    def _regions(h, w, k, corner):
        if corner == "top_left":
            legend = (0, 0, k - 1, k - 1)
            recipient = (k, k, h - 1, w - 1)
            bands = [((0, k, k - 1, w - 1)), ((k, 0, h - 1, k - 1))]
        elif corner == "top_right":
            legend = (0, w - k, k - 1, w - 1)
            recipient = (k, 0, h - 1, w - k - 1)
            bands = [((0, 0, k - 1, w - k - 1)), ((k, w - k, h - 1, w - 1))]
        elif corner == "bottom_left":
            legend = (h - k, 0, h - 1, k - 1)
            recipient = (0, k, h - k - 1, w - 1)
            bands = [((h - k, k, h - 1, w - 1)), ((0, 0, h - k - 1, k - 1))]
        elif corner == "bottom_right":
            legend = (h - k, w - k, h - 1, w - 1)
            recipient = (0, 0, h - k - 1, w - k - 1)
            bands = [((h - k, 0, h - 1, w - k - 1)), ((0, w - k, h - k - 1, w - 1))]
        else:
            raise Inapplicable("unknown corner")
        return legend, recipient, bands

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        k = self.legend_size
        if h < 3 * k or w < 3 * k:
            raise Inapplicable("scene too small for normalized legend")
        candidates = []
        for corner in ("top_left", "top_right", "bottom_left", "bottom_right"):
            legend_box, recipient_box, band_boxes = self._regions(h, w, k, corner)
            legend_grid = _extract(value, legend_box)
            legend_values = [cell for row in legend_grid for cell in row]
            if len(set(legend_values)) != k * k:
                continue
            band_values = []
            for box in band_boxes:
                r0, c0, r1, c1 = box
                if r0 <= r1 and c0 <= c1:
                    band_values.extend(value[r][c] for r in range(r0, r1 + 1) for c in range(c0, c1 + 1))
            if not band_values or len(set(band_values)) != 1:
                continue
            neutral = band_values[0]
            if neutral in set(legend_values):
                continue
            rr0, cc0, rr1, cc1 = recipient_box
            rh, rw = rr1 - rr0 + 1, cc1 - cc0 + 1
            if rh <= 0 or rw <= 0 or rh % k or rw % k:
                continue
            recipient_values = [value[r][c] for r in range(rr0, rr1 + 1) for c in range(cc0, cc1 + 1)]
            rec_counts = Counter(recipient_values)
            if len(rec_counts) != 2:
                continue
            best = max(rec_counts.values())
            backgrounds = [colour for colour, count in rec_counts.items() if count == best]
            if len(backgrounds) != 1:
                continue
            background = backgrounds[0]
            source = next(colour for colour in rec_counts if colour != background)
            source_cells = [(r, c) for r in range(rr0, rr1 + 1) for c in range(cc0, cc1 + 1) if value[r][c] == source]
            if len(source_cells) < k * k:
                continue
            candidates.append((corner, legend_box, recipient_box, legend_grid, neutral, background, source, tuple(source_cells)))
        if len(candidates) != 1:
            raise Inapplicable("corner matrix legend not unique")
        return candidates[0]

    def predict(self, value):
        value = grid(value)
        _, _, recipient_box, legend_grid, _, _, _, source_cells = self.analyse(value)
        rr0, cc0, rr1, cc1 = recipient_box
        rh, rw = rr1 - rr0 + 1, cc1 - cc0 + 1
        k = self.legend_size
        out = _array(value)
        used = set()
        for r, c in source_cells:
            br = min(k - 1, (r - rr0) * k // rh)
            bc = min(k - 1, (c - cc0) * k // rw)
            out[r][c] = legend_grid[br][bc]
            used.add((br, bc))
        if len(used) < 2:
            raise Inapplicable("source does not witness multiple spatial roles")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="corner_colour_matrix_with_neutral_bands_and_recipient_field",
            relation="normalized_spatial_bin_correspondence",
            operator="correspondence_transfer",
            parameters={"legend_size": self.legend_size},
            definitions={
                "spatial_bin": "one normalized row/column partition of the recipient field",
                "legend_cell": "the colour occupying the homologous legend position",
            },
            propositions=[
                "Recipient coordinates are normalized independently of legend corner.",
                "Each source cell receives the colour of its homologous legend bin.",
            ],
            corollary="Transfer the corner legend matrix to source cells by normalized spatial role.",
            common_notions=["homology", "normalized coordinate", "spatial partition", "legend transfer"],
        )


def _fit_spatial_bin_legend(pairs):
    programs = []
    for size in (2, 3, 4):
        program = SpatialBinLegendTransferProgram(size)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 4. Ordered axis classes -> semantic colour sequence.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OrderedAxisClassRecolourProgram:
    axis: str
    output_colours: tuple[int, ...]

    kind = "ordered_axis_class_recolour"

    @property
    def schema_key(self):
        return self.kind, self.axis, self.output_colours

    def analyse(self, value):
        value = grid(value)
        counts = Counter(cell for row in value for cell in row)
        if len(counts) != 2:
            raise Inapplicable("ordered-axis source must be binary")
        best = max(counts.values())
        backgrounds = [colour for colour, count in counts.items() if count == best]
        if len(backgrounds) != 1:
            raise Inapplicable("background role tied")
        background = backgrounds[0]
        source = next(colour for colour in counts if colour != background)
        cells = [(r, c) for r, row in enumerate(value) for c, colour in enumerate(row) if colour == source]
        coordinates = sorted({c if self.axis == "columns" else r for r, c in cells})
        if len(coordinates) != len(self.output_colours) or len(coordinates) < 3:
            raise Inapplicable("ordered class cardinality differs")
        groups = {coordinate: [] for coordinate in coordinates}
        for r, c in cells:
            groups[c if self.axis == "columns" else r].append((r, c))
        if max(len(group) for group in groups.values()) < 2:
            raise Inapplicable("axis classes are not structurally witnessed")
        return background, source, coordinates, groups

    def predict(self, value):
        value = grid(value)
        _, _, coordinates, groups = self.analyse(value)
        out = _array(value)
        for coordinate, colour in zip(coordinates, self.output_colours):
            for r, c in groups[coordinate]:
                out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="binary_field_with_repeated_axis_classes",
            relation="ordered_coordinate_rank",
            operator="correspondence_transfer",
            parameters={"axis": self.axis, "output_colours": list(self.output_colours)},
            definitions={
                "axis_class": "all source cells sharing one row or column",
                "rank": "the left-to-right or top-to-bottom order of a class",
            },
            propositions=[
                "Class identity is determined by coordinate rank, not absolute position.",
                "All members of one class receive the same learned semantic colour.",
            ],
            corollary="Recolour source classes by their ordered axis rank.",
            common_notions=["rank", "equivalence class", "coordinate order", "recolouring"],
        )


def _fit_ordered_axis_classes(pairs):
    programs = []
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return programs
    for axis in ("columns", "rows"):
        learned = None
        valid = True
        for source, target in pairs:
            source, target = grid(source), grid(target)
            counts = Counter(cell for row in source for cell in row)
            if len(counts) != 2:
                valid = False
                break
            best = max(counts.values())
            backgrounds = [colour for colour, count in counts.items() if count == best]
            if len(backgrounds) != 1:
                valid = False
                break
            background = backgrounds[0]
            source_colour = next(colour for colour in counts if colour != background)
            cells = [(r, c) for r, row in enumerate(source) for c, value in enumerate(row) if value == source_colour]
            coords = sorted({c if axis == "columns" else r for r, c in cells})
            if not (3 <= len(coords) <= 8):
                valid = False
                break
            palette = []
            for coordinate in coords:
                positions = [(r, c) for r, c in cells if (c if axis == "columns" else r) == coordinate]
                values = {target[r][c] for r, c in positions}
                if len(values) != 1:
                    valid = False
                    break
                palette.append(next(iter(values)))
            if not valid:
                break
            if len(set(palette)) != len(palette):
                valid = False
                break
            for r, row in enumerate(source):
                for c, value in enumerate(row):
                    if value == background and target[r][c] != background:
                        valid = False
                        break
                if not valid:
                    break
            palette = tuple(palette)
            if learned is None:
                learned = palette
            elif learned != palette:
                valid = False
                break
        if valid and learned:
            program = OrderedAxisClassRecolourProgram(axis, learned)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 5. Full separator rows/columns -> highlighted cover.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FullSeparatorHighlightProgram:
    replacement_colour: int

    kind = "full_separator_line_highlight"

    @property
    def schema_key(self):
        return self.kind, self.replacement_colour

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        if len(_palette(value)) != 2 or self.replacement_colour in _palette(value):
            raise Inapplicable("separator scene must be binary with fresh consequence colour")
        candidates = []
        for separator in sorted(_palette(value)):
            rows = tuple(r for r in range(h) if all(value[r][c] == separator for c in range(w)))
            cols = tuple(c for c in range(w) if all(value[r][c] == separator for r in range(h)))
            if len(rows) + len(cols) < 2:
                continue
            covered = {(r, c) for r in rows for c in range(w)} | {(r, c) for c in cols for r in range(h)}
            if not covered or len(covered) == h * w:
                continue
            candidates.append((separator, rows, cols, covered))
        if len(candidates) != 1:
            raise Inapplicable("separator line system not unique")
        return candidates[0]

    def predict(self, value):
        value = grid(value)
        _, _, _, covered = self.analyse(value)
        out = _array(value)
        for r, c in covered:
            out[r][c] = self.replacement_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="binary_texture_with_complete_separator_lines",
            relation="full_row_or_column_membership",
            operator="derived_cover_completion",
            parameters={"replacement_colour": self.replacement_colour},
            definitions={
                "separator_line": "a complete row or column of one input colour",
                "cover": "the union of all separator-line cells",
            },
            propositions=[
                "Only complete separator lines qualify.",
                "Intersections and every other separator-line cell receive one semantic colour.",
            ],
            corollary="Highlight the union of all complete separator rows and columns.",
            common_notions=["line completion", "set union", "membership", "separator"],
        )


def _fit_full_separator_highlight(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    introduced = None
    for source, target in pairs:
        new = _palette(grid(target)) - _palette(grid(source))
        if len(new) != 1:
            return []
        introduced = new if introduced is None else introduced & new
    if not introduced:
        return []
    programs = []
    for colour in sorted(introduced):
        program = FullSeparatorHighlightProgram(colour)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 6. Solid rectangle -> one-cell-border interior completion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SolidRectangleInteriorFillProgram:
    replacement_colour: int
    border_thickness: int = 1

    kind = "solid_rectangle_interior_fill"

    @property
    def schema_key(self):
        return self.kind, self.replacement_colour, self.border_thickness

    def analyse(self, value):
        value = grid(value)
        counts = Counter(cell for row in value for cell in row)
        if len(counts) != 2 or self.replacement_colour in counts:
            raise Inapplicable("rectangle completion requires binary input and fresh colour")
        candidates = []
        for background in sorted(counts):
            foreground = next(colour for colour in counts if colour != background)
            components = _non_background_components(value, background, 4)
            boxes = []
            valid = True
            for component in components:
                box = _bbox(component)
                r0, c0, r1, c1 = box
                if set(component) != _box_cells(box):
                    valid = False
                    break
                if r1 - r0 + 1 < 2 * self.border_thickness + 1 or c1 - c0 + 1 < 2 * self.border_thickness + 1:
                    valid = False
                    break
                boxes.append(box)
            if valid and len(boxes) >= 2:
                candidates.append((background, foreground, tuple(boxes)))
        if len(candidates) != 1:
            raise Inapplicable("solid rectangle interpretation not unique")
        return candidates[0]

    def predict(self, value):
        value = grid(value)
        _, _, boxes = self.analyse(value)
        out = _array(value)
        t = self.border_thickness
        for r0, c0, r1, c1 in boxes:
            for r in range(r0 + t, r1 - t + 1):
                for c in range(c0 + t, c1 - t + 1):
                    out[r][c] = self.replacement_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="multiple_solid_monochrome_rectangles",
            relation="distance_from_component_boundary",
            operator="derived_cover_completion",
            parameters={"replacement_colour": self.replacement_colour, "border_thickness": self.border_thickness},
            definitions={
                "border": "cells within the learned thickness of a rectangle boundary",
                "interior": "all rectangle cells outside that border cover",
            },
            propositions=[
                "Every foreground component is a solid rectangle.",
                "The border is invariant and the strict interior receives one semantic colour.",
            ],
            corollary="Fill each rectangle interior while retaining its boundary frame.",
            common_notions=["region completion", "boundary distance", "interior", "rectangle"],
        )


def _fit_rectangle_interior(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    introduced = None
    for source, target in pairs:
        new = _palette(grid(target)) - _palette(grid(source))
        if len(new) != 1:
            return []
        introduced = new if introduced is None else introduced & new
    programs = []
    for colour in sorted(introduced or ()):
        for thickness in (1, 2):
            program = SolidRectangleInteriorFillProgram(colour, thickness)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 7. Corner seed -> periodic completion of its rectangular canvas.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PeriodicSeedCompletionProgram:
    kind = "corner_seed_periodic_completion"

    @property
    def schema_key(self):
        return (self.kind,)

    def analyse(self, value):
        value = grid(value)
        outside = _unique_mode(value)
        components = _non_background_components(value, outside, 4)
        if not components:
            raise Inapplicable("no periodic canvases")
        records = []
        canvas_background = None
        for component in components:
            box = _bbox(component)
            if set(component) != _box_cells(box):
                raise Inapplicable("canvas is not rectangular")
            r0, c0, r1, c1 = box
            sub = _extract(value, box)
            sub_counts = Counter(cell for row in sub for cell in row)
            if len(sub_counts) != 2:
                raise Inapplicable("canvas must contain one background and one seed colour")
            best = max(sub_counts.values())
            backgrounds = [colour for colour, count in sub_counts.items() if count == best]
            if len(backgrounds) != 1:
                raise Inapplicable("canvas background tied")
            local_background = backgrounds[0]
            seed_colour = next(colour for colour in sub_counts if colour != local_background)
            if canvas_background is None:
                canvas_background = local_background
            elif canvas_background != local_background:
                raise Inapplicable("canvas backgrounds disagree")
            seed = [(rr, cc) for rr, row in enumerate(sub) for cc, colour in enumerate(row) if colour == seed_colour]
            if len(seed) < 2:
                raise Inapplicable("seed too small")
            sr0, sc0, sr1, sc1 = _bbox(seed)
            sh, sw = sr1 - sr0 + 1, sc1 - sc0 + 1
            ch, cw = _shape(sub)
            touches_h = int(sr0 == 0) + int(sr1 == ch - 1)
            touches_w = int(sc0 == 0) + int(sc1 == cw - 1)
            if touches_h != 1 or touches_w != 1:
                raise Inapplicable("seed must occupy one canvas corner")
            if sh < 2 or sw < 2 or ch % sh or cw % sw or (ch == sh and cw == sw):
                raise Inapplicable("canvas is not tiled by seed extent")
            mask = frozenset((rr - sr0, cc - sc0) for rr, cc in seed)
            if len(mask) == sh * sw:
                raise Inapplicable("seed must include foreground and background roles")
            records.append((box, local_background, seed_colour, (sh, sw), mask))
        return outside, tuple(records)

    def predict(self, value):
        value = grid(value)
        _, records = self.analyse(value)
        out = _array(value)
        changed = 0
        for box, background, seed_colour, (sh, sw), mask in records:
            r0, c0, r1, c1 = box
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    colour = seed_colour if ((r - r0) % sh, (c - c0) % sw) in mask else background
                    changed += int(out[r][c] != colour)
                    out[r][c] = colour
        if changed < 2:
            raise Inapplicable("periodic completion adds no material")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="rectangular_canvases_with_corner_seed_motifs",
            relation="modular_coordinate_equivalence",
            operator="derived_cover_completion",
            parameters={},
            definitions={
                "seed": "the compact two-colour motif touching one canvas corner",
                "periodic_class": "canvas cells with equal coordinates modulo the seed extent",
            },
            propositions=[
                "The canvas dimensions are integer multiples of the seed extent.",
                "Every modularly homologous cell inherits the seed role.",
            ],
            corollary="Complete each canvas by periodically extending its corner seed.",
            common_notions=["periodicity", "modular coordinate", "seed", "completion"],
        )


def _fit_periodic_seed(pairs):
    program = PeriodicSeedCompletionProgram()
    try:
        return [program] if all(program.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


# ---------------------------------------------------------------------------
# 8. Shape-colour dictionary -> bidirectional panel codec.
# ---------------------------------------------------------------------------


def _colour_components_in_region(value, box, background):
    r0, c0, r1, c1 = box
    records = {}
    colours = sorted({value[r][c] for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)} - {background})
    for colour in colours:
        cells = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if value[r][c] == colour}
        if not cells:
            continue
        # Dictionary symbols may be disconnected pixel masks.  They must,
        # however, be compact and localized as one side-band glyph.
        box = _bbox(cells)
        rr0, cc0, rr1, cc1 = box
        if len(cells) < 2 or rr1 - rr0 + 1 > 5 or cc1 - cc0 + 1 > 5:
            raise Inapplicable("dictionary colour is not one compact glyph")
        records[colour] = {
            "cells": frozenset(cells),
            "normalised": _normalised_cells(cells),
            "canonical": _canonical_d4(cells),
            "box": _bbox(cells),
        }
    return records


@dataclass(frozen=True)
class SymbolDictionaryCodecProgram:
    band_orientation: str
    panel_base: int
    mask_colour: int

    kind = "shape_colour_dictionary_codec"

    @property
    def schema_key(self):
        return self.kind, self.band_orientation, self.panel_base, self.mask_colour

    def _candidate_scenes(self, value):
        value = grid(value)
        h, w = _shape(value)
        scenes = []
        orientations = (self.band_orientation,)
        for orientation in orientations:
            if orientation == "vertical":
                widths = range(3, min(9, w - 2))
                sides = ("left", "right")
                for width in widths:
                    for side in sides:
                        band = (0, 0, h - 1, width - 1) if side == "left" else (0, w - width, h - 1, w - 1)
                        field = (0, width, h - 1, w - 1) if side == "left" else (0, 0, h - 1, w - width - 1)
                        scenes.extend(self._analyse_partition(value, band, field, orientation, side))
            elif orientation == "horizontal":
                heights = range(3, min(9, h - 2))
                sides = ("top", "bottom")
                for height in heights:
                    for side in sides:
                        band = (0, 0, height - 1, w - 1) if side == "top" else (h - height, 0, h - 1, w - 1)
                        field = (height, 0, h - 1, w - 1) if side == "top" else (0, 0, h - height - 1, w - 1)
                        scenes.extend(self._analyse_partition(value, band, field, orientation, side))
            else:
                raise Inapplicable("unknown dictionary-band orientation")
        return scenes

    def _analyse_partition(self, value, band, field, orientation, side):
        br0, bc0, br1, bc1 = band
        fr0, fc0, fr1, fc1 = field
        if fr0 > fr1 or fc0 > fc1:
            return []
        band_grid = _extract(value, band)
        try:
            legend_background = _mode(band_grid)
        except Inapplicable:
            return []
        try:
            dictionary = _colour_components_in_region(value, band, legend_background)
        except Inapplicable:
            return []
        if len(dictionary) < 3:
            return []
        canonical_to_colour = defaultdict(list)
        for colour, record in dictionary.items():
            canonical_to_colour[record["canonical"]].append(colour)
        if any(len(colours) != 1 for colours in canonical_to_colour.values()):
            return []
        field_grid = _extract(value, field)
        try:
            field_background = _mode(field_grid)
        except Inapplicable:
            return []
        # Extract all non-background components in the field and require solid
        # rectangular supports of a common size.
        local_components = _foreground_components(field_grid, field_background, 4)
        if len(local_components) < 4:
            return []
        panel_records = []
        dimensions = set()
        for component in local_components:
            local_box = _bbox(component)
            lr0, lc0, lr1, lc1 = local_box
            if set(component) != _box_cells(local_box):
                return []
            dimensions.add((lr1 - lr0 + 1, lc1 - lc0 + 1))
            global_box = (fr0 + lr0, fc0 + lc0, fr0 + lr1, fc0 + lc1)
            panel_records.append(global_box)
        if len(dimensions) != 1:
            return []
        ph, pw = next(iter(dimensions))
        if ph < 3 or pw < 3:
            return []
        patterned = 0
        decoded = []
        for box in panel_records:
            panel = _extract(value, box)
            palette = _palette(panel)
            if len(palette) == 1:
                key = next(iter(palette))
                if key not in dictionary:
                    return []
                decoded.append((box, "colour", key, None))
            elif palette == {self.panel_base, self.mask_colour}:
                base_count = sum(cell == self.panel_base for row in panel for cell in row)
                mask_cells = [(r, c) for r, row in enumerate(panel) for c, cell in enumerate(row) if cell == self.mask_colour]
                if base_count <= len(mask_cells) or len(mask_cells) < 2:
                    return []
                canonical = _canonical_d4(mask_cells)
                colours = canonical_to_colour.get(canonical, [])
                if len(colours) != 1:
                    return []
                patterned += 1
                decoded.append((box, "shape", colours[0], tuple(mask_cells)))
            else:
                return []
        if patterned < 1:
            return []
        return [{
            "orientation": orientation,
            "side": side,
            "band": band,
            "field": field,
            "legend_background": legend_background,
            "field_background": field_background,
            "dictionary": dictionary,
            "panels": tuple(decoded),
            "panel_shape": (ph, pw),
        }]

    def analyse(self, value):
        candidates = self._candidate_scenes(value)
        # Different candidate band widths can describe the same physical scene.
        # Canonicalize by field, panel boxes, and dictionary colours.
        unique = {}
        for scene in candidates:
            key = (
                scene["field"],
                tuple(item[0] for item in scene["panels"]),
                tuple(sorted(scene["dictionary"])),
            )
            unique[key] = scene
        if len(unique) != 1:
            raise Inapplicable("shape-colour dictionary scene not unique")
        return next(iter(unique.values()))

    def predict(self, value):
        value = grid(value)
        scene = self.analyse(value)
        ph, pw = scene["panel_shape"]
        out = _array(value)
        for box, representation, key, _ in scene["panels"]:
            r0, c0, r1, c1 = box
            if representation == "shape":
                for r in range(r0, r1 + 1):
                    for c in range(c0, c1 + 1):
                        out[r][c] = key
            else:
                record = scene["dictionary"][key]
                normalised = record["normalised"]
                sh = max(r for r, _ in normalised) + 1
                sw = max(c for _, c in normalised) + 1
                if sh > ph or sw > pw or (ph - sh) % 2 or (pw - sw) % 2:
                    raise Inapplicable("dictionary symbol cannot be centred in panel")
                ro, co = (ph - sh) // 2, (pw - sw) // 2
                for r in range(r0, r1 + 1):
                    for c in range(c0, c1 + 1):
                        out[r][c] = self.panel_base
                for rr, cc in normalised:
                    out[r0 + ro + rr][c0 + co + cc] = self.mask_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="side_symbol_dictionary_and_equal_rectangular_message_panels",
            relation="D4_shape_to_colour_bijection",
            operator="correspondence_transfer",
            parameters={
                "band_orientation": self.band_orientation,
                "panel_base": self.panel_base,
                "mask_colour": self.mask_colour,
            },
            definitions={
                "dictionary_symbol": "one monochrome side-band component keyed by its colour",
                "shape_message": "a base panel containing a D4-equivalent mask",
                "colour_message": "a uniform panel filled by one dictionary key colour",
            },
            propositions=[
                "A shape message is encoded as its corresponding uniform key colour.",
                "A uniform key colour is decoded as the centred dictionary shape in the panel alphabet.",
            ],
            corollary="Toggle each panel between homologous shape and colour representations.",
            common_notions=["dictionary", "D4 equivalence", "encoding", "decoding", "correspondence"],
        )


def _dictionary_parameter_candidates(value):
    value = grid(value)
    candidates = set()
    h, w = _shape(value)
    for orientation in ("vertical", "horizontal"):
        # Generate plausible base/mask pairs from rectangular components in the
        # complement of every side band.  Full validation remains in predict().
        if orientation == "vertical":
            spans = [("left", width) for width in range(3, min(9, w - 2))] + [("right", width) for width in range(3, min(9, w - 2))]
            for side, width in spans:
                field = (0, width, h - 1, w - 1) if side == "left" else (0, 0, h - 1, w - width - 1)
                fr0, fc0, fr1, fc1 = field
                try:
                    background = _mode(_extract(value, field))
                except Inapplicable:
                    continue
                local = _extract(value, field)
                for component in _foreground_components(local, background, 4):
                    box = _bbox(component)
                    if set(component) != _box_cells(box):
                        continue
                    panel = _extract(local, box)
                    pal = _palette(panel)
                    if len(pal) == 2:
                        cnt = Counter(cell for row in panel for cell in row)
                        base = max(cnt, key=cnt.get)
                        mask = next(colour for colour in pal if colour != base)
                        candidates.add((orientation, base, mask))
        else:
            spans = [("top", height) for height in range(3, min(9, h - 2))] + [("bottom", height) for height in range(3, min(9, h - 2))]
            for side, height in spans:
                field = (height, 0, h - 1, w - 1) if side == "top" else (0, 0, h - height - 1, w - 1)
                try:
                    background = _mode(_extract(value, field))
                except Inapplicable:
                    continue
                local = _extract(value, field)
                for component in _foreground_components(local, background, 4):
                    box = _bbox(component)
                    if set(component) != _box_cells(box):
                        continue
                    panel = _extract(local, box)
                    pal = _palette(panel)
                    if len(pal) == 2:
                        cnt = Counter(cell for row in panel for cell in row)
                        base = max(cnt, key=cnt.get)
                        mask = next(colour for colour in pal if colour != base)
                        candidates.add((orientation, base, mask))
    return candidates


def _fit_symbol_dictionary_codec(pairs):
    if not pairs:
        return []
    candidates = _dictionary_parameter_candidates(grid(pairs[0][0]))
    programs = []
    for orientation, base, mask in sorted(candidates):
        program = SymbolDictionaryCodecProgram(orientation, base, mask)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


_FITTERS = {
    "legend_pair_palette_permutation": _fit_legend_pair_permutation,
    "axis_legend_coordinate_projection": _fit_axis_legend_projection,
    "spatial_bin_legend_transfer": _fit_spatial_bin_legend,
    "ordered_axis_class_recolour": _fit_ordered_axis_classes,
    "full_separator_line_highlight": _fit_full_separator_highlight,
    "solid_rectangle_interior_fill": _fit_rectangle_interior,
    "corner_seed_periodic_completion": _fit_periodic_seed,
    "shape_colour_dictionary_codec": _fit_symbol_dictionary_codec,
}


def fit_transfer_cover_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    programs = []
    seen = set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        for program in fitter(pairs):
            if program.schema_key not in seen:
                seen.add(program.schema_key)
                programs.append(program)
    return programs


def _counterfactual(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        detail = {}
        try:
            if isinstance(program, LegendPairPermutationProgram):
                box, background, _ = program.analyse(source)
                r0, c0, _, _ = box
                work = _array(source)
                work[r0][c0] = background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"legend_pair_break_changes_or_rejects": passed}

            elif isinstance(program, AxisLegendProjectionProgram):
                _, line, background, _, legend, _ = program.analyse(source)
                coordinate = next(iter(legend))
                work = _array(source)
                if program.orientation == "column":
                    work[coordinate][line] = background
                else:
                    work[line][coordinate] = background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"legend_coordinate_removal_changes_or_rejects": passed}

            elif isinstance(program, SpatialBinLegendTransferProgram):
                _, legend_box, _, _, neutral, _, _, _ = program.analyse(source)
                r0, c0, _, _ = legend_box
                work = _array(source)
                work[r0][c0] = neutral
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"legend_matrix_damage_changes_or_rejects": passed}

            elif isinstance(program, OrderedAxisClassRecolourProgram):
                background, _, _, groups = program.analyse(source)
                coordinate = next(iter(groups))
                r, c = groups[coordinate][0]
                work = _array(source)
                work[r][c] = background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"axis_class_intervention_changes_or_rejects": passed}

            elif isinstance(program, FullSeparatorHighlightProgram):
                separator, rows0, cols0, _ = program.analyse(source)
                other = next(colour for colour in _palette(source) if colour != separator)
                work = _array(source)
                if rows0:
                    work[rows0[0]][0] = other
                else:
                    work[0][cols0[0]] = other
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"separator_break_changes_or_rejects": passed}

            elif isinstance(program, SolidRectangleInteriorFillProgram):
                background, _, boxes = program.analyse(source)
                r0, c0, _, _ = boxes[0]
                work = _array(source)
                work[r0][c0] = background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"rectangle_break_changes_or_rejects": passed}

            elif isinstance(program, PeriodicSeedCompletionProgram):
                _, records = program.analyse(source)
                box, background, seed_colour, _, mask = records[0]
                r0, c0, r1, c1 = box
                cell = next(
                    (r, c)
                    for r in range(r0, r1 + 1)
                    for c in range(c0, c1 + 1)
                    if source[r][c] == seed_colour
                )
                work = _array(source)
                work[cell[0]][cell[1]] = background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"seed_damage_changes_or_rejects": passed}

            elif isinstance(program, SymbolDictionaryCodecProgram):
                scene = program.analyse(source)
                key = next(iter(scene["dictionary"]))
                cell = next(iter(scene["dictionary"][key]["cells"]))
                work = _array(source)
                work[cell[0]][cell[1]] = scene["legend_background"]
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                detail = {"dictionary_symbol_damage_changes_or_rejects": passed}
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **detail})
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_transfer_cover_algebra(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_transfer_cover_programs(pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds)
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_transfer_cover_algebra": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programs_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = []
    for program in fit_transfer_cover_programs(pairs, minimum_pairs=2, allowed_kinds=allowed):
        try:
            if (
                tuple(program.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(program, pairs).get("passed")
            ):
                programs.append(program)
        except Inapplicable:
            pass
    return expected, programs


def _validate_program(clean, program, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_transfer_cover_programs(remaining, minimum_pairs=1, allowed_kinds=(program.kind,))
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(program, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual.get("passed")
    return {
        "passed": bool(passed),
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_transfer_cover_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programs = _programs_for_expected(clean, full)
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_program(clean, program, expected) for program in programs]
    passed = any(check.get("passed") for check in checks)
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": next((check["folds"] for check in checks if check.get("passed")), checks[0]["folds"]),
        "counterfactuals": [item for check in checks for item in check.get("counterfactuals", [])],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
