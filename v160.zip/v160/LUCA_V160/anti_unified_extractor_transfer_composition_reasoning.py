"""LUCA V146: anti-unified extractors and bounded transfer composition.

The family expresses seven ARC transformations through two consequence
operators:

    scene -> typed nodes -> typed edges -> bounded relation chain
          -> shared consequence operator -> deterministic full grid -> proof

Inference is task-ID blind and test-target blind.  Colours, directions,
scales, panels, reflections, legends, and ownership relations are inferred
from the demonstrations and current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations, product

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anti_unified_extractor_transfer_composition"
LANGUAGE = "spinoza_anti_unified_extractor_transfer_composition_v146"
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Shared evidence language and structural helpers.
# ---------------------------------------------------------------------------


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "anti_unified_extractors": True,
            "bounded_transfer_composition": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, *, colour=None, connectivity=4, include_background=False):
    value = grid(value)
    h, w = _shape(value)
    background = _mode(value)
    if connectivity == 4:
        directions = ((-1, 0), (1, 0), (0, -1), (0, 1))
    else:
        directions = tuple(
            (dr, dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr, dc) != (0, 0)
        )
    seen = set()
    output = []
    for r in range(h):
        for c in range(w):
            cell_colour = value[r][c]
            if (r, c) in seen:
                continue
            if not include_background and cell_colour == background:
                continue
            if colour is not None and cell_colour != colour:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w) or (nr, nc) in seen:
                        continue
                    if value[nr][nc] == cell_colour:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append({
                "colour": int(cell_colour),
                "cells": frozenset(cells),
                "bbox": _bbox(cells),
            })
    return output


def _mixed_components(value: Grid, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    background = _mode(value)
    directions = ((-1, 0), (1, 0), (0, -1), (0, 1)) if connectivity == 4 else tuple(
        (dr, dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr, dc) != (0, 0)
    )
    seen, output = set(), []
    for r in range(h):
        for c in range(w):
            if value[r][c] == background or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w) or (nr, nc) in seen:
                        continue
                    if value[nr][nc] != background:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append({
                "cells": frozenset(cells),
                "colours": frozenset(value[rr][cc] for rr, cc in cells),
                "bbox": _bbox(cells),
            })
    return output


def _filled_rectangle(cells):
    cells = frozenset(cells)
    r0, c0, r1, c1 = _bbox(cells)
    return cells == frozenset((r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1))


def _line_between(a, b):
    dr = b[0] - a[0]
    dc = b[1] - a[1]
    if dr == 0:
        step = (0, 1 if dc > 0 else -1)
        length = abs(dc)
    elif dc == 0:
        step = (1 if dr > 0 else -1, 0)
        length = abs(dr)
    elif abs(dr) == abs(dc):
        step = (1 if dr > 0 else -1, 1 if dc > 0 else -1)
        length = abs(dr)
    else:
        raise Inapplicable("not an axis or 45-degree line")
    return tuple((a[0] + index * step[0], a[1] + index * step[1]) for index in range(length + 1))


def _sign(value):
    return -1 if value < 0 else 1 if value > 0 else 0


def _changed_colour_candidates(pairs):
    shared = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        colours = {
            target[r][c]
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] != target[r][c]
        }
        shared = colours if shared is None else shared & colours
    return sorted(shared or ())


# ---------------------------------------------------------------------------
# Shared operator I: boundary-conditioned geometry emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ThreeCornerFrameDiagonalProgram:
    emit_colour: int
    kind = "three_corner_frame_diagonal"
    operator = "boundary_conditioned_geometry_emission"
    node_vocabulary = "boundary_anchor_and_separator_nodes"
    edge_vocabulary = "reflection_and_direction_successor_edges"

    @property
    def schema_key(self):
        return (self.kind, self.emit_colour)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 1 or self.emit_colour in _palette(value):
            raise Inapplicable("one singleton marker colour and a novel emitted colour required")
        marker_colour = colours[0]
        markers = [(r, c) for r in range(h) for c in range(w) if value[r][c] == marker_colour]
        if len(markers) != 4:
            raise Inapplicable("exactly four singleton anchors required")
        if any(len(component["cells"]) != 1 for component in _components(value)):
            raise Inapplicable("anchors must be singleton components")

        candidates = []
        for triple in combinations(markers, 3):
            triple = tuple(triple)
            for common in triple:
                row_mates = [cell for cell in triple if cell != common and cell[0] == common[0]]
                col_mates = [cell for cell in triple if cell != common and cell[1] == common[1]]
                if len(row_mates) != 1 or len(col_mates) != 1:
                    continue
                row_corner, col_corner = row_mates[0], col_mates[0]
                side_row = abs(col_corner[0] - common[0])
                side_col = abs(row_corner[1] - common[1])
                if side_row != side_col or side_row < 2:
                    continue
                missing = (col_corner[0], row_corner[1])
                if missing in markers:
                    continue
                r0, c0, r1, c1 = _bbox((common, row_corner, col_corner, missing))
                distractors = [cell for cell in markers if cell not in triple]
                if len(distractors) != 1:
                    continue
                dr, dc = distractors[0]
                if not (r0 < dr < r1 and c0 < dc < c1):
                    continue
                claims = set(_line_between(row_corner, missing))
                claims.update(_line_between(col_corner, missing))
                claims.update(_line_between(row_corner, col_corner))
                claims.difference_update(markers)
                if claims:
                    candidates.append((missing, frozenset(claims)))
        unique = {(missing, claims) for missing, claims in candidates}
        if len(unique) != 1:
            raise Inapplicable("unique three-corner square relation required")
        _, claims = next(iter(unique))
        output = _array(value)
        for r, c in claims:
            if output[r][c] != background:
                raise Inapplicable("frame/diagonal claim collides")
            output[r][c] = self.emit_colour
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no materialisation")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="four same-colour singleton anchors, three of which define three corners of a square",
            relation_chain=(
                "select the unique three-corner square and reject the strict-interior distractor",
                "derive the missing corner and its two incident sides",
                "materialise the two absent sides and the diagonal joining the non-common present corners",
            ),
            parameters={"emit_colour": self.emit_colour},
            corollary="Complete the missing square corner structure and its demonstrated diagonal.",
            notions=["three-corner square", "strict-interior distractor", "missing corner", "diagonal incidence"],
        )


@dataclass(frozen=True)
class DiagonalWallReflectionProgram:
    emit_colour: int
    kind = "diagonal_wall_reflection"
    operator = "boundary_conditioned_geometry_emission"
    node_vocabulary = "boundary_anchor_and_separator_nodes"
    edge_vocabulary = "reflection_and_direction_successor_edges"

    @property
    def schema_key(self):
        return (self.kind, self.emit_colour)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 2 or self.emit_colour in _palette(value):
            raise Inapplicable("wall and diagonal seed colours plus a novel emitted colour required")
        by_colour = {colour: [(r, c) for r in range(h) for c in range(w) if value[r][c] == colour] for colour in colours}
        candidates = []
        for wall_colour in colours:
            wall_cells = by_colour[wall_colour]
            if not _filled_rectangle(wall_cells):
                continue
            r0, c0, r1, c1 = _bbox(wall_cells)
            wall_axis = None
            if c0 == 0 and c1 == w - 1 and (r0 == 0 or r1 == h - 1):
                wall_axis = 0
                wall_side = -1 if r0 == 0 else 1
            elif r0 == 0 and r1 == h - 1 and (c0 == 0 or c1 == w - 1):
                wall_axis = 1
                wall_side = -1 if c0 == 0 else 1
            if wall_axis is None:
                continue
            seed_colour = next(colour for colour in colours if colour != wall_colour)
            seeds = sorted(by_colour[seed_colour])
            if not 2 <= len(seeds) <= 4:
                continue
            # The seed itself must be one contiguous 45-degree segment.
            ordered = None
            for a, b in ((seeds[0], seeds[-1]), (seeds[-1], seeds[0])):
                try:
                    line = _line_between(a, b)
                except Inapplicable:
                    continue
                if set(line) == set(seeds) and abs(a[0] - b[0]) == abs(a[1] - b[1]):
                    ordered = line
                    break
            if ordered is None:
                continue
            endpoints = (ordered[0], ordered[-1])
            # Choose the endpoint nearest the wall and continue in that direction.
            def wall_distance(cell):
                return cell[wall_axis] - (r1 if wall_axis == 0 and wall_side < 0 else c1 if wall_axis == 1 and wall_side < 0 else r0 if wall_axis == 0 else c0)
            # Simpler geometric distance to the wall rectangle.
            def distance(cell):
                if wall_axis == 0:
                    return (cell[0] - r1 - 1) if wall_side < 0 else (r0 - cell[0] - 1)
                return (cell[1] - c1 - 1) if wall_side < 0 else (c0 - cell[1] - 1)
            near = min(endpoints, key=distance)
            far = endpoints[1] if near == endpoints[0] else endpoints[0]
            step = (_sign(near[0] - far[0]), _sign(near[1] - far[1]))
            if step[0] == 0 or step[1] == 0:
                continue
            claims = []
            r, c = near
            while True:
                nr, nc = r + step[0], c + step[1]
                if not (0 <= nr < h and 0 <= nc < w):
                    claims = []
                    break
                if value[nr][nc] == wall_colour:
                    contact = (r, c)
                    break
                if value[nr][nc] != background:
                    claims = []
                    break
                claims.append((nr, nc))
                r, c = nr, nc
            if not claims:
                continue
            reflected = list(step)
            reflected[wall_axis] *= -1
            r, c = contact
            while True:
                nr, nc = r + reflected[0], c + reflected[1]
                if not (0 <= nr < h and 0 <= nc < w):
                    break
                if value[nr][nc] != background:
                    claims = []
                    break
                claims.append((nr, nc))
                r, c = nr, nc
            if claims:
                candidates.append((wall_colour, seed_colour, tuple(claims)))
        unique = {(wall, seed, claims) for wall, seed, claims in candidates}
        if len(unique) != 1:
            raise Inapplicable("unique boundary wall and diagonal seed required")
        _, _, claims = next(iter(unique))
        output = _array(value)
        for r, c in claims:
            output[r][c] = self.emit_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a 45-degree seed segment approaching a solid boundary wall",
            relation_chain=(
                "infer the seed direction toward the wall",
                "continue to the last free cell before the wall",
                "reflect the wall-normal component and continue to the outer boundary",
            ),
            parameters={"emit_colour": self.emit_colour},
            corollary="Emit the demonstrated diagonal path with specular reflection at the solid wall.",
            notions=["boundary wall", "diagonal seed", "contact cell", "reflected successor"],
        )


@dataclass(frozen=True)
class SeparatorDirectedRaysProgram:
    role_map: tuple
    kind = "separator_directed_axis_rays"
    operator = "boundary_conditioned_geometry_emission"
    node_vocabulary = "boundary_anchor_and_separator_nodes"
    edge_vocabulary = "reflection_and_direction_successor_edges"

    @property
    def schema_key(self):
        return (self.kind, self.role_map)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        role_map = dict(self.role_map)
        separator_candidates = []
        for colour in sorted(_palette(value) - {background}):
            cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
            rows = {r for r, _ in cells}
            cols = {c for _, c in cells}
            if len(rows) == 1 and len(cells) == w:
                separator_candidates.append((0, next(iter(rows)), colour))
            if len(cols) == 1 and len(cells) == h:
                separator_candidates.append((1, next(iter(cols)), colour))
        if len(separator_candidates) != 1:
            raise Inapplicable("one full separator line required")
        axis, separator, separator_colour = separator_candidates[0]
        semantic_colours = sorted(_palette(value) - {background, separator_colour})
        if set(semantic_colours) != set(role_map):
            raise Inapplicable("semantic colours do not match learned ray roles")
        components = _components(value)
        markers = []
        for component in components:
            if component["colour"] == separator_colour:
                continue
            if len(component["cells"]) != 1:
                raise Inapplicable("all ray anchors must be singleton components")
            markers.append((component["colour"], next(iter(component["cells"]))))
        if len(markers) < 4:
            raise Inapplicable("multiple ray anchors required")
        output = _array(value)
        claimed = {}
        for colour, cell in markers:
            coordinate = cell[axis]
            if coordinate == separator:
                raise Inapplicable("marker on separator")
            toward = 1 if separator > coordinate else -1
            direction = toward if role_map[colour] == "toward" else -toward
            r, c = cell
            while True:
                nr, nc = (r + direction, c) if axis == 0 else (r, c + direction)
                if not (0 <= nr < h and 0 <= nc < w):
                    break
                if (axis == 0 and nr == separator) or (axis == 1 and nc == separator):
                    break
                if value[nr][nc] != background:
                    raise Inapplicable("ray collides with another semantic node")
                previous = claimed.get((nr, nc))
                if previous is not None and previous != colour:
                    raise Inapplicable("ray ownership conflict")
                claimed[(nr, nc)] = colour
                r, c = nr, nc
        if not claimed:
            raise Inapplicable("no ray continuation")
        for (r, c), colour in claimed.items():
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a full separator line with singleton semantic anchors on one or both sides",
            relation_chain=(
                "classify each semantic colour as toward-separator or away-from-separator",
                "bind every singleton to the separator-normal axis",
                "continue the learned role to the separator or outer boundary",
            ),
            parameters={"role_map": list(self.role_map)},
            corollary="Extend every marker along its learned separator-relative direction.",
            notions=["separator", "singleton anchor", "toward role", "away role"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: instructional structure transfer.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReflectedGuidePatternTransferProgram:
    kind = "reflected_guide_pattern_transfer"
    operator = "instructional_structure_transfer"
    node_vocabulary = "instructional_template_and_recipient_nodes"
    edge_vocabulary = "scale_alignment_and_panel_correspondence_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    @staticmethod
    def _aligned_line(cells):
        cells = sorted(cells)
        if len(cells) < 3:
            return None
        rows = {r for r, _ in cells}
        cols = {c for _, c in cells}
        if len(rows) == 1:
            return 0, next(iter(rows)), tuple(c for _, c in cells)
        if len(cols) == 1:
            return 1, next(iter(cols)), tuple(r for r, _ in cells)
        return None

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 2:
            raise Inapplicable("exactly source and target colours required")
        components_by_colour = {colour: _components(value, colour=colour) for colour in colours}
        candidates = []
        for source_colour, target_colour in ((colours[0], colours[1]), (colours[1], colours[0])):
            source_components = components_by_colour[source_colour]
            target_components = components_by_colour[target_colour]
            source_singletons = [next(iter(component["cells"])) for component in source_components if len(component["cells"]) == 1]
            target_singletons = [next(iter(component["cells"])) for component in target_components if len(component["cells"]) == 1]
            source_pattern = set().union(*(component["cells"] for component in source_components if len(component["cells"]) > 1)) if any(len(component["cells"]) > 1 for component in source_components) else set()
            if not source_pattern or any(len(component["cells"]) != 1 for component in target_components):
                continue
            source_line = self._aligned_line(source_singletons)
            target_line = self._aligned_line(target_singletons)
            if source_line is None or target_line is None:
                continue
            source_axis, source_coordinate, source_orth = source_line
            target_axis, target_coordinate, target_orth = target_line
            if source_axis != target_axis or source_orth != target_orth or source_coordinate == target_coordinate:
                continue
            delta = source_coordinate - target_coordinate
            pattern_coordinates = [cell[source_axis] for cell in source_pattern]
            if delta > 0 and not all(coordinate < target_coordinate for coordinate in pattern_coordinates):
                continue
            if delta < 0 and not all(coordinate > target_coordinate for coordinate in pattern_coordinates):
                continue
            claims = set()
            for r, c in source_pattern:
                cell = [r, c]
                cell[source_axis] = source_coordinate + target_coordinate - cell[source_axis]
                rr, cc = cell
                if not (0 <= rr < h and 0 <= cc < w):
                    raise Inapplicable("reflected pattern leaves the canvas")
                claims.add((rr, cc))
            if claims:
                candidates.append((source_colour, target_colour, frozenset(claims)))
        unique = {(source, target, claims) for source, target, claims in candidates}
        if len(unique) != 1:
            raise Inapplicable("unique reflected guide transfer required")
        _, target_colour, claims = next(iter(unique))
        output = _array(value)
        for r, c in claims:
            if output[r][c] != background:
                raise Inapplicable("transferred pattern collides")
            output[r][c] = target_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a source pattern beside a target-colour guide line and a parallel source-colour recipient line",
            relation_chain=(
                "extract congruent guide and recipient anchor lines",
                "reflect the source pattern across its guide line",
                "translate to the recipient line and transfer the guide colour",
            ),
            parameters={},
            corollary="Reflect and transfer the source pattern from the guide line to the homologous recipient line.",
            notions=["guide line", "recipient line", "parallel correspondence", "reflected transfer"],
        )


@dataclass(frozen=True)
class InstructionalScaledTemplateProgram:
    kind = "instructional_scaled_template_transfer"
    operator = "instructional_structure_transfer"
    node_vocabulary = "instructional_template_and_recipient_nodes"
    edge_vocabulary = "scale_alignment_and_panel_correspondence_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 2:
            raise Inapplicable("template and anchor colours required")
        mixed = [component for component in _mixed_components(value) if len(component["colours"]) == 2]
        candidates = []
        for instruction in mixed:
            instruction_cells = instruction["cells"]
            for template_colour, anchor_colour in ((colours[0], colours[1]), (colours[1], colours[0])):
                template_all = {(r, c) for r in range(h) for c in range(w) if value[r][c] == template_colour}
                anchor_all = {(r, c) for r in range(h) for c in range(w) if value[r][c] == anchor_colour}
                template_cells = template_all & instruction_cells
                source_anchors = anchor_all & instruction_cells
                outside_anchors = anchor_all - instruction_cells
                if not template_cells or not source_anchors or template_cells != template_all or not outside_anchors:
                    continue
                target_components = []
                for component in _components(value, colour=anchor_colour):
                    if component["cells"] <= instruction_cells:
                        continue
                    cells = component["cells"]
                    r0, c0, r1, c1 = component["bbox"]
                    size = r1 - r0 + 1
                    if size != c1 - c0 + 1 or not _filled_rectangle(cells):
                        target_components = []
                        break
                    target_components.append({"cells": cells, "top_left": (r0, c0), "scale": size})
                if not target_components:
                    continue
                source_anchors = tuple(sorted(source_anchors))
                source_ref = source_anchors[0]
                index = {(item["scale"], item["top_left"]): idx for idx, item in enumerate(target_components)}
                groups = set()
                for idx, item in enumerate(target_components):
                    scale, target_ref = item["scale"], item["top_left"]
                    group = []
                    for anchor in source_anchors:
                        expected = (
                            target_ref[0] + scale * (anchor[0] - source_ref[0]),
                            target_ref[1] + scale * (anchor[1] - source_ref[1]),
                        )
                        match = index.get((scale, expected))
                        if match is None:
                            group = []
                            break
                        group.append(match)
                    if group:
                        groups.add(tuple(sorted(group)))
                groups = sorted(groups)
                # Exact-cover the target anchor components with congruent groups.
                covers = []
                def search(remaining, chosen):
                    if not remaining:
                        covers.append(tuple(chosen))
                        return
                    first = min(remaining)
                    for group in groups:
                        group_set = set(group)
                        if first in group_set and group_set <= remaining:
                            search(remaining - group_set, chosen + [group])
                            if len(covers) > 1:
                                return
                search(set(range(len(target_components))), [])
                if len(covers) != 1:
                    continue
                claims = set()
                for group in covers[0]:
                    ref_index = next(
                        index_in_group
                        for index_in_group in group
                        if target_components[index_in_group]["top_left"] == min(
                            (target_components[i]["top_left"] for i in group)
                        )
                    ) if len(source_anchors) == 1 else None
                    # Recover the component corresponding to the lexicographically first source anchor.
                    ref_candidates = []
                    for i in group:
                        scale = target_components[i]["scale"]
                        tl = target_components[i]["top_left"]
                        expected_positions = {
                            (
                                tl[0] + scale * (anchor[0] - source_ref[0]),
                                tl[1] + scale * (anchor[1] - source_ref[1]),
                            )
                            for anchor in source_anchors
                        }
                        actual_positions = {target_components[j]["top_left"] for j in group}
                        if expected_positions == actual_positions:
                            ref_candidates.append(i)
                    if len(ref_candidates) != 1:
                        raise Inapplicable("target anchor reference is not unique")
                    ref_item = target_components[ref_candidates[0]]
                    scale = ref_item["scale"]
                    target_ref = ref_item["top_left"]
                    for tr, tc in template_cells:
                        block_r = target_ref[0] + scale * (tr - source_ref[0])
                        block_c = target_ref[1] + scale * (tc - source_ref[1])
                        for dr in range(scale):
                            for dc in range(scale):
                                rr, cc = block_r + dr, block_c + dc
                                if 0 <= rr < h and 0 <= cc < w:
                                    claims.add((rr, cc))
                if claims:
                    candidates.append((template_colour, anchor_colour, frozenset(claims)))
        unique = {(template, anchor, claims) for template, anchor, claims in candidates}
        if len(unique) != 1:
            raise Inapplicable("unique instructional template transfer required")
        template_colour, anchor_colour, claims = next(iter(unique))
        output = _array(value)
        for r, c in claims:
            if output[r][c] not in (background, template_colour):
                raise Inapplicable("scaled template collides with anchor material")
            output[r][c] = template_colour
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no target template materialisation")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="one mixed template/anchor instruction and one or more filled-square anchor recipients",
            relation_chain=(
                "extract the template and its anchor configuration",
                "match recipient anchor groups under an inferred integer scale",
                "project every template cell as a scaled block, clipping only at the canvas boundary",
            ),
            parameters={},
            corollary="Transfer the instructional template to every congruent scaled anchor group.",
            notions=["mixed instruction", "anchor configuration", "integer scale", "clipped block projection"],
        )


@dataclass(frozen=True)
class LegendPanelBackgroundProgram:
    kind = "legend_coded_panel_background"
    operator = "instructional_structure_transfer"
    node_vocabulary = "instructional_template_and_recipient_nodes"
    edge_vocabulary = "scale_alignment_and_panel_correspondence_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        if w < 4 or h < 6:
            raise Inapplicable("canvas too small")
        mapping = {}
        legend_cells = set()
        for r in range(h - 1):
            left = value[r][0]
            right = value[r][1]
            if left == background or right == background or left == right:
                continue
            if value[r + 1][0] != left or value[r + 1][1] != right:
                continue
            if value[r][2] != background or value[r + 1][2] != background:
                continue
            if r > 0 and (value[r - 1][0] != background or value[r - 1][1] != background):
                continue
            if r + 2 < h and (value[r + 2][0] != background or value[r + 2][1] != background):
                continue
            if left in mapping and mapping[left] != right:
                raise Inapplicable("legend conflict")
            mapping[left] = right
            legend_cells.update({(r, 0), (r + 1, 0), (r, 1), (r + 1, 1)})
        if len(mapping) < 2 or len(set(mapping.values())) != len(mapping):
            raise Inapplicable("at least two one-to-one legend pairs required")
        output = _array(value)
        object_count = 0
        for object_colour, panel_colour in mapping.items():
            for component in _components(value, colour=object_colour):
                cells = set(component["cells"])
                if cells <= legend_cells:
                    continue
                if len(cells) < 4:
                    raise Inapplicable("legend object must be a nontrivial component")
                object_count += 1
                r0, c0, r1, c1 = component["bbox"]
                er0, ec0 = max(0, r0 - 1), max(0, c0 - 1)
                er1, ec1 = min(h - 1, r1 + 1), min(w - 1, c1 + 1)
                # Exterior background inside the expanded box; enclosed holes remain unchanged.
                queue = []
                seen = set()
                for r in range(er0, er1 + 1):
                    for c in range(ec0, ec1 + 1):
                        if r not in (er0, er1) and c not in (ec0, ec1):
                            continue
                        if value[r][c] == background:
                            seen.add((r, c))
                            queue.append((r, c))
                while queue:
                    r, c = queue.pop()
                    for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                        nr, nc = r + dr, c + dc
                        if not (er0 <= nr <= er1 and ec0 <= nc <= ec1) or (nr, nc) in seen:
                            continue
                        if value[nr][nc] == background:
                            seen.add((nr, nc))
                            queue.append((nr, nc))
                for r, c in seen:
                    if output[r][c] not in (background, panel_colour):
                        raise Inapplicable("object panel collision")
                    output[r][c] = panel_colour
        if object_count < 2:
            raise Inapplicable("multiple legend-coded objects required")
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no panel background emitted")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="nontrivial coloured objects plus a boundary legend of paired vertical dominoes",
            relation_chain=(
                "decode each object-colour to panel-colour legend pair",
                "extract every non-legend object and its one-cell expanded envelope",
                "colour only exterior-connected background in that envelope, preserving enclosed holes",
            ),
            parameters={},
            corollary="Place each object on its legend-coded exterior panel while retaining the object and its holes.",
            notions=["paired legend", "object class", "expanded envelope", "exterior-connected background"],
        )


@dataclass(frozen=True)
class SplitPanelMotifTransferProgram:
    kind = "split_panel_motif_transfer"
    operator = "instructional_structure_transfer"
    node_vocabulary = "instructional_template_and_recipient_nodes"
    edge_vocabulary = "scale_alignment_and_panel_correspondence_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        candidates = []
        for border_colour in sorted(_palette(value)):
            if not (
                all(value[0][c] == border_colour for c in range(w))
                and all(value[h - 1][c] == border_colour for c in range(w))
                and all(value[r][0] == border_colour and value[r][w - 1] == border_colour for r in range(h))
            ):
                continue
            separators = [c for c in range(1, w - 1) if all(value[r][c] == border_colour for r in range(h))]
            if len(separators) != 1:
                continue
            separator = separators[0]
            panels = ((1, separator - 1), (separator + 1, w - 2))
            panel_data = []
            for start, end in panels:
                cells = [value[r][c] for r in range(1, h - 1) for c in range(start, end + 1)]
                mode = Counter(cells).most_common(1)[0][0]
                nonbase = {(r, c) for r in range(1, h - 1) for c in range(start, end + 1) if value[r][c] != mode}
                panel_data.append((start, end, int(mode), nonbase))
            reference_indices = [index for index, data in enumerate(panel_data) if data[3]]
            target_indices = [index for index, data in enumerate(panel_data) if not data[3]]
            if len(reference_indices) != 1 or len(target_indices) != 1:
                continue
            reference = panel_data[reference_indices[0]]
            target = panel_data[target_indices[0]]
            ref_start, ref_end, ref_base, _ = reference
            tgt_start, tgt_end, tgt_base, _ = target
            if ref_base == border_colour or tgt_base == border_colour:
                continue
            motif_components = []
            seen = set()
            for r in range(1, h - 1):
                for c in range(ref_start, ref_end + 1):
                    if (r, c) in seen or value[r][c] == ref_base:
                        continue
                    colour = value[r][c]
                    stack = [(r, c)]
                    seen.add((r, c))
                    cells = []
                    while stack:
                        rr, cc = stack.pop()
                        cells.append((rr, cc))
                        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                            nr, nc = rr + dr, cc + dc
                            if not (1 <= nr < h - 1 and ref_start <= nc <= ref_end) or (nr, nc) in seen:
                                continue
                            if value[nr][nc] == colour:
                                seen.add((nr, nc))
                                stack.append((nr, nc))
                    if not _filled_rectangle(cells):
                        motif_components = []
                        break
                    motif_components.append((colour, _bbox(cells)))
                if not motif_components and seen:
                    break
            if not motif_components:
                continue
            claims = {}
            ref_width = ref_end - ref_start + 1
            for colour, (r0, c0, r1, c1) in motif_components:
                width = c1 - c0 + 1
                left_margin = c0 - ref_start
                right_margin = ref_end - c1
                if left_margin == right_margin and width == ref_width - 2 * left_margin and width > 2:
                    tc0, tc1 = tgt_start + left_margin, tgt_end - right_margin
                elif left_margin < right_margin:
                    tc0, tc1 = tgt_start + left_margin, tgt_start + left_margin + width - 1
                elif right_margin < left_margin:
                    tc1, tc0 = tgt_end - right_margin, tgt_end - right_margin - width + 1
                else:
                    raise Inapplicable("centred small motif has no unique edge correspondence")
                if not (tgt_start <= tc0 <= tc1 <= tgt_end):
                    raise Inapplicable("transferred motif outside target panel")
                for r in range(r0, r1 + 1):
                    for c in range(tc0, tc1 + 1):
                        previous = claims.get((r, c))
                        if previous is not None and previous != colour:
                            raise Inapplicable("motif ownership conflict")
                        claims[(r, c)] = colour
            if claims:
                candidates.append((border_colour, separator, tgt_base, tuple(sorted(claims.items()))))
        unique = {(border, separator, target_base, claims) for border, separator, target_base, claims in candidates}
        if len(unique) != 1:
            raise Inapplicable("unique bordered split-panel transfer required")
        _, _, target_base, claims = next(iter(unique))
        output = _array(value)
        for (r, c), colour in claims:
            if output[r][c] != target_base:
                raise Inapplicable("target panel not uniform at transfer location")
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a bordered canvas split into one motif panel and one uniform recipient panel",
            relation_chain=(
                "extract filled rectangular motifs and their horizontal edge roles",
                "map reference-panel edge offsets to the recipient panel",
                "preserve small edge-anchored motifs and stretch edge-to-edge bars",
            ),
            parameters={},
            corollary="Transfer the reference motif layout into the homologous recipient panel.",
            notions=["split panel", "edge offset", "filled motif", "bar stretching"],
        )


# ---------------------------------------------------------------------------
# Fitters.
# ---------------------------------------------------------------------------


def _fit_static(pairs, cls):
    programme = cls()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_emitted_colour(pairs, cls):
    output = []
    for colour in _changed_colour_candidates(pairs):
        programme = cls(int(colour))
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_separator_rays(pairs):
    semantic_sets = []
    for source, _ in pairs:
        source = grid(source)
        background = _mode(source)
        full_colours = set()
        h, w = _shape(source)
        for colour in _palette(source) - {background}:
            cells = {(r, c) for r in range(h) for c in range(w) if source[r][c] == colour}
            if (len({r for r, _ in cells}) == 1 and len(cells) == w) or (len({c for _, c in cells}) == 1 and len(cells) == h):
                full_colours.add(colour)
        semantics = set(_palette(source) - {background}) - full_colours
        semantic_sets.append(semantics)
    if not semantic_sets or any(semantics != semantic_sets[0] for semantics in semantic_sets) or not 2 <= len(semantic_sets[0]) <= 3:
        return []
    colours = sorted(semantic_sets[0])
    output = []
    for roles in product(("toward", "away"), repeat=len(colours)):
        if len(set(roles)) < 2:
            continue
        programme = SeparatorDirectedRaysProgram(tuple(zip(colours, roles)))
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "three_corner_frame_diagonal": lambda pairs: _fit_emitted_colour(pairs, ThreeCornerFrameDiagonalProgram),
    "diagonal_wall_reflection": lambda pairs: _fit_emitted_colour(pairs, DiagonalWallReflectionProgram),
    "separator_directed_axis_rays": _fit_separator_rays,
    "reflected_guide_pattern_transfer": lambda pairs: _fit_static(pairs, ReflectedGuidePatternTransferProgram),
    "instructional_scaled_template_transfer": lambda pairs: _fit_static(pairs, InstructionalScaledTemplateProgram),
    "legend_coded_panel_background": lambda pairs: _fit_static(pairs, LegendPanelBackgroundProgram),
    "split_panel_motif_transfer": lambda pairs: _fit_static(pairs, SplitPanelMotifTransferProgram),
}


def fit_anti_unified_extractor_transfer_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


# ---------------------------------------------------------------------------
# Counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        target = grid(target)
        original = programme.predict(source)
        background = _mode(source)
        foreground_colours = sorted(_palette(source) - {background})
        candidates = [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] != background
        ]
        candidates += [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] == background and source[r][c] != target[r][c]
        ]
        candidates += [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] == background
        ][:4]
        seen = set()
        passed = False
        tested = 0
        for r, c in candidates:
            if (r, c) in seen:
                continue
            seen.add((r, c))
            replacement = background if source[r][c] != background else (
                foreground_colours[0] if foreground_colours else (background + 1) % 10
            )
            if replacement == source[r][c]:
                continue
            tested += 1
            work = _array(source)
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                break
            if tested >= 16:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "anti_unified_extractor_or_transfer_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_anti_unified_extractor_transfer_composition(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anti_unified_extractor_transfer_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_extractors": True,
            "bounded_transfer_composition": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_anti_unified_extractor_transfer_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anti_unified_extractor_transfer_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_anti_unified_extractor_transfer_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
