"""Validation-qualified evidence, with explicit staged acceptance priority.

Consensus concerns qualified families, not all raw hypotheses or independent votes.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import copy
from correspondence import grid
from runtime import abstain

RECONSIDER = frozenset(('no_fit', 'ambiguous', 'validation_rejected'))
INCOMPLETE = frozenset(('timeout', 'error', 'incomplete', 'not_run'))

@dataclass(frozen=True)
class Evidence:
    name: str
    raw: dict[str, Any]
    validated: dict[str, Any]


def joint_key(result: dict, count: int):
    if result.get('status') != 'unique':
        return None
    tests = result.get('tests')
    if not isinstance(tests, list) or len(tests) != count:
        raise ValueError('unique prediction has an incorrect test count')
    if any(t.get('status') != 'unique' or t.get('prediction') is None for t in tests):
        raise ValueError('unique prediction lacks a complete joint output')
    return tuple(grid(t['prediction']) for t in tests)


def certificate(entry: Evidence, demonstrations: int, count: int):
    """Return eligibility and explanation; malformed unique certificates are errors."""
    r, v = entry.raw, entry.validated
    if r.get('status') in INCOMPLETE or v.get('status') in INCOMPLETE:
        return False, 'incomplete'
    if v.get('status') != 'unique':
        return False, str(v.get('status', 'malformed_status'))
    if demonstrations < 2:
        raise ValueError('validation requires at least two demonstrations')
    rk, vk = joint_key(r, count), joint_key(v, count)
    if rk is None or rk != vk:
        raise ValueError('raw/validated joint prediction mismatch')
    check = v.get('validation', {})
    folds = check.get('folds', [])
    if check.get('passed') is not True or len(folds) != demonstrations:
        raise ValueError('incomplete or failed validation certificate')
    indices = [f.get('held_index') for f in folds]
    if any(type(i) is not int for i in indices) or sorted(indices) != list(range(demonstrations)):
        raise ValueError('validation fold indices are missing, duplicated or invalid')
    if not all(f.get('status') == 'unique' and f.get('held_example_exact') is True
               and f.get('test_prediction_stable') is True for f in folds):
        raise ValueError('validation certificate contains a failed fold')
    return True, 'qualified'


def reconcile(baseline: dict, entries: list[Evidence], *, expected: tuple[str, ...],
              demonstrations: int, test_count: int, candidate: dict | None = None) -> dict:
    """Preserve answers; reconcile complete abstentions without majority voting.

    `candidate` is supplied only at an appended registry stage. Without a
    qualified prediction, a previous no-fit takes this new stage's abstention.
    Earlier ambiguity/validation rejection remains visible. Stage order is
    intentional: accepted answers are never overwritten by later stages.
    """
    if test_count < 1 or demonstrations < 1:
        raise ValueError('nonempty train and test are required')
    names = [e.name for e in entries]
    if len(set(names)) != len(names) or set(names) != set(expected):
        raise ValueError('exact complete evidence registry required')
    by_name = {e.name: e for e in entries}
    ordered = [by_name[n] for n in expected]
    groups, errors, assessments = {}, [], []
    for e in ordered:
        try:
            ok, why = certificate(e, demonstrations, test_count)
            if why == 'incomplete':
                errors.append(e.name + ':incomplete')
            key = joint_key(e.validated, test_count) if ok else None
        except (ValueError, TypeError, KeyError) as exc:
            ok, why, key = False, 'malformed_certificate', None
            errors.append(e.name + ':' + str(exc))
        if ok:
            groups.setdefault(key, []).append(e.name)
        assessments.append({'family': e.name, 'qualified': ok, 'reason': why,
                            'raw_status': e.raw.get('status'),
                            'validated_status': e.validated.get('status')})
    status = baseline['status']
    baseline_key = joint_key(baseline, test_count) if status == 'unique' else None
    if status == 'unique':
        result, decision = copy.deepcopy(baseline), 'accepted_answer_preserved'
    elif status not in RECONSIDER:
        result, decision = copy.deepcopy(baseline), 'incomplete_or_ineligible_preserved'
    elif errors:
        result = abstain(test_count, 'incomplete', 'qualified registry incomplete')
        decision = 'registry_incomplete'
    elif len(groups) > 1:
        result = abstain(test_count, 'ambiguous', 'qualified families disagree')
        decision = 'qualified_conflict'
    elif groups:
        key = next(iter(groups))
        supporters = sorted(groups[key])
        result = {'status': 'unique', 'joint_hypotheses': 1,
                  'tests': [{'status': 'unique', 'prediction': [list(r) for r in g]} for g in key],
                  'supporting_families': supporters,
                  'supporting_laws': [copy.deepcopy(law) for e in ordered if e.name in supporters
                                      for law in e.validated.get('supporting_laws', [])][:20]}
        decision = 'qualified_consensus'
    else:
        result = copy.deepcopy(candidate if status == 'no_fit' and candidate is not None else baseline)
        decision = 'no_qualified_evidence'
    result['evidence'] = {
        'decision': decision, 'previous_status': status, 'registry_errors': errors,
        'qualified_families': sorted(n for names in groups.values() for n in names),
        'qualified_joint_predictions': len(groups), 'assessments': assessments,
        'qualified_conflicts_with_baseline': sorted(n for k, names in groups.items()
                        if baseline_key is not None and k != baseline_key for n in names),
        'raw_global_consensus_claimed': False, 'majority_voting': False}
    return result
