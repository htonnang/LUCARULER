"""Colour-preserving panel overlay with demonstration-induced precedence.

Reuses V64's equal-panel Layout and transparent Background roles. One program
splits and aligns panels, treats the inferred background as transparent and
writes foreground pixels in a demonstration-fitted order. Later layers win.
Every consistent order is retained: unseen overlaps are not resolved by the
first enumerated order. All test inputs must share one complete program.
This is a finite family, not an arbitrary spatial-composition search.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import permutations, product
from typing import Iterable
from correspondence import grid
from runtime import joint_result, public_task
from panel_layout import Background, Layout, LAYOUTS

Grid = tuple[tuple[int, ...], ...]
TEMPLATE = 'panel_partition -> shared_local_coordinates -> colour_preserving_overlay'


def render(panels: tuple[Grid, ...], background: int, order: tuple[int, ...]) -> Grid:
    """Transactional, colour-preserving rendering; later indices have priority."""
    if not 2 <= len(panels) <= 4 or sorted(order) != list(range(len(panels))):
        raise ValueError('order must contain every panel exactly once (2 to 4 panels)')
    panels = tuple(grid(p) for p in panels)
    h, w = len(panels[0]), len(panels[0][0])
    if any((len(p), len(p[0])) != (h, w) for p in panels):
        raise ValueError('panel shapes differ')
    if type(background) is not int or not 0 <= background <= 9:
        raise ValueError('invalid transparent colour')
    out = [[background] * w for _ in range(h)]
    for index in order:
        for r, row in enumerate(panels[index]):
            for c, colour in enumerate(row):
                if colour != background:
                    out[r][c] = colour
    return grid(out)


@dataclass(frozen=True)
class OverlayProgram:
    layout: Layout
    background: Background
    order: tuple[int, ...]

    def predict(self, raw) -> Grid | None:
        a = grid(raw)
        panels = self.layout.split(a)
        if panels is None:
            return None
        bg = self.background.value(a, panels)
        if bg is None:
            return None
        return render(panels, bg, self.order)

    def name(self) -> str:
        return (f'split_panels({self.layout.name()}) -> transparent({self.background.name()})'
                f' -> preserve_colours(order={self.order},later_wins)')

    def template(self) -> str:
        return TEMPLATE

    def trace(self, raw) -> dict | None:
        a = grid(raw); panels = self.layout.split(a)
        if panels is None:
            return None
        bg = self.background.value(a, panels)
        if bg is None:
            return None
        h, w = len(panels[0]), len(panels[0][0])
        occupied = shared = conflicts = empty = 0
        for r, c in product(range(h), range(w)):
            values = [p[r][c] for p in panels if p[r][c] != bg]
            occupied += bool(values)
            shared += len(values) > 1
            conflicts += len(set(values)) > 1
            empty += not values
        return {'layout':self.layout.name(), 'panel_shape':[h,w],
                'panel_count':len(panels), 'transparent_colour':bg,
                'background_role':self.background.name(), 'layer_order':list(self.order),
                'occupied_output_cells':occupied, 'multiply_occupied_cells':shared,
                'different_colour_overlap_cells':conflicts, 'empty_output_cells':empty,
                'foreground_colours':sorted({v for p in panels for row in p for v in row if v != bg}),
                'prediction':[list(row) for row in render(panels,bg,self.order)]}


def _possible_cellwise(panels: tuple[Grid,...], bg: int, target: Grid) -> bool:
    """Necessary condition only; a SINGLE global precedence must then fit all cells."""
    for r, row in enumerate(target):
        for c, expected in enumerate(row):
            visible = {p[r][c] for p in panels if p[r][c] != bg}
            if expected not in (visible if visible else {bg}):
                return False
    return True


def fit(raw_pairs: Iterable) -> list[OverlayProgram]:
    pairs = tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs:
        return []
    common = set.intersection(*({v for row in a for v in row} for a,y in pairs))
    backgrounds = [Background(),Background('unique_modal')]
    backgrounds += [Background('constant',c) for c in sorted(common)]
    programs = []
    for rows, cols in LAYOUTS:
        for rg, cg in product((0,1,2) if rows>1 else (0,), (0,1,2) if cols>1 else (0,)):
            layout = Layout(rows,cols,rg,cg)
            if any(len(a) != rows*len(y)+(rows-1)*rg or
                   len(a[0]) != cols*len(y[0])+(cols-1)*cg for a,y in pairs):
                continue
            splits = tuple(layout.split(a) for a,y in pairs)
            if any(p is None for p in splits):
                continue
            for bg_rule in backgrounds:
                bgs = tuple(bg_rule.value(a,p) for (a,y),p in zip(pairs,splits))
                if any(bg is None for bg in bgs):
                    continue
                if not all(_possible_cellwise(p,bg,y) for p,bg,(a,y) in zip(splits,bgs,pairs)):
                    continue
                for order in permutations(range(rows*cols)):
                    if not all(render(p,bg,order)==y for p,bg,(a,y) in zip(splits,bgs,pairs)):
                        continue
                    law = OverlayProgram(layout,bg_rule,order)
                    # Defensive replay: same predict path is used for demonstrations and tests.
                    if not all(law.predict(a)==y for a,y in pairs):
                        raise AssertionError('fitted panel law failed exact demonstration replay')
                    programs.append(law)
    return programs


def evaluate(programs: list[OverlayProgram], inputs: list) -> dict:
    groups = {}; rejected = 0
    for program in programs:
        predictions = tuple(program.predict(a) for a in inputs)
        if any(p is None for p in predictions):
            rejected += 1
            continue
        groups.setdefault(predictions,[]).append({
            'family':'colour_panels_v65','law':program.name(),'template':program.template()})
    result = joint_result(groups,len(inputs))
    result['candidates'] = [
        {'predictions':[[list(row) for row in p] for p in key],
         'program_count':len(support),'templates':[TEMPLATE],
         'laws':[s['law'] for s in support]} for key,support in groups.items()]
    result['inapplicable_programs'] = rejected
    result['stats'] = {'fitted_programs':len(programs),'beam_pruning':False,
        'fitted_alternatives_discarded':False,'search_complete_within_declared_grammar':True,
        'foreground_colours_preserved':True}
    return result


def infer(task: dict) -> dict:
    clean = public_task(task)
    programs = fit([(e['input'],e['output']) for e in clean['train']])
    return evaluate(programs,[e['input'] for e in clean['test']])


def validate_leave_one_out(task: dict, fitted: dict) -> dict:
    """Within-task check: refit without each demonstration, never use official targets."""
    clean = public_task(task); n = len(clean['train'])
    if fitted['status'] != 'unique':
        return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if n < 2:
        return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected = [t['prediction'] for t in fitted['tests']]
    folds = []
    for held in range(n):
        fold = {'train':[d for i,d in enumerate(clean['train']) if i != held],
                'test':[{'input':clean['train'][held]['input']}] + clean['test']}
        output = infer(fold)
        predictions = [t['prediction'] for t in output['tests']]
        exact = output['status']=='unique' and predictions[0]==clean['train'][held]['output']
        stable = output['status']=='unique' and predictions[1:]==expected
        folds.append({'held_index':held,'status':output['status'],
                      'held_example_exact':exact,'test_prediction_stable':stable,
                      'joint_hypotheses':output['joint_hypotheses'],
                      'fitted_programs':output['stats']['fitted_programs']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':passed,'reason':'passed' if passed else 'held_example_or_stability_failure','folds':folds}
