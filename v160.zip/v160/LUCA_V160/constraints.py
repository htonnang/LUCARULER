"""Shared finite-domain search for scene edits and object assignments.

The solver removes only choices lacking support for an explicit constraint. It
never uses a task identifier, a score, or an expected test grid. A solution is a
representative assignment, not a vote. Equivalent future states can be merged
only when their accumulated symbolic emission and obligations also agree.
"""
from __future__ import annotations

from collections import Counter
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Hashable, Iterator

_PROFILE: ContextVar[Counter | None] = ContextVar('luca_constraint_profile', default=None)


@contextmanager
def profile():
    """Optional process-local diagnostics; does not alter search or acceptance."""
    counters = Counter()
    token = _PROFILE.set(counters)
    try:
        yield counters
    finally:
        _PROFILE.reset(token)


def _indices(bits: int):
    while bits:
        bit = bits & -bits
        yield bit.bit_length() - 1
        bits ^= bit


@dataclass(frozen=True)
class Choice:
    """An alternative in one variable's domain.

    ``emission`` must encode every observable contribution of the alternative;
    it is unioned for safe effect-state memoization. ``covers`` and ``needs``
    use caller-defined requirement bits. ``exclusive`` represents resources
    that may not overlap. Equal writes can merge; different values conflict.
    ``resource`` optionally adds an all-different, one-reference-per-source rule.
    Domain adapters retain their own symbolic programs outside this record.
    """
    emission: frozenset[Hashable]
    covers: int = 0
    needs: int = 0
    exclusive: int = 0
    writes: tuple[tuple[int, int], ...] = ()
    resource: int | None = None

    def __post_init__(self):
        if not isinstance(self.emission, frozenset):
            raise ValueError('emission must be an immutable set of effect tokens')
        if any(type(x) is not int or x < 0 for x in (self.covers, self.needs, self.exclusive)):
            raise ValueError('constraint masks must be nonnegative integers')
        if self.resource is not None and (type(self.resource) is not int or self.resource < 0):
            raise ValueError('resource must be a nonnegative integer or None')
        if len(dict(self.writes)) != len(self.writes):
            raise ValueError('writes must have unique positions')


def _matching_exists(domains: list[set[int]]) -> bool:
    """Necessary AND sufficient matching feasibility for this bipartite graph.

    The returned matching is never used to select a prediction; its existence
    only proves that this particular capacity condition is not impossible.
    """
    if not domains:
        return True
    if any(not d for d in domains) or len(set().union(*domains)) < len(domains):
        return False
    owner: dict[int, int] = {}

    def augment(i: int, seen: set[int]) -> bool:
        for resource in sorted(domains[i]):
            if resource in seen:
                continue
            seen.add(resource)
            if resource not in owner or augment(owner[resource], seen):
                owner[resource] = i
                return True
        return False

    return all(augment(i, set()) for i in sorted(range(len(domains)), key=lambda i: len(domains[i])))


class ConstraintSearch:
    """Exhaustive within the supplied domains; arc/coverage/capacity pruning.

    Consumers may stop after finding two *different complete outputs*. A timeout
    must be handled as incomplete by the caller, not interpreted as no solution.
    """
    def __init__(self, domains, *, required: int = 0, unique_resources: bool = False,
                 label: str = 'generic'):
        self.domains = tuple(tuple(d) for d in domains)
        if type(required) is not int or required < 0 or type(unique_resources) is not bool:
            raise ValueError('invalid coverage or resource constraint')
        if any(not isinstance(o, Choice) for d in self.domains for o in d):
            raise ValueError('every alternative must be a Choice')
        self.required = required
        self.unique_resources = unique_resources
        self.label = label
        self.stats = Counter(calls=1, variables=len(self.domains),
                             initial_options=sum(map(len, self.domains)))
        self._writes = tuple(tuple(dict(o.writes) for o in d) for d in self.domains)
        self._support: dict[tuple[int, int, int], int] = {}
        self._memo: set[tuple] = set()
        self.exhausted = False

    def _supported(self, i: int, oi: int, j: int) -> int:
        key = (i, oi, j)
        if key in self._support:
            return self._support[key]
        a = self.domains[i][oi]
        aw = self._writes[i][oi]
        mask = 0
        for oj, b in enumerate(self.domains[j]):
            self.stats['compatibility_checks'] += 1
            if a.exclusive & b.exclusive:
                continue
            if self.unique_resources and a.resource is not None and a.resource == b.resource:
                continue
            bw = self._writes[j][oj]
            small, large = (aw, bw) if len(aw) <= len(bw) else (bw, aw)
            if any(p in large and large[p] != v for p, v in small.items()):
                continue
            mask |= 1 << oj
        self._support[key] = mask
        return mask

    def _propagate(self, state: tuple[int, ...], covered: int, required: int):
        active = [i for i, bits in enumerate(state) if bits]
        ds = list(state)
        while True:
            self.stats['propagation_rounds'] += 1
            changed = False
            # AC-3-style support propagation over all remaining binary constraints.
            for i in active:
                before = ds[i]
                keep = before
                for oi in _indices(before):
                    if any(not (self._supported(i, oi, j) & ds[j]) for j in active if j != i):
                        keep &= ~(1 << oi)
                if not keep:
                    self.stats['arc_failures'] += 1
                    return None
                if keep != before:
                    self.stats['pruned_options'] += before.bit_count() - keep.bit_count()
                    ds[i] = keep
                    changed = True
            # Requirements common to every option of a variable are already mandatory.
            mandatory = required
            coverage = {}
            for i in active:
                union = 0
                intersection = None
                for oi in _indices(ds[i]):
                    o = self.domains[i][oi]
                    union |= o.covers
                    intersection = o.needs if intersection is None else intersection & o.needs
                coverage[i] = union
                mandatory |= intersection or 0
            total = covered
            for value in coverage.values():
                total |= value
            if mandatory & ~total:
                self.stats['coverage_failures'] += 1
                return None
            # A choice must permit its own requirements and every mandatory bit.
            # If only this variable can provide a bit, its chosen option must do so.
            for i in active:
                others = covered
                for j in active:
                    if j != i:
                        others |= coverage[j]
                before = ds[i]
                keep = 0
                for oi in _indices(before):
                    o = self.domains[i][oi]
                    if not ((mandatory | o.needs) & ~(others | o.covers)):
                        keep |= 1 << oi
                if not keep:
                    self.stats['coverage_failures'] += 1
                    return None
                if keep != before:
                    self.stats['pruned_options'] += before.bit_count() - keep.bit_count()
                    ds[i] = keep
                    changed = True
            if changed:
                continue
            # Hall-capacity feasibility detects deficient subsets, not only an
            # insufficient total number of references. No concrete matching wins.
            if self.unique_resources:
                resources = []
                for i in active:
                    values = {self.domains[i][oi].resource for oi in _indices(ds[i])}
                    if None not in values:
                        resources.append(values)
                if not _matching_exists(resources):
                    self.stats['capacity_failures'] += 1
                    return None
            missing = mandatory & ~covered
            if missing:
                # Coverage also implies a matching only when ONE selected choice
                # can provide at most one of the missing bits. Multi-cell paint
                # effects are deliberately NOT subjected to this restriction.
                unit = all((self.domains[i][oi].covers & missing).bit_count() <= 1
                           for i in active for oi in _indices(ds[i]))
                if unit:
                    providers = [
                        {i for i in active if coverage[i] & (1 << bit)}
                        for bit in _indices(missing)
                    ]
                    if not _matching_exists(providers):
                        self.stats['capacity_failures'] += 1
                        return None
            return tuple(ds), mandatory

    def solutions(self) -> Iterator[tuple[int, ...]]:
        """Yield representative domain-index assignments with equivalent-state sharing."""
        initial = tuple((1 << len(d)) - 1 for d in self.domains)
        if any(not d for d in self.domains):
            self.exhausted = True
            return
        assignment = [-1] * len(self.domains)

        def visit(state, covered, required, emission):
            self.stats['nodes'] += 1
            propagated = self._propagate(state, covered, required)
            if propagated is None:
                return
            state, required = propagated
            signature = (state, covered, required, emission)
            if signature in self._memo:
                self.stats['memo_hits'] += 1
                return
            self._memo.add(signature)
            active = [i for i, bits in enumerate(state) if bits]
            if not active:
                if required & ~covered:
                    return
                self.stats['leaves'] += 1
                yield tuple(assignment)
                return
            i = min(active, key=lambda j: (state[j].bit_count(), j))
            for oi in _indices(state[i]):
                o = self.domains[i][oi]
                new = list(state)
                new[i] = 0
                feasible = True
                for j in active:
                    if j == i:
                        continue
                    new[j] &= self._supported(i, oi, j)
                    if not new[j]:
                        feasible = False
                        break
                if not feasible:
                    self.stats['forward_failures'] += 1
                    continue
                assignment[i] = oi
                yield from visit(tuple(new), covered | o.covers, required | o.needs,
                                 emission | o.emission)
                assignment[i] = -1
        try:
            yield from visit(initial, 0, self.required, frozenset())
            self.exhausted = True
        finally:
            destination = _PROFILE.get()
            if destination is not None:
                destination.update({self.label + '.' + k: v for k, v in self.stats.items()})
