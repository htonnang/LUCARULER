"""V78: input-derived exemplar libraries selected by partial-object evidence.

A finite program describes perception, donor roles, orientation and boundary
semantics. No learned program stores patches, coordinates or test answers.
Reference selection requires a unique best visible write effect for each query.
Tied different effects invalidate that program, never pick the first donor.
This local uniqueness gate is a declared restriction, not global assignment search.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from functools import lru_cache
from itertools import product


from correspondence import grid
from runtime import public_task

from attributes import components, background
from pattern_lifting import orient, paint_tile

FAMILY = 'reference_pattern_completion_v78'
ORIENTATIONS = ('identity','rotations','dihedral','r90','r180','r270',
                'flip','flip90','flip180','flip270')


def transforms(group):
    if group == 'identity':return ((0,False),)
    if group == 'rotations':return tuple((r,False) for r in range(4))
    if group == 'dihedral':return tuple(product(range(4),(False,True)))
    named={'r90':(1,False),'r180':(2,False),'r270':(3,False),
           'flip':(0,True),'flip90':(1,True),'flip180':(2,True),'flip270':(3,True)}
    if group not in named:raise ValueError('unknown orientation group')
    return (named[group],)


@dataclass(frozen=True)
class Patch:
    cells: tuple
    tile: tuple
    origin: tuple
    palette: frozenset


@lru_cache(maxsize=1024)
def parse(a, bg_rule, connectivity):
    """Reuse the shared component extractor; multicolour foreground connectivity."""
    bg=background(a,bg_rule)
    if bg is None:return None
    obs=components(a,bg,connectivity,False);patches=[]
    for o in obs:
        r0,c0,r1,c1=o.box;pts=set(o.cells)
        tile=tuple(tuple(a[r][c] if (r,c) in pts else bg for c in range(c0,c1+1))
                   for r in range(r0,r1+1))
        cells=tuple((r,c,a[r][c]) for r,c in o.cells)
        patches.append(Patch(cells,tile,(r0,c0),frozenset(v for r,c,v in cells)))
    return bg,tuple(patches)


def role_indices(patches, donors, targets):
    if len(patches)<2:return (),()
    largest=max(len(p.cells) for p in patches)
    if donors=='multicolour':ds=tuple(i for i,p in enumerate(patches) if len(p.palette)>=2)
    elif donors=='largest':ds=tuple(i for i,p in enumerate(patches) if len(p.cells)==largest and largest>=2)
    else:raise ValueError('unknown donor role')
    if targets=='monochrome':qs=tuple(i for i,p in enumerate(patches) if i not in ds and len(p.palette)==1)
    elif targets=='smaller':qs=tuple(i for i,p in enumerate(patches) if i not in ds and len(p.cells)<largest)
    else:raise ValueError('unknown target role')
    return ds,qs


def render_writes(a, bg, effects):
    """One transactional overlay; no foreground erasure or order-based conflicts."""
    writes={}
    for effect in effects:
        for r,c,v in effect:
            if not (0<=r<len(a) and 0<=c<len(a[0])):return None
            if a[r][c] not in (bg,v):return None
            if (r,c) in writes and writes[(r,c)]!=v:return None
            writes[(r,c)]=v
    out=[list(row) for row in a]
    for (r,c),v in writes.items():out[r][c]=v
    return grid(out)


@lru_cache(maxsize=4096)
def placements(a,bg,patches,ds,query_index,orientation,boundary):
    """All compatible placements for a query, scored against original evidence.

    Deduplication is by visible added writes. Repeated identical donors do not vote.
    """
    if boundary not in ('reject','clip'):raise ValueError('unknown boundary policy')
    query=patches[query_index];qr,qc,qv=query.cells[0]
    h,w=len(a),len(a[0]);options={}
    for i in ds:
        donor=patches[i]
        if len(donor.cells)<=len(query.cells) or not query.palette<=donor.palette:continue
        for turns,flip in transforms(orientation):
            tile=paint_tile(orient(donor.tile,turns,flip),bg,'template',None)
            cells=tuple((r,c,v) for r,row in enumerate(tile) for c,v in enumerate(row) if v!=bg)
            th,tw=len(tile),len(tile[0])
            for ar,ac,av in cells:
                if av!=qv:continue
                dr,dc=qr-ar,qc-ac
                if boundary=='reject' and (dr<0 or dc<0 or dr+th>h or dc+tw>w):continue
                mapped={(r+dr,c+dc):v for r,c,v in cells}
                if any(mapped.get((r,c))!=v for r,c,v in query.cells):continue
                visible=tuple((r,c,v) for (r,c),v in mapped.items() if 0<=r<h and 0<=c<w)
                if any(a[r][c] not in (bg,v) for r,c,v in visible):continue
                added=tuple(sorted((r,c,v) for r,c,v in visible if a[r][c]==bg))
                if not added:continue
                support=sum(a[r][c]==v for r,c,v in visible)
                record={'donor_index':i,'origin':(dr,dc),'turns':turns,'flip':flip,
                        'support':support,'visible_cells':len(visible),'clipped':len(visible)<len(cells)}
                if added not in options:options[added]={'support':support,'references':[record]}
                else:
                    options[added]['support']=max(support,options[added]['support'])
                    options[added]['references'].append(record)
    return tuple((effect,value['support'],tuple(value['references'])) for effect,value in options.items())


@dataclass(frozen=True)
class ReferenceProgram:
    background_rule: int | str
    connectivity: int
    donors: str
    targets: str
    orientation: str
    boundary: str
    evidence: str

    def apply(self,raw,trace=False):
        a=grid(raw);s=parse(a,self.background_rule,self.connectivity)
        if s is None:return None,{'reason':'background_unresolved'}
        bg,ps=s;ds,qs=role_indices(ps,self.donors,self.targets)
        detail={'background':bg,'donors':list(ds),'queries':list(qs),'matches':[]}
        if not ds or not qs:return None,{**detail,'reason':'missing_donor_or_query'}
        effects=[]
        for q in qs:
            opts=placements(a,bg,ps,ds,q,self.orientation,self.boundary)
            if self.evidence=='maximum_support' and opts:
                best=max(o[1] for o in opts);opts=tuple(o for o in opts if o[1]==best)
            elif self.evidence not in ('all','maximum_support'):raise ValueError('unknown evidence policy')
            if len(opts)!=1:
                return None,{**detail,'reason':'no_matching_reference' if not opts else 'reference_ambiguity',
                             'query_index':q,'competing_effects':len(opts)}
            effect,support,refs=opts[0];effects.append(effect)
            if trace:detail['matches'].append({'query_index':q,'support':support,'added_pixels':len(effect),
                       'equivalent_references':list(refs),'added_writes':effect})
        result=render_writes(a,bg,effects)
        if result is None:return None,{**detail,'reason':'transactional_collision'}
        if result==a:return None,{**detail,'reason':'no_observed_completion'}
        if trace:
            detail['input_patterns']=[{'index':i,'origin':p.origin,'tile':p.tile,'palette':sorted(p.palette)} for i,p in enumerate(ps)]
        return result,{**detail,'reason':'complete'}

    def predict(self,a):return self.apply(a)[0]
    def describe(self):return {'family':FAMILY,**asdict(self)}
    def trace(self,a):
        result,detail=self.apply(a,trace=True)
        return {'program':self.describe(),'scene':detail,'prediction':result}


def fit(raw_pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any((len(a),len(a[0]))!=(len(y),len(y[0])) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    bgs=[]
    for rule in ('modal',*sorted(common)):
        if all((bg:=background(a,rule)) is not None and all(a[r][c]==bg or a[r][c]==y[r][c]
                 for r in range(len(a)) for c in range(len(a[0]))) for a,y in pairs):bgs.append(rule)
    result=[]
    for bg,conn,donors,targets in product(bgs,(4,8),('multicolour','largest'),('monochrome','smaller')):
        if any((s:=parse(a,bg,conn)) is None or not all(role_indices(s[1],donors,targets)) for a,y in pairs):continue
        for ori,bound,evidence in product(ORIENTATIONS,('reject','clip'),('all','maximum_support')):
            model=ReferenceProgram(bg,conn,donors,targets,ori,bound,evidence)
            if all(model.predict(a)==y for a,y in pairs):result.append(model)
    return result


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0
    for m in models:
        key=tuple(m.predict(t['input']) for t in clean['test'])
        if any(p is None for p in key):invalid+=1;continue
        groups.setdefault(key,[]).append(m.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    key=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
      'tests':[{'status':status,'prediction':[list(r) for r in key[i]] if key else None} for i in range(len(clean['test']))],
      'supporting_families':[FAMILY] if key else [],'supporting_laws':groups[key][:20] if key else [],
      'witness_predictions':[[[list(r) for r in y] for y in k] for k in list(groups)[:2]],
      'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
               'all_admitted_joint_alternatives_retained':True,'local_unique_reference_gate':True}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        f={'train':[d for i,d in enumerate(clean['train']) if i!=held],
           'test':[{'input':demo['input']}]+clean['test']}
        r=infer(f);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
          'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
          'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
          'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


