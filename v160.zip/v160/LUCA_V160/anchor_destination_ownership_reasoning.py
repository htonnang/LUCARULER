"""LUCA V159: anchor-destination ownership and transport.

This family anti-unifies singleton-payload movements around structurally inferred
anchors and frames:

* external markers compact to unique anchor-shell destinations while preserving
  their relative sector;
* four inner-corner payloads are extruded to diagonally opposite outer corners;
* a two-payload successor chain moves one payload to the other's source and the
  second payload to the corresponding opposite-side exterior corner.

The implementation is task-ID blind and target blind. Backgrounds, colours,
anchor dimensions, frame dimensions, payload positions, orientation, and test
placements are inferred from demonstrations or the current input. No absolute
training coordinates or official test targets are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anchor_destination_ownership"
LANGUAGE = "spinoza_anchor_destination_ownership_v159"
SCHEMA_VERSION = 1
OPERATOR = "anchor_destination_ownership_materialisation"
NODE_VOCABULARY = "anchor_frame_marker_and_payload_nodes"
EDGE_VOCABULARY = "relative_sector_corner_successor_and_ownership_edges"


SIDES = ("top", "bottom", "left", "right")


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "anchor_destination_ownership_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "payload_colour_preserved": True,
            "payload_count_preserved": True,
            "destination_ownership_unique": True,
            "shared_consequence_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _background(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    common = counts.most_common()
    if len(common) > 1 and common[0][1] == common[1][1]:
        raise Inapplicable("background frequency is tied")
    return common[0][0]


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, background: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] != background
    }
    output = []
    neighbours = ((-1, 0), (1, 0), (0, -1), (0, 1))
    while remaining:
        seed = next(iter(remaining))
        colour = value[seed[0]][seed[1]]
        remaining.remove(seed)
        stack = [seed]
        cells = {seed}
        while stack:
            r, c = stack.pop()
            for dr, dc in neighbours:
                point = (r + dr, c + dc)
                if point in remaining and value[point[0]][point[1]] == colour:
                    remaining.remove(point)
                    cells.add(point)
                    stack.append(point)
        output.append((colour, frozenset(cells)))
    output.sort(key=lambda item: (_bbox(item[1]), item[0], len(item[1])))
    return tuple(output)


def _solid_rectangle(cells):
    r0, c0, r1, c1 = _bbox(cells)
    return len(cells) == (r1 - r0 + 1) * (c1 - c0 + 1)


def _outline_rectangle(cells):
    r0, c0, r1, c1 = _bbox(cells)
    if r1 - r0 < 2 or c1 - c0 < 2:
        return False
    expected = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }
    return set(cells) == expected


def _same_shape_and_counts(source: Grid, target: Grid):
    source = grid(source)
    target = grid(target)
    if _shape(source) != _shape(target):
        return False
    return Counter(cell for row in source for cell in row) == Counter(
        cell for row in target for cell in row
    )


def _inside(cells, h, w):
    return all(0 <= r < h and 0 <= c < w for r, c in cells)


def _move_payloads(value: Grid, background: int, moves, protected=frozenset()):
    value = grid(value)
    h, w = _shape(value)
    work = _array(value)
    protected = set(protected)
    for _, source, _ in moves:
        for r, c in source:
            work[r][c] = background
    occupied = set()
    for colour, _, target in moves:
        if not _inside(target, h, w):
            raise Inapplicable("destination leaves the canvas")
        for r, c in target:
            if (r, c) in protected or (r, c) in occupied or work[r][c] != background:
                raise Inapplicable("destination ownership is not unique")
            occupied.add((r, c))
            work[r][c] = colour
    prediction = grid(work)
    if prediction == value:
        raise Inapplicable("transport has no consequence")
    return prediction


@dataclass(frozen=True)
class MarkerShellCompactionProgram:
    background: int

    kind = "marker_shell_compaction"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _background(value) != self.background:
            raise Inapplicable("background role changed")
        components = _components(value, self.background)
        rectangles = [
            item for item in components
            if len(item[1]) >= 4 and _solid_rectangle(item[1])
        ]
        singletons = [item for item in components if len(item[1]) == 1]
        if len(rectangles) != 1 or len(singletons) < 2:
            raise Inapplicable("one solid anchor and at least two singleton payloads are required")
        if len(rectangles) + len(singletons) != len(components):
            raise Inapplicable("unexpected non-anchor material")
        if len({colour for colour, _ in singletons}) != 1:
            raise Inapplicable("singleton payloads must share one role colour")
        _, anchor = rectangles[0]
        r0, c0, r1, c1 = _bbox(anchor)
        moves = []
        destinations = set()
        for colour, cells in singletons:
            (r, c), = tuple(cells)
            if r0 <= r <= r1 and c0 <= c <= c1:
                raise Inapplicable("payload lies inside the solid anchor")
            rr = r0 - 1 if r < r0 else r1 + 1 if r > r1 else r
            cc = c0 - 1 if c < c0 else c1 + 1 if c > c1 else c
            destination = (rr, cc)
            if destination in destinations:
                raise Inapplicable("multiple payloads claim the same shell destination")
            destinations.add(destination)
            moves.append((colour, cells, frozenset((destination,))))
        return anchor, tuple(moves)

    def predict(self, value: Grid):
        anchor, moves = self._scene(value)
        return _move_payloads(value, self.background, moves, anchor)

    def describe(self, pairs):
        return _law(
            self,
            scene="one solid rectangular anchor and multiple same-role singleton payloads",
            relation_chain=(
                "extract the unique solid rectangular anchor and singleton payload nodes",
                "classify each payload by its row/column sector relative to the anchor",
                "assign the unique adjacent-shell destination preserving that relative sector",
                "erase the payload guides and materialise the owned shell destinations",
            ),
            parameters={
                "background": self.background,
                "distance_policy": "compact_to_one_cell_anchor_shell",
                "ownership_policy": "unique_relative_sector_destination",
            },
            corollary="payloads compact to the anchor shell without changing colour or sector role",
            notions=(
                "anchor geometry and colour are preserved",
                "multiple payloads may occupy side or corner sectors",
                "destination collisions or inside-anchor payloads abstain",
            ),
        )


@dataclass(frozen=True)
class OppositeCornerExtrusionProgram:
    background: int

    kind = "opposite_corner_extrusion"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _background(value) != self.background:
            raise Inapplicable("background role changed")
        h, w = _shape(value)
        components = _components(value, self.background)
        frames = [item for item in components if _outline_rectangle(item[1])]
        singletons = [item for item in components if len(item[1]) == 1]
        if len(frames) != 1 or len(singletons) != 4:
            raise Inapplicable("one outline frame and four singleton payloads are required")
        if len(frames) + len(singletons) != len(components):
            raise Inapplicable("unexpected non-frame material")
        if len({colour for colour, _ in singletons}) != 4:
            raise Inapplicable("the four payload roles must have distinct colours")
        _, frame = frames[0]
        r0, c0, r1, c1 = _bbox(frame)
        mapping = {
            (r0 + 1, c0 + 1): (r1 + 1, c1 + 1),
            (r0 + 1, c1 - 1): (r1 + 1, c0 - 1),
            (r1 - 1, c0 + 1): (r0 - 1, c1 + 1),
            (r1 - 1, c1 - 1): (r0 - 1, c0 - 1),
        }
        if not _inside(mapping.values(), h, w):
            raise Inapplicable("the frame lacks a complete one-cell exterior corner shell")
        moves = []
        seen_sources = set()
        for colour, cells in singletons:
            source = next(iter(cells))
            if source not in mapping or source in seen_sources:
                raise Inapplicable("payloads must occupy the four inner-corner roles")
            seen_sources.add(source)
            moves.append((colour, cells, frozenset((mapping[source],))))
        if seen_sources != set(mapping):
            raise Inapplicable("all four inner-corner roles are required")
        return frame, tuple(moves)

    def predict(self, value: Grid):
        frame, moves = self._scene(value)
        return _move_payloads(value, self.background, moves, frame)

    def describe(self, pairs):
        return _law(
            self,
            scene="one rectangular outline frame with four distinct inner-corner payload roles",
            relation_chain=(
                "extract the outline frame and the four inner-corner singleton payloads",
                "pair every inner corner with the diagonally opposite outer-shell corner",
                "assign each payload to its unique opposite-corner destination",
                "preserve the frame and materialise the four exterior payload roles",
            ),
            parameters={
                "background": self.background,
                "corner_relation": "inner_corner_to_diagonally_opposite_outer_corner",
                "ownership_policy": "one_payload_per_outer_corner",
            },
            corollary="the frame reverses corner roles from its inner shell to its outer shell",
            notions=(
                "payload colours are semantic roles and remain unchanged",
                "frame dimensions and position are inferred from the current input",
                "missing corners, duplicate roles or out-of-bounds destinations abstain",
            ),
        )


@dataclass(frozen=True)
class SuccessorCornerTransportProgram:
    background: int
    follower_colour: int
    leader_colour: int
    marker_side: str

    kind = "successor_corner_transport"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _background(value) != self.background:
            raise Inapplicable("background role changed")
        components = _components(value, self.background)
        rectangles = [
            item for item in components
            if len(item[1]) >= 6 and _solid_rectangle(item[1])
        ]
        singletons = [item for item in components if len(item[1]) == 1]
        if len(rectangles) != 1 or len(singletons) != 2:
            raise Inapplicable("one solid rectangle and two singleton payloads are required")
        if len(rectangles) + len(singletons) != len(components):
            raise Inapplicable("unexpected material around the rectangle")
        by_colour = {colour: cells for colour, cells in singletons}
        if set(by_colour) != {self.follower_colour, self.leader_colour}:
            raise Inapplicable("payload role colours changed")
        _, rectangle = rectangles[0]
        r0, c0, r1, c1 = _bbox(rectangle)
        follower = next(iter(by_colour[self.follower_colour]))
        leader = next(iter(by_colour[self.leader_colour]))
        if self.marker_side == "top":
            if follower[0] != r0 - 1 or leader[0] != r0 - 1:
                raise Inapplicable("payloads are not on the top reference side")
            if not (c0 <= follower[1] <= c1 and c0 <= leader[1] <= c1) or follower[1] == leader[1]:
                raise Inapplicable("top payload order is not unique")
            leader_target = (r1, c0 - 1 if leader[1] < follower[1] else c1 + 1)
        elif self.marker_side == "bottom":
            if follower[0] != r1 + 1 or leader[0] != r1 + 1:
                raise Inapplicable("payloads are not on the bottom reference side")
            if not (c0 <= follower[1] <= c1 and c0 <= leader[1] <= c1) or follower[1] == leader[1]:
                raise Inapplicable("bottom payload order is not unique")
            leader_target = (r0, c0 - 1 if leader[1] < follower[1] else c1 + 1)
        elif self.marker_side == "left":
            if follower[1] != c0 - 1 or leader[1] != c0 - 1:
                raise Inapplicable("payloads are not on the left reference side")
            if not (r0 <= follower[0] <= r1 and r0 <= leader[0] <= r1) or follower[0] == leader[0]:
                raise Inapplicable("left payload order is not unique")
            leader_target = (r0 - 1 if leader[0] < follower[0] else r1 + 1, c1)
        elif self.marker_side == "right":
            if follower[1] != c1 + 1 or leader[1] != c1 + 1:
                raise Inapplicable("payloads are not on the right reference side")
            if not (r0 <= follower[0] <= r1 and r0 <= leader[0] <= r1) or follower[0] == leader[0]:
                raise Inapplicable("right payload order is not unique")
            leader_target = (r0 - 1 if leader[0] < follower[0] else r1 + 1, c0)
        else:
            raise Inapplicable("unknown reference side")
        moves = (
            (self.follower_colour, by_colour[self.follower_colour], frozenset((leader,))),
            (self.leader_colour, by_colour[self.leader_colour], frozenset((leader_target,))),
        )
        return rectangle, moves

    def predict(self, value: Grid):
        rectangle, moves = self._scene(value)
        return _move_payloads(value, self.background, moves, rectangle)

    def describe(self, pairs):
        opposite = {
            "top": "bottom",
            "bottom": "top",
            "left": "right",
            "right": "left",
        }[self.marker_side]
        return _law(
            self,
            scene="one solid rectangle with two ordered singleton payload roles on one exterior side",
            relation_chain=(
                "extract the rectangle and the ordered follower/leader payload pair",
                "move the follower into the leader's vacated source position",
                f"send the leader to the {opposite}-side exterior corner determined by their order",
                "preserve the rectangle and materialise the two owned destinations",
            ),
            parameters={
                "background": self.background,
                "follower_colour": self.follower_colour,
                "leader_colour": self.leader_colour,
                "marker_side": self.marker_side,
                "ownership_policy": "successor_then_opposite_side_corner",
            },
            corollary="the ordered payload pair forms a two-stage successor transport around the rectangle",
            notions=(
                "follower and leader roles are learned from demonstrations",
                "the leader's tangential order selects the opposite-side corner",
                "role ties, missing side alignment, collision or overflow abstain",
            ),
        )


def _common_background(pairs):
    backgrounds = []
    for source, target in pairs:
        if not _same_shape_and_counts(source, target):
            raise Inapplicable("destination transport must preserve canvas shape and colour counts")
        source_background = _background(source)
        target_background = _background(target)
        if source_background != target_background:
            raise Inapplicable("background role changes across the transformation")
        backgrounds.append(source_background)
    if len(set(backgrounds)) != 1:
        raise Inapplicable("demonstrations use inconsistent background roles")
    return backgrounds[0]


def _fit_marker_shell(pairs):
    try:
        background = _common_background(pairs)
        programme = MarkerShellCompactionProgram(background)
        if all(programme.predict(source) == grid(target) for source, target in pairs):
            return (programme,)
    except Inapplicable:
        pass
    return ()


def _fit_opposite_corner(pairs):
    try:
        background = _common_background(pairs)
        programme = OppositeCornerExtrusionProgram(background)
        if all(programme.predict(source) == grid(target) for source, target in pairs):
            return (programme,)
    except Inapplicable:
        pass
    return ()


def _singleton_role_colours(value, background):
    components = _components(value, background)
    return tuple(sorted(colour for colour, cells in components if len(cells) == 1))


def _fit_successor_corner(pairs):
    try:
        background = _common_background(pairs)
        colours = _singleton_role_colours(pairs[0][0], background)
    except Inapplicable:
        return ()
    if len(colours) != 2 or colours[0] == colours[1]:
        return ()
    output = []
    for follower in colours:
        leader = colours[1] if follower == colours[0] else colours[0]
        for side in SIDES:
            programme = SuccessorCornerTransportProgram(background, follower, leader, side)
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return tuple(output)


def fit_anchor_destination_ownership_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return ()
    allowed = set(allowed_kinds or ()) or None
    programmes = []
    for fitter in (_fit_marker_shell, _fit_opposite_corner, _fit_successor_corner):
        try:
            programmes.extend(fitter(pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            pass
    output = []
    seen = set()
    for programme in programmes:
        if allowed is not None and programme.kind not in allowed:
            continue
        key = (type(programme).__name__, repr(programme))
        if key in seen:
            continue
        seen.add(key)
        output.append(programme)
    output.sort(key=lambda programme: (programme.kind, repr(programme)))
    return tuple(output)


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, MarkerShellCompactionProgram):
                anchor, moves = programme._scene(source)
                _, source_cells, _ = moves[0]
                r, c = next(iter(source_cells))
                candidates.append((r, c, programme.background, "singleton_payload_node"))
                ar, ac = sorted(anchor)[0]
                candidates.append((ar, ac, programme.background, "solid_anchor_node"))
            elif isinstance(programme, OppositeCornerExtrusionProgram):
                frame, moves = programme._scene(source)
                r, c = sorted(frame)[0]
                candidates.append((r, c, programme.background, "outline_frame_node"))
                _, source_cells, _ = moves[0]
                r, c = next(iter(source_cells))
                candidates.append((r, c, programme.background, "inner_corner_payload_node"))
            elif isinstance(programme, SuccessorCornerTransportProgram):
                rectangle, moves = programme._scene(source)
                _, source_cells, _ = moves[0]
                r, c = next(iter(source_cells))
                candidates.append((r, c, programme.background, "follower_payload_node"))
                rr, cc = sorted(rectangle)[0]
                candidates.append((rr, cc, programme.background, "solid_rectangle_node"))
        except (Inapplicable, StopIteration, IndexError):
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {
                    "cell": [r, c],
                    "from": int(previous),
                    "to": int(replacement),
                    "role": role,
                }
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_anchor_destination_ownership(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anchor_destination_ownership_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "payload_colour_preserved": True,
            "payload_count_preserved": True,
            "destination_ownership_unique": True,
            "shared_consequence_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_anchor_destination_ownership_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anchor_destination_ownership_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_anchor_destination_ownership(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
