"""Shared runtime utilities. No task data, history or version dispatch chain."""
from __future__ import annotations
from contextlib import contextmanager
import signal
import time
import copy
from typing import Any, Callable
from correspondence import grid

class FamilyTimeout(BaseException):
    pass


@contextmanager
def time_limit(seconds: float):
    if seconds <= 0:
        yield
        return
    if not hasattr(signal,'setitimer'):
        raise RuntimeError('Per-family timeouts require POSIX; use timeout=0 on Windows.')
    def stop(signum,frame):raise FamilyTimeout()
    old=signal.signal(signal.SIGALRM,stop)
    signal.setitimer(signal.ITIMER_REAL,seconds)
    try:yield
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGALRM,old)


def public_task(task: dict[str,Any]) -> dict[str,Any]:
    """Construct a fresh data object; discard task IDs and ALL test-output fields."""
    if not isinstance(task,dict) or not task.get('train') or not task.get('test'):
        raise ValueError('task must have nonempty train and test lists')
    return {
        'train':[{'input':[list(r) for r in grid(d['input'])],
                  'output':[list(r) for r in grid(d['output'])]} for d in task['train']],
        'test':[{'input':[list(r) for r in grid(t['input'])]} for t in task['test']],
    }


def describe(law: Any) -> str:
    f=getattr(law,'name',None)
    return f() if callable(f) else repr(law)


def joint_result(groups: dict, count: int, incomplete: bool = False) -> dict[str,Any]:
    status = ('incomplete' if incomplete else 'unique' if len(groups)==1
              else 'ambiguous' if groups else 'no_fit')
    chosen = next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
                     for i in range(count)],
            'supporting_families':sorted({s['family'] for s in groups[chosen]}) if chosen else [],
            'supporting_laws':groups[chosen][:20] if chosen else []}


def abstain(count: int, status: str, reason: str) -> dict:
    result = joint_result({}, count)
    result['status'] = status
    for test in result['tests']: test['status'] = status
    result['reason'] = reason
    return result


def run_checked(task: dict, infer: Callable, validate: Callable, *,
                search_timeout: float = 0, validation_timeout: float = 0) -> dict:
    """Run an unchanged native fitter and its unchanged validation function.

    Resource failures are explicit abstentions. Test targets never enter fitting.
    Native validators are not replaced with a generic or relaxed validator.
    """
    clean = public_task(task)
    count = len(clean['test'])
    start = time.perf_counter()
    try:
        with time_limit(search_timeout):
            raw = infer(clean)
    except FamilyTimeout:
        raw = abstain(count, 'timeout', 'family search incomplete')
    except Exception as exc:
        raw = abstain(count, 'error', f'{type(exc).__name__}: {exc}')
    raw['runtime_seconds'] = time.perf_counter() - start
    start = time.perf_counter()
    try:
        with time_limit(validation_timeout):
            check = validate(clean, raw)
    except FamilyTimeout:
        check = {'passed': False, 'reason': 'validation_timeout', 'folds': []}
    except Exception as exc:
        check = {'passed': False, 'reason': f'validation_error:{type(exc).__name__}:{exc}', 'folds': []}
    validated = copy.deepcopy(raw)
    if raw['status'] == 'unique' and not check['passed']:
        reason = check['reason']
        status = ('timeout' if reason == 'validation_timeout' else
                  'error' if reason.startswith('validation_error:') else 'validation_rejected')
        validated = abstain(count, status, reason)
    validated['validation'] = check
    validated['runtime_seconds'] = raw['runtime_seconds'] + time.perf_counter() - start
    return {'raw': raw, 'validated': validated}
