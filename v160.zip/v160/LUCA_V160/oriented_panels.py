"""LUCA V66: exact orientation-and-overlay constraint synthesis.

Language: V65 equal-panel layouts/background roles, independently fitted D4
orientations per panel, and one global later-wins layer order. All demonstrations
share a program. No task IDs or official test answers are consumed.

We solve colour/coverage constraints top-layer-first using integer bitsets.
Orientations equivalent on demonstrations share fitting work but are *retained*
as alternatives and re-expanded jointly over all test inputs. This is not a
beam search, or a rule that treats demonstration equivalence as universal.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from math import prod
from typing import Iterable
from geometry import rotate, reflect
from correspondence import grid
from runtime import public_task, joint_result
from panel_layout import Background, Layout, LAYOUTS
from colour_panels import render

Grid = tuple[tuple[int, ...], ...]
TEMPLATE = 'panel_partition -> per_panel_dihedral_orientation -> colour_preserving_overlay'
ORIENTATIONS = tuple(range(8))


def orient(raw, code: int) -> Grid:
    """0..3 clockwise quarter-turns; 4..7 reflect left/right then rotate."""
    if type(code) is not int or code not in ORIENTATIONS:
        raise ValueError('orientation code must be an integer in 0..7')
    a = grid(raw)
    if code >= 4:
        a = reflect(a, 'horizontal')
    return rotate(a, code % 4)


def orientation_name(code: int) -> str:
    if code not in ORIENTATIONS:
        raise ValueError('invalid orientation')
    return ('reflect_lr_then_' if code >= 4 else '') + f'rotate_{90*(code%4)}'


@dataclass(frozen=True)
class OrientedOverlayProgram:
    layout: Layout
    background: Background
    order: tuple[int, ...]
    orientation_options: tuple[tuple[int, ...], ...]

    @property
    def expanded_count(self) -> int:
        return prod(len(options) for options in self.orientation_options)

    def name(self) -> str:
        return (f'split_panels({self.layout.name()}) -> transparent({self.background.name()})'
                f' -> D4_options={self.orientation_options}'
                f' -> preserve_colours(order={self.order},later_wins)')

    def template(self) -> str:
        return TEMPLATE

    def joint_predictions(self, raw_inputs: Iterable) -> set[tuple[Grid, ...]]:
        """Expand one fixed orientation choice across ALL inputs of a task.

        A colour-orientation hypothesis may not be selected independently per
        test grid. Runtime grouping uses the joint test *inputs*, not targets.
        """
        arrays = tuple(grid(a) for a in raw_inputs)
        if not arrays:
            return set()
        splits = tuple(self.layout.split(a) for a in arrays)
        if any(p is None for p in splits):
            return set()
        bgs = tuple(self.background.value(a, panels) for a, panels in zip(arrays, splits))
        if any(bg is None for bg in bgs):
            return set()
        n = self.layout.rows * self.layout.columns
        if len(self.orientation_options) != n or sorted(self.order) != list(range(n)):
            raise ValueError('invalid program panel specification')
        options = []
        for index, codes in enumerate(self.orientation_options):
            # Equivalent test transformations can safely share rendering work.
            options.append(tuple(dict.fromkeys(
                tuple(orient(panels[index], code) for panels in splits) for code in codes)))
        groups = set()
        for views in product(*options):
            if any(len({(len(v[t]), len(v[t][0])) for v in views}) != 1
                   for t in range(len(arrays))):
                continue
            key = tuple(render(tuple(v[t] for v in views), bgs[t], self.order)
                        for t in range(len(arrays)))
            groups.add(key)
        return groups

    def predict(self, raw) -> Grid | None:
        outputs = self.joint_predictions((raw,))
        return next(iter(outputs))[0] if len(outputs) == 1 else None

    def trace(self, raw) -> dict | None:
        a = grid(raw); panels = self.layout.split(a)
        if panels is None:
            return None
        bg = self.background.value(a, panels)
        if bg is None:
            return None
        options = self.joint_predictions((a,))
        return {'layout': self.layout.name(), 'background_role': self.background.name(),
                'transparent_colour': bg, 'layer_order': list(self.order),
                'orientation_options': [[orientation_name(c) for c in cs] for cs in self.orientation_options],
                'expanded_program_count': self.expanded_count,
                'source_panels': [[list(r) for r in p] for p in panels],
                'representative_oriented_panels': [[list(r) for r in orient(p, cs[0])]
                    for p, cs in zip(panels, self.orientation_options)],
                'distinct_predictions': len(options),
                'prediction': [list(r) for r in next(iter(options))[0]] if len(options) == 1 else None}


def _candidate_layouts(pairs):
    for rows, cols in LAYOUTS:
        for rg, cg in product((0, 1, 2) if rows > 1 else (0,),
                              (0, 1, 2) if cols > 1 else (0,)):
            layout = Layout(rows, cols, rg, cg)
            shapes_ok = True
            for a, y in pairs:
                ah = len(a) - (rows-1)*rg; aw = len(a[0]) - (cols-1)*cg
                if ah <= 0 or aw <= 0 or ah % rows or aw % cols:
                    shapes_ok = False; break
                ph, pw = ah//rows, aw//cols
                if (len(y), len(y[0])) not in ((ph, pw), (pw, ph)):
                    shapes_ok = False; break
            if shapes_ok:
                yield layout


def _orientation_groups(splits, targets, index):
    groups = {}
    for code in ORIENTATIONS:
        transformed = tuple(orient(panels[index], code) for panels in splits)
        if any((len(p), len(p[0])) != (len(y), len(y[0])) for p, y in zip(transformed, targets)):
            continue
        groups.setdefault(transformed, []).append(code)
    return [(tuple(codes), values) for values, codes in groups.items()]


def _masks(values, targets, backgrounds):
    fg = wrong = on_empty_target = 0
    bit = 1
    for panel, target, bg in zip(values, targets, backgrounds):
        for row, expected in zip(panel, target):
            for c, y in zip(row, expected):
                if c != bg:
                    fg |= bit
                    if c != y:
                        wrong |= bit
                    if y == bg:
                        on_empty_target |= bit
                bit <<= 1
    return fg, wrong, on_empty_target


def _solve_order(groups, target_foreground):
    """Exact CSP. Groups contain (orientation-options, foreground, wrong) tuples.

    A top layer must be correct wherever visible. A lower layer may disagree
    only where a higher layer already covers it. Every target foreground cell
    must finally be covered. Transparent layers can never erase foreground.
    """
    n = len(groups)
    potential = [0]*n
    for i, candidates in enumerate(groups):
        for _, foreground, _ in candidates:
            potential[i] |= foreground

    def visit(remaining, covered, top_order, selected):
        if not remaining:
            if covered == target_foreground:
                yield tuple(reversed(top_order)), tuple(selected[i] for i in range(n))
            return
        attainable = covered
        for index in remaining:
            attainable |= potential[index]
        if target_foreground & ~attainable:
            return
        for index in remaining:
            rest = tuple(i for i in remaining if i != index)
            for codes, foreground, wrong in groups[index]:
                if wrong & ~covered:
                    continue
                selected[index] = codes
                yield from visit(rest, covered | foreground, top_order+(index,), selected)
                del selected[index]
    yield from visit(tuple(range(n)), 0, (), {})


def fit(raw_pairs: Iterable) -> list[OrientedOverlayProgram]:
    pairs = tuple((grid(a), grid(y)) for a, y in raw_pairs)
    if not pairs:
        return []
    targets = tuple(y for a, y in pairs)
    common = set.intersection(*({v for row in a for v in row} for a, y in pairs))
    backgrounds = [Background(), Background('unique_modal')]
    backgrounds += [Background('constant', c) for c in sorted(common)]
    programs = []
    for layout in _candidate_layouts(pairs):
        splits = tuple(layout.split(a) for a, y in pairs)
        if any(p is None for p in splits):
            continue
        n = layout.rows * layout.columns
        orientation_groups = [_orientation_groups(splits, targets, i) for i in range(n)]
        if any(not options for options in orientation_groups):
            continue
        for background in backgrounds:
            bgs = tuple(background.value(a, ps) for (a, y), ps in zip(pairs, splits))
            if any(bg is None for bg in bgs):
                continue
            target_foreground = 0; bit = 1
            for y, bg in zip(targets, bgs):
                for row in y:
                    for colour in row:
                        if colour != bg:
                            target_foreground |= bit
                        bit <<= 1
            groups = []
            for options in orientation_groups:
                candidates = []
                for codes, values in options:
                    foreground, wrong, on_empty = _masks(values, targets, bgs)
                    if not on_empty:
                        candidates.append((codes, foreground, wrong))
                groups.append(candidates)
            if any(not candidates for candidates in groups):
                continue
            for order, codes in _solve_order(groups, target_foreground):
                law = OrientedOverlayProgram(layout, background, order, codes)
                # Replaying a representative is exact: all codes in each group
                # have identical oriented grids on EVERY demonstration.
                for (a, y), panels, bg in zip(pairs, splits, bgs):
                    pred = render(tuple(orient(p, cs[0]) for p, cs in zip(panels, codes)), bg, order)
                    if pred != y:
                        raise AssertionError('CSP law failed exact demonstration replay')
                programs.append(law)
    return programs


def evaluate(programs: list[OrientedOverlayProgram], raw_inputs: Iterable) -> dict:
    inputs = tuple(raw_inputs); groups = {}; rejected = 0; supports = {}
    for law in programs:
        keys = law.joint_predictions(inputs)
        if not keys:
            rejected += 1
        for key in keys:
            support = groups.setdefault(key, [])
            # Only reporting is capped; ALL distinct joint predictions retained.
            if len(support) < 20:
                support.append({'family': 'oriented_panels_v66', 'law': law.name(), 'template': TEMPLATE})
            supports[key] = supports.get(key, 0) + 1
    result = joint_result(groups, len(inputs))
    result['candidates'] = [{'predictions': [[list(r) for r in p] for p in key],
                             'program_groups': supports[key], 'templates': [TEMPLATE],
                             'representative_laws': [s['law'] for s in support]}
                            for key, support in sorted(groups.items())]
    result['inapplicable_program_groups'] = rejected
    result['stats'] = {'fitted_programs': sum(l.expanded_count for l in programs),
                       'compressed_program_groups': len(programs), 'beam_pruning': False,
                       'fitted_alternatives_discarded': False,
                       'search_complete_within_declared_grammar': True,
                       'foreground_colours_preserved': True,
                       'orientation_language_size': 8}
    return result


def infer(task: dict) -> dict:
    clean = public_task(task)
    laws = fit((d['input'], d['output']) for d in clean['train'])
    return evaluate(laws, (t['input'] for t in clean['test']))


def validate_leave_one_out(task: dict, fitted: dict) -> dict:
    """Refit without each demo, then test its target and ordinary-input stability."""
    clean = public_task(task); n = len(clean['train'])
    if fitted['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if n < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [t['prediction'] for t in fitted['tests']]
    folds = []
    for held in range(n):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': clean['train'][held]['input']}] + clean['test']}
        result = infer(fold)
        predictions = [t['prediction'] for t in result['tests']]
        exact = result['status'] == 'unique' and predictions[0] == clean['train'][held]['output']
        stable = result['status'] == 'unique' and predictions[1:] == expected
        folds.append({'held_index': held, 'status': result['status'],
                      'held_example_exact': exact, 'test_prediction_stable': stable,
                      'joint_hypotheses': result['joint_hypotheses'],
                      'fitted_programs': result['stats']['fitted_programs']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure',
            'folds': folds}
