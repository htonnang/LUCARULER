# LUCA V160: Four Equivariant Family Rewrites

The rewritten families are:

1. Equivariant anchor transport.
2. Equivariant adjacent/self-measured transport.
3. Equivariant ordered-phase reasoning.
4. Equivariant reference-frame transfer.

Original four-family exact coverage is preserved at 12 tasks. Each rewrite adds one previously unsupported training task, producing 16 exact applications with no incorrect unique, ambiguous, or validation-rejected predictions.

The new transfer tasks are `dc433765`, `4364c1c4`, `b457fec5`, and `e681b708`.

The acceptance evidence includes leave-one-demonstration-out refitting, structural counterfactuals, target-leakage controls, all four rotations, arbitrary colour permutations, full-corpus screening, and 87-family engine parity.
