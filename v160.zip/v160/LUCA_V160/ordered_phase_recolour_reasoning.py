"""LUCA V150: ordered phase recolouring.

A shared consequence operator recolours a learned periodic phase over ordered
structural units. Two conservative constructors are supported:

    scene -> congruent component nodes -> axis-successor edges
          -> terminal-anchored phase -> whole-component recolouring

    scene -> directional run nodes -> run-successor edges
          -> endpoint-anchored phase -> cell recolouring

The family is task-ID blind and target blind. Colours, component shapes,
ordering axis, direction, endpoint, period, phase, and target colour are inferred
from demonstrations and the current input. No absolute demonstration coordinates
are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_ordered_phase_recolour"
LANGUAGE = "spinoza_ordered_phase_recolour_v150"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "periodic_phase_recolour",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_order": True,
            "periodic_phase_relation": True,
            "shared_phase_recolour_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _foreground_colour(value: Grid):
    value = grid(value)
    background = _mode(value)
    colours = sorted(_palette(value) - {background})
    if len(colours) != 1:
        raise Inapplicable("exactly one foreground colour required")
    return background, int(colours[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] == colour
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for neighbour in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    return tuple(output)


def _normalised_shape(component):
    r0, c0, _, _ = _bbox(component)
    return tuple(sorted((r - r0, c - c0) for r, c in component))


def _phase_indices(length, anchor, period, residue):
    if length < 1 or period < 2 or not (0 <= residue < period):
        raise Inapplicable("invalid phase parameters")
    order = range(length) if anchor == "low" else range(length - 1, -1, -1)
    return frozenset(index for step, index in enumerate(order) if step % period == residue)


def _changed_target_colour(pairs):
    targets = set()
    changed = 0
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        if _shape(source) != _shape(target):
            raise Inapplicable("phase recolouring preserves shape")
        for source_row, target_row in zip(source, target):
            for before, after in zip(source_row, target_row):
                if before != after:
                    changed += 1
                    targets.add(int(after))
    if not changed or len(targets) != 1:
        raise Inapplicable("one learned target colour required")
    return next(iter(targets))


@dataclass(frozen=True)
class AxisOrderedComponentPhaseProgram:
    axis: str
    anchor: str
    period: int
    residue: int
    target_colour: int

    kind = "axis_ordered_component_phase_recolour"
    operator = "ordered_phase_recolour"
    node_vocabulary = "ordered_congruent_units_and_directional_runs"
    edge_vocabulary = "successor_and_endpoint_phase_edges"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.axis,
            self.anchor,
            self.period,
            self.residue,
            self.target_colour,
        )

    def _ordered_components(self, value: Grid):
        value = grid(value)
        background, source_colour = _foreground_colour(value)
        if self.target_colour in _palette(value):
            raise Inapplicable("target colour must be absent from the input")
        components = _components(value, source_colour)
        if not (2 <= len(components) <= 40):
            raise Inapplicable("two to forty components required")
        shapes = {_normalised_shape(component) for component in components}
        if len(shapes) != 1:
            raise Inapplicable("all ordered units must be translation-congruent")

        axis_index = 0 if self.axis == "rows" else 1
        records = []
        for component in components:
            r0, c0, r1, c1 = _bbox(component)
            low, high = (r0, r1) if axis_index == 0 else (c0, c1)
            records.append((low, high, component))
        records.sort(key=lambda item: (item[0], item[1], tuple(sorted(item[2]))))
        if len({item[0] for item in records}) != len(records):
            raise Inapplicable("ordered units have tied axis origins")
        # Axis projections may overlap when congruent units occupy different rows/columns;
        # the order remains structural as long as their origins are unique.
        return background, source_colour, tuple(record[2] for record in records)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        _, _, components = self._ordered_components(value)
        selected = _phase_indices(len(components), self.anchor, self.period, self.residue)
        if not selected or len(selected) == len(components):
            raise Inapplicable("phase must select a strict nonempty subset")
        output = _array(value)
        for index, component in enumerate(components):
            if index in selected:
                for r, c in component:
                    output[r][c] = self.target_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="translation-congruent monochrome components with a strict non-overlapping axis order",
            relation_chain=(
                "extract congruent connected-component nodes",
                f"order nodes along the {self.axis[:-1]} axis",
                f"anchor a period-{self.period} phase at the {self.anchor} endpoint",
                "recolour every selected phase node while preserving its complete support",
            ),
            parameters={
                "axis": self.axis,
                "anchor": self.anchor,
                "period": self.period,
                "residue": self.residue,
                "target_colour": self.target_colour,
            },
            corollary="Recolour one periodic phase of the ordered congruent units.",
            notions=["congruent unit", "strict axis order", "endpoint anchor", "periodic phase"],
        )


@dataclass(frozen=True)
class DirectionalRunPhaseProgram:
    direction: tuple[int, int]
    anchor: str
    period: int
    residue: int
    target_colour: int

    kind = "directional_run_phase_recolour"
    operator = "ordered_phase_recolour"
    node_vocabulary = "ordered_congruent_units_and_directional_runs"
    edge_vocabulary = "successor_and_endpoint_phase_edges"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.direction,
            self.anchor,
            self.period,
            self.residue,
            self.target_colour,
        )

    def _runs(self, value: Grid):
        value = grid(value)
        _, source_colour = _foreground_colour(value)
        if self.target_colour in _palette(value):
            raise Inapplicable("target colour must be absent from the input")
        cells = {
            (r, c)
            for r, row in enumerate(value)
            for c, colour in enumerate(row)
            if colour == source_colour
        }
        if len(cells) < 3:
            raise Inapplicable("at least three run cells required")
        dr, dc = self.direction
        starts = sorted(cell for cell in cells if (cell[0] - dr, cell[1] - dc) not in cells)
        runs = []
        covered = set()
        for start in starts:
            run = []
            current = start
            while current in cells:
                run.append(current)
                covered.add(current)
                current = (current[0] + dr, current[1] + dc)
            runs.append(tuple(run))
        if covered != cells:
            raise Inapplicable("directional runs do not cover every foreground cell")
        if not runs or any(len(run) < 3 for run in runs):
            raise Inapplicable("every directional run must contain at least three cells")
        return tuple(runs)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        runs = self._runs(value)
        output = _array(value)
        selected_total = 0
        for run in runs:
            selected = _phase_indices(len(run), self.anchor, self.period, self.residue)
            if not selected or len(selected) == len(run):
                raise Inapplicable("run phase must select a strict nonempty subset")
            selected_total += len(selected)
            for index, (r, c) in enumerate(run):
                if index in selected:
                    output[r][c] = self.target_colour
        if not selected_total:
            raise Inapplicable("no phase cells selected")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more monochrome directional runs with a shared successor direction",
            relation_chain=(
                "extract maximal directional run nodes",
                f"link consecutive cells by successor edges {self.direction}",
                f"anchor a period-{self.period} phase at the {self.anchor} endpoint of every run",
                "recolour the selected phase cells while preserving all other material",
            ),
            parameters={
                "direction": list(self.direction),
                "anchor": self.anchor,
                "period": self.period,
                "residue": self.residue,
                "target_colour": self.target_colour,
            },
            corollary="Recolour one periodic phase independently in every directional run.",
            notions=["directional run", "successor edge", "endpoint anchor", "periodic phase"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, counterfactual validation, and LODO validation.
# ---------------------------------------------------------------------------


def _fit_axis_component(pairs):
    try:
        target_colour = _changed_target_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for axis in ("rows", "columns"):
        for anchor in ("low", "high"):
            for period in (2, 3, 4):
                for residue in range(period):
                    programme = AxisOrderedComponentPhaseProgram(
                        axis, anchor, period, residue, target_colour
                    )
                    try:
                        if all(programme.predict(source) == grid(target) for source, target in pairs):
                            output.append(programme)
                    except Inapplicable:
                        pass
    return output


def _fit_directional_runs(pairs):
    try:
        target_colour = _changed_target_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for direction in ((0, 1), (1, 0), (1, 1), (1, -1)):
        for anchor in ("low", "high"):
            for period in (2, 3, 4):
                for residue in range(period):
                    programme = DirectionalRunPhaseProgram(
                        direction, anchor, period, residue, target_colour
                    )
                    try:
                        if all(programme.predict(source) == grid(target) for source, target in pairs):
                            output.append(programme)
                    except Inapplicable:
                        pass
    return output


_FITTERS = {
    "axis_ordered_component_phase_recolour": _fit_axis_component,
    "directional_run_phase_recolour": _fit_directional_runs,
}


def fit_ordered_phase_recolour_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        background = _mode(source)
        foreground = sorted(
            (r, c)
            for r, row in enumerate(source)
            for c, colour in enumerate(row)
            if colour != background
        )
        passed = False
        witness = None
        tested = 0
        for r, c in foreground:
            tested += 1
            work = _array(source)
            work[r][c] = background
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {"cell": [r, c], "from": int(source[r][c]), "to": int(background)}
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "ordered_unit_or_successor_phase_edge" if passed else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_ordered_phase_recolour(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_ordered_phase_recolour_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "periodic_phase_relation": True,
            "shared_phase_recolour_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_ordered_phase_recolour_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_ordered_phase_recolour_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_ordered_phase_recolour(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
