"""LUCA V127: composable recursive generative primitives.

This family factors several ARC constructions into conservative typed
programmes.  The shared language is::

    source -> structural primitive -> optional quantitative parameter
           -> typed emitter -> output

Twelve schemas are exposed:

* ``colour_class_self_substitution``;
* ``mask_colour_kronecker_composition``;
* ``edge_extrusion``;
* ``diagonal_row_shear``;
* ``colour_frequency_histogram``;
* ``prefix_staircase_extension``;
* ``palindromic_row_bounce``;
* ``affine_row_recurrence_extension``;
* ``sequence_diagonal_band_projection``;
* ``staggered_half_separator``;
* ``marker_diagonal_block_projection``;
* ``palette_scaled_corner_connectors``.

No task identifiers, test targets, or stored demonstration coordinates are
available to inference.  Exact demonstration fit is necessary but not
sufficient: laws must survive prediction consensus, held-demonstration
refitting, counterfactual interventions, and metadata-poisoning tests.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_composable_recursive_generative_primitives"
LANGUAGE = "spinoza_composable_recursive_generative_primitives_v1"
SCHEMA_VERSION = "composable_recursive_primitives_schema_v1"


# ---------------------------------------------------------------------------
# Shared helpers.
# ---------------------------------------------------------------------------


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    maximum = max(counts.values())
    modes = [colour for colour, count in counts.items() if count == maximum]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _safe_predict(program, source):
    try:
        return program.predict(source)
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
        raise Inapplicable("programme became inapplicable")


# ---------------------------------------------------------------------------
# Primitive 1: colour-class self substitution.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColourClassSelfSubstitutionProgram:
    background_colour: int
    kind: str = "colour_class_self_substitution"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height < 2 or width < 2:
            raise Inapplicable("source is too small")
        if self.background_colour in _palette(value):
            raise Inapplicable("substitution background must be absent from the source")
        colours = sorted(_palette(value))
        if len(colours) < 2:
            raise Inapplicable("at least two source classes are required")
        out_height, out_width = height * height, width * width
        if out_height > 60 or out_width > 60:
            raise Inapplicable("expanded grid exceeds conservative bound")
        result = [[self.background_colour for _ in range(out_width)] for _ in range(out_height)]
        for block_row in range(height):
            for block_col in range(width):
                colour = value[block_row][block_col]
                for row in range(height):
                    for col in range(width):
                        if value[row][col] == colour:
                            result[block_row * height + row][block_col * width + col] = colour
        prediction = tuple(tuple(row) for row in result)
        return {"colours": colours, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "class_count": len(analysis["colours"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "ColourClassMask", "type": "Grid x Colour -> BinaryMask"},
                {"name": "ClassSubstitution", "type": "Grid x MaskDictionary -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DeriveClassMasks", "effect": "build one source-shaped mask per colour class"},
                {"index": 2, "definition": "SubstituteByCellClass", "effect": "replace each source cell by its class mask"},
            ],
            corollary="each source colour defines its own recursive substitution block",
            common_notions=[{"name": "colour_class_substitution_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 2: mask-colour Kronecker composition.
# ---------------------------------------------------------------------------


def _two_square_panels(value: Grid):
    value = grid(value)
    height, width = _shape(value)
    if width == 2 * height:
        return (
            tuple(tuple(row[:height]) for row in value),
            tuple(tuple(row[height:]) for row in value),
            "horizontal",
        )
    if height == 2 * width:
        return (
            tuple(tuple(row) for row in value[:width]),
            tuple(tuple(row) for row in value[width:]),
            "vertical",
        )
    raise Inapplicable("input is not two equal square panels")


@dataclass(frozen=True)
class MaskColourKroneckerProgram:
    background_colour: int
    kind: str = "mask_colour_kronecker_composition"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        panel_a, panel_b, axis = _two_square_panels(value)
        candidates = []
        for mask_panel, colour_panel, role_order in (
            (panel_a, panel_b, "first_mask"),
            (panel_b, panel_a, "second_mask"),
        ):
            mask_palette = _palette(mask_panel)
            colour_palette = _palette(colour_panel)
            if self.background_colour not in mask_palette or self.background_colour not in colour_palette:
                continue
            if len(mask_palette) != 2:
                continue
            if len(colour_palette - {self.background_colour}) < 2:
                continue
            size, _ = _shape(mask_panel)
            mask = [[cell != self.background_colour for cell in row] for row in mask_panel]
            result = [[self.background_colour for _ in range(size * size)] for _ in range(size * size)]
            for block_row in range(size):
                for block_col in range(size):
                    colour = colour_panel[block_row][block_col]
                    if colour == self.background_colour:
                        continue
                    for row in range(size):
                        for col in range(size):
                            if mask[row][col]:
                                result[block_row * size + row][block_col * size + col] = colour
            candidates.append((tuple(tuple(row) for row in result), role_order, size))
        groups = defaultdict(list)
        for prediction, role_order, size in candidates:
            groups[prediction].append((role_order, size))
        if len(groups) != 1:
            raise Inapplicable("mask and colour-panel roles are not unique")
        prediction, roles = next(iter(groups.items()))
        return {"prediction": prediction, "roles": roles, "axis": axis}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "panel_axis": analysis["axis"],
                "role_bindings": analysis["roles"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "BinarySupportPanel", "type": "SquareGrid -> BinaryMask"},
                {"name": "ColourRolePanel", "type": "SquareGrid -> ColourGrid"},
                {"name": "KroneckerEmitter", "type": "Mask x ColourGrid -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindPanelRoles", "effect": "identify the binary mask and multicolour role panels"},
                {"index": 2, "definition": "EmitColouredMaskBlocks", "effect": "replace every colour role by a coloured copy of the mask"},
            ],
            corollary="a binary support panel and a colour-role panel compose by Kronecker substitution",
            common_notions=[{"name": "mask_colour_composition_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 3: edge extrusion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EdgeExtrusionProgram:
    background_colour: int
    kind: str = "edge_extrusion"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 2

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height < 2 or width < 2:
            raise Inapplicable("edge extrusion requires a rectangular source")
        result = [[self.background_colour for _ in range(width + 2)] for _ in range(height + 2)]
        for row in range(height):
            for col in range(width):
                result[row + 1][col + 1] = value[row][col]
        for col in range(width):
            result[0][col + 1] = value[0][col]
            result[height + 1][col + 1] = value[-1][col]
        for row in range(height):
            result[row + 1][0] = value[row][0]
            result[row + 1][width + 1] = value[row][-1]
        return {"prediction": tuple(tuple(row) for row in result)}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "BoundaryTrace", "type": "Grid -> FourEdges"},
                {"name": "EdgeExtrusion", "type": "Grid x FourEdges -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "EmbedSource", "effect": "place the source inside a one-cell frame"},
                {"index": 2, "definition": "ExtrudeEdges", "effect": "copy each edge outward while leaving corners blank"},
            ],
            corollary="the four source edges extend one cell into a blank frame",
            common_notions=[{"name": "edge_extrusion_evidence", "evidence": [
                {"demonstration": index, "source_shape": list(_shape(source)), "output_exact": self.predict(source) == grid(target)}
                for index, (source, target) in enumerate(pairs)
            ]}],
        )


# ---------------------------------------------------------------------------
# Primitive 4: diagonal row shear.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DiagonalRowShearProgram:
    background_colour: int
    direction: str
    kind: str = "diagonal_row_shear"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.direction

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height < 2 or self.background_colour in _palette(value):
            raise Inapplicable("row shear requires nonbackground source rows")
        result = [[self.background_colour for _ in range(width + height - 1)] for _ in range(height)]
        for row in range(height):
            offset = height - 1 - row if self.direction == "descending" else row
            if self.direction not in {"descending", "ascending"}:
                raise Inapplicable("unknown shear direction")
            result[row][offset:offset + width] = list(value[row])
        return {"prediction": tuple(tuple(row) for row in result)}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "direction": self.direction},
            definitions=[
                {"name": "OrderedRows", "type": "Grid -> RowSequence"},
                {"name": "UnitShear", "type": "RowSequence x Direction -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindRowOrder", "effect": "retain source row order"},
                {"index": 2, "definition": "ShearRows", "effect": "offset successive rows by one cell"},
            ],
            corollary="ordered rows define an affine diagonal shear",
            common_notions=[{"name": "row_shear_evidence", "evidence": [
                {"demonstration": index, "source_shape": list(_shape(source)), "output_exact": self.predict(source) == grid(target)}
                for index, (source, target) in enumerate(pairs)
            ]}],
        )


# ---------------------------------------------------------------------------
# Primitive 5: colour-frequency histogram.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColourFrequencyHistogramProgram:
    background_colour: int
    alignment: str = "top"
    kind: str = "colour_frequency_histogram"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.alignment

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if self.background_colour in _palette(value):
            raise Inapplicable("histogram background must be absent from the source")
        counts = Counter(cell for row in value for cell in row)
        if len(counts) < 3:
            raise Inapplicable("at least three colour classes are required")
        if len(set(counts.values())) != len(counts):
            raise Inapplicable("frequency ranking contains a tie")
        ordered = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
        height = max(counts.values())
        result = [[self.background_colour for _ in ordered] for _ in range(height)]
        for col, (colour, count) in enumerate(ordered):
            if self.alignment == "top":
                rows = range(count)
            elif self.alignment == "bottom":
                rows = range(height - count, height)
            else:
                raise Inapplicable("unknown histogram alignment")
            for row in rows:
                result[row][col] = colour
        return {"prediction": tuple(tuple(row) for row in result), "counts": ordered}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "ranked_counts": analysis["counts"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "alignment": self.alignment},
            definitions=[
                {"name": "ColourMaterial", "type": "Grid -> ColourCountMap"},
                {"name": "StrictFrequencyRank", "type": "ColourCountMap -> OrderedColours"},
                {"name": "HistogramEmitter", "type": "OrderedColours -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "CountColourMaterial", "effect": "measure every colour class"},
                {"index": 2, "definition": "RankStrictly", "effect": "order colours by decreasing material"},
                {"index": 3, "definition": "EmitColumns", "effect": "draw one aligned column per colour"},
            ],
            corollary="strict colour frequencies define a canonical histogram",
            common_notions=[{"name": "colour_histogram_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 6: prefix staircase.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PrefixStaircaseProgram:
    background_colour: int
    kind: str = "prefix_staircase_extension"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height != 1 or width % 2:
            raise Inapplicable("source must be one even-length row")
        row = value[0]
        prefix = 0
        while prefix < width and row[prefix] != self.background_colour:
            prefix += 1
        if prefix == 0 or any(cell != self.background_colour for cell in row[prefix:]):
            raise Inapplicable("foreground is not one contiguous prefix")
        colours = {cell for cell in row[:prefix]}
        if len(colours) != 1:
            raise Inapplicable("prefix has multiple colours")
        colour = next(iter(colours))
        out_height = width // 2
        if prefix + out_height - 1 > width:
            raise Inapplicable("staircase exceeds the available width")
        result = [[self.background_colour for _ in range(width)] for _ in range(out_height)]
        for out_row in range(out_height):
            for col in range(prefix + out_row):
                result[out_row][col] = colour
        return {"prediction": tuple(tuple(row) for row in result), "prefix": prefix, "colour": colour}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "prefix": analysis["prefix"], "colour": analysis["colour"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "ForegroundPrefix", "type": "Row -> PrefixLength x Colour"},
                {"name": "StaircaseEmitter", "type": "PrefixLength x Width -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "MeasurePrefix", "effect": "derive the initial foreground length"},
                {"index": 2, "definition": "GrowPrefixByRow", "effect": "increase foreground length by one per output row"},
            ],
            corollary="a one-dimensional prefix defines a triangular staircase expansion",
            common_notions=[{"name": "prefix_staircase_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 7: palindromic row bounce.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PalindromicRowBounceProgram:
    kind: str = "palindromic_row_bounce"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 2

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, _ = _shape(value)
        if height < 2:
            raise Inapplicable("at least two rows are required")
        period = list(range(height)) + list(range(height - 2, 0, -1))
        out_height = 4 * height - 3
        prediction = tuple(value[period[index % len(period)]] for index in range(out_height))
        return {"prediction": prediction, "period": period}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "RowSequence", "type": "Grid -> OrderedRows"},
                {"name": "BouncePeriod", "type": "OrderedRows -> PalindromicCycle"},
            ],
            propositions=[
                {"index": 1, "definition": "TraverseForward", "effect": "visit rows from first to last"},
                {"index": 2, "definition": "ReflectInterior", "effect": "return through interior rows without duplicating endpoints"},
                {"index": 3, "definition": "RepeatBounce", "effect": "emit two cycles plus the initial row"},
            ],
            corollary="an ordered row sequence defines a palindromic bounce extension",
            common_notions=[{"name": "row_bounce_evidence", "evidence": [
                {"demonstration": index, "row_count": _shape(source)[0], "output_exact": self.predict(source) == grid(target)}
                for index, (source, target) in enumerate(pairs)
            ]}],
        )


# ---------------------------------------------------------------------------
# Primitive 8: affine row recurrence.
# ---------------------------------------------------------------------------


def _shift_row(row, displacement: int, background_colour: int):
    width = len(row)
    result = [background_colour for _ in range(width)]
    if displacement >= 0:
        if displacement < width:
            result[displacement:] = list(row[:width - displacement])
    else:
        shift = -displacement
        if shift < width:
            result[:width - shift] = list(row[shift:])
    return tuple(result)


@dataclass(frozen=True)
class AffineRowRecurrenceProgram:
    background_colour: int
    kind: str = "affine_row_recurrence_extension"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height >= width or width < 3:
            raise Inapplicable("row recurrence expects a shorter-than-wide source")
        candidates = []
        for period in range(1, height):
            for displacement in range(-width + 1, width):
                if all(value[index] == _shift_row(value[index - period], displacement, self.background_colour) for index in range(period, height)):
                    candidates.append((period, displacement))
        if not candidates:
            raise Inapplicable("no affine row recurrence")
        period, displacement = min(candidates, key=lambda item: (item[0], abs(item[1]), item[1]))
        rows = [tuple(row) for row in value]
        while len(rows) < width:
            rows.append(_shift_row(rows[-period], displacement, self.background_colour))
        prediction = tuple(rows[:width])
        return {"prediction": prediction, "period": period, "displacement": displacement}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "period": analysis["period"], "displacement": analysis["displacement"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "RowBlockPeriod", "type": "Grid -> Integer"},
                {"name": "HorizontalTranslation", "type": "Row x Integer -> Row"},
                {"name": "AffineRowRecurrence", "type": "Rows x Period x Translation -> Rows"},
            ],
            propositions=[
                {"index": 1, "definition": "FitMinimalRecurrence", "effect": "derive the shortest row period and translation"},
                {"index": 2, "definition": "ExtendToSquare", "effect": "continue the recurrence until height equals width"},
            ],
            corollary="a translated row-block recurrence completes the square canvas",
            common_notions=[{"name": "affine_row_recurrence_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 9: one-dimensional sequence to diagonal bands.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SequenceDiagonalBandProgram:
    background_colour: int
    kind: str = "sequence_diagonal_band_projection"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height != 1 or width < 3:
            raise Inapplicable("source must be one row")
        roles = [(index, colour) for index, colour in enumerate(value[0]) if colour != self.background_colour]
        if not roles:
            raise Inapplicable("no foreground sequence roles")
        colours = [colour for _, colour in roles]
        if len(set(colours)) != len(colours):
            raise Inapplicable("foreground sequence colours are not unique")
        size = width * len(roles)
        if size > 60:
            raise Inapplicable("projected grid exceeds conservative bound")
        result = [[self.background_colour for _ in range(size)] for _ in range(size)]
        for position, colour in roles:
            diagonal_sum = size - 1 + position
            for row in range(size):
                col = diagonal_sum - row
                if 0 <= col < size:
                    result[row][col] = colour
        return {"prediction": tuple(tuple(row) for row in result), "roles": roles}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "roles": analysis["roles"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "SequenceRole", "type": "ColumnIndex x Colour"},
                {"name": "AntiDiagonalEmitter", "type": "SequenceRoles -> SquareGrid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindNonbackgroundRoles", "effect": "retain ordered nonbackground cells"},
                {"index": 2, "definition": "ProjectDiagonalBands", "effect": "map each role to its offset anti-diagonal"},
            ],
            corollary="a sparse one-dimensional colour sequence projects to parallel diagonal bands",
            common_notions=[{"name": "sequence_diagonal_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 10: staggered half separator.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StaggeredHalfSeparatorProgram:
    separator_colour: int
    kind: str = "staggered_half_separator"

    @property
    def schema_key(self):
        return self.kind, self.separator_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height < 2 or height % 2 or self.separator_colour in _palette(value):
            raise Inapplicable("source does not define two equal nonseparator halves")
        half = height // 2
        result = [[self.separator_colour for _ in range(width + 1)] for _ in range(height + 1)]
        for row in range(half):
            result[row][:width] = list(value[row])
        for row in range(half, height):
            result[row + 1][1:] = list(value[row])
        return {"prediction": tuple(tuple(row) for row in result), "half": half}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"separator_colour": self.separator_colour},
            definitions=[
                {"name": "EqualRowHalves", "type": "Grid -> TopHalf x BottomHalf"},
                {"name": "StaggeredSeparator", "type": "TopHalf x BottomHalf x Colour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "SplitRowsEqually", "effect": "bind upper and lower panels"},
                {"index": 2, "definition": "InsertSeparatorCross", "effect": "separate and horizontally stagger the panels"},
            ],
            corollary="two equal row panels define a staggered separator composition",
            common_notions=[{"name": "staggered_separator_evidence", "evidence": [
                {"demonstration": index, "half_height": _shape(source)[0] // 2, "output_exact": self.predict(source) == grid(target)}
                for index, (source, target) in enumerate(pairs)
            ]}],
        )


# ---------------------------------------------------------------------------
# Primitive 11: marker-directed block diagonal.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerDiagonalBlockProgram:
    background_colour: int
    kind: str = "marker_diagonal_block_projection"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if _shape(value) != (3, 3):
            raise Inapplicable("marker projection expects a 3x3 source")
        cells = [(row, col) for row in range(3) for col in range(3) if value[row][col] != self.background_colour]
        if len(cells) != 4:
            raise Inapplicable("source must contain one filled 2x2 role block")
        min_row = min(row for row, _ in cells)
        max_row = max(row for row, _ in cells)
        min_col = min(col for _, col in cells)
        max_col = max(col for _, col in cells)
        if (max_row - min_row, max_col - min_col) != (1, 1):
            raise Inapplicable("nonbackground cells do not form a 2x2 block")
        block = [value[row][min_col:max_col + 1] for row in range(min_row, max_row + 1)]
        counts = Counter(cell for row in block for cell in row)
        singleton = [colour for colour, count in counts.items() if count == 1]
        majority = [colour for colour, count in counts.items() if count == 3]
        if len(singleton) != 1 or len(majority) != 1:
            raise Inapplicable("2x2 block does not contain one marker and one majority colour")
        marker = singleton[0]
        fill = majority[0]
        marker_row = marker_col = None
        for row in range(2):
            for col in range(2):
                if block[row][col] == marker:
                    marker_row, marker_col = row, col
        block_size = len(cells)
        result = [[self.background_colour for _ in range(2 * block_size + 1)] for _ in range(2 * block_size + 1)]
        if marker_row == marker_col:
            placements = ((min_row, min_col), (min_row + block_size, min_col + block_size))
            orientation = "main_diagonal"
        else:
            placements = ((min_row, min_col + block_size), (min_row + block_size, min_col))
            orientation = "anti_diagonal"
        for start_row, start_col in placements:
            for row in range(block_size):
                for col in range(block_size):
                    result[start_row + row][start_col + col] = fill
        return {
            "prediction": tuple(tuple(row) for row in result),
            "marker_colour": marker,
            "fill_colour": fill,
            "orientation": orientation,
            "role_origin": [min_row, min_col],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "orientation": analysis["orientation"], "origin": analysis["role_origin"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "SingletonMarker", "type": "TwoByTwoBlock -> CornerRole"},
                {"name": "DiagonalBlockEmitter", "type": "CornerRole x Colour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindMarkerCorner", "effect": "determine main or anti-diagonal orientation"},
                {"index": 2, "definition": "EmitPairedBlocks", "effect": "draw two equal majority-colour blocks"},
            ],
            corollary="a singleton marker corner determines the diagonal orientation of paired blocks",
            common_notions=[{"name": "marker_diagonal_block_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Primitive 12: palette scale plus corner connectors.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PaletteScaledCornerConnectorProgram:
    background_colour: int
    connector_colour: int
    kind: str = "palette_scaled_corner_connectors"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.connector_colour

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if _shape(value) != (5, 5):
            raise Inapplicable("corner connector expects a 5x5 source")
        if self.connector_colour in _palette(value):
            raise Inapplicable("connector colour must be absent from the source")
        semantic = _palette(value) - {self.background_colour}
        scale = len(semantic)
        if scale < 2 or scale > 5:
            raise Inapplicable("invalid palette-derived scale")
        blocks = []
        for row in range(4):
            for col in range(4):
                colours = {value[r][c] for r in range(row, row + 2) for c in range(col, col + 2)}
                if len(colours) == 1:
                    colour = next(iter(colours))
                    if colour != self.background_colour:
                        blocks.append((row, col, colour))
        if len(blocks) != 1:
            raise Inapplicable("source does not contain one unique monochrome 2x2 block")
        block_row, block_col, block_colour = blocks[0]
        source_array = _array(value)
        result = []
        for row in source_array:
            expanded = []
            for cell in row:
                expanded.extend([cell] * scale)
            for _ in range(scale):
                result.append(expanded.copy())
        top = block_row * scale
        left = block_col * scale
        bottom = (block_row + 2) * scale - 1
        right = (block_col + 2) * scale - 1
        if block_row > 0 and block_col > 0:
            for offset in range(scale):
                result[top - 1 - offset][left - 1 - offset] = self.connector_colour
        if block_row > 0 and block_col + 2 < 5:
            for offset in range(scale):
                result[top - 1 - offset][right + 1 + offset] = self.connector_colour
        if block_row + 2 < 5 and block_col > 0:
            for offset in range(scale):
                result[bottom + 1 + offset][left - 1 - offset] = self.connector_colour
        if block_row + 2 < 5 and block_col + 2 < 5:
            for offset in range(scale):
                result[bottom + 1 + offset][right + 1 + offset] = self.connector_colour
        return {
            "prediction": tuple(tuple(row) for row in result),
            "scale": scale,
            "block_origin": [block_row, block_col],
            "block_colour": block_colour,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({"demonstration": index, "scale": analysis["scale"], "block_origin": analysis["block_origin"], "output_exact": analysis["prediction"] == grid(target)})
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "connector_colour": self.connector_colour},
            definitions=[
                {"name": "PaletteScale", "type": "Grid -> Integer"},
                {"name": "MonochromeBlock", "type": "Grid -> TwoByTwoRole"},
                {"name": "CornerConnector", "type": "ScaledRole x Colour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ScaleBySemanticPalette", "effect": "uniformly expand every source cell"},
                {"index": 2, "definition": "BindUniqueBlock", "effect": "locate the unique monochrome 2x2 role"},
                {"index": 3, "definition": "EmitCornerDiagonals", "effect": "mark available diagonal source-cell roles"},
            ],
            corollary="palette cardinality and a unique block jointly define scaled diagonal connectors",
            common_notions=[{"name": "palette_connector_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting.
# ---------------------------------------------------------------------------


def _common_colours(pairs, *, source=True, target=True):
    sets = []
    for input_grid, output_grid in pairs:
        colours = set()
        if source:
            colours |= _palette(input_grid)
        if target:
            colours |= _palette(output_grid)
        sets.append(colours)
    return set.intersection(*sets) if sets else set()


def _fit_one_parameter(program_class, pairs, values):
    programmes = []
    for value in values:
        program = program_class(value)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                programmes.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    return programmes


def _fit_colour_class_substitution(pairs):
    target_common = set.intersection(*(_palette(target) for _, target in pairs))
    source_union = set.union(*(_palette(source) for source, _ in pairs))
    candidates = sorted(target_common - source_union)
    return _fit_one_parameter(ColourClassSelfSubstitutionProgram, pairs, candidates)


def _fit_mask_colour_kronecker(pairs):
    common = _common_colours(pairs)
    return _fit_one_parameter(MaskColourKroneckerProgram, pairs, sorted(common))


def _fit_edge_extrusion(pairs):
    candidates = set(range(10))
    for source, target in pairs:
        target = grid(target)
        corners = {target[0][0], target[0][-1], target[-1][0], target[-1][-1]}
        if len(corners) != 1:
            return []
        candidates &= corners
    return _fit_one_parameter(EdgeExtrusionProgram, pairs, sorted(candidates))


def _fit_row_shear(pairs):
    target_common = set.intersection(*(_palette(target) for _, target in pairs))
    source_union = set.union(*(_palette(source) for source, _ in pairs))
    backgrounds = sorted(target_common - source_union)
    programmes = []
    for background in backgrounds:
        for direction in ("descending", "ascending"):
            program = DiagonalRowShearProgram(background, direction)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
    return programmes


def _fit_histogram(pairs):
    target_common = set.intersection(*(_palette(target) for _, target in pairs))
    source_union = set.union(*(_palette(source) for source, _ in pairs))
    programmes = []
    for background in sorted(target_common - source_union):
        for alignment in ("top", "bottom"):
            program = ColourFrequencyHistogramProgram(background, alignment)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
    return programmes


def _fit_prefix_staircase(pairs):
    common = set.intersection(*(_palette(source) & _palette(target) for source, target in pairs))
    return _fit_one_parameter(PrefixStaircaseProgram, pairs, sorted(common))


def _fit_row_bounce(pairs):
    program = PalindromicRowBounceProgram()
    try:
        return [program] if all(program.predict(source) == target for source, target in pairs) else []
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
        return []


def _fit_row_recurrence(pairs):
    common = set.intersection(*(_palette(source) for source, _ in pairs))
    return _fit_one_parameter(AffineRowRecurrenceProgram, pairs, sorted(common))


def _fit_sequence_diagonal(pairs):
    common = set.intersection(*(_palette(source) & _palette(target) for source, target in pairs))
    return _fit_one_parameter(SequenceDiagonalBandProgram, pairs, sorted(common))


def _fit_staggered_separator(pairs):
    target_common = set.intersection(*(_palette(target) for _, target in pairs))
    source_union = set.union(*(_palette(source) for source, _ in pairs))
    return _fit_one_parameter(StaggeredHalfSeparatorProgram, pairs, sorted(target_common - source_union))


def _fit_marker_blocks(pairs):
    common = set.intersection(*(_palette(source) & _palette(target) for source, target in pairs))
    return _fit_one_parameter(MarkerDiagonalBlockProgram, pairs, sorted(common))


def _fit_palette_connectors(pairs):
    source_common = set.intersection(*(_palette(source) for source, _ in pairs))
    target_common = set.intersection(*(_palette(target) for _, target in pairs))
    source_union = set.union(*(_palette(source) for source, _ in pairs))
    connectors = sorted(target_common - source_union)
    programmes = []
    for background in sorted(source_common):
        for connector in connectors:
            program = PaletteScaledCornerConnectorProgram(background, connector)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
    return programmes


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, ColourClassSelfSubstitutionProgram):
        return _shape(source), analysis["colours"]
    if isinstance(program, MaskColourKroneckerProgram):
        return analysis["axis"], analysis["roles"]
    if isinstance(program, EdgeExtrusionProgram):
        return _shape(source), sorted(_palette(source))
    if isinstance(program, DiagonalRowShearProgram):
        return _shape(source), _serial(source)
    if isinstance(program, ColourFrequencyHistogramProgram):
        return analysis["counts"]
    if isinstance(program, PrefixStaircaseProgram):
        return analysis["prefix"], analysis["colour"], _shape(source)
    if isinstance(program, PalindromicRowBounceProgram):
        return _shape(source)[0], _serial(source)
    if isinstance(program, AffineRowRecurrenceProgram):
        return analysis["period"], analysis["displacement"]
    if isinstance(program, SequenceDiagonalBandProgram):
        return analysis["roles"]
    if isinstance(program, StaggeredHalfSeparatorProgram):
        return analysis["half"], _shape(source)[1]
    if isinstance(program, MarkerDiagonalBlockProgram):
        return analysis["orientation"], analysis["role_origin"]
    if isinstance(program, PaletteScaledCornerConnectorProgram):
        return analysis["scale"], analysis["block_origin"]
    raise Inapplicable("unknown composable primitive")


def fit_composable_recursive_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    fitters = (
        ("colour_class_self_substitution", lambda: _fit_colour_class_substitution(pairs)),
        ("mask_colour_kronecker_composition", lambda: _fit_mask_colour_kronecker(pairs)),
        ("edge_extrusion", lambda: _fit_edge_extrusion(pairs)),
        ("diagonal_row_shear", lambda: _fit_row_shear(pairs)),
        ("colour_frequency_histogram", lambda: _fit_histogram(pairs)),
        ("prefix_staircase_extension", lambda: _fit_prefix_staircase(pairs)),
        ("palindromic_row_bounce", lambda: _fit_row_bounce(pairs)),
        ("affine_row_recurrence_extension", lambda: _fit_row_recurrence(pairs)),
        ("sequence_diagonal_band_projection", lambda: _fit_sequence_diagonal(pairs)),
        ("staggered_half_separator", lambda: _fit_staggered_separator(pairs)),
        ("marker_diagonal_block_projection", lambda: _fit_marker_blocks(pairs)),
        ("palette_scaled_corner_connectors", lambda: _fit_palette_connectors(pairs)),
    )
    selected = []
    for kind, fitter in fitters:
        if allowed is not None and kind not in allowed:
            continue
        try:
            selected.extend(fitter())
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    exact = []
    for program in selected:
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            exact.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    unique = {program.schema_key: program for program in exact}
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.permissiveness_cost)))


# ---------------------------------------------------------------------------
# Counterfactual adequacy.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    passed = bool(rows) and all(
        all(value for key, value in row.items() if key != "demonstration")
        for row in rows
    )
    return {"kind": kind, "rows": rows, "passed": passed}


def _recolour_equivariance(program, source, original, excluded=()):
    excluded = set(excluded)
    colours = sorted(_palette(source) - excluded)
    if not colours:
        return True
    old = colours[0]
    fresh = _fresh_colour(source, tuple(excluded | {old}))
    recoloured = _replace_colour(source, old, fresh)
    try:
        prediction = program.predict(recoloured)
    except Inapplicable:
        return False
    return prediction == _replace_colour(original, old, fresh)


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        relation_necessary = False
        equivariant = True

        if isinstance(program, ColourClassSelfSubstitutionProgram):
            equivariant = _recolour_equivariance(
                program, source, original, (program.background_colour,)
            )
            colours = sorted(_palette(source))
            merged = _replace_colour(source, colours[-1], colours[0])
            try:
                relation_necessary = program.predict(merged) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, MaskColourKroneckerProgram):
            panel_a, panel_b, _ = _two_square_panels(source)
            colour_panel = panel_a if len(_palette(panel_a) - {program.background_colour}) >= 2 else panel_b
            colour = next(iter(sorted(_palette(colour_panel) - {program.background_colour})))
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            changed = False
            for row in range(len(modified)):
                for col in range(len(modified[0])):
                    if modified[row][col] != program.background_colour:
                        modified[row][col] = program.background_colour
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, EdgeExtrusionProgram):
            equivariant = _recolour_equivariance(
                program, source, original, (program.background_colour,)
            )
            modified = _array(source)
            modified[0][0] = _fresh_colour(source, (program.background_colour,))
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, DiagonalRowShearProgram):
            equivariant = _recolour_equivariance(
                program, source, original, (program.background_colour,)
            )
            modified = _array(source)
            modified[0][0] = _fresh_colour(source, (program.background_colour,))
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, ColourFrequencyHistogramProgram):
            equivariant = _recolour_equivariance(
                program, source, original, (program.background_colour,)
            )
            modified = _array(source)
            counts = Counter(cell for row in source for cell in row)
            ordered = sorted(counts, key=lambda colour: (-counts[colour], colour))
            old, new = ordered[0], ordered[-1]
            changed = False
            for row in range(len(modified)):
                for col in range(len(modified[0])):
                    if modified[row][col] == old:
                        modified[row][col] = new
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, PrefixStaircaseProgram):
            analysis = program.analyse(source)
            colour = analysis["colour"]
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            modified[0][max(0, analysis["prefix"] // 2)] = program.background_colour
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, PalindromicRowBounceProgram):
            equivariant = _recolour_equivariance(program, source, original)
            modified = _array(source)
            modified[0][0] = _fresh_colour(source)
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, AffineRowRecurrenceProgram):
            equivariant = _recolour_equivariance(program, source, original, (program.background_colour,))
            modified = _array(source)
            if len(modified) > 1:
                modified[-1][0] = _fresh_colour(source)
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, SequenceDiagonalBandProgram):
            equivariant = _recolour_equivariance(program, source, original, (program.background_colour,))
            analysis = program.analyse(source)
            position, colour = analysis["roles"][0]
            modified = _array(source)
            new_position = position + 1 if position + 1 < len(modified[0]) and modified[0][position + 1] == program.background_colour else position - 1
            if new_position >= 0 and modified[0][new_position] == program.background_colour:
                modified[0][position] = program.background_colour
                modified[0][new_position] = colour
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, StaggeredHalfSeparatorProgram):
            equivariant = _recolour_equivariance(program, source, original, (program.separator_colour,))
            modified = _array(source)
            modified[0][0] = program.separator_colour
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, MarkerDiagonalBlockProgram):
            analysis = program.analyse(source)
            fill = analysis["fill_colour"]
            fresh = _fresh_colour(source, (fill,))
            recoloured = _replace_colour(source, fill, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, fill, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            cells = [(r, c) for r in range(3) for c in range(3) if source[r][c] != program.background_colour]
            marker = analysis["marker_colour"]
            marker_cell = next((r, c) for r, c in cells if source[r][c] == marker)
            swap_cell = next((r, c) for r, c in cells if source[r][c] == fill and (r - min(x for x, _ in cells)) != (c - min(y for _, y in cells)))
            modified[marker_cell[0]][marker_cell[1]] = fill
            modified[swap_cell[0]][swap_cell[1]] = marker
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, PaletteScaledCornerConnectorProgram):
            analysis = program.analyse(source)
            equivariant = _recolour_equivariance(program, source, original, (program.background_colour, program.connector_colour))
            colours = sorted(_palette(source) - {program.background_colour, analysis["block_colour"]})
            if colours:
                modified = _replace_colour(source, colours[-1], program.background_colour)
                try:
                    relation_necessary = program.predict(modified) != original
                except Inapplicable:
                    relation_necessary = True
            else:
                relation_necessary = True

        else:
            return {"kind": "unknown", "passed": False}

        rows.append({
            "demonstration": index,
            "relation_necessary": relation_necessary,
            "equivariant_or_stable": equivariant,
        })
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Inference and validation.
# ---------------------------------------------------------------------------


def infer_composable_recursive(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_composable_recursive_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    counterfactual_rejected = 0
    for program in programmes:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                counterfactual_rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": counterfactual_rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "composable_recursive_primitives": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "colour_class_self_substitution":
        return ColourClassSelfSubstitutionProgram(int(parameters["background_colour"]))
    if kind == "mask_colour_kronecker_composition":
        return MaskColourKroneckerProgram(int(parameters["background_colour"]))
    if kind == "edge_extrusion":
        return EdgeExtrusionProgram(int(parameters["background_colour"]))
    if kind == "diagonal_row_shear":
        return DiagonalRowShearProgram(int(parameters["background_colour"]), str(parameters["direction"]))
    if kind == "colour_frequency_histogram":
        return ColourFrequencyHistogramProgram(int(parameters["background_colour"]), str(parameters["alignment"]))
    if kind == "prefix_staircase_extension":
        return PrefixStaircaseProgram(int(parameters["background_colour"]))
    if kind == "palindromic_row_bounce":
        return PalindromicRowBounceProgram()
    if kind == "affine_row_recurrence_extension":
        return AffineRowRecurrenceProgram(int(parameters["background_colour"]))
    if kind == "sequence_diagonal_band_projection":
        return SequenceDiagonalBandProgram(int(parameters["background_colour"]))
    if kind == "staggered_half_separator":
        return StaggeredHalfSeparatorProgram(int(parameters["separator_colour"]))
    if kind == "marker_diagonal_block_projection":
        return MarkerDiagonalBlockProgram(int(parameters["background_colour"]))
    if kind == "palette_scaled_corner_connectors":
        return PaletteScaledCornerConnectorProgram(int(parameters["background_colour"]), int(parameters["connector_colour"]))
    raise Inapplicable("unknown composable-recursive schema")


def validate_composable_recursive(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected_tuple = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_composable_recursive_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held_index,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def composable_recursive_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_composable_recursive_programs(pairs)}))


infer = infer_composable_recursive
validate = validate_composable_recursive
