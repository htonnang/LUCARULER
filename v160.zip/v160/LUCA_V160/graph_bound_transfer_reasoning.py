"""LUCA V115: graph-bound instructional transfer.

This research family composes the component-graph vocabulary introduced in
V104-V106 with the instructional-transfer discipline of V114.  It contains two
conservative schemas:

* ``homologous_pattern_propagation`` -- one or more instructional components
  provide a colour pattern that is transferred to every homologous neutral
  component with the same normalized support shape;
* ``boundary_marker_orientation`` -- boundary markers bind adjacent two-colour
  objects along their row or column and orient a designated colour toward the
  marker.

Programs contain no task IDs, saved targets, coordinates from demonstrations,
or official test outputs.  Exact training fit is necessary but not sufficient:
accepted predictions must also survive leave-one-demonstration-out refitting,
schema-specific counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from itertools import permutations
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_graph_bound_instructional_transfer"
LANGUAGE = "spinoza_graph_bound_transfer_language_v1"
SCHEMA_VERSION = "graph_bound_transfer_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


@dataclass(frozen=True)
class _Component:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    mask: tuple[tuple[int, int], ...]
    pattern: tuple[tuple[int, int, int], ...]
    palette: tuple[int, ...]


def _components(value: Grid, background: int, connectivity: int = 4) -> tuple[_Component, ...]:
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    a = grid(value)
    h, w = _shape(a)
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions.extend([(1, 1), (1, -1), (-1, 1), (-1, -1)])
    seen: set[tuple[int, int]] = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or a[r][c] == background:
                continue
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or a[nr][nc] == background:
                        continue
                    seen.add((nr, nc))
                    queue.append((nr, nc))
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            mask = tuple(sorted((rr - r0, cc - c0) for rr, cc in cells))
            pattern = tuple(sorted((rr - r0, cc - c0, a[rr][cc]) for rr, cc in cells))
            palette = tuple(sorted({a[rr][cc] for rr, cc in cells}))
            result.append(_Component(tuple(sorted(cells)), (r0, c0, r1, c1), mask, pattern, palette))
    return tuple(result)


def _pattern_map(component: _Component) -> dict[tuple[int, int], int]:
    return {(r, c): colour for r, c, colour in component.pattern}


def _rot180(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(reversed(row)) for row in reversed(a))


# ---------------------------------------------------------------------------
# Schema I: one instructional component pattern propagates to homologous nodes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HomologousPatternPropagationProgram:
    recipient_colour: int
    connectivity: int = 4
    source_policy: str = "preserve"
    kind: str = "homologous_pattern_propagation"

    @property
    def schema_key(self):
        return (self.kind, self.recipient_colour, self.connectivity, self.source_policy)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (0 if self.source_policy == "preserve" else 1, self.connectivity, self.recipient_colour)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        if self.recipient_colour == background:
            raise Inapplicable("recipient colour is the background")
        components = _components(a, background, self.connectivity)
        if len(components) < 2:
            raise Inapplicable("requires multiple graph nodes")
        groups: dict[tuple[tuple[int, int], ...], list[_Component]] = defaultdict(list)
        for component in components:
            groups[component.mask].append(component)

        assignments = []
        assigned_recipient_cells: set[tuple[int, int]] = set()
        instructional_components = []
        for mask, members in groups.items():
            recipients = [member for member in members if member.palette == (self.recipient_colour,)]
            if not recipients:
                continue
            instructors = [member for member in members if member.palette != (self.recipient_colour,)]
            if not instructors:
                raise Inapplicable("recipient group lacks an instructional homolog")
            patterns = {_serial(member.pattern): member for member in instructors}
            if len(patterns) != 1:
                raise Inapplicable("homologous instruction patterns disagree")
            instructor = next(iter(patterns.values()))
            if self.recipient_colour in instructor.palette:
                raise Inapplicable("instruction pattern reuses the recipient role colour")
            mapping = _pattern_map(instructor)
            if set(mapping) != set(mask):
                raise Inapplicable("instruction support disagrees with homologous mask")
            instructional_components.append(instructor)
            for recipient in recipients:
                assignments.append((recipient, mapping))
                assigned_recipient_cells.update(recipient.cells)

        all_recipient_components = [
            component for component in components if component.palette == (self.recipient_colour,)
        ]
        if not assignments:
            raise Inapplicable("no homologous recipient assignment")
        if assigned_recipient_cells != {cell for component in all_recipient_components for cell in component.cells}:
            raise Inapplicable("not every recipient node has one instructional homolog")
        if self.source_policy not in ("preserve", "erase"):
            raise Inapplicable("unknown instructional source policy")
        return background, components, tuple(assignments), tuple(instructional_components)

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        background, _, assignments, instructors = self._analyse(a)
        output = _array(a)
        for recipient, mapping in assignments:
            r0, c0, _, _ = recipient.box
            for rr, cc in recipient.cells:
                local = (rr - r0, cc - c0)
                output[rr][cc] = mapping[local]
        if self.source_policy == "erase":
            for instructor in instructors:
                for r, c in instructor.cells:
                    output[r][c] = background
        predicted = tuple(tuple(row) for row in output)
        if predicted == a:
            raise Inapplicable("instructional graph transfer has no effect")
        return predicted

    def describe(self, pairs):
        inventories = []
        palettes = []
        for source, _ in pairs:
            _, components, assignments, instructors = self._analyse(source)
            inventories.append({
                "nodes": len(components),
                "recipients": len(assignments),
                "instruction_patterns": len(instructors),
            })
            palettes.append([list(instructor.palette) for instructor in instructors])
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "recipient_colour": self.recipient_colour,
                "connectivity": self.connectivity,
                "source_policy": self.source_policy,
            },
            "definitions": [
                {"name": "ComponentGraphNode", "type": "Grid -> ConnectedComponent"},
                {"name": "HomologousShape", "type": "Node x Node -> Boolean"},
                {"name": "InstructionPattern", "type": "Node -> LocalColourMap"},
            ],
            "propositions": [
                {"index": 1, "definition": "GroupHomologousNodes", "effect": "partition nodes by normalized support shape"},
                {"index": 2, "definition": "BindInstructionAndRecipients", "effect": "separate patterned instructor from neutral homologs"},
                {"index": 3, "definition": "PropagateLocalPattern", "effect": "copy local colours to every recipient node"},
                {"index": 4, "definition": "InstructionSourcePolicy", "effect": "preserve or erase the instructional node"},
            ],
            "corollary": "one instructional homolog determines the colour pattern of all neutral homologous nodes",
            "common_notions": [
                {"name": "inventories", "evidence": inventories},
                {"name": "instruction_palettes", "evidence": palettes},
                {"name": "translation_invariant_support", "evidence": True},
            ],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema II: boundary markers orient two-colour objects on aligned rays
# ---------------------------------------------------------------------------


def _boundary_directions(r: int, c: int, h: int, w: int):
    directions = []
    if r == 0:
        directions.append((1, 0, "top"))
    if r == h - 1:
        directions.append((-1, 0, "bottom"))
    if c == 0:
        directions.append((0, 1, "left"))
    if c == w - 1:
        directions.append((0, -1, "right"))
    return directions


@dataclass(frozen=True)
class BoundaryMarkerOrientationProgram:
    marker_colour: int
    near_colour: int
    far_colour: int
    kind: str = "boundary_marker_orientation"

    @property
    def schema_key(self):
        return (self.kind, self.marker_colour, self.near_colour, self.far_colour)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.marker_colour, self.near_colour, self.far_colour)

    def _ray_pair(self, a: Grid, marker: tuple[int, int], direction: tuple[int, int]):
        h, w = _shape(a)
        dr, dc = direction
        r, c = marker
        candidates = []
        distance = 1
        while True:
            r1, c1 = r + dr * distance, c + dc * distance
            r2, c2 = r + dr * (distance + 1), c + dc * (distance + 1)
            if not (0 <= r2 < h and 0 <= c2 < w):
                break
            values = {a[r1][c1], a[r2][c2]}
            if values == {self.near_colour, self.far_colour}:
                # All cells between marker and the first member of the pair must
                # be background.  This makes the boundary marker the nearest
                # aligned causal instruction.
                background = _unique_modal(a)
                path = [
                    (r + dr * step, c + dc * step)
                    for step in range(1, distance)
                ]
                if all(a[rr][cc] == background for rr, cc in path):
                    candidates.append(((r1, c1), (r2, c2), distance))
            distance += 1
        if not candidates:
            return None
        nearest = min(item[2] for item in candidates)
        best = [item for item in candidates if item[2] == nearest]
        if len(best) != 1:
            raise Inapplicable("marker has ambiguous nearest aligned pair")
        return best[0][:2]

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        background = _unique_modal(a)
        if len({background, self.marker_colour, self.near_colour, self.far_colour}) != 4:
            raise Inapplicable("marker and payload roles must be colour-distinct")
        palette = _palette(a)
        if not {self.marker_colour, self.near_colour, self.far_colour}.issubset(palette):
            raise Inapplicable("missing marker or payload colour")
        if palette - {background, self.marker_colour, self.near_colour, self.far_colour}:
            raise Inapplicable("unexpected colour outside boundary-orientation grammar")
        markers = [
            (r, c) for r in range(h) for c in range(w)
            if a[r][c] == self.marker_colour and (r in (0, h - 1) or c in (0, w - 1))
        ]
        if len(markers) < 2:
            raise Inapplicable("requires multiple boundary instructions")
        if any(a[r][c] == self.marker_colour and (r, c) not in markers for r in range(h) for c in range(w)):
            raise Inapplicable("marker colour occurs away from the boundary")
        assignments = []
        used_cells: set[tuple[int, int]] = set()
        directions_seen = set()
        for marker in markers:
            matches = []
            for dr, dc, label in _boundary_directions(marker[0], marker[1], h, w):
                pair = self._ray_pair(a, marker, (dr, dc))
                if pair is not None:
                    matches.append((pair, label))
            if len(matches) != 1:
                raise Inapplicable("boundary marker does not bind one aligned payload pair")
            pair, label = matches[0]
            if any(cell in used_cells for cell in pair):
                raise Inapplicable("two markers bind the same payload pair")
            used_cells.update(pair)
            directions_seen.add(label)
            assignments.append((marker, pair, label))
        payload_cells = {
            (r, c) for r in range(h) for c in range(w)
            if a[r][c] in (self.near_colour, self.far_colour)
        }
        if used_cells != payload_cells:
            raise Inapplicable("not every payload cell is bound by one boundary marker")
        return background, tuple(markers), tuple(assignments), tuple(sorted(directions_seen))

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        _, _, assignments, _ = self._analyse(a)
        output = _array(a)
        for _, (near_cell, far_cell), _ in assignments:
            output[near_cell[0]][near_cell[1]] = self.near_colour
            output[far_cell[0]][far_cell[1]] = self.far_colour
        predicted = tuple(tuple(row) for row in output)
        if predicted == a:
            raise Inapplicable("orientation instruction has no effect")
        return predicted

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, markers, assignments, directions = self._analyse(source)
            evidence.append({
                "markers": len(markers),
                "payload_pairs": len(assignments),
                "boundary_sides": list(directions),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "marker_colour": self.marker_colour,
                "near_colour": self.near_colour,
                "far_colour": self.far_colour,
            },
            "definitions": [
                {"name": "BoundaryMarker", "type": "Grid -> BoundaryInstruction"},
                {"name": "AlignedPayloadPair", "type": "Marker x Grid -> OrderedPair"},
                {"name": "TowardMarkerOrientation", "type": "OrderedPair -> OrderedColours"},
            ],
            "propositions": [
                {"index": 1, "definition": "RayBinding", "effect": "bind each marker to its nearest aligned two-colour pair"},
                {"index": 2, "definition": "OrientNearColour", "effect": "place the designated colour nearer the marker"},
            ],
            "corollary": "boundary instructions orient every aligned two-colour object",
            "common_notions": [
                {"name": "boundary_binding_evidence", "evidence": evidence},
                {"name": "axis_equivariance", "evidence": True},
            ],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Fitting and inference
# ---------------------------------------------------------------------------


def _fit_homologous_pattern(pairs):
    try:
        palettes = [
            _palette(source) - {_unique_modal(source)}
            for source, _ in pairs
        ]
    except (Inapplicable, ValueError, IndexError, TypeError):
        return []
    candidates = set.intersection(*map(set, palettes)) if palettes else set()
    programs = []
    for recipient_colour in sorted(candidates):
        for connectivity in (4, 8):
            for source_policy in ("preserve", "erase"):
                program = HomologousPatternPropagationProgram(recipient_colour, connectivity, source_policy)
                try:
                    if all(program.predict(source) == target for source, target in pairs):
                        programs.append(program)
                except (Inapplicable, ValueError, IndexError, TypeError):
                    continue
    return programs


def _fit_boundary_orientation(pairs):
    if not pairs:
        return []
    common_colours = None
    boundary_colours = None
    try:
        normalized = []
        for source, _ in pairs:
            a = grid(source)
            h, w = _shape(a)
            background = _unique_modal(a)
            normalized.append((a, h, w, background))
    except (Inapplicable, ValueError, IndexError, TypeError):
        return []
    for a, h, w, background in normalized:
        colours = _palette(a) - {background}
        boundary = {
            a[r][c]
            for r in range(h) for c in range(w)
            if r in (0, h - 1) or c in (0, w - 1)
            if a[r][c] != background
        }
        common_colours = colours if common_colours is None else common_colours & colours
        boundary_colours = boundary if boundary_colours is None else boundary_colours & boundary
    programs = []
    for marker_colour in sorted(boundary_colours or ()):
        payload_colours = sorted((common_colours or set()) - {marker_colour})
        if len(payload_colours) != 2:
            continue
        for near_colour, far_colour in permutations(payload_colours, 2):
            program = BoundaryMarkerOrientationProgram(marker_colour, near_colour, far_colour)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programs.append(program)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
    return programs


def _role_varies(program, pairs):
    if isinstance(program, HomologousPatternPropagationProgram):
        evidence = []
        for source, _ in pairs:
            _, _, assignments, instructors = program._analyse(source)
            evidence.append((
                len(assignments),
                tuple(sorted(instructor.palette for instructor in instructors)),
                tuple(sorted(recipient.box for recipient, _ in assignments)),
            ))
        return len({_serial(item) for item in evidence}) >= 2
    if isinstance(program, BoundaryMarkerOrientationProgram):
        evidence = []
        all_sides = set()
        for source, _ in pairs:
            _, markers, assignments, directions = program._analyse(source)
            evidence.append((len(markers), tuple(marker for marker in markers), directions))
            all_sides.update(directions)
        return len({_serial(item) for item in evidence}) >= 2 and len(all_sides) >= 2
    return False


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "homologous_pattern_propagation" in allowed:
        programs.extend(_fit_homologous_pattern(pairs))
    if allowed is None or "boundary_marker_orientation" in allowed:
        programs.extend(_fit_boundary_orientation(pairs))
    return programs


def fit_graph_bound_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_graph_bound_transfer(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_graph_bound_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "graph_bound_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "graph_bound_instructional_transfer": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery and validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    if kind == "homologous_pattern_propagation":
        return HomologousPatternPropagationProgram(
            int(parameters["recipient_colour"]),
            int(parameters.get("connectivity", 4)),
            str(parameters.get("source_policy", "preserve")),
        )
    if kind == "boundary_marker_orientation":
        return BoundaryMarkerOrientationProgram(
            int(parameters["marker_colour"]),
            int(parameters["near_colour"]),
            int(parameters["far_colour"]),
        )
    raise Inapplicable("unknown graph-bound transfer schema")


def _homologous_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        bg, _, assignments, instructors = program._analyse(a)
        recipient, _ = assignments[0]
        # Remove one complete instructional homolog from the same shape group.
        instructors = [component for component in instructors if component.mask == recipient.mask]
        removed = _array(a)
        for r, c in instructors[0].cells:
            removed[r][c] = bg
        try:
            instruction_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            instruction_necessary = True

        # Recolour the instructional pattern.  Geometry is unchanged and the
        # recolouring must propagate to every recipient in the group.
        instructor = instructors[0]
        replacement_map = {}
        used = _palette(a)
        available = [colour for colour in range(10) if colour not in used and colour != bg]
        next_colour = iter(available)
        for colour in instructor.palette:
            replacement_map[colour] = next(next_colour, (colour + 1) % 10)
        recoloured = _array(a)
        for r, c in instructor.cells:
            recoloured[r][c] = replacement_map[a[r][c]]
        try:
            changed_prediction = program.predict(tuple(tuple(row) for row in recoloured))
            expected_map = {
                (r - instructor.box[0], c - instructor.box[1]): recoloured[r][c]
                for r, c in instructor.cells
            }
            recolour_propagates = changed_prediction != original and all(
                changed_prediction[r][c] == expected_map[(r - recipient.box[0], c - recipient.box[1])]
                for r, c in recipient.cells
            )
        except (Inapplicable, StopIteration):
            recolour_propagates = False

        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "instruction_necessary": instruction_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["instruction_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _boundary_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        _, markers, _, _ = program._analyse(a)
        background = _unique_modal(a)
        removed = _array(a)
        removed[markers[0][0]][markers[0][1]] = background
        try:
            marker_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            marker_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        recoloured = _array(a)
        replacement = next(
            (colour for colour in range(10) if colour not in _palette(a)),
            (program.marker_colour + 1) % 10,
        )
        for r, c in markers:
            recoloured[r][c] = replacement
        try:
            marker_identity_necessary = program.predict(tuple(tuple(row) for row in recoloured)) != original
        except Inapplicable:
            marker_identity_necessary = True
        rows.append({
            "demonstration": index,
            "marker_necessary": marker_necessary,
            "marker_identity_necessary": marker_identity_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["marker_necessary"] and row["marker_identity_necessary"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, HomologousPatternPropagationProgram):
        return _homologous_counterfactuals(program, pairs)
    if isinstance(program, BoundaryMarkerOrientationProgram):
        return _boundary_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_graph_bound_transfer(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_graph_bound_transfer(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def graph_bound_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_graph_bound_programs(pairs)}))


infer = infer_graph_bound_transfer
validate = validate_graph_bound_transfer
