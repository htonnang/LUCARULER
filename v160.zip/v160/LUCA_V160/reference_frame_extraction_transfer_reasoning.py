"""LUCA V147: reference-frame extraction and transfer.

Three transformations share one conservative consequence operator:

    scene -> reference nodes -> alignment/orientation/selection edges
          -> reference-frame extraction or transfer -> deterministic grid -> proof

Inference is task-ID blind and target blind.  Colours, panel roles, marker
correspondences, D4 orientation, crop side, and output dimensions are derived
from the demonstrations and each current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_reference_frame_extraction_transfer"
LANGUAGE = "spinoza_reference_frame_extraction_transfer_v147"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "reference_conditioned": True,
            "bounded_extraction_or_transfer": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _mixed_components(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    background = _mode(value)
    seen = set()
    output = []
    for r in range(h):
        for c in range(w):
            if value[r][c] == background or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w) or (nr, nc) in seen:
                        continue
                    if value[nr][nc] != background:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append({
                "cells": frozenset(cells),
                "bbox": _bbox(cells),
                "colours": frozenset(value[rr][cc] for rr, cc in cells),
            })
    return output


def _crop(value: Grid, bbox):
    value = grid(value)
    r0, c0, r1, c1 = bbox
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _full_rectangle(cells):
    cells = frozenset(cells)
    r0, c0, r1, c1 = _bbox(cells)
    return cells == frozenset((r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1))


def _unique_mode_in_crop(value: Grid):
    counts = Counter(cell for row in value for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("panel base is not unique")
    return int(winners[0])


def _rot90(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    return tuple(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))


def _flip_lr(value: Grid):
    return tuple(tuple(reversed(row)) for row in grid(value))


def _d4(value: Grid):
    value = grid(value)
    candidates = []
    current = value
    for _ in range(4):
        candidates.append(current)
        candidates.append(_flip_lr(current))
        current = _rot90(current)
    seen = set()
    output = []
    for candidate in candidates:
        if candidate not in seen:
            seen.add(candidate)
            output.append(candidate)
    return output


def _sign(value):
    return -1 if value < 0 else 1 if value > 0 else 0


def _relation_signature(positions):
    colours = sorted(positions)
    return tuple(
        (
            first,
            second,
            _sign(positions[first][0] - positions[second][0]),
            _sign(positions[first][1] - positions[second][1]),
        )
        for index, first in enumerate(colours)
        for second in colours[index + 1 :]
    )


# ---------------------------------------------------------------------------
# Shared operator: reference-frame extraction and transfer.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerAlignedMotifTransferProgram:
    kind = "marker_aligned_motif_transfer"
    operator = "reference_frame_extraction_transfer"
    node_vocabulary = "panel_marker_and_boundary_reference_nodes"
    edge_vocabulary = "alignment_orientation_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _mode(value)
        components = _mixed_components(value)
        if len(components) != 2 or not all(_full_rectangle(item["cells"]) for item in components):
            raise Inapplicable("exactly two filled non-background panels required")

        panels = []
        for item in components:
            panel = _crop(value, item["bbox"])
            if min(_shape(panel)) < 3:
                raise Inapplicable("panels too small")
            panels.append((panel, item["bbox"]))

        bases = [_unique_mode_in_crop(panel) for panel, _ in panels]
        if bases[0] != bases[1]:
            raise Inapplicable("panels do not share a base colour")
        base = bases[0]
        if base == background:
            raise Inapplicable("panel base must differ from canvas background")

        panel_palettes = [_palette(panel) for panel, _ in panels]
        accents = [
            colour
            for colour in (panel_palettes[0] & panel_palettes[1]) - {base}
            if sum(cell == colour for row in panels[0][0] for cell in row) == 1
            and sum(cell == colour for row in panels[1][0] for cell in row) == 1
        ]
        if len(accents) != 1:
            raise Inapplicable("one shared singleton alignment marker required")
        accent = accents[0]

        reference_indices = [
            index
            for index, palette in enumerate(panel_palettes)
            if palette == {base, accent}
        ]
        if len(reference_indices) != 1:
            raise Inapplicable("one blank reference panel required")
        reference_index = reference_indices[0]
        motif_index = 1 - reference_index
        motif_palette = panel_palettes[motif_index]
        if not (motif_palette - {base, accent}):
            raise Inapplicable("motif panel must contain payload material")

        reference = panels[reference_index][0]
        motif = panels[motif_index][0]
        reference_marker = next(
            (r, c)
            for r, row in enumerate(reference)
            for c, cell in enumerate(row)
            if cell == accent
        )
        motif_marker = next(
            (r, c)
            for r, row in enumerate(motif)
            for c, cell in enumerate(row)
            if cell == accent
        )
        delta = (
            reference_marker[0] - motif_marker[0],
            reference_marker[1] - motif_marker[1],
        )
        h, w = _shape(reference)
        output = [[base for _ in range(w)] for _ in range(h)]
        emitted = 0
        for r, row in enumerate(motif):
            for c, colour in enumerate(row):
                if colour == base:
                    continue
                nr, nc = r + delta[0], c + delta[1]
                if 0 <= nr < h and 0 <= nc < w:
                    output[nr][nc] = colour
                    emitted += 1
        if emitted < 2 or output[reference_marker[0]][reference_marker[1]] != accent:
            raise Inapplicable("aligned motif does not produce a valid reference-frame payload")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="two filled panels sharing a singleton alignment marker",
            relation_chain=(
                "identify the blank reference panel and payload-bearing motif panel",
                "align their shared singleton marker roles",
                "translate and clip non-base motif material into the reference frame",
            ),
            parameters={},
            corollary="Emit the marker-aligned motif in the dimensions of the blank reference panel.",
            notions=["reference panel", "shared marker", "translation", "clipped transfer"],
        )


@dataclass(frozen=True)
class ExternalMarkerOrientedPanelProgram:
    kind = "external_marker_oriented_panel"
    operator = "reference_frame_extraction_transfer"
    node_vocabulary = "panel_marker_and_boundary_reference_nodes"
    edge_vocabulary = "alignment_orientation_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        components = _mixed_components(value)
        panel_candidates = [
            item
            for item in components
            if _full_rectangle(item["cells"])
            and len(item["cells"]) >= 25
            and len(item["colours"]) >= 4
        ]
        if len(panel_candidates) != 1:
            raise Inapplicable("one large filled panel required")
        panel_item = panel_candidates[0]
        external_components = [item for item in components if item is not panel_item]
        if len(external_components) != 3 or any(len(item["cells"]) != 1 for item in external_components):
            raise Inapplicable("exactly three external singleton markers required")

        panel = _crop(value, panel_item["bbox"])
        base = _unique_mode_in_crop(panel)
        external_positions = {}
        for item in external_components:
            (position,) = tuple(item["cells"])
            colour = value[position[0]][position[1]]
            if colour in external_positions:
                raise Inapplicable("external marker colours must be distinct")
            external_positions[colour] = position
        if len(external_positions) != 3:
            raise Inapplicable("three marker colours required")

        for colour in external_positions:
            if sum(cell == colour for row in panel for cell in row) != 1:
                raise Inapplicable("every external marker must have one internal correspondent")
        if base in external_positions:
            raise Inapplicable("panel base cannot be a marker role")

        target_signature = _relation_signature(external_positions)
        candidates = []
        for transformed in _d4(panel):
            positions = {}
            valid = True
            for colour in external_positions:
                matches = [
                    (r, c)
                    for r, row in enumerate(transformed)
                    for c, cell in enumerate(row)
                    if cell == colour
                ]
                if len(matches) != 1:
                    valid = False
                    break
                positions[colour] = matches[0]
            if valid and _relation_signature(positions) == target_signature:
                candidates.append(transformed)
        unique = []
        seen = set()
        for candidate in candidates:
            if candidate not in seen:
                seen.add(candidate)
                unique.append(candidate)
        if len(unique) != 1:
            raise Inapplicable("external marker relation does not select one D4 orientation")
        return unique[0]

    def describe(self, pairs):
        return _law(
            self,
            scene="one filled payload panel with three internal markers and three external marker references",
            relation_chain=(
                "pair internal and external marker colours",
                "compare their row-column order and equality relations",
                "select the unique D4-oriented panel whose marker graph matches the external graph",
            ),
            parameters={},
            corollary="Orient and extract the complete panel according to the external marker relation graph.",
            notions=["marker correspondence", "relation signature", "D4 orientation", "panel extraction"],
        )


@dataclass(frozen=True)
class BoundaryMarkerHalfExtractionProgram:
    kind = "boundary_marker_half_extraction"
    operator = "reference_frame_extraction_transfer"
    node_vocabulary = "panel_marker_and_boundary_reference_nodes"
    edge_vocabulary = "alignment_orientation_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 2:
            raise Inapplicable("one payload and one boundary marker colour required")

        candidates = []
        for colour in colours:
            cells = [(r, c) for r in range(h) for c in range(w) if value[r][c] == colour]
            if len(cells) != 2:
                continue
            if abs(cells[0][0] - cells[1][0]) + abs(cells[0][1] - cells[1][1]) != 2:
                continue
            sides = []
            if all(r == 0 for r, _ in cells):
                sides.append("top")
            if all(r == h - 1 for r, _ in cells):
                sides.append("bottom")
            if all(c == 0 for _, c in cells):
                sides.append("left")
            if all(c == w - 1 for _, c in cells):
                sides.append("right")
            if len(sides) == 1:
                candidates.append((colour, tuple(cells), sides[0]))
        if len(candidates) != 1:
            raise Inapplicable("one same-boundary marker pair required")
        marker_colour, markers, side = candidates[0]
        payload_colour = next(colour for colour in colours if colour != marker_colour)
        if sum(cell == payload_colour for row in value for cell in row) < 3:
            raise Inapplicable("payload support is too small")

        if side in ("left", "right"):
            if h % 2:
                raise Inapplicable("vertical split requires an even height")
            split = h // 2
            rows = [r for r, _ in markers]
            if max(rows) < split:
                selected = [list(row) for row in value[:split]]
            elif min(rows) >= split:
                selected = [list(row) for row in value[split:]]
            else:
                raise Inapplicable("markers straddle the split")
        else:
            if w % 2:
                raise Inapplicable("horizontal split requires an even width")
            split = w // 2
            cols = [c for _, c in markers]
            if max(cols) < split:
                selected = [list(row[:split]) for row in value]
            elif min(cols) >= split:
                selected = [list(row[split:]) for row in value]
            else:
                raise Inapplicable("markers straddle the split")

        for r, row in enumerate(selected):
            for c, colour in enumerate(row):
                if colour == marker_colour:
                    selected[r][c] = background
        output = grid(selected)
        if marker_colour in _palette(output) or payload_colour not in _palette(output):
            raise Inapplicable("selected half does not preserve payload while deleting markers")
        return output

    def describe(self, pairs):
        return _law(
            self,
            scene="a patterned canvas with a same-boundary pair of reference markers",
            relation_chain=(
                "identify the marker-bearing boundary and its orthogonal half-axis",
                "select the half indicated by the marker pair position",
                "remove the reference markers while preserving the selected payload",
            ),
            parameters={},
            corollary="Extract the marker-selected half-canvas and erase the marker role.",
            notions=["boundary marker", "half selection", "orthogonal crop", "marker deletion"],
        )


# ---------------------------------------------------------------------------
# Fitting, counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


def _fit_static(pairs, cls):
    programme = cls()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


_FITTERS = {
    "marker_aligned_motif_transfer": lambda pairs: _fit_static(pairs, MarkerAlignedMotifTransferProgram),
    "external_marker_oriented_panel": lambda pairs: _fit_static(pairs, ExternalMarkerOrientedPanelProgram),
    "boundary_marker_half_extraction": lambda pairs: _fit_static(pairs, BoundaryMarkerHalfExtractionProgram),
}


def fit_reference_frame_extraction_transfer_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        target = grid(target)
        original = programme.predict(source)
        background = _mode(source)
        foreground_colours = sorted(_palette(source) - {background})
        changed_cells = [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] != target[r][c]
            and r < len(target)
            and c < len(target[0])
        ] if _shape(source) == _shape(target) else []
        colour_counts = Counter(cell for row in source for cell in row)
        candidates = sorted(
            (
                (r, c)
                for r in range(len(source))
                for c in range(len(source[0]))
                if source[r][c] != background
            ),
            key=lambda cell: (
                colour_counts[source[cell[0]][cell[1]]],
                0 if cell[0] in (0, len(source) - 1) or cell[1] in (0, len(source[0]) - 1) else 1,
                cell,
            ),
        )
        candidates += changed_cells
        candidates += [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] == background
        ][:6]
        seen = set()
        passed = False
        tested = 0
        for r, c in candidates:
            if (r, c) in seen:
                continue
            seen.add((r, c))
            replacement = background if source[r][c] != background else (
                foreground_colours[0] if foreground_colours else (background + 1) % 10
            )
            if replacement == source[r][c]:
                continue
            tested += 1
            work = _array(source)
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                break
            if tested >= 20:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "reference_node_or_alignment_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_reference_frame_extraction_transfer(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_reference_frame_extraction_transfer_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "reference_conditioned": True,
            "bounded_extraction_or_transfer": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_reference_frame_extraction_transfer_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_reference_frame_extraction_transfer_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_reference_frame_extraction_transfer(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
