"""LUCA V122: learned counterfactual feature induction.

The family extends the V121 selector algebra with programmes whose decisive
feature or structural relation is induced from demonstrations rather than
chosen by a task identifier::

    scene -> candidates/relations -> induce feature -> compare -> bind -> emit

Five conservative schemas are exposed:

* ``learned_component_feature_selector`` learns a non-positional component
  feature and comparison relation, then emits the selected raw crop;
* ``lattice_cell_feature_selector`` learns which property selects one logical
  cell inside a separator lattice;
* ``homologous_anchor_pair_window`` uses a unique pair of repeated elongated
  anchors to define a crop window;
* ``dihedral_tile_seed_extraction`` recovers the seed tile of a D4-generated
  non-overlapping tiling;
* ``periodic_hole_recovery`` reconstructs a rectangular missing patch from a
  witnessed two-dimensional periodic law.

The implementation contains no task identifiers, stored demonstration
coordinates, or test outputs.  Exact training fit is necessary but not
sufficient: accepted predictions must survive consensus, leave-one-
demonstration-out refitting, counterfactual interventions, and metadata
leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from fractions import Fraction
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_learned_counterfactual_feature_induction"
LANGUAGE = "spinoza_learned_counterfactual_feature_induction_v1"
SCHEMA_VERSION = "learned_counterfactual_feature_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _directions(connectivity: int):
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    result = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        result += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    return result


def _bbox(cells: Iterable[tuple[int, int]]) -> tuple[int, int, int, int]:
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _crop(value: Grid, cells_or_box) -> Grid:
    value = grid(value)
    if len(cells_or_box) == 4 and all(isinstance(item, int) for item in cells_or_box):
        r0, c0, r1, c1 = cells_or_box
    else:
        r0, c0, r1, c1 = _bbox(cells_or_box)
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_mask(cells: Iterable[tuple[int, int]]):
    cells = tuple(cells)
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _components_by_predicate(value: Grid, predicate, *, connectivity: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if predicate(value[r][c])}
    result = []
    while remaining:
        start = min(remaining)
        remaining.remove(start)
        component = {start}
        queue = deque([start])
        while queue:
            r, c = queue.popleft()
            for dr, dc in _directions(connectivity):
                neighbour = (r + dr, c + dc)
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        result.append(tuple(sorted(component)))
    return tuple(result)


def _monochrome_components(value: Grid, background: int, connectivity: int):
    value = grid(value)
    result = []
    for colour in sorted(_palette(value) - {background}):
        for cells in _components_by_predicate(
            value,
            lambda cell, colour=colour: cell == colour,
            connectivity=connectivity,
        ):
            result.append({"cells": cells, "colour": colour, "crop": _crop(value, cells)})
    return tuple(result)


def _colour_classes(value: Grid, background: int):
    value = grid(value)
    result = []
    for colour in sorted(_palette(value) - {background}):
        cells = tuple(sorted((r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == colour))
        if cells:
            result.append({"cells": cells, "colour": colour, "crop": _crop(value, cells)})
    return tuple(result)


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    maximum = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == maximum]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _rotate90(value: Grid) -> Grid:
    value = grid(value)
    h, w = _shape(value)
    return tuple(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))


def _rotate180(value: Grid) -> Grid:
    return _rotate90(_rotate90(value))


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused colour")


def _rotate90_mask(mask):
    mask = tuple(mask)
    h = max(r for r, _ in mask) + 1
    rotated = {(c, h - 1 - r) for r, c in mask}
    r0 = min(r for r, _ in rotated)
    c0 = min(c for _, c in rotated)
    return tuple(sorted((r - r0, c - c0) for r, c in rotated))


def _reflect_lr_mask(mask):
    mask = tuple(mask)
    width = max(c for _, c in mask) + 1
    return tuple(sorted((r, width - 1 - c) for r, c in mask))


def _reflect_tb_mask(mask):
    mask = tuple(mask)
    height = max(r for r, _ in mask) + 1
    return tuple(sorted((height - 1 - r, c) for r, c in mask))


def _d4_transforms(value: Grid):
    value = grid(value)
    result = []
    current = value
    for _ in range(4):
        result.append(current)
        result.append(tuple(tuple(reversed(row)) for row in current))
        current = _rotate90(current)
    return tuple(dict.fromkeys(result))


def _holes(cells: Iterable[tuple[int, int]]) -> int:
    points = set(_normalised_mask(cells))
    h = max(r for r, _ in points) + 1
    w = max(c for _, c in points) + 1
    background = {(r, c) for r in range(h) for c in range(w) if (r, c) not in points}
    visited = set()
    result = 0
    for start in sorted(background):
        if start in visited:
            continue
        queue = deque([start])
        visited.add(start)
        touches_boundary = False
        while queue:
            r, c = queue.popleft()
            touches_boundary |= r in (0, h - 1) or c in (0, w - 1)
            for dr, dc in _directions(4):
                neighbour = (r + dr, c + dc)
                if neighbour in background and neighbour not in visited:
                    visited.add(neighbour)
                    queue.append(neighbour)
        if not touches_boundary:
            result += 1
    return result


def _perimeter(cells: Iterable[tuple[int, int]]) -> int:
    points = set(cells)
    return sum((r + dr, c + dc) not in points for r, c in points for dr, dc in _directions(4))


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Schema I: learned non-positional component feature -> crop.
# ---------------------------------------------------------------------------

SAFE_COMPONENT_FEATURES = (
    "area",
    "bbox_area",
    "perimeter",
    "holes",
    "density",
    "d4_stabiliser",
    "shape_frequency",
    "global_colour_material",
)
SAFE_COMPARISONS = ("unique_max", "unique_min", "singleton_value")


def _component_candidates(value: Grid, *, candidate_mode: str, background_rule: str, connectivity: int):
    value = grid(value)
    background = 0 if background_rule == "zero" else _unique_modal(value)
    if candidate_mode == "monochrome_components":
        candidates = _monochrome_components(value, background, connectivity)
    elif candidate_mode == "colour_classes":
        candidates = _colour_classes(value, background)
    else:
        raise Inapplicable("unknown candidate mode")
    if len(candidates) < 3:
        raise Inapplicable("feature induction requires at least three candidates")
    shape_frequency = Counter(_normalised_mask(item["cells"]) for item in candidates)
    global_material = Counter(cell for row in value for cell in row)
    rows = []
    for item in candidates:
        r0, c0, r1, c1 = _bbox(item["cells"])
        height = r1 - r0 + 1
        width = c1 - c0 + 1
        area = len(item["cells"])
        mask = _normalised_mask(item["cells"])
        transformed = []
        current = mask
        for _ in range(4):
            transformed.append(current)
            transformed.append(_reflect_lr_mask(current))
            current = _rotate90_mask(current)
        rows.append({
            **item,
            "features": {
                "area": area,
                "bbox_area": height * width,
                "perimeter": _perimeter(item["cells"]),
                "holes": _holes(item["cells"]),
                "density": Fraction(area, height * width),
                "d4_stabiliser": sum(candidate == mask for candidate in transformed),
                "shape_frequency": shape_frequency[mask],
                "global_colour_material": global_material[item["colour"]],
            },
        })
    return background, tuple(rows)


def _select_index(values, comparison: str):
    values = tuple(values)
    if len(values) < 2 or len(set(values)) < 2:
        raise Inapplicable("insufficient comparative evidence")
    if comparison == "unique_max":
        target = max(values)
        winners = [index for index, value in enumerate(values) if value == target]
    elif comparison == "unique_min":
        target = min(values)
        winners = [index for index, value in enumerate(values) if value == target]
    elif comparison == "singleton_value":
        counts = Counter(values)
        singleton_values = [value for value, count in counts.items() if count == 1]
        if len(singleton_values) != 1:
            raise Inapplicable("feature has no sole singleton class")
        winners = [values.index(singleton_values[0])]
    else:
        raise Inapplicable("unknown comparison")
    if len(winners) != 1:
        raise Inapplicable("comparison does not bind one candidate")
    return winners[0]


@dataclass(frozen=True)
class LearnedComponentFeatureSelectorProgram:
    candidate_mode: str
    background_rule: str
    connectivity: int
    feature: str
    comparison: str
    kind: str = "learned_component_feature_selector"

    @property
    def schema_key(self):
        return self.kind, self.candidate_mode, self.background_rule, self.connectivity, self.feature, self.comparison

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return SAFE_COMPONENT_FEATURES.index(self.feature), SAFE_COMPARISONS.index(self.comparison), self.candidate_mode, self.connectivity

    def analyse(self, value: Grid):
        background, candidates = _component_candidates(
            value,
            candidate_mode=self.candidate_mode,
            background_rule=self.background_rule,
            connectivity=self.connectivity,
        )
        values = [item["features"][self.feature] for item in candidates]
        winner_index = _select_index(values, self.comparison)
        winner = candidates[winner_index]
        return {
            "background": background,
            "candidates": candidates,
            "values": tuple(values),
            "winner_index": winner_index,
            "winner": winner,
            "prediction": winner["crop"],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "candidate_count": len(analysis["candidates"]),
                "feature_values": [str(value) for value in analysis["values"]],
                "selected_bbox": list(_bbox(analysis["winner"]["cells"])),
                "selected_colour": analysis["winner"]["colour"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "candidate_mode": self.candidate_mode,
                "background_rule": self.background_rule,
                "connectivity": self.connectivity,
                "feature": self.feature,
                "comparison": self.comparison,
            },
            definitions=[
                {"name": "CandidateSet", "type": "Grid -> ComponentSet"},
                {"name": "LearnedFeature", "type": "Component -> Quantity"},
                {"name": "Comparison", "type": "QuantitySet -> UniqueRole"},
                {"name": "CropEmitter", "type": "Role -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ConstructCandidates", "effect": "derive non-positional object candidates"},
                {"index": 2, "definition": "MeasureFeature", "effect": "evaluate the induced structural quantity"},
                {"index": 3, "definition": "CompareAndBind", "effect": "bind the sole extremal or singleton role"},
                {"index": 4, "definition": "EmitCrop", "effect": "return the raw bounding-box crop"},
            ],
            corollary="the uniquely feature-selected component is the answer",
            common_notions=[{"name": "learned_feature_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema II: separator lattice -> learned cell feature -> selected cell crop.
# ---------------------------------------------------------------------------

LATTICE_FEATURES = (
    "foreground_palette_size",
    "foreground_count",
    "component_count",
    "largest_component_area",
    "left_right_symmetric",
    "top_bottom_symmetric",
    "half_turn_symmetric",
)
LATTICE_COMPARISONS = ("unique_min", "unique_max", "unique_true", "unique_false", "singleton_value")


def _runs(indices: Iterable[int]):
    values = sorted(set(indices))
    if not values:
        return tuple()
    result = [[values[0]]]
    for value in values[1:]:
        if value == result[-1][-1] + 1:
            result[-1].append(value)
        else:
            result.append([value])
    return tuple(tuple(run) for run in result)


def _lattice_decompositions(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    result = []
    for separator in sorted(_palette(value)):
        full_rows = {r for r in range(h) if all(value[r][c] == separator for c in range(w))}
        full_cols = {c for c in range(w) if all(value[r][c] == separator for r in range(h))}
        if not full_rows or not full_cols:
            continue
        row_groups = _runs(r for r in range(h) if r not in full_rows)
        col_groups = _runs(c for c in range(w) if c not in full_cols)
        if len(row_groups) < 2 or len(col_groups) < 2:
            continue
        if len({len(run) for run in row_groups}) != 1 or len({len(run) for run in col_groups}) != 1:
            continue
        cells = []
        valid = True
        for row_index, rows in enumerate(row_groups):
            for col_index, cols in enumerate(col_groups):
                cell = tuple(tuple(value[r][c] for c in cols) for r in rows)
                try:
                    background = _unique_modal(cell)
                except Inapplicable:
                    if 0 in _palette(cell):
                        background = 0
                    else:
                        valid = False
                        break
                foreground = {(r, c) for r, row in enumerate(cell) for c, colour in enumerate(row) if colour != background}
                components = _components_by_predicate(cell, lambda colour, bg=background: colour != bg, connectivity=4)
                palette_size = len(_palette(cell) - {background})
                if foreground:
                    mask = tuple(sorted(foreground))
                    height, width = _shape(cell)
                    lr = mask == tuple(sorted((r, width - 1 - c) for r, c in mask))
                    tb = mask == tuple(sorted((height - 1 - r, c) for r, c in mask))
                    ht = mask == tuple(sorted((height - 1 - r, width - 1 - c) for r, c in mask))
                else:
                    lr = tb = ht = True
                cells.append({
                    "position": (row_index, col_index),
                    "crop": cell,
                    "background": background,
                    "features": {
                        "foreground_palette_size": palette_size,
                        "foreground_count": len(foreground),
                        "component_count": len(components),
                        "largest_component_area": max((len(component) for component in components), default=0),
                        "left_right_symmetric": lr,
                        "top_bottom_symmetric": tb,
                        "half_turn_symmetric": ht,
                    },
                })
            if not valid:
                break
        if valid:
            result.append({
                "separator": separator,
                "full_rows": tuple(sorted(full_rows)),
                "full_cols": tuple(sorted(full_cols)),
                "row_groups": row_groups,
                "col_groups": col_groups,
                "cells": tuple(cells),
            })
    return tuple(result)


def _lattice_select_index(values, comparison):
    if comparison in SAFE_COMPARISONS:
        return _select_index(values, comparison)
    values = tuple(values)
    if comparison == "unique_true":
        winners = [index for index, value in enumerate(values) if value is True]
        if False not in values:
            raise Inapplicable("no contrasting false evidence")
    elif comparison == "unique_false":
        winners = [index for index, value in enumerate(values) if value is False]
        if True not in values:
            raise Inapplicable("no contrasting true evidence")
    else:
        raise Inapplicable("unknown lattice comparison")
    if len(winners) != 1:
        raise Inapplicable("lattice comparison is not unique")
    return winners[0]


@dataclass(frozen=True)
class LatticeCellFeatureSelectorProgram:
    feature: str
    comparison: str
    kind: str = "lattice_cell_feature_selector"

    @property
    def schema_key(self):
        return self.kind, self.feature, self.comparison

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return LATTICE_FEATURES.index(self.feature), LATTICE_COMPARISONS.index(self.comparison)

    def analyse(self, value: Grid):
        predictions = []
        analyses = []
        for decomposition in _lattice_decompositions(value):
            values = [cell["features"][self.feature] for cell in decomposition["cells"]]
            try:
                winner_index = _lattice_select_index(values, self.comparison)
            except Inapplicable:
                continue
            winner = decomposition["cells"][winner_index]
            predictions.append(winner["crop"])
            analyses.append({**decomposition, "values": tuple(values), "winner_index": winner_index, "winner": winner})
        unique = {prediction for prediction in predictions}
        if len(unique) != 1:
            raise Inapplicable("lattice interpretation has no unique prediction")
        chosen = next(analysis for analysis in analyses if analysis["winner"]["crop"] == next(iter(unique)))
        chosen["prediction"] = next(iter(unique))
        return chosen

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "separator": analysis["separator"],
                "lattice_shape": [len(analysis["row_groups"]), len(analysis["col_groups"])],
                "feature_values": [str(value) for value in analysis["values"]],
                "selected_position": list(analysis["winner"]["position"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"feature": self.feature, "comparison": self.comparison},
            definitions=[
                {"name": "SeparatorLattice", "type": "Grid -> LogicalCellSet"},
                {"name": "CellFeature", "type": "LogicalCell -> Quantity"},
                {"name": "Comparison", "type": "QuantitySet -> UniqueRole"},
                {"name": "CellCrop", "type": "Role -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "FindLattice", "effect": "derive full separator bands and logical cells"},
                {"index": 2, "definition": "MeasureCells", "effect": "evaluate one learned feature per cell"},
                {"index": 3, "definition": "SelectRole", "effect": "bind the unique feature-selected cell"},
                {"index": 4, "definition": "EmitCell", "effect": "return the selected cell crop"},
            ],
            corollary="the uniquely selected lattice cell is the answer",
            common_notions=[{"name": "lattice_feature_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema III: repeated elongated anchors -> relation-defined crop window.
# ---------------------------------------------------------------------------


def _straight_line(cells):
    r0, c0, r1, c1 = _bbox(cells)
    if c0 == c1 and len(cells) == r1 - r0 + 1:
        return "vertical", r1 - r0 + 1
    if r0 == r1 and len(cells) == c1 - c0 + 1:
        return "horizontal", c1 - c0 + 1
    return None


def _anchor_pair_analysis(value: Grid, pad: int):
    value = grid(value)
    h, w = _shape(value)
    candidate_groups = []
    for colour in sorted(_palette(value)):
        components = _components_by_predicate(value, lambda cell, colour=colour: cell == colour, connectivity=4)
        groups = defaultdict(list)
        for cells in components:
            line = _straight_line(cells)
            if line and line[1] >= 2:
                groups[(_normalised_mask(cells), line)].append(cells)
        for (mask, (orientation, length)), members in groups.items():
            if len(members) != 2:
                continue
            boxes = [_bbox(member) for member in members]
            if orientation == "vertical" and not all(box[0] == boxes[0][0] and box[2] == boxes[0][2] for box in boxes):
                continue
            if orientation == "horizontal" and not all(box[1] == boxes[0][1] and box[3] == boxes[0][3] for box in boxes):
                continue
            candidate_groups.append({
                "colour": colour,
                "orientation": orientation,
                "length": length,
                "members": tuple(members),
                "boxes": tuple(boxes),
            })
    if not candidate_groups:
        raise Inapplicable("no homologous elongated anchor pair")
    maximum = max(group["length"] for group in candidate_groups)
    winners = [group for group in candidate_groups if group["length"] == maximum]
    if len(winners) != 1:
        raise Inapplicable("anchor-pair role is not uniquely longest")
    winner = winners[0]
    r0 = min(box[0] for box in winner["boxes"])
    c0 = min(box[1] for box in winner["boxes"])
    r1 = max(box[2] for box in winner["boxes"])
    c1 = max(box[3] for box in winner["boxes"])
    if winner["orientation"] == "vertical":
        r0, r1 = max(0, r0 - pad), min(h - 1, r1 + pad)
    else:
        c0, c1 = max(0, c0 - pad), min(w - 1, c1 + pad)
    prediction = _crop(value, (r0, c0, r1, c1))
    return {**winner, "pad": pad, "window": (r0, c0, r1, c1), "prediction": prediction}


@dataclass(frozen=True)
class HomologousAnchorPairWindowProgram:
    pad: int
    kind: str = "homologous_anchor_pair_window"

    @property
    def schema_key(self):
        return self.kind, self.pad

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.pad

    def analyse(self, value: Grid):
        return _anchor_pair_analysis(value, self.pad)

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "anchor_colour": analysis["colour"],
                "orientation": analysis["orientation"],
                "anchor_length": analysis["length"],
                "window": list(analysis["window"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"pad": self.pad},
            definitions=[
                {"name": "ElongatedAnchor", "type": "Component -> LineRole"},
                {"name": "HomologousPair", "type": "LineRoleSet -> Pair"},
                {"name": "RelationWindow", "type": "Pair -> BoundingRegion"},
            ],
            propositions=[
                {"index": 1, "definition": "FindAnchors", "effect": "derive repeated straight-line components"},
                {"index": 2, "definition": "BindUniquePair", "effect": "select the uniquely longest homologous pair"},
                {"index": 3, "definition": "ExpandAlongAxis", "effect": "apply the learned endpoint padding"},
                {"index": 4, "definition": "EmitWindow", "effect": "return the relation-defined crop"},
            ],
            corollary="the homologous anchor pair defines the answer window",
            common_notions=[{"name": "anchor_pair_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema IV: D4-generated tiling -> seed tile.
# ---------------------------------------------------------------------------


def _divisors(value: int):
    return tuple(candidate for candidate in range(1, value + 1) if value % candidate == 0)


def _dihedral_seed_analysis(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    candidates = []
    for tile_h in _divisors(h):
        for tile_w in _divisors(w):
            tile_count = (h // tile_h) * (w // tile_w)
            if tile_count < 4 or (tile_h == h and tile_w == w):
                continue
            base = tuple(tuple(value[r][c] for c in range(tile_w)) for r in range(tile_h))
            if len(_palette(base)) < 3:
                continue
            orbit = {candidate for candidate in _d4_transforms(base) if _shape(candidate) == (tile_h, tile_w)}
            tiles = []
            for r0 in range(0, h, tile_h):
                for c0 in range(0, w, tile_w):
                    tiles.append(tuple(tuple(value[r][c] for c in range(c0, c0 + tile_w)) for r in range(r0, r0 + tile_h)))
            if any(tile not in orbit for tile in tiles):
                continue
            if len(set(tiles)) < 3:
                continue
            candidates.append({
                "tile_shape": (tile_h, tile_w),
                "tile_count": tile_count,
                "distinct_tiles": len(set(tiles)),
                "prediction": base,
            })
    if not candidates:
        raise Inapplicable("no D4 tile grammar")
    minimum_area = min(item["tile_shape"][0] * item["tile_shape"][1] for item in candidates)
    winners = [item for item in candidates if item["tile_shape"][0] * item["tile_shape"][1] == minimum_area]
    predictions = {item["prediction"] for item in winners}
    if len(predictions) != 1:
        raise Inapplicable("tile grammar has no unique seed")
    return next(item for item in winners if item["prediction"] == next(iter(predictions)))


@dataclass(frozen=True)
class DihedralTileSeedExtractionProgram:
    kind: str = "dihedral_tile_seed_extraction"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        return _dihedral_seed_analysis(value)

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "tile_shape": list(analysis["tile_shape"]),
                "tile_count": analysis["tile_count"],
                "distinct_orbit_members": analysis["distinct_tiles"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "TilePartition", "type": "Grid -> TileSet"},
                {"name": "D4Orbit", "type": "Tile -> TransformSet"},
                {"name": "SeedTile", "type": "TileSet -> Tile"},
            ],
            propositions=[
                {"index": 1, "definition": "FindMinimalPartition", "effect": "derive the smallest repeated tile dimensions"},
                {"index": 2, "definition": "VerifyD4Orbit", "effect": "require every tile to be a transform of the seed"},
                {"index": 3, "definition": "EmitSeed", "effect": "return the top-left instructional tile"},
            ],
            corollary="the D4-generated tiling is explained by its seed tile",
            common_notions=[{"name": "dihedral_tile_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema V: rectangular zero hole -> periodic reconstruction.
# ---------------------------------------------------------------------------


def _zero_rectangle(value: Grid):
    value = grid(value)
    zeros = tuple((r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == 0)
    if not zeros:
        raise Inapplicable("no missing rectangle")
    box = _bbox(zeros)
    r0, c0, r1, c1 = box
    if len(zeros) != (r1 - r0 + 1) * (c1 - c0 + 1):
        raise Inapplicable("zero cells are not one rectangle")
    return box


def _periodic_hole_analysis(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    r0, c0, r1, c1 = _zero_rectangle(value)
    if len(_palette(value) - {0}) < 2:
        raise Inapplicable("periodic recovery requires multiple witnessed colours")
    candidates = []
    for period_r in range(1, h + 1):
        for period_c in range(1, w + 1):
            if period_r == h and period_c == w:
                continue
            mapping = {}
            conflict = False
            witnesses = Counter()
            for r in range(h):
                for c in range(w):
                    colour = value[r][c]
                    if colour == 0:
                        continue
                    key = (r % period_r, c % period_c)
                    witnesses[key] += 1
                    if key in mapping and mapping[key] != colour:
                        conflict = True
                        break
                    mapping[key] = colour
                if conflict:
                    break
            if conflict:
                continue
            missing_keys = {(r % period_r, c % period_c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
            if not missing_keys <= set(mapping):
                continue
            if not any(count >= 2 for count in witnesses.values()):
                continue
            prediction = tuple(
                tuple(mapping[(r % period_r, c % period_c)] for c in range(c0, c1 + 1))
                for r in range(r0, r1 + 1)
            )
            candidates.append({
                "period": (period_r, period_c),
                "hole": (r0, c0, r1, c1),
                "prediction": prediction,
                "witnessed_residues": len(mapping),
            })
    if not candidates:
        raise Inapplicable("no witnessed periodic reconstruction")
    minimum_area = min(item["period"][0] * item["period"][1] for item in candidates)
    winners = [item for item in candidates if item["period"][0] * item["period"][1] == minimum_area]
    predictions = {item["prediction"] for item in winners}
    if len(predictions) != 1:
        raise Inapplicable("periodic reconstruction is ambiguous")
    return next(item for item in winners if item["prediction"] == next(iter(predictions)))


@dataclass(frozen=True)
class PeriodicHoleRecoveryProgram:
    kind: str = "periodic_hole_recovery"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        return _periodic_hole_analysis(value)

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "period": list(analysis["period"]),
                "hole": list(analysis["hole"]),
                "witnessed_residues": analysis["witnessed_residues"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "MissingRectangle", "type": "Grid -> Region"},
                {"name": "PeriodicResidueMap", "type": "ObservedCells -> ColourMap"},
                {"name": "HoleReconstruction", "type": "ColourMap × Region -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "FindHole", "effect": "bind the sole rectangular zero region"},
                {"index": 2, "definition": "InferPeriod", "effect": "derive the smallest conflict-free residue map"},
                {"index": 3, "definition": "ReconstructHole", "effect": "project witnessed colours into the missing region"},
            ],
            corollary="the periodic law determines the missing patch",
            common_notions=[{"name": "periodic_hole_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, validation.
# ---------------------------------------------------------------------------


def _candidate_programs(allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    result = []
    if allowed is None or "learned_component_feature_selector" in allowed:
        for candidate_mode in ("monochrome_components", "colour_classes"):
            for background_rule in ("zero", "modal"):
                for connectivity in (4, 8):
                    for feature in SAFE_COMPONENT_FEATURES:
                        for comparison in SAFE_COMPARISONS:
                            result.append(LearnedComponentFeatureSelectorProgram(
                                candidate_mode, background_rule, connectivity, feature, comparison
                            ))
    if allowed is None or "lattice_cell_feature_selector" in allowed:
        for feature in LATTICE_FEATURES:
            for comparison in LATTICE_COMPARISONS:
                result.append(LatticeCellFeatureSelectorProgram(feature, comparison))
    if allowed is None or "homologous_anchor_pair_window" in allowed:
        result.extend(HomologousAnchorPairWindowProgram(pad) for pad in (0, 1, 2))
    if allowed is None or "dihedral_tile_seed_extraction" in allowed:
        result.append(DihedralTileSeedExtractionProgram())
    if allowed is None or "periodic_hole_recovery" in allowed:
        result.append(PeriodicHoleRecoveryProgram())
    return tuple(result)


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, LearnedComponentFeatureSelectorProgram):
        winner = analysis["winner"]
        return _bbox(winner["cells"]), winner["colour"], str(analysis["values"][analysis["winner_index"]])
    if isinstance(program, LatticeCellFeatureSelectorProgram):
        return analysis["winner"]["position"], analysis["separator"], str(analysis["values"][analysis["winner_index"]])
    if isinstance(program, HomologousAnchorPairWindowProgram):
        return analysis["window"], analysis["colour"], analysis["length"]
    if isinstance(program, DihedralTileSeedExtractionProgram):
        return analysis["tile_shape"], analysis["tile_count"], analysis["distinct_tiles"]
    if isinstance(program, PeriodicHoleRecoveryProgram):
        return analysis["hole"], analysis["period"]
    raise Inapplicable("unknown programme")


def _is_subgrid(target: Grid, source: Grid) -> bool:
    target = grid(target)
    source = grid(source)
    th, tw = _shape(target)
    sh, sw = _shape(source)
    if th > sh or tw > sw:
        return False
    return any(
        all(source[r0 + r][c0 + c] == target[r][c] for r in range(th) for c in range(tw))
        for r0 in range(sh - th + 1)
        for c0 in range(sw - tw + 1)
    )


def _dihedral_output_affordance(source: Grid, target: Grid) -> bool:
    source = grid(source)
    target = grid(target)
    sh, sw = _shape(source)
    th, tw = _shape(target)
    return (
        sh % th == 0
        and sw % tw == 0
        and (sh // th) * (sw // tw) >= 4
        and tuple(tuple(source[r][c] for c in range(tw)) for r in range(th)) == target
    )


def _periodic_output_affordance(source: Grid, target: Grid) -> bool:
    try:
        r0, c0, r1, c1 = _zero_rectangle(source)
    except Inapplicable:
        return False
    return _shape(target) == (r1 - r0 + 1, c1 - c0 + 1)


def fit_learned_feature_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    """Fit V122 programmes with shared per-scene analyses and affordance gates."""
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    selected = []
    crop_affordance = all(_is_subgrid(target, source) for source, target in pairs)
    dihedral_affordance = all(_dihedral_output_affordance(source, target) for source, target in pairs)
    periodic_affordance = all(_periodic_output_affordance(source, target) for source, target in pairs)

    if crop_affordance and (allowed is None or "learned_component_feature_selector" in allowed):
        for candidate_mode in ("monochrome_components", "colour_classes"):
            for background_rule in ("zero", "modal"):
                for connectivity in (4, 8):
                    try:
                        evidence = [
                            _component_candidates(
                                source,
                                candidate_mode=candidate_mode,
                                background_rule=background_rule,
                                connectivity=connectivity,
                            )
                            for source, _ in pairs
                        ]
                    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                        continue
                    for feature in SAFE_COMPONENT_FEATURES:
                        for comparison in SAFE_COMPARISONS:
                            signatures = []
                            exact = True
                            for (source, target), (_, candidates) in zip(pairs, evidence):
                                try:
                                    values = [item["features"][feature] for item in candidates]
                                    winner_index = _select_index(values, comparison)
                                    winner = candidates[winner_index]
                                except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
                                    exact = False
                                    break
                                if winner["crop"] != target:
                                    exact = False
                                    break
                                signatures.append((_bbox(winner["cells"]), winner["colour"], str(values[winner_index])))
                            if not exact:
                                continue
                            if require_role_variation and len({_serial(signature) for signature in signatures}) < 2:
                                continue
                            selected.append(LearnedComponentFeatureSelectorProgram(
                                candidate_mode, background_rule, connectivity, feature, comparison
                            ))

    if crop_affordance and (allowed is None or "lattice_cell_feature_selector" in allowed):
        try:
            decomposition_evidence = [_lattice_decompositions(source) for source, _ in pairs]
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            decomposition_evidence = []
        for feature in LATTICE_FEATURES:
            for comparison in LATTICE_COMPARISONS:
                signatures = []
                exact = bool(decomposition_evidence)
                for (source, target), decompositions in zip(pairs, decomposition_evidence):
                    predictions = []
                    analyses = []
                    for decomposition in decompositions:
                        values = [cell["features"][feature] for cell in decomposition["cells"]]
                        try:
                            winner_index = _lattice_select_index(values, comparison)
                        except Inapplicable:
                            continue
                        winner = decomposition["cells"][winner_index]
                        predictions.append(winner["crop"])
                        analyses.append((decomposition, values, winner_index, winner))
                    unique_predictions = set(predictions)
                    if len(unique_predictions) != 1:
                        exact = False
                        break
                    prediction = next(iter(unique_predictions))
                    if prediction != target:
                        exact = False
                        break
                    decomposition, values, winner_index, winner = next(
                        analysis for analysis in analyses if analysis[3]["crop"] == prediction
                    )
                    signatures.append((winner["position"], decomposition["separator"], str(values[winner_index])))
                if not exact:
                    continue
                if require_role_variation and len({_serial(signature) for signature in signatures}) < 2:
                    continue
                selected.append(LatticeCellFeatureSelectorProgram(feature, comparison))

    remaining_kinds = set()
    if crop_affordance:
        remaining_kinds.add("homologous_anchor_pair_window")
    if dihedral_affordance:
        remaining_kinds.add("dihedral_tile_seed_extraction")
    if periodic_affordance:
        remaining_kinds.add("periodic_hole_recovery")
    if allowed is not None:
        remaining_kinds &= allowed
    for program in _candidate_programs(remaining_kinds):
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            selected.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_learned_features(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_learned_feature_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        groups[predictions].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:50] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "learned_counterfactual_feature_induction": True,
            "positional_features_allowed": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "learned_component_feature_selector":
        return LearnedComponentFeatureSelectorProgram(
            str(parameters["candidate_mode"]),
            str(parameters["background_rule"]),
            int(parameters["connectivity"]),
            str(parameters["feature"]),
            str(parameters["comparison"]),
        )
    if kind == "lattice_cell_feature_selector":
        return LatticeCellFeatureSelectorProgram(str(parameters["feature"]), str(parameters["comparison"]))
    if kind == "homologous_anchor_pair_window":
        return HomologousAnchorPairWindowProgram(int(parameters["pad"]))
    if kind == "dihedral_tile_seed_extraction":
        return DihedralTileSeedExtractionProgram()
    if kind == "periodic_hole_recovery":
        return PeriodicHoleRecoveryProgram()
    raise Inapplicable("unknown learned-feature schema")


def _counterfactual_result(kind, rows):
    passed = all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _component_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        old = analysis["winner"]["colour"]
        fresh = _fresh_colour(source, (old,))
        recoloured = _replace_colour(source, old, fresh)
        expected = _replace_colour(original, old, fresh)
        try:
            colour_equivariant = program.predict(recoloured) == expected
        except Inapplicable:
            colour_equivariant = False
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False
        cause_necessary = False
        winner_cells = list(analysis["winner"]["cells"])
        for count in range(1, min(len(winner_cells), 4) + 1):
            modified = _array(source)
            for r, c in winner_cells[:count]:
                modified[r][c] = analysis["background"]
            try:
                changed = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                changed = True
            if changed:
                cause_necessary = True
                break
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "rotation_equivariant": rotation_equivariant,
            "cause_necessary": cause_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _lattice_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False

        # Test separator identity under a legal ARC colour permutation.  A swap
        # remains available even when all ten colours already occur.
        separator = analysis["separator"]
        alternatives = [colour for colour in sorted(_palette(source)) if colour != separator]
        separator_identity_invariant = False
        if alternatives:
            other = alternatives[0]
            def swap(value):
                return tuple(tuple(
                    other if cell == separator else separator if cell == other else cell
                    for cell in row
                ) for row in grid(value))
            try:
                separator_identity_invariant = program.predict(swap(source)) == swap(original)
            except Inapplicable:
                separator_identity_invariant = False

        # Perturb the selected logical cell using an in-palette colour that is
        # absent from that cell; if none exists, remove one foreground cell.
        cause_necessary = False
        winner = analysis["winner"]
        row_group = analysis["row_groups"][winner["position"][0]]
        col_group = analysis["col_groups"][winner["position"][1]]
        modified = _array(source)
        winner_palette = _palette(winner["crop"])
        replacement = next((colour for colour in range(10) if colour not in winner_palette), None)
        changed_cell = None
        if replacement is not None:
            for r in row_group:
                for c in col_group:
                    if source[r][c] == winner["background"]:
                        changed_cell = (r, c)
                        break
                if changed_cell:
                    break
            if changed_cell:
                modified[changed_cell[0]][changed_cell[1]] = replacement
        else:
            for r in row_group:
                for c in col_group:
                    if source[r][c] != winner["background"]:
                        changed_cell = (r, c)
                        modified[r][c] = winner["background"]
                        break
                if changed_cell:
                    break
        if changed_cell:
            try:
                cause_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                cause_necessary = True
        rows.append({
            "demonstration": index,
            "separator_identity_invariant": separator_identity_invariant,
            "rotation_equivariant": rotation_equivariant,
            "cause_necessary": cause_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _anchor_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        modified = _array(source)
        r, c = analysis["members"][0][0]
        replacement = next((colour for colour in sorted(_palette(source)) if colour != analysis["colour"]), 0)
        modified[r][c] = replacement
        try:
            anchor_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            anchor_necessary = True
        fresh = _fresh_colour(source, (analysis["colour"],))
        recoloured = _replace_colour(source, analysis["colour"], fresh)
        expected = _replace_colour(original, analysis["colour"], fresh)
        try:
            colour_equivariant = program.predict(recoloured) == expected
        except Inapplicable:
            colour_equivariant = False
        try:
            rotation_equivariant = program.predict(_rotate90(source)) == _rotate90(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "anchor_necessary": anchor_necessary,
            "colour_equivariant": colour_equivariant,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _tile_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        tile_h, tile_w = analysis["tile_shape"]
        modified = _array(source)
        target_r = 0
        target_c = tile_w if tile_w < len(source[0]) else 0
        fresh = _fresh_colour(source)
        modified[target_r][target_c] = fresh
        try:
            orbit_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            orbit_necessary = True
        old = original[0][0]
        fresh2 = _fresh_colour(source, (fresh, old))
        recoloured = _replace_colour(source, old, fresh2)
        expected = _replace_colour(original, old, fresh2)
        try:
            colour_equivariant = program.predict(recoloured) == expected
        except Inapplicable:
            colour_equivariant = False
        rows.append({
            "demonstration": index,
            "orbit_necessary": orbit_necessary,
            "colour_equivariant": colour_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _periodic_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        r0, c0, _, _ = analysis["hole"]
        modified = _array(source)
        modified[r0][c0] = original[0][0]
        try:
            hole_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            hole_necessary = True
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "hole_necessary": hole_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_validation(program, pairs):
    if isinstance(program, LearnedComponentFeatureSelectorProgram):
        return _component_counterfactuals(program, pairs)
    if isinstance(program, LatticeCellFeatureSelectorProgram):
        return _lattice_counterfactuals(program, pairs)
    if isinstance(program, HomologousAnchorPairWindowProgram):
        return _anchor_counterfactuals(program, pairs)
    if isinstance(program, DihedralTileSeedExtractionProgram):
        return _tile_counterfactuals(program, pairs)
    if isinstance(program, PeriodicHoleRecoveryProgram):
        return _periodic_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_learned_features(task, full):
    """Validate a unique full-data prediction by held-demonstration refitting.

    Each fold fits programmes on the remaining demonstrations only.  The held
    output is then used strictly as validation evidence: programmes that miss
    the held example are rejected, and every held-exact programme must agree on
    the frozen unseen-test prediction.  This is stronger and more informative
    than rejecting a fold merely because the reduced training set admits extra
    hypotheses that fail the held example.
    """
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (item["input"], item["output"])
            for index, item in enumerate(clean["train"])
            if index != held
        )
        refitted = fit_learned_feature_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(demonstration["input"]) != grid(demonstration["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, test_predictions in held_exact:
            groups[test_predictions].append(program.schema_key)
        expected_tuple = tuple(grid(prediction) for prediction in expected)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def learned_feature_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_learned_feature_programs(pairs)}))


infer = infer_learned_features
validate = validate_learned_features
