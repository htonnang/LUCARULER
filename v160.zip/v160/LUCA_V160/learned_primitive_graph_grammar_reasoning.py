"""LUCA V145: learned primitive graph grammar and bounded three-stage search.

The family anti-unifies nine ARC transformations under three shared operators:

    scene -> typed nodes -> typed edges -> bounded relation chain
          -> shared consequence operator -> deterministic full grid -> proof

Runtime inference is task-ID blind and test-target blind.  Colours, centres,
directions, ownership, code maps, and output roles are inferred from the
training demonstrations and the current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_learned_primitive_graph_grammar"
LANGUAGE = "spinoza_learned_primitive_graph_grammar_v145"
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Shared evidence language and structural helpers.
# ---------------------------------------------------------------------------


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "learned_primitive_graph_grammar": True,
            "bounded_three_stage_relation_chain": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, *, colour=None, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    background = _mode(value)
    if connectivity == 4:
        directions = ((-1, 0), (1, 0), (0, -1), (0, 1))
    else:
        directions = tuple(
            (dr, dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr, dc) != (0, 0)
        )
    seen = set()
    output = []
    for r in range(h):
        for c in range(w):
            cell_colour = value[r][c]
            if cell_colour == background or (colour is not None and cell_colour != colour) or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w) or (nr, nc) in seen:
                        continue
                    if value[nr][nc] == cell_colour:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append({"colour": cell_colour, "cells": frozenset(cells), "bbox": _bbox(cells)})
    return output


def _filled_rectangle(cells):
    cells = frozenset(cells)
    r0, c0, r1, c1 = _bbox(cells)
    return cells == frozenset((r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1))


def _perimeter_rectangle(cells):
    cells = frozenset(cells)
    r0, c0, r1, c1 = _bbox(cells)
    perimeter = frozenset(
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    )
    return cells == perimeter


def _diagonal_ray(origin, direction, h, w):
    dr, dc = direction
    r, c = origin[0] + dr, origin[1] + dc
    output = []
    while 0 <= r < h and 0 <= c < w:
        output.append((r, c))
        r += dr
        c += dc
    return tuple(output)


def _sign(value):
    return -1 if value < 0 else 1 if value > 0 else 0


def _rotate90(cell, centre2):
    r, c = cell
    cr2, cc2 = centre2
    rr2 = cr2 + cc2 - 2 * c
    cc2 = cc2 - cr2 + 2 * r
    if rr2 % 2 or cc2 % 2:
        raise Inapplicable("rotation does not map cells to cells")
    return rr2 // 2, cc2 // 2


# ---------------------------------------------------------------------------
# Shared operator I: D4-equivariant diagonal ray emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CoreBranchDiagonalExtensionProgram:
    kind = "core_branch_diagonal_extension"
    operator = "d4_diagonal_ray_emission"
    node_vocabulary = "corner_branch_and_frame_nodes"
    edge_vocabulary = "outward_diagonal_successor_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) != 1:
            raise Inapplicable("one semantic foreground colour required")
        colour = colours[0]
        cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
        blocks = []
        for r in range(h - 1):
            for c in range(w - 1):
                block = {(r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1)}
                if block <= cells:
                    blocks.append((r, c, block))
        candidates = []
        for r0, c0, block in blocks:
            branches = []
            corner_directions = (
                ((r0, c0), (-1, -1)),
                ((r0, c0 + 1), (-1, 1)),
                ((r0 + 1, c0), (1, -1)),
                ((r0 + 1, c0 + 1), (1, 1)),
            )
            explained = set(block)
            for corner, direction in corner_directions:
                ray = _diagonal_ray(corner, direction, h, w)
                prefix = []
                for cell in ray:
                    if cell in cells:
                        prefix.append(cell)
                    else:
                        break
                if prefix:
                    branches.append((corner, direction, ray))
                    explained.update(prefix)
            if branches and explained == cells:
                candidates.append((block, branches))
        if len(candidates) != 1:
            raise Inapplicable("unique 2x2 core with seeded diagonal branches required")
        _, branches = candidates[0]
        output = _array(value)
        for _, _, ray in branches:
            for r, c in ray:
                if output[r][c] not in (background, colour):
                    raise Inapplicable("diagonal branch collision")
                output[r][c] = colour
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no continuation")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="one 2x2 semantic core with one or more witnessed diagonal branch seeds",
            relation_chain=(
                "bind each seed to its unique core corner",
                "infer the outward D4 diagonal successor",
                "continue every witnessed branch to the canvas boundary",
            ),
            parameters={},
            corollary="Extend every seeded corner branch along its D4-equivariant diagonal until the boundary.",
            notions=["2x2 core", "corner role", "diagonal successor", "boundary termination"],
        )


@dataclass(frozen=True)
class FramePayloadDiagonalProjectionProgram:
    kind = "frame_payload_diagonal_projection"
    operator = "d4_diagonal_ray_emission"
    node_vocabulary = "corner_branch_and_frame_nodes"
    edge_vocabulary = "outward_diagonal_successor_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        components = _components(value)
        if len(components) != 2:
            raise Inapplicable("one frame and one payload component required")
        payload_candidates = [component for component in components if _filled_rectangle(component["cells"])]
        support_candidates = []
        for component in components:
            cells = component["cells"]
            if len(cells) < 4:
                continue
            degrees = {}
            for r, c in cells:
                neighbours = [(r + dr, c + dc) for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)) if (r + dr, c + dc) in cells]
                degrees[(r, c)] = neighbours
            if max(map(len, degrees.values()), default=0) > 2:
                continue
            bends = []
            for cell, neighbours in degrees.items():
                if len(neighbours) != 2:
                    continue
                (r1, c1), (r2, c2) = neighbours
                if r1 != r2 and c1 != c2:
                    bends.append(cell)
            if 1 <= len(bends) <= 2:
                support_candidates.append((component, tuple(sorted(bends))))
        pairs_found = []
        for payload in payload_candidates:
            for support, bends in support_candidates:
                if payload is support or payload["colour"] == support["colour"]:
                    continue
                pr0, pc0, pr1, pc1 = payload["bbox"]
                pr2, pc2 = pr0 + pr1, pc0 + pc1
                rays = []
                valid = True
                for bend in bends:
                    dr = _sign(2 * bend[0] - pr2)
                    dc = _sign(2 * bend[1] - pc2)
                    if dr == 0 or dc == 0:
                        valid = False
                        break
                    ray = _diagonal_ray(bend, (dr, dc), h, w)
                    if not ray:
                        valid = False
                        break
                    rays.append(ray)
                if valid:
                    pairs_found.append((payload, support, rays))
        if len(pairs_found) != 1:
            raise Inapplicable("unique frame/payload relation required")
        payload, _, rays = pairs_found[0]
        output = _array(value)
        for ray in rays:
            for r, c in ray:
                if output[r][c] not in (background, payload["colour"]):
                    raise Inapplicable("projected diagonal collision")
                output[r][c] = payload["colour"]
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no projected ray")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="one rectilinear L/U support and one filled payload rectangle",
            relation_chain=(
                "identify every support bend relative to the payload centre",
                "select the diagonally opposite D4 direction",
                "project the payload colour from each bend to the boundary",
            ),
            parameters={},
            corollary="Emit payload-coloured rays diagonally outward from every support bend opposite the payload.",
            notions=["support bend", "payload centre", "opposite quadrant", "D4 projection"],
        )


@dataclass(frozen=True)
class ColourDirectedBlockDiagonalProjectionProgram:
    direction_map: tuple

    kind = "colour_directed_block_diagonal_projection"
    operator = "d4_diagonal_ray_emission"
    node_vocabulary = "corner_branch_and_frame_nodes"
    edge_vocabulary = "outward_diagonal_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.direction_map

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        mapping = dict(self.direction_map)
        components = _components(value)
        if len(components) != len(mapping):
            raise Inapplicable("one 2x2 block per learned colour required")
        by_colour = {}
        for component in components:
            if component["colour"] in by_colour:
                raise Inapplicable("one component per learned colour required")
            if len(component["cells"]) != 4 or not _filled_rectangle(component["cells"]):
                raise Inapplicable("solid 2x2 blocks required")
            r0, c0, r1, c1 = component["bbox"]
            if (r1 - r0, c1 - c0) != (1, 1):
                raise Inapplicable("solid 2x2 blocks required")
            by_colour[component["colour"]] = component
        if set(by_colour) != set(mapping):
            raise Inapplicable("learned semantic colours missing")
        output = _array(value)
        for colour, direction in mapping.items():
            component = by_colour[colour]
            r0, c0, r1, c1 = component["bbox"]
            dr, dc = direction
            origin = (r0 if dr < 0 else r1, c0 if dc < 0 else c1)
            for r, c in _diagonal_ray(origin, direction, h, w):
                if output[r][c] not in (background, colour):
                    raise Inapplicable("semantic diagonal collision")
                output[r][c] = colour
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no semantic diagonal continuation")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="two semantic 2x2 blocks whose colours witness stable diagonal roles",
            relation_chain=(
                "bind each colour to its demonstrated diagonal role",
                "select the corresponding block corner",
                "continue the colour-labelled diagonal to the boundary",
            ),
            parameters={"direction_map": [[colour, list(direction)] for colour, direction in self.direction_map]},
            corollary="Project each semantic block colour along its learned D4 diagonal role.",
            notions=["semantic colour role", "2x2 block", "corner selection", "diagonal ray"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: axis-role projection and ownership.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AlignedMarkerBlockConnectorProgram:
    kind = "aligned_marker_block_connector"
    operator = "axis_role_projection"
    node_vocabulary = "anchor_marker_and_boundary_nodes"
    edge_vocabulary = "alignment_and_ownership_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        components = _components(value)
        anchors = []
        singleton_markers = []
        for component in components:
            if len(component["cells"]) == 4 and _filled_rectangle(component["cells"]):
                r0, c0, r1, c1 = component["bbox"]
                if (r1 - r0, c1 - c0) == (1, 1):
                    anchors.append(component)
                    continue
            if len(component["cells"]) == 1:
                singleton_markers.append(component)
                continue
            raise Inapplicable("one 2x2 anchor and singleton markers required")
        if len(anchors) != 1 or len(singleton_markers) < 2:
            raise Inapplicable("unique 2x2 anchor required")
        anchor = anchors[0]
        r0, c0, r1, c1 = anchor["bbox"]
        output = _array(value)
        connected = 0
        for marker in singleton_markers:
            (r, c), = marker["cells"]
            paths = []
            if r in (r0, r1):
                target_c = c0 if c < c0 else c1 if c > c1 else None
                if target_c is not None:
                    step = 1 if target_c > c else -1
                    paths.append(tuple((r, cc) for cc in range(c + step, target_c, step)))
            if c in (c0, c1):
                target_r = r0 if r < r0 else r1 if r > r1 else None
                if target_r is not None:
                    step = 1 if target_r > r else -1
                    paths.append(tuple((rr, c) for rr in range(r + step, target_r, step)))
            if len(paths) > 1:
                raise Inapplicable("marker alignment ambiguous")
            if paths:
                for rr, cc in paths[0]:
                    if output[rr][cc] != background:
                        raise Inapplicable("connector collision")
                    output[rr][cc] = marker["colour"]
                connected += 1
        if not connected:
            raise Inapplicable("no aligned marker")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one 2x2 anchor block and several coloured singleton markers",
            relation_chain=(
                "select markers sharing an anchor boundary row or column",
                "derive the unique incidence edge to the nearest anchor side",
                "materialise the intervening axis cells in the marker colour",
            ),
            parameters={},
            corollary="Connect every axis-aligned marker to the anchor block while leaving unaligned markers unchanged.",
            notions=["anchor block", "singleton marker", "axis incidence", "nearest anchor side"],
        )


@dataclass(frozen=True)
class NearestBoundaryOwnershipProjectionProgram:
    kind = "nearest_boundary_ownership_projection"
    operator = "axis_role_projection"
    node_vocabulary = "anchor_marker_and_boundary_nodes"
    edge_vocabulary = "alignment_and_ownership_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        full_rows = [
            (r, value[r][0])
            for r in range(h)
            if len(set(value[r])) == 1 and value[r][0] != background
        ]
        full_cols = [
            (c, value[0][c])
            for c in range(w)
            if len({value[r][c] for r in range(h)}) == 1 and value[0][c] != background
        ]
        orientation = None
        if len(full_rows) == 2 and {row for row, _ in full_rows} == {0, h - 1} and not full_cols:
            orientation = "vertical"
            boundaries = sorted(full_rows)
        elif len(full_cols) == 2 and {col for col, _ in full_cols} == {0, w - 1} and not full_rows:
            orientation = "horizontal"
            boundaries = sorted(full_cols)
        else:
            raise Inapplicable("two opposite full coloured boundaries required")
        if boundaries[0][1] == boundaries[1][1]:
            raise Inapplicable("boundary roles must have different colours")
        boundary_colours = {boundaries[0][1], boundaries[1][1]}
        marker_cells = []
        marker_colours = set()
        for r in range(h):
            for c in range(w):
                colour = value[r][c]
                if colour == background or colour in boundary_colours:
                    continue
                marker_cells.append((r, c, colour))
                marker_colours.add(colour)
        if len(marker_colours) != 1 or len(marker_cells) < 2:
            raise Inapplicable("one repeated marker colour required")
        if any(len(component["cells"]) != 1 for component in _components(value) if component["colour"] in marker_colours):
            raise Inapplicable("markers must be singletons")
        output = _array(value)
        for r, c, _ in marker_cells:
            if orientation == "vertical":
                d0, d1 = r, h - 1 - r
                if d0 == d1:
                    raise Inapplicable("boundary ownership tie")
                if d0 < d1:
                    rr, cc, colour = r - 1, c, boundaries[0][1]
                else:
                    rr, cc, colour = r + 1, c, boundaries[1][1]
            else:
                d0, d1 = c, w - 1 - c
                if d0 == d1:
                    raise Inapplicable("boundary ownership tie")
                if d0 < d1:
                    rr, cc, colour = r, c - 1, boundaries[0][1]
                else:
                    rr, cc, colour = r, c + 1, boundaries[1][1]
            if not (0 <= rr < h and 0 <= cc < w) or output[rr][cc] != background:
                raise Inapplicable("owned projection cell unavailable")
            output[rr][cc] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="two opposite coloured boundaries and one repeated singleton marker role",
            relation_chain=(
                "compare each marker's distance to the two boundaries",
                "assign strict ownership to the nearer boundary",
                "project one boundary-coloured cell toward the owner",
            ),
            parameters={},
            corollary="Annotate every marker with one cell pointing toward its uniquely nearest coloured boundary.",
            notions=["boundary role", "distance", "strict ownership", "one-step projection"],
        )


@dataclass(frozen=True)
class BarLengthCodeProjectionProgram:
    marker_side: str
    length_code: tuple

    kind = "bar_length_code_projection"
    operator = "axis_role_projection"
    node_vocabulary = "anchor_marker_and_boundary_nodes"
    edge_vocabulary = "alignment_and_ownership_edges"

    @property
    def schema_key(self):
        return self.kind, self.marker_side, self.length_code

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        rows = value if self.marker_side == "top" else tuple(reversed(value))
        marker_cells = [(c, colour) for c, colour in enumerate(rows[0]) if colour != background]
        if len(marker_cells) != 1:
            raise Inapplicable("one boundary marker required")
        marker_col, _ = marker_cells[0]
        mapping = dict(self.length_code)
        output = [list(row) for row in rows]
        bars = 0
        for r in range(1, h):
            nonbackground = [c for c, colour in enumerate(rows[r]) if colour != background]
            if not nonbackground:
                continue
            start, end = min(nonbackground), max(nonbackground)
            if nonbackground != list(range(start, end + 1)):
                raise Inapplicable("one contiguous horizontal bar per active row required")
            if marker_col in nonbackground:
                raise Inapplicable("bar overlaps marker axis")
            length = end - start + 1
            if length not in mapping:
                raise Inapplicable("unwitnessed bar length")
            if output[r][marker_col] != background:
                raise Inapplicable("code cell occupied")
            output[r][marker_col] = mapping[length]
            bars += 1
        if not bars:
            raise Inapplicable("no data bars")
        predicted = grid(output)
        return predicted if self.marker_side == "top" else grid(reversed(predicted))

    def describe(self, pairs):
        return _law(
            self,
            scene="one boundary marker axis and several horizontal data bars",
            relation_chain=(
                "measure each bar's witnessed run length",
                "look up the demonstration-induced semantic code",
                "project the code onto the marker axis",
            ),
            parameters={"marker_side": self.marker_side, "length_code": [list(item) for item in self.length_code]},
            corollary="Write one learned code cell on the marker axis for every contiguous data bar.",
            notions=["marker axis", "bar length", "semantic code", "axis projection"],
        )


# ---------------------------------------------------------------------------
# Shared operator III: D4 orbit materialisation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MinimalRotationalOrbitCompletionProgram:
    kind = "minimal_rotational_orbit_completion"
    operator = "d4_orbit_materialisation"
    node_vocabulary = "symmetry_anchor_and_square_nodes"
    edge_vocabulary = "d4_orbit_and_corner_adjacency_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    @staticmethod
    def _closure(value: Grid, centre2):
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        assignments = {}
        for r in range(h):
            for c in range(w):
                colour = value[r][c]
                if colour == background:
                    continue
                cell = (r, c)
                for _ in range(4):
                    rr, cc = cell
                    if not (0 <= rr < h and 0 <= cc < w):
                        raise Inapplicable("rotational orbit leaves the canvas")
                    previous = assignments.get(cell)
                    if previous is not None and previous != colour:
                        raise Inapplicable("rotational colour conflict")
                    assignments[cell] = colour
                    cell = _rotate90(cell, centre2)
        output = _array(value)
        for (r, c), colour in assignments.items():
            if output[r][c] not in (background, colour):
                raise Inapplicable("rotational orbit collision")
            output[r][c] = colour
        return grid(output)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        candidates = defaultdict(list)
        for cr2 in range(2 * h - 1):
            for cc2 in range(2 * w - 1):
                try:
                    predicted = self._closure(value, (cr2, cc2))
                except Inapplicable:
                    continue
                additions = sum(
                    predicted[r][c] != value[r][c]
                    for r in range(h)
                    for c in range(w)
                )
                if additions:
                    candidates[additions].append((predicted, (cr2, cc2)))
        if not candidates:
            raise Inapplicable("no nontrivial rotational closure")
        minimum = min(candidates)
        outputs = {item[0] for item in candidates[minimum]}
        if len(outputs) != 1:
            raise Inapplicable("minimum rotational closure not unique")
        return next(iter(outputs))

    def describe(self, pairs):
        return _law(
            self,
            scene="a partial multicolour pattern admitting one minimal fourfold rotational closure",
            relation_chain=(
                "enumerate cell-preserving quarter-turn centres",
                "reject colour conflicts and out-of-canvas orbits",
                "select the unique closure requiring the fewest new cells",
            ),
            parameters={},
            corollary="Complete the unique minimum-addition C4 orbit of the observed pattern.",
            notions=["quarter turn", "orbit", "colour consistency", "minimum closure"],
        )


@dataclass(frozen=True)
class SquareCornerWhiskerProgram:
    whisker_colour: int

    kind = "square_corner_whisker_materialisation"
    operator = "d4_orbit_materialisation"
    node_vocabulary = "symmetry_anchor_and_square_nodes"
    edge_vocabulary = "d4_orbit_and_corner_adjacency_edges"

    @property
    def schema_key(self):
        return self.kind, self.whisker_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        output = _array(value)
        selected = 0
        for component in _components(value):
            r0, c0, r1, c1 = component["bbox"]
            height, width = r1 - r0 + 1, c1 - c0 + 1
            if height != width or height < 2:
                continue
            if not (_filled_rectangle(component["cells"]) or _perimeter_rectangle(component["cells"])):
                continue
            selected += 1
            candidates = (
                (r0 - 1, c0), (r0, c0 - 1),
                (r0 - 1, c1), (r0, c1 + 1),
                (r1, c0 - 1), (r1 + 1, c0),
                (r1, c1 + 1), (r1 + 1, c1),
            )
            for r, c in candidates:
                if not (0 <= r < h and 0 <= c < w):
                    continue
                if output[r][c] == background:
                    output[r][c] = self.whisker_colour
                elif output[r][c] != self.whisker_colour:
                    raise Inapplicable("corner whisker collision")
        if not selected:
            raise Inapplicable("no square frame or filled square")
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no corner whiskers added")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more square frames or filled square components",
            relation_chain=(
                "bind every square bounding-box corner",
                "derive the two outward orthogonal adjacency edges",
                "materialise the complete D4 corner-whisker orbit",
            ),
            parameters={"whisker_colour": self.whisker_colour},
            corollary="Place the semantic whisker colour immediately outside both axes of every square corner.",
            notions=["square component", "bounding-box corner", "orthogonal adjacency", "D4 orbit"],
        )


@dataclass(frozen=True)
class SemanticSingletonStencilProgram:
    stencil_map: tuple

    kind = "semantic_singleton_stencil_materialisation"
    operator = "d4_orbit_materialisation"
    node_vocabulary = "symmetry_anchor_and_square_nodes"
    edge_vocabulary = "d4_orbit_and_corner_adjacency_edges"

    @property
    def schema_key(self):
        return self.kind, self.stencil_map

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        components = _components(value)
        if not components or any(len(component["cells"]) != 1 for component in components):
            raise Inapplicable("all semantic objects must be singletons")
        mapping = {colour: (shape, emit) for colour, shape, emit in self.stencil_map}
        output = _array(value)
        acted = 0
        offsets = {
            "plus": ((-1, 0), (1, 0), (0, -1), (0, 1)),
            "diagonal": ((-1, -1), (-1, 1), (1, -1), (1, 1)),
        }
        claims = {}
        for component in components:
            colour = component["colour"]
            if colour not in mapping:
                continue
            shape, emit = mapping[colour]
            (r, c), = component["cells"]
            for dr, dc in offsets[shape]:
                rr, cc = r + dr, c + dc
                if not (0 <= rr < h and 0 <= cc < w):
                    continue
                previous = claims.get((rr, cc))
                if previous is not None and previous != emit:
                    raise Inapplicable("stencil ownership conflict")
                if value[rr][cc] not in (background, emit):
                    raise Inapplicable("stencil collides with semantic anchor")
                claims[(rr, cc)] = emit
            acted += 1
        if not acted:
            raise Inapplicable("no learned stencil role present")
        for (r, c), emit in claims.items():
            output[r][c] = emit
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no stencil materialisation")
        return predicted

    def describe(self, pairs):
        return _law(
            self,
            scene="isolated semantic singleton anchors with demonstrated local D4 stencils",
            relation_chain=(
                "bind each acting anchor colour to a plus or diagonal orbit",
                "infer the semantic emission colour",
                "materialise every in-bounds orbit under collision consensus",
            ),
            parameters={"stencil_map": [list(item) for item in self.stencil_map]},
            corollary="Emit the learned local D4 stencil around every semantic singleton anchor.",
            notions=["singleton role", "plus orbit", "diagonal orbit", "collision consensus"],
        )



@dataclass(frozen=True)
class PedestalDiagonalProjectionProgram:
    kind = "pedestal_diagonal_projection"
    operator = "d4_diagonal_ray_emission"
    node_vocabulary = "corner_branch_and_frame_nodes"
    edge_vocabulary = "outward_diagonal_successor_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    @staticmethod
    def _rotate(value: Grid):
        value = grid(value)
        h, w = _shape(value)
        return grid(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))

    @classmethod
    def _canonical_prediction(cls, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        if h < 3 or w < 3:
            raise Inapplicable("pedestal canvas too small")
        active_rows = [r for r, row in enumerate(value) if any(cell != background for cell in row)]
        if active_rows != [h - 2, h - 1]:
            raise Inapplicable("two-row boundary pedestal required")
        bottom = value[h - 1]
        if any(cell == background for cell in bottom):
            raise Inapplicable("pedestal boundary must be complete")
        upper_active = [c for c, cell in enumerate(value[h - 2]) if cell != background]
        if not upper_active or upper_active != list(range(min(upper_active), max(upper_active) + 1)):
            raise Inapplicable("one contiguous upper support required")
        left, right = min(upper_active), max(upper_active)
        support_colour = value[h - 2][left]
        if any(value[h - 2][c] != support_colour for c in upper_active):
            raise Inapplicable("upper support must be monochrome")
        payload_colour = bottom[left]
        if payload_colour in (background, support_colour):
            raise Inapplicable("distinct payload colour required")
        if any(bottom[c] != payload_colour for c in range(left, right + 1)):
            raise Inapplicable("payload interval must match the upper support")
        if any(bottom[c] != support_colour for c in list(range(0, left)) + list(range(right + 1, w))):
            raise Inapplicable("support colour must own the boundary flanks")
        output = _array(value)
        for origin, direction in (((h - 2, left), (-1, -1)), ((h - 2, right), (-1, 1))):
            for r, c in _diagonal_ray(origin, direction, h, w):
                if output[r][c] not in (background, payload_colour):
                    raise Inapplicable("pedestal diagonal collision")
                output[r][c] = payload_colour
        predicted = grid(output)
        if predicted == value:
            raise Inapplicable("no pedestal continuation")
        return predicted

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        candidates = []
        current = value
        for turns in range(4):
            try:
                canonical_prediction = self._canonical_prediction(current)
                predicted = canonical_prediction
                for _ in range((4 - turns) % 4):
                    predicted = self._rotate(predicted)
                candidates.append(predicted)
            except Inapplicable:
                pass
            current = self._rotate(current)
        outputs = set(candidates)
        if len(outputs) != 1:
            raise Inapplicable("unique D4 pedestal orientation required")
        return next(iter(outputs))

    def describe(self, pairs):
        return _law(
            self,
            scene="a two-colour boundary pedestal with one upper support interval",
            relation_chain=(
                "bind the payload interval beneath the support bar",
                "derive the two outward diagonal corner successors",
                "continue the payload rays to the opposite boundaries",
            ),
            parameters={},
            corollary="Project the payload colour diagonally outward from both support corners in the inferred D4 orientation.",
            notions=["boundary pedestal", "payload interval", "support corner", "D4 diagonal continuation"],
        )


@dataclass(frozen=True)
class PanelGridAxisClosureProgram:
    kind = "panel_grid_axis_closure"
    operator = "axis_role_projection"
    node_vocabulary = "anchor_marker_and_boundary_nodes"
    edge_vocabulary = "alignment_and_ownership_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        row_candidates = defaultdict(list)
        col_candidates = defaultdict(list)
        for r, row in enumerate(value):
            if len(set(row)) == 1:
                row_candidates[row[0]].append(r)
        for c in range(w):
            column = [value[r][c] for r in range(h)]
            if len(set(column)) == 1:
                col_candidates[column[0]].append(c)
        separators = [
            colour for colour in set(row_candidates) & set(col_candidates)
            if row_candidates[colour] and col_candidates[colour]
        ]
        if len(separators) != 1:
            raise Inapplicable("one shared row/column separator colour required")
        separator = separators[0]
        separator_rows = row_candidates[separator]
        separator_cols = col_candidates[separator]
        row_ranges = []
        start = 0
        for stop in separator_rows + [h]:
            if start < stop:
                row_ranges.append((start, stop - 1))
            start = stop + 1
        col_ranges = []
        start = 0
        for stop in separator_cols + [w]:
            if start < stop:
                col_ranges.append((start, stop - 1))
            start = stop + 1
        if len(row_ranges) < 2 or len(col_ranges) < 2:
            raise Inapplicable("multi-panel lattice required")
        heights = {r1 - r0 + 1 for r0, r1 in row_ranges}
        widths = {c1 - c0 + 1 for c0, c1 in col_ranges}
        if len(heights) != 1 or len(widths) != 1:
            raise Inapplicable("uniform panel dimensions required")
        panel_cells = [
            value[r][c]
            for r0, r1 in row_ranges
            for c0, c1 in col_ranges
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
        ]
        counts = Counter(panel_cells)
        base = counts.most_common(1)[0][0]
        if base == separator:
            raise Inapplicable("panel base distinct from separator required")
        markers = defaultdict(set)
        for pr, (r0, r1) in enumerate(row_ranges):
            for pc, (c0, c1) in enumerate(col_ranges):
                foreign = []
                for r in range(r0, r1 + 1):
                    for c in range(c0, c1 + 1):
                        colour = value[r][c]
                        if colour != base:
                            foreign.append((r - r0, c - c0, colour))
                for lr, lc, colour in foreign:
                    if colour == separator:
                        raise Inapplicable("separator inside panel")
                    markers[(colour, lr, lc)].add((pr, pc))
        if not markers:
            raise Inapplicable("no panel markers")
        claims = {}
        for role, positions in markers.items():
            colour, lr, lc = role
            by_row = defaultdict(list)
            by_col = defaultdict(list)
            for pr, pc in positions:
                by_row[pr].append(pc)
                by_col[pc].append(pr)
            expanded = set(positions)
            for pr, pcs in by_row.items():
                if len(pcs) >= 2:
                    expanded.update((pr, pc) for pc in range(min(pcs), max(pcs) + 1))
            for pc, prs in by_col.items():
                if len(prs) >= 2:
                    expanded.update((pr, pc) for pr in range(min(prs), max(prs) + 1))
            for pr, pc in expanded - positions:
                r0, _ = row_ranges[pr]
                c0, _ = col_ranges[pc]
                cell = (r0 + lr, c0 + lc)
                previous = claims.get(cell)
                if previous is not None and previous != colour:
                    raise Inapplicable("panel closure ownership conflict")
                claims[cell] = colour
        if not claims:
            raise Inapplicable("no axis interval closure")
        output = _array(value)
        for (r, c), colour in claims.items():
            if output[r][c] not in (base, colour):
                raise Inapplicable("panel target occupied")
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a uniform separator lattice with at most one typed marker per panel",
            relation_chain=(
                "compress markers into panel-grid coordinates and local roles",
                "close every same-role row or column interval",
                "project the marker colour back to the corresponding panel cell",
            ),
            parameters={},
            corollary="Complete all axis-aligned marker intervals in the panel lattice while preserving each marker's local coordinate.",
            notions=["separator lattice", "panel coordinate", "local marker role", "axis interval closure"],
        )

# ---------------------------------------------------------------------------
# Fitters.
# ---------------------------------------------------------------------------


def _fit_static(pairs, cls):
    programme = cls()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_colour_directed_blocks(pairs):
    first = grid(pairs[0][0])
    background = _mode(first)
    colours = sorted(_palette(first) - {background})
    if len(colours) != 2:
        return []
    if any(sorted(_palette(source) - {_mode(source)}) != colours for source, _ in pairs):
        return []
    directions = ((-1, -1), (-1, 1), (1, -1), (1, 1))
    output = []
    for assigned in product(directions, repeat=len(colours)):
        programme = ColourDirectedBlockDiagonalProjectionProgram(tuple(zip(colours, assigned)))
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_bar_length_code(pairs):
    output = []
    for side in ("top", "bottom"):
        mapping = {}
        valid = True
        for source, target in pairs:
            source = grid(source)
            target = grid(target)
            rows = source if side == "top" else tuple(reversed(source))
            target_rows = target if side == "top" else tuple(reversed(target))
            background = _mode(source)
            markers = [c for c, colour in enumerate(rows[0]) if colour != background]
            if len(markers) != 1:
                valid = False
                break
            marker_col = markers[0]
            for r in range(1, len(rows)):
                active = [c for c, colour in enumerate(rows[r]) if colour != background]
                changed = [c for c in range(len(rows[0])) if rows[r][c] != target_rows[r][c]]
                if not active:
                    if changed:
                        valid = False
                        break
                    continue
                start, end = min(active), max(active)
                if active != list(range(start, end + 1)) or marker_col in active:
                    valid = False
                    break
                if changed != [marker_col] or rows[r][marker_col] != background:
                    valid = False
                    break
                length = end - start + 1
                code = target_rows[r][marker_col]
                if code == background or (length in mapping and mapping[length] != code):
                    valid = False
                    break
                mapping[length] = code
            if not valid:
                break
        if valid and len(mapping) >= 2:
            programme = BarLengthCodeProjectionProgram(side, tuple(sorted(mapping.items())))
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return output


def _fit_square_whiskers(pairs):
    candidate_colours = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        background = _mode(source)
        changes = [target[r][c] for r in range(len(source)) for c in range(len(source[0])) if source[r][c] != target[r][c]]
        current = set(changes) - {background}
        candidate_colours = current if candidate_colours is None else candidate_colours & current
    output = []
    for colour in sorted(candidate_colours or ()): 
        programme = SquareCornerWhiskerProgram(colour)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_singleton_stencils(pairs):
    palette_sets = [set(_palette(source) - {_mode(source)}) for source, _ in pairs]
    candidate_anchors = sorted(set.intersection(*palette_sets)) if palette_sets else []
    emitted_colours = sorted(set().union(*(
        {target[r][c] for r in range(len(source)) for c in range(len(source[0])) if source[r][c] != target[r][c]}
        for source, target in pairs
    )))
    # Acting semantic colours must recur in every demonstration.  This both
    # captures the intended role vocabulary and prevents an exponential sweep
    # over scene-specific colours.
    if not emitted_colours or not candidate_anchors or len(candidate_anchors) > 4:
        return []
    options = [(None, None)] + [
        (shape, emit)
        for shape in ("plus", "diagonal")
        for emit in emitted_colours
    ]
    output = []
    for assignment in product(options, repeat=len(candidate_anchors)):
        mapping = tuple(
            (colour, shape, emit)
            for colour, (shape, emit) in zip(candidate_anchors, assignment)
            if shape is not None
        )
        if len(mapping) < 2:
            continue
        programme = SemanticSingletonStencilProgram(mapping)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "core_branch_diagonal_extension": lambda pairs: _fit_static(pairs, CoreBranchDiagonalExtensionProgram),
    "frame_payload_diagonal_projection": lambda pairs: _fit_static(pairs, FramePayloadDiagonalProjectionProgram),
    "colour_directed_block_diagonal_projection": _fit_colour_directed_blocks,
    "pedestal_diagonal_projection": lambda pairs: _fit_static(pairs, PedestalDiagonalProjectionProgram),
    "aligned_marker_block_connector": lambda pairs: _fit_static(pairs, AlignedMarkerBlockConnectorProgram),
    "nearest_boundary_ownership_projection": lambda pairs: _fit_static(pairs, NearestBoundaryOwnershipProjectionProgram),
    "panel_grid_axis_closure": lambda pairs: _fit_static(pairs, PanelGridAxisClosureProgram),
    "minimal_rotational_orbit_completion": lambda pairs: _fit_static(pairs, MinimalRotationalOrbitCompletionProgram),
    "square_corner_whisker_materialisation": _fit_square_whiskers,
    "semantic_singleton_stencil_materialisation": _fit_singleton_stencils,
}


def fit_learned_primitive_graph_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


# ---------------------------------------------------------------------------
# Counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        target = grid(target)
        original = programme.predict(source)
        background = _mode(source)
        foreground_colours = sorted(_palette(source) - {background})
        candidates = [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] != background
        ]
        candidates += [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] == background and source[r][c] != target[r][c]
        ]
        candidates += [
            (r, c)
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] == background
        ][:4]
        seen = set()
        passed = False
        tested = 0
        for r, c in candidates:
            if (r, c) in seen:
                continue
            seen.add((r, c))
            replacement = background if source[r][c] != background else (foreground_colours[0] if foreground_colours else (background + 1) % 10)
            if replacement == source[r][c]:
                continue
            tested += 1
            work = _array(source)
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                break
            if tested >= 12:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "learned_graph_node_or_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_learned_primitive_graph_grammar(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_learned_primitive_graph_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "learned_primitive_graph_grammar": True,
            "bounded_three_stage_relation_chain": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_learned_primitive_graph_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_learned_primitive_graph_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_learned_primitive_graph_grammar(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
