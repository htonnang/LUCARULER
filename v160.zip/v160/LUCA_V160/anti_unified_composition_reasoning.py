"""LUCA V129: anti-unified instruction/selector composition.

The family composes previously separate reasoning stages into conservative,
proof-carrying programmes::

    scene -> instruction / selector relation -> object binding
          -> local transformation -> canonical emission

Schemas:

* ``embedded_marker_object_repair``;
* ``nested_palette_swap_crop``;
* ``mask_role_inversion``;
* ``semantic_colour_count_panel_selector``;
* ``nearest_marker_colour_recolour``;
* ``external_pair_codebook_recolour``.

No task identifier, official target, or stored demonstration coordinate is
available during inference.  Exact training fit is necessary but not
sufficient: programmes must agree on the unseen prediction, survive
held-demonstration refitting, and pass schema-specific counterfactual tests.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_anti_unified_compositional_search"
LANGUAGE = "spinoza_anti_unified_compositional_search_v1"
SCHEMA_VERSION = "anti_unified_compositional_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {int(cell) for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    best = max(counts.values())
    modes = [int(colour) for colour, count in counts.items() if count == best]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _candidate_backgrounds(pairs) -> list[int]:
    candidates = None
    for source, _ in pairs:
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_unique_mode(source))
        except Inapplicable:
            pass
        candidates = values if candidates is None else candidates & values
    return sorted(candidates or ())


def _dirs(connectivity: int):
    base = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        base += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return base


def _components(value: Grid, *, background: int, connectivity: int = 4, same_colour: bool = False):
    value = grid(value)
    height, width = _shape(value)
    seen = set()
    rows = []
    for row in range(height):
        for col in range(width):
            if (row, col) in seen or value[row][col] == background:
                continue
            seed_colour = value[row][col]
            stack = [(row, col)]
            seen.add((row, col))
            cells = []
            while stack:
                current = stack.pop()
                cells.append(current)
                for dr, dc in _dirs(connectivity):
                    nr, nc = current[0] + dr, current[1] + dc
                    if not (0 <= nr < height and 0 <= nc < width) or (nr, nc) in seen:
                        continue
                    if value[nr][nc] == background:
                        continue
                    if same_colour and value[nr][nc] != seed_colour:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            r0 = min(r for r, _ in cells)
            r1 = max(r for r, _ in cells)
            c0 = min(c for _, c in cells)
            c1 = max(c for _, c in cells)
            rows.append({
                "cells": tuple(sorted(cells)),
                "bbox": (r0, c0, r1, c1),
                "colour": int(seed_colour) if same_colour else None,
            })
    rows.sort(key=lambda item: item["bbox"])
    return rows


def _crop(value: Grid, bbox) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = bbox
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _bbox_for_cells(cells):
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


# ---------------------------------------------------------------------------
# Embedded marker repair.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EmbeddedMarkerRepairProgram:
    background_colour: int
    marker_colour: int
    connectivity: int = 4
    kind: str = "embedded_marker_object_repair"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.marker_colour, self.connectivity

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        markers = [(r, c) for r in range(height) for c in range(width) if value[r][c] == self.marker_colour]
        if len(markers) != 1:
            raise Inapplicable("the embedded marker must occur exactly once")
        marker = markers[0]
        neighbours = set()
        for dr, dc in _dirs(4):
            nr, nc = marker[0] + dr, marker[1] + dc
            if 0 <= nr < height and 0 <= nc < width:
                colour = value[nr][nc]
                if colour not in (self.background_colour, self.marker_colour):
                    neighbours.add(int(colour))
        if len(neighbours) != 1:
            raise Inapplicable("the marker must bind one host colour")
        host_colour = next(iter(neighbours))
        work = _array(value)
        work[marker[0]][marker[1]] = host_colour
        work_grid = tuple(tuple(row) for row in work)
        stack = [marker]
        seen = {marker}
        cells = []
        while stack:
            current = stack.pop()
            cells.append(current)
            for dr, dc in _dirs(self.connectivity):
                nr, nc = current[0] + dr, current[1] + dc
                if 0 <= nr < height and 0 <= nc < width and (nr, nc) not in seen and work_grid[nr][nc] == host_colour:
                    seen.add((nr, nc))
                    stack.append((nr, nc))
        if len(cells) < 3:
            raise Inapplicable("the repaired host object is too small")
        bbox = _bbox_for_cells(cells)
        r0, c0, r1, c1 = bbox
        result = [[self.background_colour] * (c1 - c0 + 1) for _ in range(r1 - r0 + 1)]
        for r, c in cells:
            result[r - r0][c - c0] = host_colour
        return {
            "marker": marker,
            "host_colour": host_colour,
            "component_cells": tuple(cells),
            "bbox": bbox,
            "prediction": tuple(tuple(row) for row in result),
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "marker_colour": self.marker_colour,
                "connectivity": self.connectivity,
            },
            definitions=[
                {"name": "EmbeddedMarker", "type": "Grid x Colour -> Cell"},
                {"name": "HostBinding", "type": "Cell x Neighbourhood -> Colour"},
                {"name": "ObjectRepair", "type": "Marker x Host -> Component"},
                {"name": "CanonicalCrop", "type": "Component -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindEmbeddedMarker", "effect": "identify the unique marker and its host colour"},
                {"index": 2, "definition": "RestoreHostCell", "effect": "replace the marker with the bound host role"},
                {"index": 3, "definition": "CropRepairedObject", "effect": "emit only the repaired host object"},
            ],
            corollary="an embedded instruction marker can be removed after it uniquely binds the object role it replaced",
            common_notions=[{
                "name": "embedded_marker_host_evidence",
                "evidence": [self.analyse(source)["host_colour"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Nested palette-role swap.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NestedPaletteSwapProgram:
    background_colour: int
    kind: str = "nested_palette_swap_crop"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        cells = [(r, c) for r, row in enumerate(value) for c, colour in enumerate(row) if colour != self.background_colour]
        if not cells:
            raise Inapplicable("no nested object")
        bbox = _bbox_for_cells(cells)
        crop = _crop(value, bbox)
        height, width = _shape(crop)
        if any(cell == self.background_colour for row in crop for cell in row):
            raise Inapplicable("the nested object must fill its bounding box")
        colours = sorted(_palette(crop))
        if len(colours) != 2:
            raise Inapplicable("the nested object must use exactly two colours")
        border = set(crop[0]) | set(crop[-1]) | {row[0] for row in crop} | {row[-1] for row in crop}
        if len(border) != 1:
            raise Inapplicable("the outer role must have one border colour")
        outer = next(iter(border))
        inner = next(colour for colour in colours if colour != outer)
        inner_cells = [(r, c) for r in range(height) for c in range(width) if crop[r][c] == inner]
        if not inner_cells:
            raise Inapplicable("missing inner rectangle")
        ibox = _bbox_for_cells(inner_cells)
        ir0, ic0, ir1, ic1 = ibox
        if ir0 <= 0 or ic0 <= 0 or ir1 >= height - 1 or ic1 >= width - 1:
            raise Inapplicable("the inner role must be strictly enclosed")
        expected = {(r, c) for r in range(ir0, ir1 + 1) for c in range(ic0, ic1 + 1)}
        if set(inner_cells) != expected:
            raise Inapplicable("the inner role must be a solid rectangle")
        if ir0 != height - 1 - ir1 or ic0 != width - 1 - ic1:
            raise Inapplicable("the inner rectangle must be centred")
        prediction = tuple(tuple(inner if cell == outer else outer for cell in row) for row in crop)
        return {
            "bbox": bbox,
            "outer_colour": int(outer),
            "inner_colour": int(inner),
            "inner_bbox": ibox,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "NestedRectangle", "type": "Grid -> Outer x Inner"},
                {"name": "PaletteRoleSwap", "type": "Outer x Inner -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindNestedRoles", "effect": "identify centred outer and inner rectangle roles"},
                {"index": 2, "definition": "SwapRoleColours", "effect": "exchange the two role colours"},
                {"index": 3, "definition": "EmitObjectCrop", "effect": "discard the surrounding canvas"},
            ],
            corollary="nested geometry determines palette roles independently of the particular colours",
            common_notions=[{
                "name": "nested_rectangle_dimensions",
                "evidence": [list(_shape(self.predict(source))) for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Binary mask-role inversion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MaskRoleInversionProgram:
    mask_colour: int
    output_background: int
    kind: str = "mask_role_inversion"

    @property
    def schema_key(self):
        return self.kind, self.mask_colour, self.output_background

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        colours = sorted(_palette(value))
        if len(colours) != 2 or self.mask_colour not in colours:
            raise Inapplicable("source must contain the mask role and one semantic colour")
        semantic = next(colour for colour in colours if colour != self.mask_colour)
        if semantic == self.output_background:
            raise Inapplicable("semantic colour cannot equal output background")
        prediction = tuple(
            tuple(semantic if cell == self.mask_colour else self.output_background for cell in row)
            for row in value
        )
        return {"semantic_colour": int(semantic), "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"mask_colour": self.mask_colour, "output_background": self.output_background},
            definitions=[
                {"name": "BinaryRoleMask", "type": "Grid x MaskColour -> BoolGrid"},
                {"name": "RoleInversionEmitter", "type": "BoolGrid x SemanticColour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindMaskAndSemanticRoles", "effect": "separate the fixed mask role from the variable semantic role"},
                {"index": 2, "definition": "InvertRoleSupport", "effect": "emit the semantic colour exactly on the mask support"},
            ],
            corollary="a fixed structural mask can be filled by the complementary semantic role while the original semantic support is erased",
            common_notions=[{
                "name": "semantic_colour_variation",
                "evidence": [self.analyse(source)["semantic_colour"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Panel selection by semantic colour evidence.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SemanticColourCountPanelProgram:
    background_colour: int
    selector_colour: int
    comparison: str
    connectivity: int = 4
    kind: str = "semantic_colour_count_panel_selector"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.selector_colour, self.comparison, self.connectivity

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        components = _components(value, background=self.background_colour, connectivity=self.connectivity, same_colour=False)
        if len(components) < 2:
            raise Inapplicable("at least two panels are required")
        panels = []
        counts = []
        for component in components:
            crop = _crop(value, component["bbox"])
            if any(cell == self.background_colour for row in crop for cell in row):
                raise Inapplicable("each panel must fill its bounding box")
            if self.selector_colour not in _palette(crop):
                raise Inapplicable("selector colour must occur in every panel")
            panels.append(crop)
            counts.append(sum(cell == self.selector_colour for row in crop for cell in row))
        target = max(counts) if self.comparison == "max" else min(counts)
        winners = [index for index, count in enumerate(counts) if count == target]
        if len(winners) != 1:
            raise Inapplicable("selector evidence is tied")
        selected = winners[0]
        return {
            "components": components,
            "panels": panels,
            "counts": counts,
            "selected_index": selected,
            "prediction": panels[selected],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "selector_colour": self.selector_colour,
                "comparison": self.comparison,
                "connectivity": self.connectivity,
            },
            definitions=[
                {"name": "FilledPanel", "type": "Grid -> Sequence[RectangularPanel]"},
                {"name": "SemanticColourCount", "type": "Panel x Colour -> Integer"},
                {"name": "UniqueExtremum", "type": "Sequence[Integer] -> PanelRole"},
            ],
            propositions=[
                {"index": 1, "definition": "SegmentFilledPanels", "effect": "construct rectangular candidate panels"},
                {"index": 2, "definition": "MeasureSelectorEvidence", "effect": "count the semantic selector colour in each candidate"},
                {"index": 3, "definition": "BindUniqueExtremum", "effect": "select the sole maximum or minimum evidence panel"},
            ],
            corollary="semantic evidence can select a panel independently of its dimensions and absolute location",
            common_notions=[{
                "name": "panel_count_evidence",
                "evidence": [self.analyse(source)["counts"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Nearest marker colour binds a template object.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class NearestMarkerColourProgram:
    background_colour: int
    template_colour: int
    kind: str = "nearest_marker_colour_recolour"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.template_colour, "squared_euclidean"

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        template = [(r, c) for r in range(height) for c in range(width) if value[r][c] == self.template_colour]
        if len(template) < 2:
            raise Inapplicable("template object is absent")
        template_components = _components(
            tuple(tuple(self.template_colour if value[r][c] == self.template_colour else self.background_colour for c in range(width)) for r in range(height)),
            background=self.background_colour,
            connectivity=4,
            same_colour=False,
        )
        if len(template_components) != 1:
            raise Inapplicable("template colour must form one component")
        marker_colours = sorted(_palette(value) - {self.background_colour, self.template_colour})
        if len(marker_colours) < 2:
            raise Inapplicable("multiple marker colours are required")
        distances = {}
        marker_cells = {}
        for colour in marker_colours:
            cells = [(r, c) for r in range(height) for c in range(width) if value[r][c] == colour]
            if not cells:
                continue
            # Markers are isolated evidence cells, not coloured objects.
            for r, c in cells:
                for dr, dc in _dirs(8):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < height and 0 <= nc < width and value[nr][nc] == colour:
                        raise Inapplicable("marker evidence must consist of isolated cells")
            marker_cells[colour] = cells
            distances[colour] = min((r - tr) ** 2 + (c - tc) ** 2 for r, c in cells for tr, tc in template)
        if len(distances) < 2:
            raise Inapplicable("insufficient marker evidence")
        best = min(distances.values())
        winners = [colour for colour, distance in distances.items() if distance == best]
        if len(winners) != 1:
            raise Inapplicable("nearest marker colour is tied")
        selected = winners[0]
        prediction = tuple(
            tuple(selected if value[r][c] == self.template_colour else self.background_colour for c in range(width))
            for r in range(height)
        )
        return {
            "selected_colour": int(selected),
            "distances": {str(k): int(v) for k, v in distances.items()},
            "marker_cells": marker_cells,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "template_colour": self.template_colour, "distance": "squared_euclidean"},
            definitions=[
                {"name": "TemplateObject", "type": "Grid x Colour -> Component"},
                {"name": "MarkerColourDistance", "type": "MarkerClass x Component -> Integer"},
                {"name": "NearestMarkerBinding", "type": "DistanceMap -> Colour"},
            ],
            propositions=[
                {"index": 1, "definition": "BindTemplateObject", "effect": "identify the coherent template support"},
                {"index": 2, "definition": "MeasureMarkerDistance", "effect": "compute the nearest squared distance for every marker colour"},
                {"index": 3, "definition": "RecolourTemplate", "effect": "project the uniquely nearest marker colour onto the template support"},
            ],
            corollary="a distributed marker class can bind an object through a unique nearest-colour relation",
            common_notions=[{
                "name": "nearest_marker_evidence",
                "evidence": [self.analyse(source)["distances"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# External pair codebook recolours one filled object.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExternalPairCodebookProgram:
    background_colour: int
    kind: str = "external_pair_codebook_recolour"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        components = _components(value, background=self.background_colour, connectivity=4, same_colour=False)
        if len(components) < 3:
            raise Inapplicable("one target object and at least two code pairs are required")
        rectangles = []
        pairs = []
        for component in components:
            crop = _crop(value, component["bbox"])
            if all(cell != self.background_colour for row in crop for cell in row) and len(component["cells"]) == len(crop) * len(crop[0]) and len(component["cells"]) >= 9:
                rectangles.append((component, crop))
            elif len(component["cells"]) == 2:
                cells = component["cells"]
                colours = [value[r][c] for r, c in cells]
                if len(set(colours)) != 2:
                    raise Inapplicable("code pair must contain two colours")
                pairs.append((component, tuple(int(x) for x in colours)))
            else:
                raise Inapplicable("all external instructions must be adjacent two-colour pairs")
        if len(rectangles) != 1 or len(pairs) < 2:
            raise Inapplicable("target rectangle or code pairs are ambiguous")
        component, target_crop = rectangles[0]
        target_palette = _palette(target_crop)
        mapping = {}
        for _, colours in pairs:
            inside = [colour for colour in colours if colour in target_palette]
            outside = [colour for colour in colours if colour not in target_palette]
            if len(inside) != 1 or len(outside) != 1:
                raise Inapplicable("each code pair must bind one source role to one new role")
            old, new = inside[0], outside[0]
            if old in mapping and mapping[old] != new:
                raise Inapplicable("codebook is contradictory")
            mapping[old] = new
        counts = Counter(cell for row in target_crop for cell in row)
        base_count = max(counts.values())
        base_candidates = [colour for colour, count in counts.items() if count == base_count]
        if len(base_candidates) != 1:
            raise Inapplicable("target base colour is ambiguous")
        base = base_candidates[0]
        required = target_palette - {base}
        if required != set(mapping):
            raise Inapplicable("every non-base target role must have one external code pair")
        prediction = tuple(tuple(mapping.get(cell, cell) for cell in row) for row in target_crop)
        return {
            "target_bbox": component["bbox"],
            "base_colour": int(base),
            "mapping": {str(k): int(v) for k, v in mapping.items()},
            "pair_components": pairs,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "FilledTargetObject", "type": "Grid -> Rectangle"},
                {"name": "ExternalColourPair", "type": "TwoCellObject -> SourceRole x TargetRole"},
                {"name": "LocalPaletteCodebook", "type": "Sequence[Pair] -> ColourMap"},
            ],
            propositions=[
                {"index": 1, "definition": "BindTargetRectangle", "effect": "identify the sole filled multicolour object"},
                {"index": 2, "definition": "InducePairCodebook", "effect": "map each non-base source role to its external paired role"},
                {"index": 3, "definition": "RecolourTarget", "effect": "apply the induced codebook and crop the target"},
            ],
            corollary="external colour pairs can specify a local palette transformation independently of object geometry",
            common_notions=[{
                "name": "pair_codebook_evidence",
                "evidence": [self.analyse(source)["mapping"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Fitters.
# ---------------------------------------------------------------------------


def _fit_embedded_marker(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        candidate_markers = None
        for source, _ in pairs:
            counts = Counter(cell for row in grid(source) for cell in row)
            singles = {int(colour) for colour, count in counts.items() if count == 1 and colour != background}
            candidate_markers = singles if candidate_markers is None else candidate_markers & singles
        for marker in sorted(candidate_markers or ()):
            program = EmbeddedMarkerRepairProgram(background, marker)
            try:
                analyses = [program.analyse(source) for source, _ in pairs]
                if all(analysis["prediction"] == grid(target) for analysis, (_, target) in zip(analyses, pairs)) and len({a["host_colour"] for a in analyses}) >= 2:
                    programmes.append(program)
            except Inapplicable:
                continue
    return programmes


def _fit_nested_swap(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        program = NestedPaletteSwapProgram(background)
        try:
            analyses = [program.analyse(source) for source, _ in pairs]
            if all(a["prediction"] == grid(target) for a, (_, target) in zip(analyses, pairs)):
                if len({_shape(a["prediction"]) for a in analyses}) >= 2 and len({(a["outer_colour"], a["inner_colour"]) for a in analyses}) >= 2:
                    programmes.append(program)
        except Inapplicable:
            continue
    return programmes


def _fit_mask_inversion(pairs):
    programmes = []
    common_source = set.intersection(*(_palette(source) for source, _ in pairs)) if pairs else set()
    common_output = set.intersection(*(_palette(target) for _, target in pairs)) if pairs else set()
    output_candidates = sorted(common_output | {0})
    for mask_colour in sorted(common_source):
        for output_background in output_candidates:
            program = MaskRoleInversionProgram(mask_colour, output_background)
            try:
                analyses = [program.analyse(source) for source, _ in pairs]
                if all(a["prediction"] == grid(target) for a, (_, target) in zip(analyses, pairs)) and len({a["semantic_colour"] for a in analyses}) >= 2:
                    programmes.append(program)
            except Inapplicable:
                continue
    return programmes


def _fit_panel_selector(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        common_colours = set.intersection(*(_palette(source) - {background} for source, _ in pairs)) if pairs else set()
        for selector in sorted(common_colours):
            for comparison in ("max", "min"):
                for connectivity in (4, 8):
                    program = SemanticColourCountPanelProgram(background, selector, comparison, connectivity)
                    try:
                        analyses = [program.analyse(source) for source, _ in pairs]
                        if all(a["prediction"] == grid(target) for a, (_, target) in zip(analyses, pairs)):
                            # The semantic role must vary across demonstrations, but it need not
                            # move to a different component index in every reduced LODO fold.
                            # Changed selected geometry or selected content is also evidence that
                            # the programme is not a fixed-window template.
                            selected_indices = {a["selected_index"] for a in analyses}
                            selected_shapes = {_shape(a["prediction"]) for a in analyses}
                            selected_crops = {_serial(a["prediction"]) for a in analyses}
                            role_varies = (
                                len(selected_indices) >= 2
                                or len(selected_shapes) >= 2
                                or len(selected_crops) >= 2
                            )
                            if role_varies and all(len(a["panels"]) >= 2 for a in analyses):
                                programmes.append(program)
                    except Inapplicable:
                        continue
    return programmes


def _fit_nearest_marker(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        common_colours = set.intersection(*(_palette(source) - {background} for source, _ in pairs)) if pairs else set()
        for template_colour in sorted(common_colours):
            program = NearestMarkerColourProgram(background, template_colour)
            try:
                analyses = [program.analyse(source) for source, _ in pairs]
                if all(a["prediction"] == grid(target) for a, (_, target) in zip(analyses, pairs)) and len({a["selected_colour"] for a in analyses}) >= 2:
                    programmes.append(program)
            except Inapplicable:
                continue
    return programmes


def _fit_pair_codebook(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        program = ExternalPairCodebookProgram(background)
        try:
            analyses = [program.analyse(source) for source, _ in pairs]
            if all(a["prediction"] == grid(target) for a, (_, target) in zip(analyses, pairs)):
                if len({tuple(sorted(a["mapping"].items())) for a in analyses}) >= 2:
                    programmes.append(program)
        except Inapplicable:
            continue
    return programmes


FITTERS = {
    "embedded_marker_object_repair": _fit_embedded_marker,
    "nested_palette_swap_crop": _fit_nested_swap,
    "mask_role_inversion": _fit_mask_inversion,
    "semantic_colour_count_panel_selector": _fit_panel_selector,
    "nearest_marker_colour_recolour": _fit_nearest_marker,
    "external_pair_codebook_recolour": _fit_pair_codebook,
}


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, EmbeddedMarkerRepairProgram):
        return analysis["host_colour"], _shape(analysis["prediction"])
    if isinstance(program, NestedPaletteSwapProgram):
        return analysis["outer_colour"], analysis["inner_colour"], _shape(analysis["prediction"])
    if isinstance(program, MaskRoleInversionProgram):
        return analysis["semantic_colour"], _shape(source)
    if isinstance(program, SemanticColourCountPanelProgram):
        return analysis["selected_index"], tuple(analysis["counts"])
    if isinstance(program, NearestMarkerColourProgram):
        return analysis["selected_colour"], tuple(sorted(analysis["distances"].items()))
    if isinstance(program, ExternalPairCodebookProgram):
        return tuple(sorted(analysis["mapping"].items())), _shape(analysis["prediction"])
    return program.schema_key


def fit_anti_unified_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds or FITTERS)
    programmes = []
    for kind, fitter in FITTERS.items():
        if kind not in allowed:
            continue
        programmes.extend(fitter(pairs))
    unique = {}
    for program in programmes:
        try:
            if require_role_variation and len({_serial(_role_signature(program, source)) for source, _ in pairs}) < 2:
                continue
            if not all(program.predict(source) == target for source, target in pairs):
                continue
        except Inapplicable:
            continue
        unique[program.schema_key] = program
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.schema_key)))


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    return {"kind": kind, "rows": rows, "passed": bool(rows) and all(row.get("passed") for row in rows)}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}

        if isinstance(program, EmbeddedMarkerRepairProgram):
            work = _array(source)
            analysis = program.analyse(source)
            r, c = analysis["marker"]
            work[r][c] = program.background_colour
            try:
                program.predict(tuple(tuple(row) for row in work))
                passed = False
            except Inapplicable:
                passed = True
            details = {"embedded_marker_necessary": passed}

        elif isinstance(program, NestedPaletteSwapProgram):
            analysis = program.analyse(source)
            fresh = _fresh_colour(source)
            modified = _replace_colour(source, analysis["inner_colour"], fresh)
            try:
                changed = program.predict(modified)
                passed = changed != original and fresh in _palette(changed)
            except Inapplicable:
                passed = False
            details = {"inner_role_recolour_equivariance": passed}

        elif isinstance(program, MaskRoleInversionProgram):
            analysis = program.analyse(source)
            fresh = _fresh_colour(source, {program.output_background, program.mask_colour})
            modified = _replace_colour(source, analysis["semantic_colour"], fresh)
            expected = tuple(tuple(fresh if cell == program.mask_colour else program.output_background for cell in row) for row in source)
            try:
                passed = program.predict(modified) == expected
            except Inapplicable:
                passed = False
            details = {"semantic_recolour_equivariance": passed}

        elif isinstance(program, SemanticColourCountPanelProgram):
            analysis = program.analyse(source)
            work = _array(source)
            counts = analysis["counts"]
            selected = analysis["selected_index"]
            if program.comparison == "max":
                competitors = [i for i in range(len(counts)) if i != selected]
                competitor = max(competitors, key=lambda i: counts[i])
                need = counts[selected] - counts[competitor]
                cells = [cell for cell in analysis["components"][competitor]["cells"] if source[cell[0]][cell[1]] != program.selector_colour]
                if 0 < need <= len(cells):
                    for r, c in cells[:need]:
                        work[r][c] = program.selector_colour
            else:
                competitors = [i for i in range(len(counts)) if i != selected]
                competitor = min(competitors, key=lambda i: counts[i])
                need = counts[competitor] - counts[selected]
                cells = [cell for cell in analysis["components"][competitor]["cells"] if source[cell[0]][cell[1]] == program.selector_colour]
                if 0 < need <= len(cells):
                    replacement = next(colour for colour in _palette(analysis["panels"][competitor]) if colour != program.selector_colour)
                    for r, c in cells[:need]:
                        work[r][c] = replacement
            try:
                program.predict(tuple(tuple(row) for row in work))
                passed = False
            except Inapplicable:
                passed = True
            details = {"selector_tie_rejected": passed}

        elif isinstance(program, NearestMarkerColourProgram):
            analysis = program.analyse(source)
            work = _array(source)
            for r, c in analysis["marker_cells"][analysis["selected_colour"]]:
                work[r][c] = program.background_colour
            modified = tuple(tuple(row) for row in work)
            try:
                passed = program.predict(modified) != original
            except Inapplicable:
                passed = True
            details = {"nearest_marker_evidence_necessary": passed}

        elif isinstance(program, ExternalPairCodebookProgram):
            analysis = program.analyse(source)
            work = _array(source)
            component, _ = analysis["pair_components"][0]
            for r, c in component["cells"]:
                work[r][c] = program.background_colour
            try:
                program.predict(tuple(tuple(row) for row in work))
                passed = False
            except Inapplicable:
                passed = True
            details = {"external_pair_necessary": passed}

        rows.append({"demonstration": index, "passed": passed, **details})
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Inference and validation.
# ---------------------------------------------------------------------------


def infer_anti_unified_composition(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anti_unified_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programmes:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_compositional_search": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "embedded_marker_object_repair":
        return EmbeddedMarkerRepairProgram(int(parameters["background_colour"]), int(parameters["marker_colour"]), int(parameters.get("connectivity", 4)))
    if kind == "nested_palette_swap_crop":
        return NestedPaletteSwapProgram(int(parameters["background_colour"]))
    if kind == "mask_role_inversion":
        return MaskRoleInversionProgram(int(parameters["mask_colour"]), int(parameters["output_background"]))
    if kind == "semantic_colour_count_panel_selector":
        return SemanticColourCountPanelProgram(
            int(parameters["background_colour"]),
            int(parameters["selector_colour"]),
            str(parameters["comparison"]),
            int(parameters.get("connectivity", 4)),
        )
    if kind == "nearest_marker_colour_recolour":
        return NearestMarkerColourProgram(int(parameters["background_colour"]), int(parameters["template_colour"]))
    if kind == "external_pair_codebook_recolour":
        return ExternalPairCodebookProgram(int(parameters["background_colour"]))
    raise Inapplicable("unknown anti-unified schema")


def validate_anti_unified_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anti_unified_programs(
            remaining,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                counterfactual = _counterfactual_validation(program, full_pairs)
                if not counterfactual.get("passed"):
                    continue
                predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        })

    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, full_pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def anti_unified_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_anti_unified_programs(pairs)}))


infer = infer_anti_unified_composition
validate = validate_anti_unified_composition
