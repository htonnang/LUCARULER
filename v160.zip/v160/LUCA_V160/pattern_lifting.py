"""Input-derived pattern-valued cells: one tile renderer, two input parsers.

A program stores structural choices, never a demonstration output pattern. Both
control and motif are recomputed from the current input. Enumeration is complete
within the finite declared grammar; demonstration equivalence is not test equality.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass, asdict
from functools import lru_cache
from itertools import product


from correspondence import grid
from runtime import public_task

from attributes import background
from cell_abstraction import Partition, view
from cell_reasoning import partitions
from geometry import rotate, reflect

FAMILY = 'pattern_valued_cells_v77'
MAX_SIDE = 30


def shape(a):
    return len(a), len(a[0])


def orient(a, turns=0, flip=False):
    return rotate(reflect(a, 'horizontal' if flip else 'none'), turns)


def select_colour(a, bg, role):
    counts = Counter(v for row in a for v in row if v != bg)
    if isinstance(role, int):
        return role if role in counts else None
    if role not in ('rarest', 'commonest') or not counts:
        return None
    value = min(counts.values()) if role == 'rarest' else max(counts.values())
    choices = [v for v,n in counts.items() if n == value]
    return choices[0] if len(choices) == 1 else None


def paint_tile(template, bg, paint, control, complement=False):
    """Single colour-preserving/mask renderer used by every pattern program."""
    if paint not in ('template', 'control'):
        raise ValueError('unknown paint operation')
    source = template
    if complement:
        fg = {v for row in template for v in row if v != bg}
        if len(fg) != 1:
            return None
        colour = next(iter(fg))
        source = tuple(tuple(colour if v == bg else bg for v in row) for row in template)
    if paint == 'template':
        return source
    if control is None:
        return None
    return tuple(tuple(bg if v == bg else control for v in row) for row in source)


@dataclass(frozen=True)
class Scene:
    controls: tuple
    motif: tuple
    rows: tuple
    cols: tuple
    canvas: tuple
    background: int


@lru_cache(maxsize=2048)
def parse_scene(a, mode, bg_rule, control_view, motif_view, partition, paint):
    """Segmentation depends only on input; targets never define a donor or cell."""
    bg = background(a, bg_rule)
    if bg is None:
        return None
    if mode == 'expand':
        controls = view(a, control_view, bg_rule)
        motif = view(a, motif_view, bg_rule)
        if controls is None or motif is None:
            return None
        th, tw = shape(motif)
        h, w = len(controls)*th, len(controls[0])*tw
        if min(h,w) < 1:
            return None
        # This family is pattern-valued, not ordinary uniform-pixel scaling.
        vals = {v for row in motif for v in row}
        if bg not in vals or len(vals) < 2 or th*tw < 2:
            return None
        rows = tuple(tuple(range(i*th,(i+1)*th)) for i in range(len(controls)))
        cols = tuple(tuple(range(j*tw,(j+1)*tw)) for j in range(len(controls[0])))
        canvas = ()  # allocate only after the oriented dimensions pass prediction checks
        return Scene(controls,motif,rows,cols,canvas,bg)
    if mode != 'lattice' or partition is None:
        raise ValueError('invalid scene mode or partition')
    axes = partition.axes(a)
    if axes is None:
        return None
    rr,cc = axes
    if len(rr)*len(cc)<2 or len({len(x) for x in rr})!=1 or len({len(x) for x in cc})!=1:
        return None
    area = len(rr[0])*len(cc[0])
    if area < 3:
        return None
    cells = tuple(tuple(tuple(tuple(a[r][c] for c in cs) for r in rs) for cs in cc) for rs in rr)
    donors = [cell for row in cells for cell in row
              if 2 <= sum(v!=bg for cr in cell for v in cr) < area]
    if not donors:
        return None
    if paint == 'template':
        if len(set(donors)) != 1:
            return None
        motif = donors[0]  # all candidates are identical, not a tie-breaking choice
    else:
        masks = {tuple(tuple(v!=bg for v in row) for row in cell) for cell in donors}
        if len(masks) != 1:
            return None
        # Only support matters in control-colour paint. Never inherit a donor colour.
        mask = next(iter(masks))
        witness_colour = (bg+1)%10
        motif = tuple(tuple(witness_colour if v else bg for v in row) for row in mask)
    # A cell control colour is usable only if it has one foreground colour.
    # Template paint needs only occupancy, represented by a sentinel other than bg.
    controls = []
    for row in cells:
        vals=[]
        for cell in row:
            fg={v for cr in cell for v in cr if v!=bg}
            vals.append(bg if not fg else next(iter(fg)) if len(fg)==1 else None)
        controls.append(tuple(vals))
    return Scene(tuple(controls),motif,rr,cc,a,bg)


@dataclass(frozen=True)
class PatternProgram:
    mode: str
    background_rule: int | str
    control_view: str = 'whole'
    motif_view: str = 'whole'
    partition: Partition | None = None
    activation: str = 'foreground'
    colour_role: int | str | None = None
    turns: int = 0
    flip: bool = False
    paint: str = 'template'
    complement: bool = False

    def scene(self, raw):
        return parse_scene(grid(raw),self.mode,self.background_rule,self.control_view,
                           self.motif_view,self.partition,self.paint)

    def predict(self, raw):
        a=grid(raw);s=self.scene(a)
        if s is None:
            return None
        motif=orient(s.motif,self.turns,self.flip)
        mh,mw=shape(motif)
        if self.mode=='expand':
            rr=tuple(tuple(range(i*mh,(i+1)*mh)) for i in range(len(s.controls)))
            cc=tuple(tuple(range(j*mw,(j+1)*mw)) for j in range(len(s.controls[0])))
            h,w=len(rr)*mh,len(cc)*mw
            if max(h,w)>MAX_SIDE:
                return None
            out=[[s.background]*w for _ in range(h)]
        else:
            rr,cc=s.rows,s.cols
            if (mh,mw)!=(len(rr[0]),len(cc[0])):
                return None
            out=[list(r) for r in s.canvas]
        picked=select_colour(a,s.background,self.colour_role) if self.activation=='colour' else None
        if self.activation=='colour' and picked is None:
            return None
        for i,rs in enumerate(rr):
            for j,cs in enumerate(cc):
                control=s.controls[i][j]
                # None denotes occupied multicolour content, not background.
                active=(self.activation=='all' or self.activation=='foreground' and control!=s.background
                        or self.activation=='background' and control==s.background
                        or self.activation=='colour' and control==picked)
                if not active:
                    continue
                tile=paint_tile(motif,s.background,self.paint,control,self.complement)
                if tile is None:
                    return None
                for r,local_r in zip(rs,tile):
                    for c,v in zip(cs,local_r):
                        out[r][c]=v
        return grid(out)

    def describe(self):
        return {'family':FAMILY,**asdict(self)}

    def trace(self, raw):
        a=grid(raw);s=self.scene(a)
        return {'program':self.describe(),'input_shape':shape(a),
                'control_grid':s.controls if s else None,'input_derived_motif':s.motif if s else None,
                'oriented_motif':orient(s.motif,self.turns,self.flip) if s else None,
                'prediction':self.predict(a)}


def fit(raw_pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs or not any(a!=y for a,y in pairs):
        return []
    same=all(shape(a)==shape(y) for a,y in pairs)
    grows=all(len(y)>=len(a) and len(y[0])>=len(a[0]) and shape(a)!=shape(y) for a,y in pairs)
    if not same and not grows:
        return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    bgs=('modal',*sorted(common));result=[]
    partlist=tuple(p for p in partitions(pairs) if p.kind!='identical_runs') if same else (None,)
    for bg,paint in product(bgs,('template','control')):
        views=(('whole','whole'),('whole','foreground_box'),('foreground_box','whole'),('foreground_box','foreground_box')) if grows else (('whole','whole'),)
        for cv,mv in views:
            for part in partlist:
                mode='expand' if grows else 'lattice'
                scenes=tuple(parse_scene(a,mode,bg,cv,mv,part,paint) for a,y in pairs)
                if any(s is None for s in scenes):
                    continue
                if cv!='whole' and not any(s.controls!=a for s,(a,y) in zip(scenes,pairs)):
                    continue
                if mv!='whole' and not any(s.motif!=a for s,(a,y) in zip(scenes,pairs)):
                    continue
                activations=[('all',None),('foreground',None),('background',None)]
                if grows:
                    activations += [('colour',c) for c in ('rarest','commonest',*sorted(common))]
                for turns,flip in product(range(4),(False,True)):
                    motifs=tuple(orient(s.motif,turns,flip) for s in scenes)
                    if (turns or flip) and all(m==s.motif for m,s in zip(motifs,scenes)):
                        continue  # explicit observed-effect prior, applied to every fold
                    dims=[(len(s.controls)*len(m),len(s.controls[0])*len(m[0])) if grows else shape(a)
                          for s,m,(a,y) in zip(scenes,motifs,pairs)]
                    if any(d!=shape(y) for d,(a,y) in zip(dims,pairs)):
                        continue
                    if same and any(shape(m)!=(len(s.rows[0]),len(s.cols[0])) for m,s in zip(motifs,scenes)):
                        continue
                    for activation,role in activations:
                        for complement in ((False,True) if grows else (False,)):
                            model=PatternProgram(mode,bg,cv,mv,part,activation,role,turns,flip,paint,complement)
                            if all(model.predict(a)==y for a,y in pairs):
                                result.append(model)
    return list(dict.fromkeys(result))


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0
    for m in models:
        key=tuple(m.predict(t['input']) for t in clean['test'])
        if any(p is None for p in key):
            invalid+=1;continue
        groups.setdefault(key,[]).append(m.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    key=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
            'tests':[{'status':status,'prediction':[list(r) for r in key[i]] if key else None} for i in range(len(clean['test']))],
            'supporting_families':[FAMILY] if key else [],'supporting_laws':groups[key][:20] if key else [],
            'witness_predictions':[[[list(r) for r in y] for y in k] for k in list(groups)[:2]],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'all_joint_alternatives_retained':True}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':
        return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:
        return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        f={'train':[d for i,d in enumerate(clean['train']) if i!=held],
           'test':[{'input':demo['input']}]+clean['test']}
        r=infer(f);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
                      'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
                      'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


