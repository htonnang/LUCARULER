"""LUCA V124: self-similar expansion and substitution grammar.

The family learns reusable macro-to-micro correspondences from demonstrations::

    source grid -> expansion relation -> block grammar -> emitted macro grid

Six conservative schemas are exposed:

* ``macro_dihedral_wallpaper`` learns a fixed macro-template of D4 transforms;
* ``frequency_selected_self_replication`` copies the whole source at cells of a
  uniquely most- or least-frequent colour;
* ``fixed_colour_self_replication`` copies the source at cells of one learned
  semantic colour;
* ``monochrome_line_self_replication`` copies the source along the unique
  monochrome row or column;
* ``binary_complement_kronecker`` expands a binary mask by the complement of
  its own foreground mask;
* ``binary_kernel_substitution`` replaces every foreground cell by one learned
  multicolour kernel and every background cell by a blank block.

No task identifiers, stored demonstration coordinates, or test outputs are
used during inference. Exact training fit is necessary but not sufficient:
accepted predictions must survive output consensus, held-demonstration
refitting, counterfactual interventions, and metadata leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_self_similar_expansion_grammar"
LANGUAGE = "spinoza_self_similar_expansion_grammar_v1"
SCHEMA_VERSION = "self_similar_expansion_schema_v1"

TRANSFORM_NAMES = (
    "identity",
    "flip_lr",
    "flip_ud",
    "rotate180",
    "rotate90",
    "rotate270",
    "transpose",
    "anti_transpose",
)


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _rotate90(value: Grid) -> Grid:
    value = grid(value)
    height, width = _shape(value)
    return tuple(tuple(value[height - 1 - r][c] for r in range(height)) for c in range(width))


def _rotate180(value: Grid) -> Grid:
    return _rotate90(_rotate90(value))


def _flip_lr(value: Grid) -> Grid:
    return tuple(tuple(reversed(row)) for row in grid(value))


def _flip_ud(value: Grid) -> Grid:
    return tuple(reversed(grid(value)))


def _transpose(value: Grid) -> Grid:
    value = grid(value)
    height, width = _shape(value)
    if height != width:
        raise Inapplicable("transpose role requires a square source")
    return tuple(tuple(value[r][c] for r in range(height)) for c in range(width))


def _transform(value: Grid, name: str) -> Grid:
    value = grid(value)
    if name == "identity":
        return value
    if name == "flip_lr":
        return _flip_lr(value)
    if name == "flip_ud":
        return _flip_ud(value)
    if name == "rotate180":
        return _rotate180(value)
    if name == "rotate90":
        if _shape(value)[0] != _shape(value)[1]:
            raise Inapplicable("quarter-turn role requires a square source")
        return _rotate90(value)
    if name == "rotate270":
        if _shape(value)[0] != _shape(value)[1]:
            raise Inapplicable("quarter-turn role requires a square source")
        return _rotate90(_rotate180(value))
    if name == "transpose":
        return _transpose(value)
    if name == "anti_transpose":
        return _flip_lr(_flip_ud(_transpose(value)))
    raise Inapplicable("unknown transform")


def _possible_transforms(source: Grid, target: Grid) -> set[str]:
    result = set()
    for name in TRANSFORM_NAMES:
        try:
            if _transform(source, name) == grid(target):
                result.add(name)
        except Inapplicable:
            continue
    return result


def _concat_horizontal(blocks: Iterable[Grid]) -> Grid:
    blocks = tuple(grid(block) for block in blocks)
    if not blocks:
        raise Inapplicable("empty block row")
    heights = {_shape(block)[0] for block in blocks}
    if len(heights) != 1:
        raise Inapplicable("block heights disagree")
    height = next(iter(heights))
    return tuple(tuple(cell for block in blocks for cell in block[r]) for r in range(height))


def _concat_vertical(block_rows: Iterable[Grid]) -> Grid:
    rows = []
    width = None
    for block_row in block_rows:
        block_row = grid(block_row)
        current_width = _shape(block_row)[1]
        if width is None:
            width = current_width
        elif width != current_width:
            raise Inapplicable("macro rows disagree in width")
        rows.extend(block_row)
    if not rows:
        raise Inapplicable("empty macro grid")
    return tuple(rows)


def _uniform_block(shape: tuple[int, int], colour: int) -> Grid:
    height, width = shape
    return tuple(tuple(colour for _ in range(width)) for _ in range(height))


def _block(value: Grid, row: int, col: int, block_shape: tuple[int, int]) -> Grid:
    value = grid(value)
    height, width = block_shape
    return tuple(
        tuple(value[row * height + r][col * width + c] for c in range(width))
        for r in range(height)
    )


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


# ---------------------------------------------------------------------------
# Schema I: fixed macro-template of source-grid D4 transforms.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MacroDihedralWallpaperProgram:
    template: tuple[tuple[str, ...], ...]
    kind: str = "macro_dihedral_wallpaper"

    @property
    def schema_key(self):
        return self.kind, self.template

    @property
    def description_length(self):
        return 3 + sum(len(row) for row in self.template)

    @property
    def permissiveness_cost(self):
        return self.kind, self.template

    def analyse(self, value: Grid):
        value = grid(value)
        if not self.template or not self.template[0]:
            raise Inapplicable("empty transform template")
        if len({len(row) for row in self.template}) != 1:
            raise Inapplicable("ragged transform template")
        output = _concat_vertical(
            _concat_horizontal(_transform(value, name) for name in row)
            for row in self.template
        )
        return {
            "template_shape": (len(self.template), len(self.template[0])),
            "transform_roles": tuple(sorted({name for row in self.template for name in row})),
            "prediction": output,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "template_shape": list(analysis["template_shape"]),
                "transform_roles": list(analysis["transform_roles"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"template": [list(row) for row in self.template]},
            definitions=[
                {"name": "SourceGrid", "type": "Grid"},
                {"name": "D4TransformRole", "type": "Grid x Transform -> Grid"},
                {"name": "MacroTemplate", "type": "TransformRoleMatrix"},
                {"name": "WallpaperEmitter", "type": "Grid x TransformRoleMatrix -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "InferMacroPartition", "effect": "derive one input-sized block per macro role"},
                {"index": 2, "definition": "BindTransformRoles", "effect": "identify a shared D4 transform at every macro position"},
                {"index": 3, "definition": "EmitWallpaper", "effect": "apply the learned transform template to the unseen source"},
            ],
            corollary="the output is a fixed macro composition of source-grid D4 transforms",
            common_notions=[{"name": "macro_dihedral_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schemas II–IV: self-replication selected by cell relations.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SelfReplicationProgram:
    selector_kind: str
    selector_value: int | str | None
    blank_colour: int
    kind: str = "cell_relation_self_replication"

    @property
    def schema_key(self):
        return self.kind, self.selector_kind, self.selector_value, self.blank_colour

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.kind, self.selector_kind, self.selector_value, self.blank_colour

    def _mask(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if self.selector_kind in ("unique_max_frequency", "unique_min_frequency"):
            counts = Counter(cell for row in value for cell in row)
            target = max(counts.values()) if self.selector_kind == "unique_max_frequency" else min(counts.values())
            winners = [colour for colour, count in counts.items() if count == target]
            if len(winners) != 1:
                raise Inapplicable("frequency relation is not unique")
            selected = winners[0]
            mask = tuple(tuple(cell == selected for cell in row) for row in value)
            return mask, {"selected_colour": selected, "selected_count": target}

        if self.selector_kind == "fixed_colour":
            selected = int(self.selector_value)
            if selected not in _palette(value):
                raise Inapplicable("learned semantic colour is absent")
            mask = tuple(tuple(cell == selected for cell in row) for row in value)
            return mask, {"selected_colour": selected, "selected_count": sum(sum(row) for row in mask)}

        if self.selector_kind == "unique_monochrome_line":
            lines = []
            for r, row in enumerate(value):
                if len(set(row)) == 1:
                    lines.append(("row", r, row[0]))
            for c in range(width):
                column = tuple(value[r][c] for r in range(height))
                if len(set(column)) == 1:
                    lines.append(("column", c, column[0]))
            if len(lines) != 1:
                raise Inapplicable("monochrome line is not unique")
            orientation, index, colour = lines[0]
            mask_rows = [[False for _ in range(width)] for _ in range(height)]
            if orientation == "row":
                for c in range(width):
                    mask_rows[index][c] = True
            else:
                for r in range(height):
                    mask_rows[r][index] = True
            return tuple(tuple(row) for row in mask_rows), {
                "orientation": orientation,
                "line_index": index,
                "selected_colour": colour,
            }

        raise Inapplicable("unknown self-replication selector")

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        mask, relation = self._mask(value)
        blank = _uniform_block((height, width), self.blank_colour)
        macro_rows = []
        for r in range(height):
            macro_rows.append(_concat_horizontal(value if mask[r][c] else blank for c in range(width)))
        prediction = _concat_vertical(macro_rows)
        return {
            "mask": mask,
            "relation": relation,
            "blank_colour": self.blank_colour,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "selector": self.selector_kind,
                "relation": analysis["relation"],
                "replicated_cells": sum(sum(1 for cell in row if cell) for row in analysis["mask"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "selector_kind": self.selector_kind,
                "selector_value": self.selector_value,
                "blank_colour": self.blank_colour,
            },
            definitions=[
                {"name": "CellRelation", "type": "Grid -> CellRoleMask"},
                {"name": "SelfReplica", "type": "Grid -> MacroBlock"},
                {"name": "BlankMacroBlock", "type": "Colour x Shape -> MacroBlock"},
                {"name": "ReplicationEmitter", "type": "Grid x CellRoleMask -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "InferCellRelation", "effect": "bind cells by frequency, semantic colour, or a unique monochrome line"},
                {"index": 2, "definition": "LiftCellRoles", "effect": "replace selected roles with the complete source grid"},
                {"index": 3, "definition": "EmitBlankElsewhere", "effect": "fill every unselected macro role with the learned blank"},
            ],
            corollary="selected source-cell roles generate self-similar copies of the complete source",
            common_notions=[{"name": "cell_relation_replication_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema V: binary mask expanded by its complement.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BinaryComplementKroneckerProgram:
    background_colour: int
    kind: str = "binary_complement_kronecker"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.kind, self.background_colour

    def analyse(self, value: Grid):
        value = grid(value)
        colours = sorted(_palette(value))
        if len(colours) != 2 or self.background_colour not in colours:
            raise Inapplicable("binary complement requires exactly two colours")
        foreground = next(colour for colour in colours if colour != self.background_colour)
        height, width = _shape(value)
        foreground_mask = tuple(tuple(cell == foreground for cell in row) for row in value)
        complement = tuple(tuple(not cell for cell in row) for row in foreground_mask)
        blank = _uniform_block((height, width), self.background_colour)
        kernel = tuple(
            tuple(foreground if complement[r][c] else self.background_colour for c in range(width))
            for r in range(height)
        )
        macro_rows = []
        for r in range(height):
            macro_rows.append(_concat_horizontal(kernel if foreground_mask[r][c] else blank for c in range(width)))
        prediction = _concat_vertical(macro_rows)
        return {
            "background_colour": self.background_colour,
            "foreground_colour": foreground,
            "foreground_mask": foreground_mask,
            "kernel": kernel,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "foreground_colour": analysis["foreground_colour"],
                "foreground_cells": sum(sum(1 for cell in row if cell) for row in analysis["foreground_mask"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "BinaryForegroundMask", "type": "Grid -> BoolGrid"},
                {"name": "MaskComplement", "type": "BoolGrid -> BoolGrid"},
                {"name": "KroneckerExpansion", "type": "BoolGrid x BoolGrid -> BoolGrid"},
                {"name": "ColourEmitter", "type": "BoolGrid x Palette -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ExtractForegroundMask", "effect": "derive the binary source relation"},
                {"index": 2, "definition": "DeriveComplementKernel", "effect": "use the complement as the foreground substitution"},
                {"index": 3, "definition": "ExpandMask", "effect": "replace each foreground cell with the complement kernel"},
            ],
            corollary="the binary source is expanded by the complement of its own foreground support",
            common_notions=[{"name": "binary_complement_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema VI: binary foreground replaced by a learned multicolour kernel.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BinaryKernelSubstitutionProgram:
    background_colour: int
    foreground_colour: int
    kernel: Grid
    kind: str = "binary_kernel_substitution"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.foreground_colour, self.kernel

    @property
    def description_length(self):
        return 5 + _shape(self.kernel)[0] * _shape(self.kernel)[1]

    @property
    def permissiveness_cost(self):
        return self.kind, self.background_colour, self.foreground_colour, self.kernel

    def analyse(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background_colour, self.foreground_colour}:
            raise Inapplicable("binary kernel source palette changed")
        source_height, source_width = _shape(value)
        kernel_height, kernel_width = _shape(self.kernel)
        blank = _uniform_block((kernel_height, kernel_width), self.background_colour)
        macro_rows = []
        foreground_cells = 0
        for r in range(source_height):
            blocks = []
            for c in range(source_width):
                if value[r][c] == self.foreground_colour:
                    blocks.append(self.kernel)
                    foreground_cells += 1
                else:
                    blocks.append(blank)
            macro_rows.append(_concat_horizontal(blocks))
        prediction = _concat_vertical(macro_rows)
        return {
            "kernel_shape": (kernel_height, kernel_width),
            "foreground_cells": foreground_cells,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "kernel_shape": list(analysis["kernel_shape"]),
                "foreground_cells": analysis["foreground_cells"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "foreground_colour": self.foreground_colour,
                "kernel": [list(row) for row in self.kernel],
            },
            definitions=[
                {"name": "BinarySourceRole", "type": "Grid -> BoolGrid"},
                {"name": "LearnedKernel", "type": "Demonstrations -> Grid"},
                {"name": "BlockSubstitution", "type": "BoolGrid x Grid -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindBinaryRoles", "effect": "separate foreground and background source cells"},
                {"index": 2, "definition": "LearnSubstitutionKernel", "effect": "derive the shared nonuniform foreground block"},
                {"index": 3, "definition": "SubstituteBlocks", "effect": "replace every foreground source cell by the learned kernel"},
            ],
            corollary="a shared multicolour kernel expands every binary foreground role",
            common_notions=[{"name": "binary_kernel_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting helpers.
# ---------------------------------------------------------------------------


def _self_replication_analysis(source: Grid, target: Grid):
    source = grid(source)
    target = grid(target)
    height, width = _shape(source)
    if _shape(target) != (height * height, width * width):
        raise Inapplicable("self-replication output shape mismatch")
    mask = [[False for _ in range(width)] for _ in range(height)]
    blank_colours = set()
    for r in range(height):
        for c in range(width):
            block = _block(target, r, c, (height, width))
            if block == source:
                mask[r][c] = True
            else:
                colours = _palette(block)
                if len(colours) != 1:
                    raise Inapplicable("macro block is neither source copy nor uniform blank")
                blank_colours.update(colours)
    if len(blank_colours) != 1:
        raise Inapplicable("self-replication blank colour is not unique")
    return tuple(tuple(row) for row in mask), next(iter(blank_colours))


def _fit_macro_dihedral(pairs, *, max_templates: int = 4096):
    macro_shape = None
    possibilities = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        if target_height % source_height or target_width % source_width:
            return []
        rows = target_height // source_height
        cols = target_width // source_width
        if rows < 2 or cols < 2:
            return []
        if macro_shape is None:
            macro_shape = (rows, cols)
        elif macro_shape != (rows, cols):
            return []
        local = []
        for r in range(rows):
            local_row = []
            for c in range(cols):
                names = _possible_transforms(source, _block(target, r, c, (source_height, source_width)))
                if not names:
                    return []
                local_row.append(names)
            local.append(local_row)
        if possibilities is None:
            possibilities = local
        else:
            for r in range(rows):
                for c in range(cols):
                    possibilities[r][c] &= local[r][c]
                    if not possibilities[r][c]:
                        return []
    if macro_shape is None or possibilities is None:
        return []
    choices = [sorted(possibilities[r][c]) for r in range(macro_shape[0]) for c in range(macro_shape[1])]
    total = 1
    for values in choices:
        total *= len(values)
        if total > max_templates:
            return []
    result = []
    for values in product(*choices):
        if len(set(values)) < 2:
            continue
        template = tuple(
            tuple(values[r * macro_shape[1]:(r + 1) * macro_shape[1]])
            for r in range(macro_shape[0])
        )
        result.append(MacroDihedralWallpaperProgram(template))
    return result


def _fit_self_replication(pairs, *, require_role_variation: bool):
    analyses = []
    blank_colour = None
    for source, target in pairs:
        mask, blank = _self_replication_analysis(source, target)
        if blank_colour is None:
            blank_colour = blank
        elif blank_colour != blank:
            return []
        analyses.append((grid(source), mask))
    result = []

    # Frequency selectors.
    for selector_kind in ("unique_max_frequency", "unique_min_frequency"):
        selected_colours = []
        valid = True
        for source, mask in analyses:
            counts = Counter(cell for row in source for cell in row)
            target = max(counts.values()) if selector_kind == "unique_max_frequency" else min(counts.values())
            winners = [colour for colour, count in counts.items() if count == target]
            if len(winners) != 1:
                valid = False
                break
            selected = winners[0]
            expected = tuple(tuple(cell == selected for cell in row) for row in source)
            if expected != mask:
                valid = False
                break
            selected_colours.append(selected)
        if valid and (not require_role_variation or len(set(selected_colours)) >= 2):
            result.append(SelfReplicationProgram(selector_kind, None, int(blank_colour)))

    # Fixed semantic colour.
    common = None
    signatures = []
    for source, mask in analyses:
        selected = {source[r][c] for r in range(len(source)) for c in range(len(source[0])) if mask[r][c]}
        if len(selected) != 1:
            common = set()
            break
        colour = next(iter(selected))
        expected = tuple(tuple(cell == colour for cell in row) for row in source)
        if expected != mask:
            common = set()
            break
        common = {colour} if common is None else common & {colour}
        signatures.append(mask)
    if common and (not require_role_variation or len({_serial(signature) for signature in signatures}) >= 2):
        for colour in sorted(common):
            result.append(SelfReplicationProgram("fixed_colour", int(colour), int(blank_colour)))

    # Unique monochrome row/column; orientation and index are input-derived.
    line_signatures = []
    valid = True
    for source, mask in analyses:
        height, width = _shape(source)
        matches = []
        for r, row in enumerate(source):
            if len(set(row)) == 1:
                expected = tuple(tuple(rr == r for _ in range(width)) for rr in range(height))
                if expected == mask:
                    matches.append(("row", r, row[0]))
        for c in range(width):
            column = tuple(source[r][c] for r in range(height))
            if len(set(column)) == 1:
                expected = tuple(tuple(cc == c for cc in range(width)) for _ in range(height))
                if expected == mask:
                    matches.append(("column", c, column[0]))
        if len(matches) != 1:
            valid = False
            break
        line_signatures.append(matches[0])
    if valid and (not require_role_variation or len(set(line_signatures)) >= 2):
        result.append(SelfReplicationProgram("unique_monochrome_line", None, int(blank_colour)))

    return result


def _fit_binary_complement(pairs):
    backgrounds = None
    for source, target in pairs:
        source = grid(source)
        colours = sorted(_palette(source))
        if len(colours) != 2:
            return []
        local = set()
        for background in colours:
            program = BinaryComplementKroneckerProgram(background)
            try:
                if program.predict(source) == grid(target):
                    local.add(background)
            except Inapplicable:
                continue
        if not local:
            return []
        backgrounds = local if backgrounds is None else backgrounds & local
    return [BinaryComplementKroneckerProgram(background) for background in sorted(backgrounds or ())]


def _fit_binary_kernel(pairs, *, require_role_variation: bool):
    candidates = None
    masks = []
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        colours = sorted(_palette(source))
        if len(colours) != 2:
            return []
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        if target_height % source_height or target_width % source_width:
            return []
        kernel_height = target_height // source_height
        kernel_width = target_width // source_width
        local = set()
        for background in colours:
            foreground = next(colour for colour in colours if colour != background)
            foreground_blocks = []
            background_blocks = []
            for r in range(source_height):
                for c in range(source_width):
                    block = _block(target, r, c, (kernel_height, kernel_width))
                    if source[r][c] == foreground:
                        foreground_blocks.append(block)
                    else:
                        background_blocks.append(block)
            if not foreground_blocks or not background_blocks:
                continue
            if not all(block == _uniform_block((kernel_height, kernel_width), background) for block in background_blocks):
                continue
            kernel = foreground_blocks[0]
            if not all(block == kernel for block in foreground_blocks):
                continue
            if len(_palette(kernel)) < 2:
                continue
            local.add((background, foreground, kernel))
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        masks.append(tuple(tuple(cell == colours[1] for cell in row) for row in source))
    if require_role_variation and len({_serial(mask) for mask in masks}) < 2:
        return []
    return [BinaryKernelSubstitutionProgram(background, foreground, kernel) for background, foreground, kernel in sorted(candidates or (), key=repr)]


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, MacroDihedralWallpaperProgram):
        return _shape(source), tuple(sorted(_palette(source))), _serial(source)
    if isinstance(program, SelfReplicationProgram):
        return analysis["relation"], analysis["mask"]
    if isinstance(program, BinaryComplementKroneckerProgram):
        return analysis["foreground_colour"], analysis["foreground_mask"]
    if isinstance(program, BinaryKernelSubstitutionProgram):
        return analysis["foreground_cells"], _shape(source)
    raise Inapplicable("unknown programme")


def fit_expansion_grammar_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
    max_macro_templates: int = 4096,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    selected = []

    for kind, fitter in (
        ("macro_dihedral_wallpaper", lambda: _fit_macro_dihedral(pairs, max_templates=max_macro_templates)),
        ("cell_relation_self_replication", lambda: _fit_self_replication(pairs, require_role_variation=require_role_variation)),
        ("binary_complement_kronecker", lambda: _fit_binary_complement(pairs)),
        ("binary_kernel_substitution", lambda: _fit_binary_kernel(pairs, require_role_variation=require_role_variation)),
    ):
        if allowed is not None and kind not in allowed:
            continue
        try:
            selected.extend(fitter())
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    exact = []
    for program in selected:
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            exact.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    unique = {program.schema_key: program for program in exact}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


# ---------------------------------------------------------------------------
# Inference.
# ---------------------------------------------------------------------------


def infer_expansion_grammar(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_expansion_grammar_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        groups[predictions].append(program.describe(pairs))
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "self_similar_expansion_grammar": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "macro_dihedral_wallpaper":
        return MacroDihedralWallpaperProgram(tuple(tuple(row) for row in parameters["template"]))
    if kind == "cell_relation_self_replication":
        return SelfReplicationProgram(
            str(parameters["selector_kind"]),
            parameters.get("selector_value"),
            int(parameters["blank_colour"]),
        )
    if kind == "binary_complement_kronecker":
        return BinaryComplementKroneckerProgram(int(parameters["background_colour"]))
    if kind == "binary_kernel_substitution":
        return BinaryKernelSubstitutionProgram(
            int(parameters["background_colour"]),
            int(parameters["foreground_colour"]),
            tuple(tuple(int(cell) for cell in row) for row in parameters["kernel"]),
        )
    raise Inapplicable("unknown expansion-grammar schema")


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    passed = bool(rows) and all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _macro_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        colours = sorted(_palette(source))
        old = colours[0]
        fresh = _fresh_colour(source, (old,))
        recoloured_source = _replace_colour(source, old, fresh)
        colour_equivariant = program.predict(recoloured_source) == _replace_colour(original, old, fresh)
        nontrivial_template = len({name for row in program.template for name in row}) >= 2
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "nontrivial_template": nontrivial_template,
        })
    return _counterfactual_result(program.kind, rows)


def _self_replication_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        relation_necessary = False
        colour_equivariant = True

        if program.selector_kind in ("unique_max_frequency", "unique_min_frequency"):
            selected = analysis["relation"]["selected_colour"]
            fresh = _fresh_colour(source, (selected,))
            recoloured = _replace_colour(source, selected, fresh)
            try:
                colour_equivariant = program.predict(recoloured) == _replace_colour(original, selected, fresh)
            except Inapplicable:
                colour_equivariant = False
            modified = _array(source)
            changed = False
            for r, row in enumerate(analysis["mask"]):
                for c, flag in enumerate(row):
                    if flag:
                        replacement = next(colour for colour in sorted(_palette(source)) if colour != selected)
                        modified[r][c] = replacement
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif program.selector_kind == "fixed_colour":
            selected = int(program.selector_value)
            modified = _array(source)
            changed = False
            replacement = next(colour for colour in sorted(_palette(source)) if colour != selected)
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell == selected:
                        modified[r][c] = replacement
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif program.selector_kind == "unique_monochrome_line":
            modified = _array(source)
            relation = analysis["relation"]
            fresh = _fresh_colour(source)
            if relation["orientation"] == "row":
                modified[relation["line_index"]][0] = fresh
            else:
                modified[0][relation["line_index"]] = fresh
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True
        else:
            raise Inapplicable("unknown selector")

        rows.append({
            "demonstration": index,
            "relation_necessary": relation_necessary,
            "colour_equivariant": colour_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _binary_complement_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        foreground = analysis["foreground_colour"]
        fresh = _fresh_colour(source, (foreground,))
        recoloured = _replace_colour(source, foreground, fresh)
        recolour_equivariant = program.predict(recoloured) == _replace_colour(original, foreground, fresh)
        modified = _array(source)
        changed = False
        for r, row in enumerate(source):
            for c, cell in enumerate(row):
                if cell == foreground:
                    modified[r][c] = program.background_colour
                    changed = True
                    break
            if changed:
                break
        try:
            mask_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            mask_necessary = True
        rows.append({
            "demonstration": index,
            "recolour_equivariant": recolour_equivariant,
            "mask_necessary": mask_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _binary_kernel_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        modified = _array(source)
        changed = False
        for r, row in enumerate(source):
            for c, cell in enumerate(row):
                if cell == program.foreground_colour:
                    modified[r][c] = program.background_colour
                    changed = True
                    break
            if changed:
                break
        try:
            foreground_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            foreground_necessary = True
        nonuniform_kernel = len(_palette(program.kernel)) >= 2
        rows.append({
            "demonstration": index,
            "foreground_necessary": foreground_necessary,
            "nonuniform_kernel": nonuniform_kernel,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_validation(program, pairs):
    if isinstance(program, MacroDihedralWallpaperProgram):
        return _macro_counterfactuals(program, pairs)
    if isinstance(program, SelfReplicationProgram):
        return _self_replication_counterfactuals(program, pairs)
    if isinstance(program, BinaryComplementKroneckerProgram):
        return _binary_complement_counterfactuals(program, pairs)
    if isinstance(program, BinaryKernelSubstitutionProgram):
        return _binary_kernel_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


# ---------------------------------------------------------------------------
# Validation.
# ---------------------------------------------------------------------------


def _macro_transform_possibilities(pairs):
    """Return per-macro-cell transform choices without enumerating templates."""
    macro_shape = None
    possibilities = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        if target_height % source_height or target_width % source_width:
            raise Inapplicable("macro dimensions are not integral")
        rows = target_height // source_height
        cols = target_width // source_width
        if rows < 2 or cols < 2:
            raise Inapplicable("macro template is too small")
        if macro_shape is None:
            macro_shape = (rows, cols)
        elif macro_shape != (rows, cols):
            raise Inapplicable("macro template shape changes")
        local = []
        for r in range(rows):
            local_row = []
            for c in range(cols):
                names = _possible_transforms(source, _block(target, r, c, (source_height, source_width)))
                if not names:
                    raise Inapplicable("macro block is not a source transform")
                local_row.append(names)
            local.append(local_row)
        if possibilities is None:
            possibilities = local
        else:
            for r in range(rows):
                for c in range(cols):
                    possibilities[r][c] &= local[r][c]
                    if not possibilities[r][c]:
                        raise Inapplicable("macro transform roles disagree")
    if macro_shape is None or possibilities is None:
        raise Inapplicable("missing macro evidence")
    return macro_shape, possibilities


def _validate_macro_fold(remaining_pairs, demonstration, tests, expected_tuple, held_index):
    """Validate one macro fold symbolically, avoiding exponential enumeration."""
    try:
        macro_shape, possibilities = _macro_transform_possibilities(remaining_pairs)
        held_source = grid(demonstration["input"])
        held_target = grid(demonstration["output"])
        source_height, source_width = _shape(held_source)
        if _shape(held_target) != (macro_shape[0] * source_height, macro_shape[1] * source_width):
            raise Inapplicable("held macro shape mismatch")
        for r in range(macro_shape[0]):
            for c in range(macro_shape[1]):
                held_names = _possible_transforms(
                    held_source,
                    _block(held_target, r, c, (source_height, source_width)),
                )
                possibilities[r][c] &= held_names
                if not possibilities[r][c]:
                    raise Inapplicable("no held-exact macro role")

        program_count = 1
        for row in possibilities:
            for names in row:
                program_count *= len(names)

        consensus_predictions = []
        ambiguous = False
        for case in tests:
            source = grid(case["input"])
            macro_rows = []
            for r in range(macro_shape[0]):
                blocks = []
                for c in range(macro_shape[1]):
                    block_predictions = set()
                    for name in possibilities[r][c]:
                        try:
                            block_predictions.add(_transform(source, name))
                        except Inapplicable:
                            continue
                    if not block_predictions:
                        raise Inapplicable("no valid transform for unseen source")
                    if len(block_predictions) != 1:
                        ambiguous = True
                        break
                    blocks.append(next(iter(block_predictions)))
                if ambiguous:
                    break
                macro_rows.append(_concat_horizontal(blocks))
            if ambiguous:
                break
            consensus_predictions.append(_concat_vertical(macro_rows))

        prediction_tuple = tuple(consensus_predictions) if not ambiguous else None
        stable = prediction_tuple == expected_tuple if prediction_tuple is not None else False
        return {
            "held_index": held_index,
            "status": "unique" if stable else "ambiguous" if ambiguous else "no_fit",
            "refitted_programs": program_count,
            "held_exact_programs": program_count,
            "held_exact_prediction_groups": 1 if prediction_tuple is not None else 2 if ambiguous else 0,
            "invalid_programs": 0,
            "held_example_exact": True,
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_symbolic_consensus",
        }
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
        return {
            "held_index": held_index,
            "status": "no_fit",
            "refitted_programs": 0,
            "held_exact_programs": 0,
            "held_exact_prediction_groups": 0,
            "invalid_programs": 0,
            "held_example_exact": False,
            "test_prediction_stable": False,
            "validation_protocol": "held_exact_symbolic_consensus",
        }


def validate_expansion_grammar(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (item["input"], item["output"])
            for index, item in enumerate(clean["train"])
            if index != held
        )
        expected_tuple = tuple(grid(prediction) for prediction in expected)
        if allowed_kinds == ("macro_dihedral_wallpaper",):
            folds.append(_validate_macro_fold(
                remaining_pairs, demonstration, clean["test"], expected_tuple, held
            ))
            continue

        refitted = fit_expansion_grammar_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(demonstration["input"]) != grid(demonstration["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, test_predictions in held_exact:
            groups[test_predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def expansion_grammar_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_expansion_grammar_programs(pairs)}))


infer = infer_expansion_grammar
validate = validate_expansion_grammar
