"""LUCA V131: learned stage algebra.

The family factors ARC solutions into reusable stages::

    scene -> instruction/relation -> role binding -> local operator -> emission

Schemas
-------
* ``witnessed_shape_codebook``: a binary instruction shape names an output
  label, which is emitted directly or transferred to a payload;
* ``self_colour_corner_group_selection``: four homologous corner markers bind
  a central payload and the marker/payload colour agreement selects one group;
* ``dotted_path_motif_selection``: a checker-like instruction and a dotted
  tree select the ring motif reached by the simplest, then longest, path.

No task identifier, official test target, or stored demonstration coordinate is
available during inference. Codebook validation explicitly distinguishes
redundant-witness leave-one-out folds from singleton direct code witnesses.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from itertools import combinations
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_learned_stage_algebra"
LANGUAGE = "spinoza_learned_stage_algebra_v1"
SCHEMA_VERSION = "learned_stage_algebra_schema_v1"


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {int(cell) for row in grid(value) for cell in row}


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    modes = [int(colour) for colour, count in counts.items() if count == best]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    return (
        min(row for row, _ in cells),
        min(col for _, col in cells),
        max(row for row, _ in cells),
        max(col for _, col in cells),
    )


def _crop(value: Grid, bbox) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = bbox
    return tuple(tuple(value[row][col] for col in range(c0, c1 + 1)) for row in range(r0, r1 + 1))


def _normalised_binary(cells):
    cells = tuple(cells)
    r0, c0, r1, c1 = _bbox(cells)
    occupied = set(cells)
    return tuple(
        tuple(1 if (row, col) in occupied else 0 for col in range(c0, c1 + 1))
        for row in range(r0, r1 + 1)
    )


def _binary_signature_for_colour(value: Grid, colour: int):
    value = grid(value)
    cells = [(row, col) for row, values in enumerate(value) for col, cell in enumerate(values) if cell == colour]
    if not cells:
        raise Inapplicable("instruction colour is absent")
    return _normalised_binary(cells)


def _binary_signature_nonbackground(value: Grid, background: int):
    value = grid(value)
    cells = [(row, col) for row, values in enumerate(value) for col, cell in enumerate(values) if cell != background]
    if not cells:
        raise Inapplicable("instruction support is empty")
    return _normalised_binary(cells)


def _mask_to_json(mask):
    return [list(row) for row in mask]


def _mapping_tuple(mapping):
    return tuple(sorted(((signature, int(label)) for signature, label in mapping.items()), key=lambda item: _serial(item[0])))


def _mapping_dict(mapping_tuple):
    return {signature: int(label) for signature, label in mapping_tuple}


def _candidate_backgrounds(pairs):
    candidates = None
    for source, _ in pairs:
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_unique_mode(source))
        except Inapplicable:
            pass
        candidates = values if candidates is None else candidates & values
    return sorted(candidates or ())


def _dirs(connectivity=4):
    values = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        values += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return values


def _components_same_colour(value: Grid, *, background: int, connectivity: int = 4):
    value = grid(value)
    height, width = _shape(value)
    seen = set()
    components = []
    for row in range(height):
        for col in range(width):
            if (row, col) in seen or value[row][col] == background:
                continue
            colour = int(value[row][col])
            stack = [(row, col)]
            seen.add((row, col))
            cells = []
            while stack:
                current = stack.pop()
                cells.append(current)
                for dr, dc in _dirs(connectivity):
                    nr, nc = current[0] + dr, current[1] + dc
                    if not (0 <= nr < height and 0 <= nc < width):
                        continue
                    if (nr, nc) in seen or value[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            box = _bbox(cells)
            components.append({
                "colour": colour,
                "cells": tuple(sorted(cells)),
                "bbox": box,
                "area": len(cells),
                "mask": _normalised_binary(cells),
                "center2": (box[0] + box[2], box[1] + box[3]),
            })
    components.sort(key=lambda item: item["bbox"])
    return components


def _rotate90(mask):
    return tuple(tuple(mask[len(mask) - 1 - row][col] for row in range(len(mask))) for col in range(len(mask[0])))


def _flip_horizontal(mask):
    return tuple(tuple(reversed(row)) for row in mask)


def _d4_masks(mask):
    result = []
    current = mask
    for _ in range(4):
        result.append(current)
        result.append(_flip_horizontal(current))
        current = _rotate90(current)
    unique = []
    seen = set()
    for item in result:
        key = _serial(item)
        if key not in seen:
            seen.add(key)
            unique.append(item)
    return tuple(unique)


def _canonical_d4(mask):
    return min((_serial(item) for item in _d4_masks(mask)))


def _law(program, *, parameters, definitions, propositions, corollary, common_notions, validation_protocol=None):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "validation_protocol": validation_protocol or "held_exact_consensus_with_counterfactual_pruning",
        },
    }


# ---------------------------------------------------------------------------
# Witnessed binary-shape codebooks.
# ---------------------------------------------------------------------------


def _split_equal_panels(value: Grid, background: int):
    value = grid(value)
    height, width = _shape(value)
    cells = [(row, col) for row in range(height) for col in range(width) if value[row][col] != background]
    if not cells:
        raise Inapplicable("panel scene is empty")
    r0, c0, r1, c1 = _bbox(cells)
    separator_cols = [
        col for col in range(c0, c1 + 1)
        if all(value[row][col] == background for row in range(r0, r1 + 1))
    ]
    separator_rows = [
        row for row in range(r0, r1 + 1)
        if all(value[row][col] == background for col in range(c0, c1 + 1))
    ]
    candidates = []
    for col in separator_cols:
        left_width = col - c0
        right_width = c1 - col
        if left_width <= 0 or left_width != right_width:
            continue
        first = tuple(tuple(value[row][c] for c in range(c0, col)) for row in range(r0, r1 + 1))
        second = tuple(tuple(value[row][c] for c in range(col + 1, c1 + 1)) for row in range(r0, r1 + 1))
        candidates.append(("horizontal", first, second))
    for row in separator_rows:
        top_height = row - r0
        bottom_height = r1 - row
        if top_height <= 0 or top_height != bottom_height:
            continue
        first = tuple(tuple(value[r][col] for col in range(c0, c1 + 1)) for r in range(r0, row))
        second = tuple(tuple(value[r][col] for col in range(c0, c1 + 1)) for r in range(row + 1, r1 + 1))
        candidates.append(("vertical", first, second))
    if len(candidates) != 1:
        raise Inapplicable("scene does not define one equal two-panel split")
    return candidates[0]


@dataclass(frozen=True)
class WitnessedShapeCodebookProgram:
    mode: str
    background: int
    mapping: tuple
    instruction_colour: int | None = None
    target_colour: int | None = None
    panel_axis: str | None = None
    instruction_index: int = 0
    kind: str = "witnessed_shape_codebook"

    @property
    def schema_key(self):
        return (
            self.kind, self.mode, self.background, self.mapping,
            self.instruction_colour, self.target_colour, self.panel_axis, self.instruction_index,
        )

    @property
    def description_length(self):
        return 4 + len(self.mapping)

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def _label(self, signature):
        mapping = _mapping_dict(self.mapping)
        if signature not in mapping:
            raise Inapplicable("instruction shape is not witnessed in the codebook")
        return mapping[signature]

    def instruction_signature(self, value: Grid):
        value = grid(value)
        if self.mode == "scalar":
            palette = _palette(value)
            if self.background not in palette or len(palette) != 2:
                raise Inapplicable("scalar codebook requires one foreground class")
            return _binary_signature_nonbackground(value, self.background)
        if self.mode == "full_recolour":
            if self.instruction_colour is None:
                raise Inapplicable("missing instruction colour")
            return _binary_signature_for_colour(value, self.instruction_colour)
        if self.mode == "paired_crop":
            axis, first, second = _split_equal_panels(value, self.background)
            if axis != self.panel_axis:
                raise Inapplicable("panel axis changed")
            panels = (first, second)
            return _binary_signature_nonbackground(panels[self.instruction_index], self.background)
        raise Inapplicable("unknown codebook mode")

    def analyse(self, value: Grid):
        value = grid(value)
        signature = self.instruction_signature(value)
        label = self._label(signature)
        if self.mode == "scalar":
            prediction = ((label,),)
            return {"signature": signature, "label": label, "prediction": prediction}
        if self.mode == "full_recolour":
            if self.instruction_colour is None or self.target_colour is None:
                raise Inapplicable("missing colour roles")
            palette = _palette(value)
            if self.background not in palette or self.instruction_colour not in palette or self.target_colour not in palette:
                raise Inapplicable("required colour role is absent")
            prediction = tuple(
                tuple(label if cell == self.target_colour else self.background for cell in row)
                for row in value
            )
            if sum(cell == self.target_colour for row in value for cell in row) <= sum(cell == self.instruction_colour for row in value for cell in row):
                raise Inapplicable("target support is not larger than instruction support")
            return {"signature": signature, "label": label, "prediction": prediction}
        if self.mode == "paired_crop":
            axis, first, second = _split_equal_panels(value, self.background)
            if axis != self.panel_axis:
                raise Inapplicable("panel axis changed")
            panels = (first, second)
            target = panels[1 - self.instruction_index]
            prediction = tuple(
                tuple(label if cell != self.background else self.background for cell in row)
                for row in target
            )
            return {"signature": signature, "label": label, "prediction": prediction}
        raise Inapplicable("unknown codebook mode")

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "mode": self.mode,
                "background": self.background,
                "mapping": [
                    {"signature": _mask_to_json(signature), "label": label}
                    for signature, label in self.mapping
                ],
                "instruction_colour": self.instruction_colour,
                "target_colour": self.target_colour,
                "panel_axis": self.panel_axis,
                "instruction_index": self.instruction_index,
            },
            definitions={
                "instruction_shape": "translation-normalised binary support",
                "codebook": "consistent instruction-shape to label relation",
                "payload": "direct scalar, full-size object support, or paired panel",
            },
            propositions=[
                "The instruction signature, not its absolute position, determines the output label.",
                "Every unseen instruction signature must be witnessed in the training codebook.",
                "The same label may be emitted directly or transferred to a payload role.",
            ],
            corollary="Apply the witnessed code and emit or transfer its label.",
            common_notions=["binary shape", "instruction code", "payload transfer", "label emission"],
            validation_protocol="witnessed_codebook_with_redundant_lodo",
        )


def _consistent_codebook(rows):
    mapping = {}
    counts = Counter()
    for signature, label in rows:
        if signature in mapping and mapping[signature] != label:
            raise Inapplicable("instruction signature has conflicting labels")
        mapping[signature] = int(label)
        counts[signature] += 1
    if len(mapping) < 2 or len(set(mapping.values())) < 2:
        raise Inapplicable("codebook lacks structural diversity")
    if max(counts.values(), default=0) < 2:
        raise Inapplicable("codebook lacks a redundant witness")
    return mapping, counts


def _fit_scalar_codebook(pairs):
    if len(pairs) < 5:
        return []
    programmes = []
    for background in _candidate_backgrounds(pairs):
        rows = []
        valid = True
        for source, target in pairs:
            sh, sw = _shape(source)
            if sh > 5 or sw > 5 or _shape(target) != (1, 1) or len(_palette(source)) != 2:
                valid = False
                break
            try:
                signature = _binary_signature_nonbackground(source, background)
            except Inapplicable:
                valid = False
                break
            rows.append((signature, int(grid(target)[0][0])))
        if not valid:
            continue
        try:
            mapping, _ = _consistent_codebook(rows)
        except Inapplicable:
            continue
        program = WitnessedShapeCodebookProgram("scalar", background, _mapping_tuple(mapping))
        if all(program.predict(source) == target for source, target in pairs):
            programmes.append(program)
    return programmes


def _fit_full_codebook(pairs):
    if len(pairs) < 4:
        return []
    programmes = []
    for background in _candidate_backgrounds(pairs):
        rows = []
        roles = []
        valid = True
        for source, target in pairs:
            if _shape(source) != _shape(target) or len(_palette(source)) != 3:
                valid = False
                break
            target_grid = grid(target)
            target_nonbg = {(r, c) for r, values in enumerate(target_grid) for c, cell in enumerate(values) if cell != background}
            labels = {target_grid[r][c] for r, c in target_nonbg}
            if not target_nonbg or len(labels) != 1 or any(target_grid[r][c] != background for r in range(len(target_grid)) for c in range(len(target_grid[0])) if (r, c) not in target_nonbg):
                valid = False
                break
            label = int(next(iter(labels)))
            source_grid = grid(source)
            nonbg_colours = sorted(_palette(source) - {background})
            matching = []
            for colour in nonbg_colours:
                support = {(r, c) for r, values in enumerate(source_grid) for c, cell in enumerate(values) if cell == colour}
                if support == target_nonbg:
                    matching.append(colour)
            if len(matching) != 1:
                valid = False
                break
            target_colour = int(matching[0])
            instruction_colour = int(next(colour for colour in nonbg_colours if colour != target_colour))
            try:
                signature = _binary_signature_for_colour(source, instruction_colour)
            except Inapplicable:
                valid = False
                break
            if sum(cell == target_colour for row in source_grid for cell in row) <= sum(cell == instruction_colour for row in source_grid for cell in row):
                valid = False
                break
            rows.append((signature, label))
            roles.append((instruction_colour, target_colour))
        if not valid or len(set(roles)) != 1:
            continue
        try:
            mapping, _ = _consistent_codebook(rows)
        except Inapplicable:
            continue
        instruction_colour, target_colour = roles[0]
        program = WitnessedShapeCodebookProgram(
            "full_recolour", background, _mapping_tuple(mapping),
            instruction_colour=instruction_colour, target_colour=target_colour,
        )
        if all(program.predict(source) == target for source, target in pairs):
            programmes.append(program)
    return programmes


def _fit_paired_codebook(pairs):
    if len(pairs) < 5:
        return []
    programmes = []
    for background in _candidate_backgrounds(pairs):
        for instruction_index in (0, 1):
            rows = []
            axes = []
            valid = True
            for source, target in pairs:
                if len(_palette(source)) != 2:
                    valid = False
                    break
                try:
                    axis, first, second = _split_equal_panels(source, background)
                except Inapplicable:
                    valid = False
                    break
                panels = (first, second)
                if _shape(target) != _shape(panels[1 - instruction_index]):
                    valid = False
                    break
                signature = _binary_signature_nonbackground(panels[instruction_index], background)
                target_panel = panels[1 - instruction_index]
                output = grid(target)
                target_mask = tuple(tuple(1 if cell != background else 0 for cell in row) for row in target_panel)
                output_mask = tuple(tuple(1 if cell != background else 0 for cell in row) for row in output)
                output_colours = _palette(output) - {background}
                if target_mask != output_mask or len(output_colours) != 1:
                    valid = False
                    break
                rows.append((signature, int(next(iter(output_colours)))))
                axes.append(axis)
            if not valid or len(set(axes)) != 1:
                continue
            try:
                mapping, _ = _consistent_codebook(rows)
            except Inapplicable:
                continue
            program = WitnessedShapeCodebookProgram(
                "paired_crop", background, _mapping_tuple(mapping),
                panel_axis=axes[0], instruction_index=instruction_index,
            )
            if all(program.predict(source) == target for source, target in pairs):
                programmes.append(program)
    return programmes


# ---------------------------------------------------------------------------
# Four-corner marker groups.
# ---------------------------------------------------------------------------


def _corner_groups(value: Grid):
    value = grid(value)
    background = _unique_mode(value)
    marker_components = _components_same_colour(value, background=background, connectivity=4)
    payload_components = _components_same_colour(value, background=background, connectivity=8)
    buckets = defaultdict(list)
    for component in marker_components:
        r0, c0, r1, c1 = component["bbox"]
        height, width = r1 - r0 + 1, c1 - c0 + 1
        if 3 <= component["area"] <= 12 and height <= 5 and width <= 5:
            buckets[(component["colour"], _canonical_d4(component["mask"]))].append(component)
    groups = []
    for (marker_colour, _), candidates in buckets.items():
        if len(candidates) < 4:
            continue
        by_center = {candidate["center2"]: candidate for candidate in candidates}
        row_centres = sorted({row for row, _ in by_center})
        col_centres = sorted({col for _, col in by_center})
        for top, bottom in combinations(row_centres, 2):
            for left, right in combinations(col_centres, 2):
                centres = ((top, left), (top, right), (bottom, left), (bottom, right))
                if not all(center in by_center for center in centres):
                    continue
                markers = tuple(by_center[center] for center in centres)
                outer = (
                    min(item["bbox"][0] for item in markers),
                    min(item["bbox"][1] for item in markers),
                    max(item["bbox"][2] for item in markers),
                    max(item["bbox"][3] for item in markers),
                )
                payloads = []
                marker_cells = set().union(*(set(marker["cells"]) for marker in markers))
                for component in payload_components:
                    if marker_cells & set(component["cells"]):
                        continue
                    r0, c0, r1, c1 = component["bbox"]
                    if not (outer[0] <= r0 and outer[1] <= c0 and r1 <= outer[2] and c1 <= outer[3]):
                        continue
                    cr2, cc2 = component["center2"]
                    if abs(2 * cr2 - (top + bottom)) <= 2 and abs(2 * cc2 - (left + right)) <= 2:
                        payloads.append(component)
                if len(payloads) == 1:
                    groups.append({
                        "marker_colour": int(marker_colour),
                        "markers": markers,
                        "payload": payloads[0],
                        "outer": outer,
                    })
    unique = {}
    for item in groups:
        key = (item["marker_colour"], item["payload"]["bbox"], item["outer"])
        unique[key] = item
    return background, tuple(unique.values())


@dataclass(frozen=True)
class SelfColourCornerGroupProgram:
    kind: str = "self_colour_corner_group_selection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        background, groups = _corner_groups(value)
        if len(groups) < 2:
            raise Inapplicable("insufficient corner-group alternatives")
        selected = [item for item in groups if item["marker_colour"] == item["payload"]["colour"]]
        if len(selected) != 1:
            raise Inapplicable("self-colour group is not unique")
        item = selected[0]
        prediction = _crop(value, item["payload"]["bbox"])
        return {"background": background, "groups": groups, "selected": item, "prediction": prediction}

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={},
            definitions={
                "corner_group": "four D4-homologous markers at rectangle corners",
                "payload": "one component centred inside the marker rectangle",
                "self_colour_relation": "marker colour equals payload colour",
            },
            propositions=[
                "Every candidate group binds four homologous corner markers and one central payload.",
                "Exactly one group satisfies marker/payload colour agreement.",
                "The selected payload is emitted with its local background crop.",
            ],
            corollary="Crop the central payload of the unique self-colour corner group.",
            common_notions=["homology", "rectangle corners", "centrality", "colour agreement"],
        )


# ---------------------------------------------------------------------------
# Dotted-tree path motif selection.
# ---------------------------------------------------------------------------


def _dense_3x3_motifs(value: Grid, background: int):
    value = grid(value)
    height, width = _shape(value)
    motifs = []
    for row in range(height - 2):
        for col in range(width - 2):
            crop = tuple(tuple(value[r][c] for c in range(col, col + 3)) for r in range(row, row + 3))
            if not all(cell != background for values in crop for cell in values):
                continue
            outer = (crop[0][0], crop[0][1], crop[0][2], crop[1][0], crop[1][2], crop[2][0], crop[2][1], crop[2][2])
            ring = len(set(outer)) == 1 and crop[1][1] != outer[0]
            motifs.append({"bbox": (row, col, row + 2, col + 2), "center": (row + 1, col + 1), "crop": crop, "ring": ring})
    return tuple(motifs)


def _tree_path(adjacency, start, goal):
    queue = deque([start])
    parent = {start: None}
    while queue:
        current = queue.popleft()
        if current == goal:
            break
        for neighbour in adjacency[current]:
            if neighbour not in parent:
                parent[neighbour] = current
                queue.append(neighbour)
    if goal not in parent:
        raise Inapplicable("ring motif is disconnected from instruction")
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent[current]
    return tuple(reversed(path))


def _colour_runs(sequence):
    return 0 if not sequence else 1 + sum(sequence[i] != sequence[i - 1] for i in range(1, len(sequence)))


@dataclass(frozen=True)
class DottedPathMotifProgram:
    kind: str = "dotted_path_motif_selection"

    @property
    def schema_key(self):
        return (self.kind, "min_runs_then_max_distance")

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        background = _unique_mode(value)
        motifs = _dense_3x3_motifs(value, background)
        instructions = [motif for motif in motifs if not motif["ring"]]
        rings = [motif for motif in motifs if motif["ring"]]
        if len(instructions) != 1 or len(rings) < 3:
            raise Inapplicable("scene lacks one instruction and at least three ring alternatives")
        instruction = instructions[0]
        parity = (instruction["center"][0] % 2, instruction["center"][1] % 2)
        nodes = {
            (row, col)
            for row, values in enumerate(value)
            for col, cell in enumerate(values)
            if cell != background and (row % 2, col % 2) == parity
        }
        if instruction["center"] not in nodes or any(ring["center"] not in nodes for ring in rings):
            raise Inapplicable("motif centre is absent from the dotted graph")
        adjacency = {node: [] for node in nodes}
        edges = 0
        for row, col in nodes:
            for dr, dc in ((2, 0), (-2, 0), (0, 2), (0, -2)):
                neighbour = (row + dr, col + dc)
                if neighbour in nodes:
                    adjacency[(row, col)].append(neighbour)
            edges += len(adjacency[(row, col)])
        edges //= 2
        # Conservative gate: the dotted graph must be one tree, giving a unique path.
        seen = set()
        queue = deque([instruction["center"]])
        while queue:
            current = queue.popleft()
            if current in seen:
                continue
            seen.add(current)
            queue.extend(adjacency[current])
        if seen != nodes or edges != len(nodes) - 1:
            raise Inapplicable("dotted graph is not a connected tree")
        candidates = []
        for ring in rings:
            path = _tree_path(adjacency, instruction["center"], ring["center"])
            colours = tuple(int(value[row][col]) for row, col in path)
            candidates.append({
                "ring": ring,
                "path": path,
                "runs": _colour_runs(colours),
                "distance": len(path) - 1,
            })
        best_runs = min(item["runs"] for item in candidates)
        filtered = [item for item in candidates if item["runs"] == best_runs]
        best_distance = max(item["distance"] for item in filtered)
        selected = [item for item in filtered if item["distance"] == best_distance]
        if len(selected) != 1:
            raise Inapplicable("path relation does not select one motif")
        prediction = selected[0]["ring"]["crop"]
        return {
            "background": background,
            "instruction": instruction,
            "rings": rings,
            "nodes": nodes,
            "selected": selected[0],
            "prediction": prediction,
        }

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"selector": "minimum_colour_runs_then_maximum_graph_distance"},
            definitions={
                "instruction": "the unique dense 3x3 motif whose perimeter is not a monochrome ring",
                "dotted_graph": "same-parity nonbackground cells connected at orthogonal distance two",
                "ring_alternative": "dense 3x3 motif with uniform perimeter and distinct centre",
            },
            propositions=[
                "The dotted graph is a connected tree and therefore gives one path to each alternative.",
                "Path simplicity is measured by the number of colour runs.",
                "The selected motif has minimum runs and, among ties, maximum graph distance.",
            ],
            corollary="Emit the selected ring motif.",
            common_notions=["instruction motif", "tree path", "colour runs", "distance", "motif selection"],
        )


# ---------------------------------------------------------------------------
# Fitting, counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


FITTERS = {
    "witnessed_shape_codebook": lambda pairs: _fit_scalar_codebook(pairs) + _fit_full_codebook(pairs) + _fit_paired_codebook(pairs),
    "self_colour_corner_group_selection": lambda pairs: [SelfColourCornerGroupProgram()],
    "dotted_path_motif_selection": lambda pairs: [DottedPathMotifProgram()],
}


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, WitnessedShapeCodebookProgram):
        return analysis["signature"], analysis["label"]
    if isinstance(program, SelfColourCornerGroupProgram):
        selected = analysis["selected"]
        return selected["marker_colour"], selected["payload"]["bbox"], selected["payload"]["mask"]
    if isinstance(program, DottedPathMotifProgram):
        selected = analysis["selected"]
        return selected["runs"], selected["distance"], selected["ring"]["crop"]
    return program.schema_key


def fit_learned_stage_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds or FITTERS)
    programmes = []
    for kind, fitter in FITTERS.items():
        if kind not in allowed:
            continue
        try:
            candidates = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            candidates = []
        for program in candidates:
            try:
                if not all(program.predict(source) == target for source, target in pairs):
                    continue
                if require_role_variation and len({_serial(_role_signature(program, source)) for source, _ in pairs}) < 2:
                    continue
                programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
    unique = {program.schema_key: program for program in programmes}
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.schema_key)))


def _counterfactual_result(kind, rows):
    return {"kind": kind, "rows": rows, "passed": bool(rows) and all(row.get("passed") for row in rows)}


def _alter_codebook_instruction(program, source):
    source = grid(source)
    work = _array(source)
    if program.mode == "scalar":
        foreground = next(iter(_palette(source) - {program.background}))
        cells = [(r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell == foreground]
        r, c = cells[0]
        work[r][c] = program.background
    elif program.mode == "full_recolour":
        cells = [(r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell == program.instruction_colour]
        r, c = cells[0]
        work[r][c] = program.background
    else:
        axis, first, second = _split_equal_panels(source, program.background)
        # Modify one instruction support cell in the original scene.
        panels = (first, second)
        instruction = panels[program.instruction_index]
        local = next((pos for pos in ((r, c) for r in range(len(instruction)) for c in range(len(instruction[0]))) if instruction[pos[0]][pos[1]] != program.background), None)
        if local is None:
            raise Inapplicable("empty instruction panel")
        cells = [(r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell != program.background]
        r0, c0, r1, c1 = _bbox(cells)
        if axis == "horizontal":
            separator = next(c for c in range(c0, c1 + 1) if all(source[r][c] == program.background for r in range(r0, r1 + 1)))
            base_col = c0 if program.instruction_index == 0 else separator + 1
            work[r0 + local[0]][base_col + local[1]] = program.background
        else:
            separator = next(r for r in range(r0, r1 + 1) if all(source[r][c] == program.background for c in range(c0, c1 + 1)))
            base_row = r0 if program.instruction_index == 0 else separator + 1
            work[base_row + local[0]][c0 + local[1]] = program.background
    return tuple(tuple(row) for row in work)


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}
        if isinstance(program, WitnessedShapeCodebookProgram):
            altered = _alter_codebook_instruction(program, source)
            try:
                changed = program.predict(altered)
                causal = changed != original
            except Inapplicable:
                causal = True
            passed = causal
            details = {"instruction_shape_change_changes_or_rejects": causal}
        elif isinstance(program, SelfColourCornerGroupProgram):
            analysis = program.analyse(source)
            broken = _array(source)
            marker = analysis["selected"]["markers"][0]
            row, col = marker["cells"][0]
            broken[row][col] = analysis["background"]
            try:
                changed = program.predict(tuple(tuple(values) for values in broken))
                marker_causal = changed != original
            except Inapplicable:
                marker_causal = True
            rotated_source = tuple(tuple(reversed(row)) for row in reversed(source))
            rotated_expected = tuple(tuple(reversed(row)) for row in reversed(original))
            try:
                rotational = program.predict(rotated_source) == rotated_expected
            except Inapplicable:
                rotational = False
            passed = marker_causal and rotational
            details = {"marker_removal_changes_or_rejects": marker_causal, "half_turn_equivariance": rotational}
        elif isinstance(program, DottedPathMotifProgram):
            analysis = program.analyse(source)
            broken = _array(source)
            row, col = analysis["instruction"]["center"]
            broken[row][col] = analysis["background"]
            try:
                changed = program.predict(tuple(tuple(values) for values in broken))
                instruction_causal = changed != original
            except Inapplicable:
                instruction_causal = True
            rotated_source = tuple(tuple(reversed(row)) for row in reversed(source))
            rotated_expected = tuple(tuple(reversed(row)) for row in reversed(original))
            try:
                rotational = program.predict(rotated_source) == rotated_expected
            except Inapplicable:
                rotational = False
            passed = instruction_causal and rotational
            details = {"instruction_removal_changes_or_rejects": instruction_causal, "half_turn_equivariance": rotational}
        rows.append({"demonstration": index, "passed": passed, **details})
    return _counterfactual_result(program.kind, rows)


def infer_learned_stage_algebra(task, *, minimum_pairs=2, allowed_kinds=None, require_role_variation=True):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_learned_stage_programs(
        pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds, require_role_variation=require_role_variation
    )
    groups = defaultdict(list)
    invalid = rejected = 0
    for program in programmes:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "learned_stage_algebra": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "witnessed_shape_codebook":
        mapping = tuple(
            (tuple(tuple(int(cell) for cell in row) for row in entry["signature"]), int(entry["label"]))
            for entry in parameters["mapping"]
        )
        return WitnessedShapeCodebookProgram(
            str(parameters["mode"]), int(parameters["background"]), mapping,
            instruction_colour=parameters.get("instruction_colour"),
            target_colour=parameters.get("target_colour"),
            panel_axis=parameters.get("panel_axis"),
            instruction_index=int(parameters.get("instruction_index", 0)),
        )
    if kind == "self_colour_corner_group_selection":
        return SelfColourCornerGroupProgram()
    if kind == "dotted_path_motif_selection":
        return DottedPathMotifProgram()
    raise Inapplicable("unknown learned-stage schema")


def _validate_codebook_program(clean, program, expected, full_pairs):
    signatures = [program.instruction_signature(demo["input"]) for demo in clean["train"]]
    counts = Counter(signatures)
    folds = []
    redundant_folds = 0
    for held_index, held_demo in enumerate(clean["train"]):
        signature = signatures[held_index]
        if counts[signature] < 2:
            exact = program.predict(held_demo["input"]) == grid(held_demo["output"])
            folds.append({
                "held_index": held_index,
                "status": "unique" if exact else "no_fit",
                "validation_mode": "singleton_direct_code_witness",
                "held_example_exact": exact,
                "test_prediction_stable": True,
                "signature_redundant": False,
            })
            continue
        redundant_folds += 1
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_learned_stage_programs(
            remaining, minimum_pairs=1, allowed_kinds=(program.kind,), require_role_variation=False
        )
        held_exact = []
        for candidate in refitted:
            if not isinstance(candidate, WitnessedShapeCodebookProgram) or candidate.mode != program.mode:
                continue
            try:
                if candidate.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                predictions = tuple(candidate.predict(case["input"]) for case in clean["test"])
                held_exact.append(predictions)
            except Inapplicable:
                continue
        groups = set(held_exact)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "validation_mode": "redundant_witness_lodo",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "signature_redundant": True,
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    test_witnessed = all(program.instruction_signature(case["input"]) in _mapping_dict(program.mapping) for case in clean["test"])
    counterfactual = _counterfactual_validation(program, full_pairs)
    passed = (
        redundant_folds >= 1
        and test_witnessed
        and all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
        and counterfactual.get("passed")
    )
    return {
        "passed": passed,
        "reason": "passed" if passed else "witnessed_codebook_validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "witnessed_codebook_plus_redundant_lodo",
        "redundant_lodo_folds": redundant_folds,
        "singleton_direct_witnesses": len(folds) - redundant_folds,
        "test_signatures_witnessed": test_witnessed,
    }


def validate_learned_stage_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])

    # Codebooks require a transparent mixed witness protocol because arbitrary
    # singleton codes cannot be rediscovered after their sole demonstration is held out.
    codebooks = [program for program in programmes if isinstance(program, WitnessedShapeCodebookProgram)]
    if codebooks:
        checks = [_validate_codebook_program(clean, program, expected, full_pairs) for program in codebooks]
        passed_checks = [check for check in checks if check.get("passed")]
        if not passed_checks:
            return checks[0]
        return passed_checks[0]

    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_learned_stage_programs(
            remaining, minimum_pairs=1, allowed_kinds=allowed_kinds, require_role_variation=False
        )
        held_exact = []
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                cf = _counterfactual_validation(program, full_pairs)
                if not cf.get("passed"):
                    continue
                predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        })
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, full_pairs))
        except Exception as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    cf_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and cf_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def learned_stage_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_learned_stage_programs(pairs)}))


infer = infer_learned_stage_algebra
validate = validate_learned_stage_algebra
