"""LUCA V111: proof-carrying trigger-action composition over axis segments.

V111 composes a structural *trigger* with a reusable line-emission action.  It
contains three schemas that share the same typed action language:

* ``embedded_marker_axis_ray`` -- a uniquely coloured marker on the rear edge
  of a symmetric object binds its forward axis; the marker colour is emitted
  from the object tip to the canvas boundary;
* ``aligned_marker_connectors`` -- singleton markers aligned with a solid
  rectangle bind its sides; background gaps are connected to the rectangle;
* ``internal_gap_axis_line`` -- a unique empty row/column inside an object's
  bounding box binds a full-canvas axis line whose colour is fitted from the
  demonstrations.

Inference receives demonstrations and test inputs only through
``runtime.public_task``.  Exact training fit is necessary but not sufficient:
full fits require role variation, held-demonstration refitting, causal
counterfactuals, prediction consensus, and no task identifiers or test targets.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_trigger_action_composition"
LANGUAGE = "spinoza_trigger_action_axis_program_v1"
SCHEMA_VERSION = "trigger_action_schema_v1"

_CARDINAL = {
    "up": (-1, 0),
    "down": (1, 0),
    "left": (0, -1),
    "right": (0, 1),
}


# ---------------------------------------------------------------------------
# Shared typed action language
# ---------------------------------------------------------------------------


def _unique_modal_background(value: Grid) -> int:
    a = grid(value)
    counts = Counter(v for row in a for v in row)
    if not counts:
        raise Inapplicable("empty grid")
    ranked = counts.most_common()
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal background")
    return ranked[0][0]


def _steps(connectivity: int):
    if connectivity == 4:
        return tuple(_CARDINAL.values())
    if connectivity == 8:
        return tuple(
            (dr, dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr, dc) != (0, 0)
        )
    raise Inapplicable("connectivity must be 4 or 8")


@dataclass(frozen=True)
class MonoComponent:
    colour: int
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]

    @property
    def area(self) -> int:
        return len(self.cells)

    @property
    def top(self) -> int:
        return self.box[0]

    @property
    def left(self) -> int:
        return self.box[1]

    @property
    def height(self) -> int:
        return self.box[2] - self.box[0] + 1

    @property
    def width(self) -> int:
        return self.box[3] - self.box[1] + 1

    def to_dict(self):
        return {
            "colour": self.colour,
            "area": self.area,
            "box": list(self.box),
            "height": self.height,
            "width": self.width,
        }


@dataclass(frozen=True)
class AxisSegment:
    """Inclusive row/column segment written by the shared V111 action."""

    orientation: str
    fixed: int
    start: int
    end: int
    colour: int
    cause: str

    def cells(self) -> tuple[tuple[int, int], ...]:
        if self.start > self.end:
            raise Inapplicable("axis segment has reversed bounds")
        if self.orientation == "vertical":
            return tuple((index, self.fixed) for index in range(self.start, self.end + 1))
        if self.orientation == "horizontal":
            return tuple((self.fixed, index) for index in range(self.start, self.end + 1))
        raise Inapplicable("axis segment orientation must be horizontal or vertical")

    def to_dict(self):
        return {
            "orientation": self.orientation,
            "fixed": self.fixed,
            "start": self.start,
            "end": self.end,
            "colour": self.colour,
            "cause": self.cause,
            "length": self.end - self.start + 1,
        }


def _extract_monochrome_components(value: Grid, connectivity: int = 4):
    a = grid(value)
    background = _unique_modal_background(a)
    directions = _steps(connectivity)
    height, width = len(a), len(a[0])
    seen = set()
    components = []
    for r in range(height):
        for c in range(width):
            if (r, c) in seen or a[r][c] == background:
                continue
            colour = a[r][c]
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in directions:
                    q = (rr + dr, cc + dc)
                    if not (0 <= q[0] < height and 0 <= q[1] < width):
                        continue
                    if q in seen or a[q[0]][q[1]] != colour:
                        continue
                    seen.add(q)
                    stack.append(q)
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            components.append(
                MonoComponent(colour, tuple(sorted(cells)), (r0, c0, r1, c1))
            )
    components.sort(key=lambda component: (component.top, component.left, component.box))
    return tuple(components), background


def _emit_segments(value: Grid, segments: Sequence[AxisSegment], background: int):
    a = grid(value)
    output = [list(row) for row in a]
    writes = []
    for segment in segments:
        for r, c in segment.cells():
            if not (0 <= r < len(a) and 0 <= c < len(a[0])):
                raise Inapplicable("axis segment leaves the canvas")
            if output[r][c] != background:
                raise Inapplicable("axis segment would overwrite observed material")
            output[r][c] = segment.colour
            writes.append((r, c, segment.colour))
    if not writes:
        raise Inapplicable("trigger produces no action")
    return tuple(tuple(row) for row in output), tuple(writes)


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _rotate_90(value: Grid):
    a = grid(value)
    return tuple(tuple(row) for row in zip(*reversed(a)))


def _fresh_colour(value: Grid, *, exclude: Sequence[int] = ()) -> int:
    palette = {v for row in grid(value) for v in row} | set(exclude)
    for colour in range(10):
        if colour not in palette:
            return colour
    raise Inapplicable("no fresh colour is available")


def _connected(cells: set[tuple[int, int]], start: tuple[int, int]) -> bool:
    seen = {start}
    stack = [start]
    while stack:
        r, c = stack.pop()
        for dr, dc in _CARDINAL.values():
            q = (r + dr, c + dc)
            if q in cells and q not in seen:
                seen.add(q)
                stack.append(q)
    return seen == cells


# ---------------------------------------------------------------------------
# Schema I: embedded marker -> forward axis -> boundary ray
# ---------------------------------------------------------------------------


def _reflection(point, marker, direction):
    r, c = point
    mr, mc = marker
    if direction in ("up", "down"):
        return (r, 2 * mc - c)
    return (2 * mr - r, c)


@dataclass(frozen=True)
class EmbeddedMarkerAxisRayProgram:
    kind: str = "embedded_marker_axis_ray"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self) -> int:
        return 3

    @property
    def permissiveness_cost(self):
        return (0,)

    def analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal_background(a)
        counts = Counter(v for row in a for v in row)
        colours = [colour for colour in counts if colour != background]
        if len(colours) != 2:
            raise Inapplicable("requires one body colour and one marker colour")
        marker_colours = [colour for colour in colours if counts[colour] == 1]
        if len(marker_colours) != 1:
            raise Inapplicable("requires one uniquely coloured marker cell")
        marker_colour = marker_colours[0]
        body_colour = next(colour for colour in colours if colour != marker_colour)
        marker = next(
            (r, c)
            for r, row in enumerate(a)
            for c, colour in enumerate(row)
            if colour == marker_colour
        )
        body = {
            (r, c)
            for r, row in enumerate(a)
            for c, colour in enumerate(row)
            if colour == body_colour
        }
        if len(body) < 4 or not _connected(body | {marker}, marker):
            raise Inapplicable("marker and body must form one structured object")

        candidates = []
        for direction, (dr, dc) in _CARDINAL.items():
            projections = [
                (r - marker[0]) * dr + (c - marker[1]) * dc for r, c in body
            ]
            if min(projections) < 0 or max(projections) < 1:
                continue
            maximum = max(projections)
            if any(
                (marker[0] + step * dr, marker[1] + step * dc) not in body
                for step in range(1, maximum + 1)
            ):
                continue
            if any(_reflection(point, marker, direction) not in body for point in body):
                continue
            cells = []
            r = marker[0] + (maximum + 1) * dr
            c = marker[1] + (maximum + 1) * dc
            while 0 <= r < len(a) and 0 <= c < len(a[0]):
                if a[r][c] != background:
                    cells = []
                    break
                cells.append((r, c))
                r += dr
                c += dc
            if not cells:
                continue
            if direction in ("up", "down"):
                segment = AxisSegment(
                    "vertical",
                    marker[1],
                    min(r for r, _ in cells),
                    max(r for r, _ in cells),
                    marker_colour,
                    "embedded_marker_forward_axis",
                )
            else:
                segment = AxisSegment(
                    "horizontal",
                    marker[0],
                    min(c for _, c in cells),
                    max(c for _, c in cells),
                    marker_colour,
                    "embedded_marker_forward_axis",
                )
            candidates.append((direction, maximum, segment))
        if len(candidates) != 1:
            raise Inapplicable("forward axis is absent or ambiguous")
        direction, maximum, segment = candidates[0]
        return {
            "background": background,
            "marker": marker,
            "marker_colour": marker_colour,
            "body_colour": body_colour,
            "body_cells": tuple(sorted(body)),
            "direction": direction,
            "body_extent": maximum,
            "segments": (segment,),
        }

    def predict(self, value: Grid):
        analysis = self.analyse(value)
        return _emit_segments(
            value, analysis["segments"], analysis["background"]
        )[0]

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):
        proofs = []
        directions = []
        marker_colours = []
        body_colours = []
        shapes = []
        for index, (a, y) in enumerate(training_pairs):
            try:
                analysis = self.analyse(a)
                prediction = self.predict(a)
                directions.append(analysis["direction"])
                marker_colours.append(analysis["marker_colour"])
                body_colours.append(analysis["body_colour"])
                shapes.append((len(grid(a)), len(grid(a)[0])))
                proofs.append(
                    {
                        "demonstration": index,
                        "exact": prediction == grid(y),
                        "trigger": {
                            "kind": "embedded_marker_rear_edge",
                            "marker": list(analysis["marker"]),
                            "direction": analysis["direction"],
                            "body_extent": analysis["body_extent"],
                        },
                        "action": [segment.to_dict() for segment in analysis["segments"]],
                    }
                )
            except Inapplicable as exc:
                proofs.append({"demonstration": index, "exact": False, "error": str(exc)})
        return _description(
            self,
            definitions=[
                ("EmbeddedMarkerTrigger", "Grid", "Marker x Body", "a unique marker lies on the rear edge of one symmetric object"),
                ("ForwardAxisBinding", "Marker x Body", "Axis", "the body occupies one marker-relative half-plane and is symmetric about the axis"),
                ("AxisSegmentEmitter", "Grid x Axis", "Grid", "write background cells from object tip to canvas boundary"),
            ],
            propositions=[
                ("detect_embedded_marker", [], "a unique coloured marker is attached to a symmetric body", "bind marker and body roles"),
                ("bind_forward_axis", [], "the body has one unambiguous forward half-plane", "derive direction and object tip"),
                ("emit_axis_segment", ["tip_to_boundary", "marker_colour"], "the bound axis beyond the body is empty", "extend the marker colour to the boundary"),
            ],
            corollary="detect_embedded_marker -> bind_forward_axis -> emit_axis_segment",
            parameters={"kind": self.kind},
            adequacy={
                "demonstrations_exact": all(proof.get("exact") for proof in proofs) if proofs else None,
                "directions_vary": len(set(directions)) >= 2 if directions else None,
                "marker_colours_vary": len(set(marker_colours)) >= 2 if marker_colours else None,
                "body_colours_vary": len(set(body_colours)) >= 2 if body_colours else None,
                "canvas_shapes_vary": len(set(shapes)) >= 2 if shapes else None,
            },
            proofs=proofs,
        )


# ---------------------------------------------------------------------------
# Schema II: aligned singleton markers -> rectangle-side connectors
# ---------------------------------------------------------------------------


def _solid_rectangle(component: MonoComponent) -> bool:
    return component.area == component.height * component.width


@dataclass(frozen=True)
class AlignedMarkerConnectorProgram:
    kind: str = "aligned_marker_connectors"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self) -> int:
        return 3

    @property
    def permissiveness_cost(self):
        return (0,)

    def analyse(self, value: Grid):
        a = grid(value)
        components, background = _extract_monochrome_components(a, 4)
        rectangles = [
            component
            for component in components
            if component.area >= 4 and _solid_rectangle(component)
        ]
        if not rectangles:
            raise Inapplicable("requires one solid rectangular body")
        maximum = max(component.area for component in rectangles)
        bodies = [component for component in rectangles if component.area == maximum]
        if len(bodies) != 1:
            raise Inapplicable("largest solid rectangular body is tied")
        body = bodies[0]
        markers = [component for component in components if component != body]
        if not markers or any(component.area != 1 for component in markers):
            raise Inapplicable("all non-body components must be singleton markers")
        marker_colours = {component.colour for component in markers}
        if len(marker_colours) != 1 or body.colour in marker_colours:
            raise Inapplicable("markers must share one colour distinct from the body")
        marker_colour = next(iter(marker_colours))
        r0, c0, r1, c1 = body.box
        segments = []
        aligned = []
        distractors = []
        for marker_component in markers:
            mr, mc = marker_component.cells[0]
            cells = []
            direction = None
            if c0 <= mc <= c1 and mr < r0:
                cells = [(r, mc) for r in range(mr + 1, r0)]
                direction = "above"
            elif c0 <= mc <= c1 and mr > r1:
                cells = [(r, mc) for r in range(r1 + 1, mr)]
                direction = "below"
            elif r0 <= mr <= r1 and mc < c0:
                cells = [(mr, c) for c in range(mc + 1, c0)]
                direction = "left"
            elif r0 <= mr <= r1 and mc > c1:
                cells = [(mr, c) for c in range(c1 + 1, mc)]
                direction = "right"
            else:
                distractors.append((mr, mc))
                continue
            if not cells:
                raise Inapplicable("aligned marker must have a nonempty background gap")
            if any(a[r][c] != background for r, c in cells):
                raise Inapplicable("aligned marker connector is obstructed")
            if direction in ("above", "below"):
                segment = AxisSegment(
                    "vertical",
                    mc,
                    min(r for r, _ in cells),
                    max(r for r, _ in cells),
                    marker_colour,
                    "marker_rectangle_alignment",
                )
            else:
                segment = AxisSegment(
                    "horizontal",
                    mr,
                    min(c for _, c in cells),
                    max(c for _, c in cells),
                    marker_colour,
                    "marker_rectangle_alignment",
                )
            segments.append(segment)
            aligned.append({"marker": [mr, mc], "direction": direction})
        if not segments:
            raise Inapplicable("no marker is axis-aligned with the body")
        return {
            "background": background,
            "body": body,
            "marker_colour": marker_colour,
            "markers": tuple(component.cells[0] for component in markers),
            "aligned": tuple(aligned),
            "distractors": tuple(distractors),
            "segments": tuple(segments),
        }

    def predict(self, value: Grid):
        analysis = self.analyse(value)
        return _emit_segments(
            value, analysis["segments"], analysis["background"]
        )[0]

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):
        proofs = []
        body_colours = []
        marker_colours = []
        body_boxes = []
        direction_sets = []
        marker_counts = []
        for index, (a, y) in enumerate(training_pairs):
            try:
                analysis = self.analyse(a)
                prediction = self.predict(a)
                body = analysis["body"]
                body_colours.append(body.colour)
                marker_colours.append(analysis["marker_colour"])
                body_boxes.append(body.box)
                marker_counts.append(len(analysis["markers"]))
                direction_sets.append(tuple(sorted(row["direction"] for row in analysis["aligned"])))
                proofs.append(
                    {
                        "demonstration": index,
                        "exact": prediction == grid(y),
                        "trigger": {
                            "kind": "marker_rectangle_alignment",
                            "body": body.to_dict(),
                            "aligned": list(analysis["aligned"]),
                            "distractors": [list(point) for point in analysis["distractors"]],
                        },
                        "action": [segment.to_dict() for segment in analysis["segments"]],
                    }
                )
            except Inapplicable as exc:
                proofs.append({"demonstration": index, "exact": False, "error": str(exc)})
        return _description(
            self,
            definitions=[
                ("SolidRectangleBody", "Grid", "Object", "the unique largest nontrivial solid rectangle"),
                ("AlignedMarkerTrigger", "MarkerSet x Object", "SideBinding", "a singleton marker shares a row or column span with the body"),
                ("AxisSegmentEmitter", "Grid x SideBinding", "Grid", "fill only the empty gap between marker and body"),
            ],
            propositions=[
                ("detect_rectangle_and_markers", [], "one rectangle and one singleton-marker colour exist", "bind body and marker roles"),
                ("bind_aligned_sides", [], "a marker lies in a body row/column projection", "derive one or more side-aligned gaps"),
                ("emit_axis_segments", ["marker_to_body", "marker_colour"], "every bound gap is unobstructed", "connect aligned markers to the body"),
            ],
            corollary="detect_rectangle_and_markers -> bind_aligned_sides -> emit_axis_segments",
            parameters={"kind": self.kind},
            adequacy={
                "demonstrations_exact": all(proof.get("exact") for proof in proofs) if proofs else None,
                "body_colours_vary": len(set(body_colours)) >= 2 if body_colours else None,
                "marker_colours_vary": len(set(marker_colours)) >= 2 if marker_colours else None,
                "body_geometry_varies": len(set(body_boxes)) >= 2 if body_boxes else None,
                "alignment_patterns_vary": len(set(direction_sets)) >= 2 if direction_sets else None,
                "marker_counts_vary": len(set(marker_counts)) >= 2 if marker_counts else None,
            },
            proofs=proofs,
        )


# ---------------------------------------------------------------------------
# Schema III: internal empty axis -> full-canvas line
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InternalGapAxisLineProgram:
    line_colour: int
    kind: str = "internal_gap_axis_line"

    @property
    def schema_key(self):
        return (self.kind, self.line_colour)

    @property
    def description_length(self) -> int:
        return 3

    @property
    def permissiveness_cost(self):
        return (0,)

    def analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal_background(a)
        nonbackground = [
            (r, c)
            for r, row in enumerate(a)
            for c, colour in enumerate(row)
            if colour != background
        ]
        object_colours = {a[r][c] for r, c in nonbackground}
        if len(object_colours) != 1 or len(nonbackground) < 4:
            raise Inapplicable("requires one structured object colour")
        object_colour = next(iter(object_colours))
        if self.line_colour in (background, object_colour):
            raise Inapplicable("line colour must be distinct from background and object")
        r0 = min(r for r, _ in nonbackground)
        r1 = max(r for r, _ in nonbackground)
        c0 = min(c for _, c in nonbackground)
        c1 = max(c for _, c in nonbackground)
        candidates = []
        for c in range(c0 + 1, c1):
            if not all(a[r][c] == background for r in range(r0, r1 + 1)):
                continue
            left = any(
                a[r][cc] != background
                for r in range(r0, r1 + 1)
                for cc in range(c0, c)
            )
            right = any(
                a[r][cc] != background
                for r in range(r0, r1 + 1)
                for cc in range(c + 1, c1 + 1)
            )
            if left and right and all(a[r][c] == background for r in range(len(a))):
                candidates.append(("vertical", c))
        for r in range(r0 + 1, r1):
            if not all(a[r][c] == background for c in range(c0, c1 + 1)):
                continue
            above = any(
                a[rr][c] != background
                for rr in range(r0, r)
                for c in range(c0, c1 + 1)
            )
            below = any(
                a[rr][c] != background
                for rr in range(r + 1, r1 + 1)
                for c in range(c0, c1 + 1)
            )
            if above and below and all(a[r][c] == background for c in range(len(a[0]))):
                candidates.append(("horizontal", r))
        if len(candidates) != 1:
            raise Inapplicable("internal empty axis is absent or ambiguous")
        orientation, index = candidates[0]
        if orientation == "vertical":
            segment = AxisSegment(
                "vertical",
                index,
                0,
                len(a) - 1,
                self.line_colour,
                "unique_internal_gap_axis",
            )
        else:
            segment = AxisSegment(
                "horizontal",
                index,
                0,
                len(a[0]) - 1,
                self.line_colour,
                "unique_internal_gap_axis",
            )
        return {
            "background": background,
            "object_colour": object_colour,
            "box": (r0, c0, r1, c1),
            "orientation": orientation,
            "axis_index": index,
            "segments": (segment,),
        }

    def predict(self, value: Grid):
        analysis = self.analyse(value)
        return _emit_segments(
            value, analysis["segments"], analysis["background"]
        )[0]

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):
        proofs = []
        orientations = []
        object_colours = []
        boxes = []
        for index, (a, y) in enumerate(training_pairs):
            try:
                analysis = self.analyse(a)
                prediction = self.predict(a)
                orientations.append(analysis["orientation"])
                object_colours.append(analysis["object_colour"])
                boxes.append(analysis["box"])
                proofs.append(
                    {
                        "demonstration": index,
                        "exact": prediction == grid(y),
                        "trigger": {
                            "kind": "unique_internal_gap_axis",
                            "orientation": analysis["orientation"],
                            "axis_index": analysis["axis_index"],
                            "object_box": list(analysis["box"]),
                        },
                        "action": [segment.to_dict() for segment in analysis["segments"]],
                    }
                )
            except Inapplicable as exc:
                proofs.append({"demonstration": index, "exact": False, "error": str(exc)})
        return _description(
            self,
            definitions=[
                ("InternalGapTrigger", "Grid", "Axis", "one empty row or column separates observed object material"),
                ("AxisColourParameter", "Demonstrations", "Colour", "one output colour is shared by every demonstrated axis"),
                ("AxisSegmentEmitter", "Grid x Axis x Colour", "Grid", "write the complete empty canvas axis"),
            ],
            propositions=[
                ("detect_internal_gap_axis", [], "one empty separator crosses the object bounding box", "bind row or column axis"),
                ("fit_axis_colour", [self.line_colour], "all demonstrations use one new line colour", "bind the action colour"),
                ("emit_axis_segment", ["full_canvas", self.line_colour], "the full axis is background", "draw the complete axis line"),
            ],
            corollary="detect_internal_gap_axis -> fit_axis_colour -> emit_axis_segment",
            parameters={"kind": self.kind, "line_colour": self.line_colour},
            adequacy={
                "demonstrations_exact": all(proof.get("exact") for proof in proofs) if proofs else None,
                "orientations_vary": len(set(orientations)) >= 2 if orientations else None,
                "object_colours_vary": len(set(object_colours)) >= 2 if object_colours else None,
                "object_geometry_varies": len(set(boxes)) >= 2 if boxes else None,
            },
            proofs=proofs,
        )


# ---------------------------------------------------------------------------
# Shared proof description, fitting and inference
# ---------------------------------------------------------------------------


def _description(
    program,
    *,
    definitions,
    propositions,
    corollary,
    parameters,
    adequacy,
    proofs,
):
    return {
        "language": LANGUAGE,
        "family": FAMILY,
        "schema": program.kind,
        "definitions": [
            {
                "name": name,
                "input_type": input_type,
                "output_type": output_type,
                "contract": contract,
            }
            for name, input_type, output_type, contract in definitions
        ],
        "axioms": [
            "training_demonstrations_exact",
            "trigger_is_input_derived",
            "role_binding_is_unique",
            "axis_action_writes_background_only",
            "held_demonstration_refitting_required",
            "causal_counterfactual_required",
            "no_task_identifier",
            "no_test_target_access",
        ],
        "propositions": [
            {
                "definition": definition,
                "parameters": list(parameters_),
                "cause": cause,
                "effect": effect,
            }
            for definition, parameters_, cause, effect in propositions
        ],
        "corollary": corollary,
        "parameters": parameters,
        "adequacy": {
            **adequacy,
            "description_length": program.description_length,
            "permissiveness_cost": list(program.permissiveness_cost),
            "shared_action_primitive": "AxisSegmentEmitter",
        },
        "proofs": proofs,
    }


def _added_background_colour(a: Grid, y: Grid):
    a, y = grid(a), grid(y)
    if len(a) != len(y) or len(a[0]) != len(y[0]):
        raise Inapplicable("axis-line fitting requires shape preservation")
    background = _unique_modal_background(a)
    changes = [
        (r, c, a[r][c], y[r][c])
        for r in range(len(a))
        for c in range(len(a[0]))
        if a[r][c] != y[r][c]
    ]
    if not changes or any(old != background for _, _, old, _ in changes):
        raise Inapplicable("output must add material only to background")
    colours = {new for _, _, _, new in changes}
    if len(colours) != 1:
        raise Inapplicable("axis action must use one added colour")
    return next(iter(colours))


def _candidate_programs(pairs: Sequence[tuple[Grid, Grid]], allowed_schemas=None):
    allowed = set(tuple(schema) for schema in allowed_schemas) if allowed_schemas else None
    fixed = (EmbeddedMarkerAxisRayProgram(), AlignedMarkerConnectorProgram())
    programs = [program for program in fixed if allowed is None or program.schema_key in allowed]
    colours = []
    try:
        colours = [_added_background_colour(a, y) for a, y in pairs]
    except (Inapplicable, ValueError, IndexError, TypeError):
        colours = []
    if colours and len(set(colours)) == 1:
        candidate = InternalGapAxisLineProgram(colours[0])
        if allowed is None or candidate.schema_key in allowed:
            programs.append(candidate)
    if allowed is not None:
        for key in allowed:
            if key and key[0] == "internal_gap_axis_line":
                candidate = InternalGapAxisLineProgram(int(key[1]))
                if candidate.schema_key not in {program.schema_key for program in programs}:
                    programs.append(candidate)
    return tuple(programs)


def _role_varies(program, pairs: Sequence[tuple[Grid, Grid]]) -> bool:
    analyses = [program.analyse(a) for a, _ in pairs]
    if isinstance(program, EmbeddedMarkerAxisRayProgram):
        return (
            len({row["direction"] for row in analyses}) >= 2
            and len({row["marker_colour"] for row in analyses}) >= 2
            and len({row["body_colour"] for row in analyses}) >= 2
        )
    if isinstance(program, AlignedMarkerConnectorProgram):
        return (
            len({row["body"].colour for row in analyses}) >= 2
            and len({row["marker_colour"] for row in analyses}) >= 2
            and len({row["body"].box for row in analyses}) >= 2
        )
    if isinstance(program, InternalGapAxisLineProgram):
        return (
            len({row["orientation"] for row in analyses}) >= 2
            and len({row["object_colour"] for row in analyses}) >= 2
        )
    return False


def fit_trigger_action_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 3,
    allowed_schemas: Iterable[tuple] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_schemas):
        try:
            if not all(program.predict(a) == y for a, y in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (
            program.description_length,
            program.permissiveness_cost,
            repr(program.schema_key),
        ),
    )


def infer_trigger_action(
    task,
    *,
    minimum_pairs: int = 3,
    allowed_schemas=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_trigger_action_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_schemas=allowed_schemas,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        predictions = []
        try:
            for case in clean["test"]:
                predictions.append(program.predict(case["input"]))
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(v) for v in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "trigger_action_schemas": sorted({program.kind for program in programs}),
            "shared_action_primitive": "AxisSegmentEmitter",
            "proof_carrying": True,
            "trigger_action_composition": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    if kind == "embedded_marker_axis_ray":
        return EmbeddedMarkerAxisRayProgram()
    if kind == "aligned_marker_connectors":
        return AlignedMarkerConnectorProgram()
    if kind == "internal_gap_axis_line":
        return InternalGapAxisLineProgram(int(parameters["line_colour"]))
    raise Inapplicable("unknown trigger-action schema")


# ---------------------------------------------------------------------------
# Causal counterfactuals and held-demonstration validation
# ---------------------------------------------------------------------------


def _embedded_counterfactuals(program, pairs):
    rows = []
    for index, (a, _) in enumerate(pairs):
        original = grid(a)
        analysis = program.analyse(original)
        mr, mc = analysis["marker"]
        removed = [list(row) for row in original]
        removed[mr][mc] = analysis["background"]
        try:
            removed_prediction = program.predict(removed)
        except Inapplicable:
            removed_prediction = None

        recoloured = [list(row) for row in original]
        fresh = _fresh_colour(original)
        recoloured[mr][mc] = fresh
        recoloured_prediction = program.predict(recoloured)
        recoloured_analysis = program.analyse(recoloured)
        ray_cells = set(recoloured_analysis["segments"][0].cells())
        colour_followed = all(
            recoloured_prediction[r][c] == fresh for r, c in ray_cells
        )

        rotated_prediction = program.predict(_rotate_90(original))
        equivariant = rotated_prediction == _rotate_90(program.predict(original))
        rows.append(
            {
                "demonstration": index,
                "marker_removed_inapplicable": removed_prediction is None,
                "marker_recolour_changes_ray_colour": colour_followed,
                "rotation_equivariant": equivariant,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["marker_removed_inapplicable"]
            and row["marker_recolour_changes_ray_colour"]
            and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _find_unaligned_cell(a, analysis):
    body = analysis["body"]
    r0, c0, r1, c1 = body.box
    background = analysis["background"]
    occupied = set(analysis["markers"]) | set(body.cells)
    for r in range(len(a)):
        for c in range(len(a[0])):
            if a[r][c] != background or (r, c) in occupied:
                continue
            aligned = (c0 <= c <= c1 and (r < r0 or r > r1)) or (
                r0 <= r <= r1 and (c < c0 or c > c1)
            )
            if not aligned:
                return (r, c)
    return None


def _aligned_counterfactuals(program, pairs):
    rows = []
    for index, (a, _) in enumerate(pairs):
        original = grid(a)
        analysis = program.analyse(original)
        marker_colour = analysis["marker_colour"]
        removed = [list(row) for row in original]
        for r, c in analysis["markers"]:
            removed[r][c] = analysis["background"]
        try:
            removed_prediction = program.predict(removed)
        except Inapplicable:
            removed_prediction = None

        distractor_cell = _find_unaligned_cell(original, analysis)
        distractor_ok = False
        if distractor_cell is not None:
            changed = [list(row) for row in original]
            changed[distractor_cell[0]][distractor_cell[1]] = marker_colour
            predicted = program.predict(changed)
            expected = [list(row) for row in program.predict(original)]
            expected[distractor_cell[0]][distractor_cell[1]] = marker_colour
            distractor_ok = predicted == tuple(tuple(row) for row in expected)

        moved_ok = False
        aligned_marker = tuple(analysis["aligned"][0]["marker"])
        move_target = _find_unaligned_cell(original, analysis)
        if move_target is not None:
            changed = [list(row) for row in original]
            changed[aligned_marker[0]][aligned_marker[1]] = analysis["background"]
            changed[move_target[0]][move_target[1]] = marker_colour
            try:
                moved_prediction = program.predict(changed)
            except Inapplicable:
                moved_prediction = None
            moved_ok = moved_prediction is None or moved_prediction != program.predict(original)

        rows.append(
            {
                "demonstration": index,
                "all_markers_removed_inapplicable": removed_prediction is None,
                "unaligned_distractor_preserved_without_connector": distractor_ok,
                "moving_aligned_marker_changes_action": moved_ok,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["all_markers_removed_inapplicable"]
            and row["unaligned_distractor_preserved_without_connector"]
            and row["moving_aligned_marker_changes_action"]
            for row in rows
        ),
    }


def _gap_counterfactuals(program, pairs):
    rows = []
    for index, (a, _) in enumerate(pairs):
        original = grid(a)
        analysis = program.analyse(original)
        segment = analysis["segments"][0]
        axis_cells = segment.cells()
        object_colour = analysis["object_colour"]
        # Fill an axis cell inside the object box, destroying the separating gap.
        r0, c0, r1, c1 = analysis["box"]
        candidates = [
            (r, c)
            for r, c in axis_cells
            if r0 <= r <= r1 and c0 <= c <= c1
        ]
        broken = [list(row) for row in original]
        r, c = candidates[len(candidates) // 2]
        broken[r][c] = object_colour
        try:
            broken_prediction = program.predict(broken)
        except Inapplicable:
            broken_prediction = None
        rotated_prediction = program.predict(_rotate_90(original))
        equivariant = rotated_prediction == _rotate_90(program.predict(original))
        rows.append(
            {
                "demonstration": index,
                "filled_gap_inapplicable": broken_prediction is None,
                "rotation_equivariant": equivariant,
            }
        )
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["filled_gap_inapplicable"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, EmbeddedMarkerAxisRayProgram):
        return _embedded_counterfactuals(program, pairs)
    if isinstance(program, AlignedMarkerConnectorProgram):
        return _aligned_counterfactuals(program, pairs)
    if isinstance(program, InternalGapAxisLineProgram):
        return _gap_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_trigger_action(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {
            "passed": False,
            "reason": "full_fit_not_unique",
            "folds": [],
            "counterfactuals": [],
        }
    if len(clean["train"]) < 3:
        return {
            "passed": False,
            "reason": "requires_three_demonstrations",
            "folds": [],
            "counterfactuals": [],
        }
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed = tuple(sorted({program.schema_key for program in programs}, key=repr))
    if not allowed:
        return {
            "passed": False,
            "reason": "missing_program_schema",
            "folds": [],
            "counterfactuals": [],
        }

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [
                d for index, d in enumerate(clean["train"]) if index != held
            ],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_trigger_action(
            fold,
            minimum_pairs=2,
            allowed_schemas=allowed,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append(
            {
                "held_index": held,
                "status": result["status"],
                "held_example_exact": result["status"] == "unique"
                and predictions[0] == demonstration["output"],
                "test_prediction_stable": result["status"] == "unique"
                and predictions[1:] == expected,
                "joint_hypotheses": result["joint_hypotheses"],
            }
        )

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError) as exc:
            counterfactuals.append(
                {"kind": program.kind, "passed": False, "error": str(exc)}
            )
    folds_passed = all(
        fold["held_example_exact"] and fold["test_prediction_stable"]
        for fold in folds
    )
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": (
            "passed"
            if passed
            else "leave_one_demonstration_out_failure"
            if not folds_passed
            else "causal_counterfactual_failure"
        ),
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def trigger_action_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(
        sorted({program.kind for program in fit_trigger_action_programs(pairs)})
    )
