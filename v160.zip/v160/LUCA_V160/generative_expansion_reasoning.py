"""LUCA V125: unified generative expansion algebra.

The family factors several macro-construction tasks into a common language::

    source -> relation / selector -> derived block or period -> macro emitter

Eight conservative schemas are exposed:

* ``axis_periodic_extension`` continues a demonstrated row/column period;
* ``stencil_wallpaper`` tiles a source and applies a learned local stencil;
* ``binary_complement_macro`` composes source/complement blocks;
* ``active_axis_fill_wallpaper`` fills active rows/columns before tiling;
* ``gap_row_diagonal_wallpaper`` binds repeated rows through separator lines;
* ``sparse_lattice_densification`` lifts residue-aligned markers to solid blocks;
* ``border_duplicate_expansion`` duplicates the outer row/column roles;
* ``toroidal_diagonal_substitution`` substitutes cyclic diagonal roles.

No task identifiers, stored demonstration coordinates, or test outputs are used
by inference.  Exact training fit is necessary but not sufficient: accepted
predictions must survive output consensus, held-demonstration refitting,
counterfactual interventions, and metadata leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from itertools import permutations
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_unified_generative_expansion_algebra"
LANGUAGE = "spinoza_unified_generative_expansion_algebra_v1"
SCHEMA_VERSION = "unified_generative_expansion_schema_v1"

OFFSET_PATTERNS = {
    "nw": ((-1, -1),),
    "ne": ((-1, 1),),
    "sw": ((1, -1),),
    "se": ((1, 1),),
    "diag4": ((-1, -1), (-1, 1), (1, -1), (1, 1)),
    "main_diag2": ((-1, -1), (1, 1)),
    "anti_diag2": ((-1, 1), (1, -1)),
    "orth4": ((-1, 0), (1, 0), (0, -1), (0, 1)),
}


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _uniform(shape: tuple[int, int], colour: int) -> Grid:
    height, width = shape
    return tuple(tuple(colour for _ in range(width)) for _ in range(height))


def _tile(value: Grid, rows: int, cols: int) -> Grid:
    value = grid(value)
    if rows < 1 or cols < 1:
        raise Inapplicable("invalid macro shape")
    return tuple(
        tuple(value[r % len(value)][c % len(value[0])] for c in range(cols * len(value[0])))
        for r in range(rows * len(value))
    )


def _minimal_period(sequence) -> int | None:
    sequence = tuple(sequence)
    for period in range(1, len(sequence)):
        if all(sequence[index] == sequence[index - period] for index in range(period, len(sequence))):
            return period
    return None


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


@dataclass(frozen=True)
class AxisPeriodicExtensionProgram:
    axis: int
    ratio_numerator: int
    ratio_denominator: int
    colour_policy: str
    background_colour: int | None
    target_foreground_colour: int | None
    kind: str = "axis_periodic_extension"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.axis,
            self.ratio_numerator,
            self.ratio_denominator,
            self.colour_policy,
            self.background_colour,
            self.target_foreground_colour,
        )

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        source_length = height if self.axis == 0 else width
        scaled = source_length * self.ratio_numerator
        if scaled % self.ratio_denominator:
            raise Inapplicable("periodic extension length is not integral")
        target_length = scaled // self.ratio_denominator
        if target_length <= source_length:
            raise Inapplicable("periodic extension must enlarge the selected axis")

        if self.colour_policy == "identity":
            mapped = value
        elif self.colour_policy == "foreground_fixed":
            if self.background_colour is None or self.target_foreground_colour is None:
                raise Inapplicable("missing foreground-map parameters")
            colours = _palette(value)
            if self.background_colour not in colours or len(colours) != 2:
                raise Inapplicable("foreground-fixed policy requires a binary input")
            mapped = tuple(
                tuple(
                    self.background_colour if cell == self.background_colour else self.target_foreground_colour
                    for cell in row
                )
                for row in value
            )
        else:
            raise Inapplicable("unknown colour policy")

        if self.axis == 0:
            sequence = tuple(mapped)
            period = _minimal_period(sequence)
            if period is None:
                raise Inapplicable("rows do not expose a repeated period")
            prediction = tuple(sequence[index % period] for index in range(target_length))
        else:
            columns = tuple(tuple(mapped[r][c] for r in range(height)) for c in range(width))
            period = _minimal_period(columns)
            if period is None:
                raise Inapplicable("columns do not expose a repeated period")
            extended = tuple(columns[index % period] for index in range(target_length))
            prediction = tuple(tuple(extended[c][r] for c in range(target_length)) for r in range(height))

        return {
            "axis": self.axis,
            "period": period,
            "source_length": source_length,
            "target_length": target_length,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "axis": analysis["axis"],
                "period": analysis["period"],
                "target_length": analysis["target_length"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "axis": self.axis,
                "ratio_numerator": self.ratio_numerator,
                "ratio_denominator": self.ratio_denominator,
                "colour_policy": self.colour_policy,
                "background_colour": self.background_colour,
                "target_foreground_colour": self.target_foreground_colour,
            },
            definitions=[
                {"name": "AxisSequence", "type": "Grid x Axis -> Sequence"},
                {"name": "MinimalPeriod", "type": "Sequence -> Integer"},
                {"name": "ColourPolicy", "type": "Grid -> Grid"},
                {"name": "PeriodicEmitter", "type": "Sequence x Length -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "MapSourceColours", "effect": "apply the learned identity or foreground-role colour policy"},
                {"index": 2, "definition": "InferMinimalAxisPeriod", "effect": "derive the shortest row or column recurrence witnessed by the input"},
                {"index": 3, "definition": "ExtendPeriod", "effect": "continue the recurrence to the learned rational output length"},
            ],
            corollary="a witnessed row or column period is extended without storing output coordinates",
            common_notions=[{"name": "axis_periodic_extension_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class StencilWallpaperProgram:
    background_colour: int
    macro_rows: int
    macro_cols: int
    scope: str
    wrap: bool
    operations: tuple[tuple[str, int], ...]
    kind: str = "stencil_wallpaper"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.macro_rows, self.macro_cols, self.scope, self.wrap, self.operations

    @property
    def description_length(self):
        return 6 + len(self.operations)

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def _process(self, value: Grid) -> Grid:
        value = grid(value)
        original = value
        rows = _array(value)
        foreground = tuple(
            (r, c)
            for r, row in enumerate(original)
            for c, cell in enumerate(row)
            if cell != self.background_colour
        )
        if not foreground:
            raise Inapplicable("stencil wallpaper requires foreground evidence")
        height, width = _shape(value)
        for operation, colour in self.operations:
            if operation == "row_fill":
                for r in sorted({r for r, _ in foreground}):
                    for c in range(width):
                        if rows[r][c] == self.background_colour:
                            rows[r][c] = colour
                continue
            if operation == "col_fill":
                for c in sorted({c for _, c in foreground}):
                    for r in range(height):
                        if rows[r][c] == self.background_colour:
                            rows[r][c] = colour
                continue
            offsets = OFFSET_PATTERNS.get(operation)
            if offsets is None:
                raise Inapplicable("unknown stencil operation")
            for r, c in foreground:
                for dr, dc in offsets:
                    rr, cc = r + dr, c + dc
                    if self.wrap:
                        rr %= height
                        cc %= width
                    if 0 <= rr < height and 0 <= cc < width and rows[rr][cc] == self.background_colour:
                        rows[rr][cc] = colour
        return tuple(tuple(row) for row in rows)

    def analyse(self, value: Grid):
        value = grid(value)
        if self.scope == "pre":
            derived = self._process(value)
            prediction = _tile(derived, self.macro_rows, self.macro_cols)
        elif self.scope == "post":
            tiled = _tile(value, self.macro_rows, self.macro_cols)
            prediction = self._process(tiled)
            derived = None
        else:
            raise Inapplicable("unknown stencil scope")
        return {
            "macro_shape": (self.macro_rows, self.macro_cols),
            "scope": self.scope,
            "operations": self.operations,
            "derived_block": derived,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "macro_shape": list(analysis["macro_shape"]),
                "scope": analysis["scope"],
                "operations": [[name, colour] for name, colour in analysis["operations"]],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "macro_rows": self.macro_rows,
                "macro_cols": self.macro_cols,
                "scope": self.scope,
                "wrap": self.wrap,
                "operations": [[name, colour] for name, colour in self.operations],
            },
            definitions=[
                {"name": "ForegroundRoleMask", "type": "Grid -> BoolGrid"},
                {"name": "LocalStencil", "type": "RoleMask x OffsetPattern -> Grid"},
                {"name": "MacroTiling", "type": "Grid x Shape -> Grid"},
                {"name": "StencilWallpaperEmitter", "type": "Grid x Stencil x MacroShape -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindForegroundRoles", "effect": "derive the foreground role mask from the current source"},
                {"index": 2, "definition": "ApplyStencil", "effect": "paint learned diagonal, row, or column relations on background cells"},
                {"index": 3, "definition": "ComposeMacroWallpaper", "effect": "apply the stencil before or after source tiling as demonstrated"},
            ],
            corollary="a local relation stencil and macro tiling jointly generate the expanded output",
            common_notions=[{"name": "stencil_wallpaper_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class BinaryComplementMacroProgram:
    layout_kind: str
    fill_policy: str
    background_colour: int
    fill_colour: int | None
    macro_rows: int
    macro_cols: int
    orientation: str
    kind: str = "binary_complement_macro"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.layout_kind,
            self.fill_policy,
            self.background_colour,
            self.fill_colour,
            self.macro_rows,
            self.macro_cols,
            self.orientation,
        )

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        colours = _palette(value)
        if len(colours) != 2 or self.background_colour not in colours:
            raise Inapplicable("complement macro requires a binary source")
        foreground = next(colour for colour in colours if colour != self.background_colour)
        fill = foreground if self.fill_policy == "source_foreground" else self.fill_colour
        if fill is None:
            raise Inapplicable("missing complement fill colour")
        complement = tuple(
            tuple(fill if cell == self.background_colour else self.background_colour for cell in row)
            for row in value
        )

        if self.layout_kind == "tile_all":
            prediction = _tile(complement, self.macro_rows, self.macro_cols)
            side = "all"
        elif self.layout_kind == "centroid_pair":
            height, width = _shape(value)
            coords = [(r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell != self.background_colour]
            if not coords:
                raise Inapplicable("missing foreground centroid")
            if self.orientation == "horizontal":
                complement = tuple(tuple(reversed(row)) for row in complement)
                mean = sum(c for _, c in coords) / len(coords)
                centre = (width - 1) / 2
                blocks = (complement, value) if mean < centre else (value, complement)
                prediction = tuple(tuple(cell for block in blocks for cell in block[r]) for r in range(height))
                side = "left" if mean < centre else "right"
            elif self.orientation == "vertical":
                complement = tuple(reversed(complement))
                mean = sum(r for r, _ in coords) / len(coords)
                centre = (height - 1) / 2
                blocks = (complement, value) if mean < centre else (value, complement)
                prediction = tuple(row for block in blocks for row in block)
                side = "top" if mean < centre else "bottom"
            else:
                raise Inapplicable("unknown complement-pair orientation")
        else:
            raise Inapplicable("unknown complement macro layout")

        return {
            "foreground_colour": foreground,
            "complement_fill": fill,
            "layout_kind": self.layout_kind,
            "source_side": side,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "foreground_colour": analysis["foreground_colour"],
                "complement_fill": analysis["complement_fill"],
                "layout_kind": analysis["layout_kind"],
                "source_side": analysis["source_side"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "layout_kind": self.layout_kind,
                "fill_policy": self.fill_policy,
                "background_colour": self.background_colour,
                "fill_colour": self.fill_colour,
                "macro_rows": self.macro_rows,
                "macro_cols": self.macro_cols,
                "orientation": self.orientation,
            },
            definitions=[
                {"name": "BinarySourceRole", "type": "Grid -> BoolGrid"},
                {"name": "ComplementRole", "type": "BoolGrid -> BoolGrid"},
                {"name": "CentroidSideRelation", "type": "Grid -> Side"},
                {"name": "ComplementMacroEmitter", "type": "Grid x Layout -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ExtractBinaryRoles", "effect": "derive foreground and background from the current source"},
                {"index": 2, "definition": "ConstructComplement", "effect": "invert the binary support using a source-relative or fixed fill"},
                {"index": 3, "definition": "ComposeComplementLayout", "effect": "tile the complement or pair it with the source according to centroid side"},
            ],
            corollary="binary source and complement roles compose a larger macro arrangement",
            common_notions=[{"name": "binary_complement_macro_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class ActiveAxisFillWallpaperProgram:
    background_colour: int
    fill_colour: int
    axis: str
    macro_rows: int
    macro_cols: int
    kind: str = "active_axis_fill_wallpaper"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.fill_colour, self.axis, self.macro_rows, self.macro_cols

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if len(_palette(value)) != 2 or self.background_colour not in _palette(value):
            raise Inapplicable("active-axis fill requires a binary source")
        rows = _array(value)
        height, width = _shape(value)
        if self.axis == "column":
            active = tuple(c for c in range(width) if any(value[r][c] != self.background_colour for r in range(height)))
            for c in active:
                for r in range(height):
                    if rows[r][c] == self.background_colour:
                        rows[r][c] = self.fill_colour
        elif self.axis == "row":
            active = tuple(r for r in range(height) if any(value[r][c] != self.background_colour for c in range(width)))
            for r in active:
                for c in range(width):
                    if rows[r][c] == self.background_colour:
                        rows[r][c] = self.fill_colour
        else:
            raise Inapplicable("unknown active-axis relation")
        if not active:
            raise Inapplicable("no active axis positions")
        derived = tuple(tuple(row) for row in rows)
        prediction = _tile(derived, self.macro_rows, self.macro_cols)
        return {"active_positions": active, "derived_block": derived, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "axis": self.axis,
                "active_positions": list(analysis["active_positions"]),
                "macro_shape": [self.macro_rows, self.macro_cols],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "fill_colour": self.fill_colour,
                "axis": self.axis,
                "macro_rows": self.macro_rows,
                "macro_cols": self.macro_cols,
            },
            definitions=[
                {"name": "ActiveAxisRelation", "type": "Grid x Axis -> IndexSet"},
                {"name": "AxisFill", "type": "Grid x IndexSet x Colour -> Grid"},
                {"name": "WallpaperTiling", "type": "Grid x MacroShape -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindActiveAxis", "effect": "select every row or column containing foreground evidence"},
                {"index": 2, "definition": "FillActiveSupport", "effect": "paint background cells in active positions with the learned auxiliary colour"},
                {"index": 3, "definition": "TileDerivedBlock", "effect": "repeat the relation-completed block over the learned macro shape"},
            ],
            corollary="active source axes are completed and reused as one wallpaper block",
            common_notions=[{"name": "active_axis_fill_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class GapRowDiagonalWallpaperProgram:
    background_colour: int
    line_colour: int
    kind: str = "gap_row_diagonal_wallpaper"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.line_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        gaps = tuple(
            r
            for r in range(1, height - 1)
            if all(cell == self.background_colour for cell in value[r])
            and value[r - 1] == value[r + 1]
            and any(cell != self.background_colour for cell in value[r - 1])
        )
        if not gaps:
            raise Inapplicable("missing repeated-row gap relation")
        rows = [[self.background_colour for _ in range(2 * width)] for _ in range(2 * height)]
        for r in range(height):
            for c in range(width):
                rows[r][c] = value[r][c]
                rows[height + r][width + c] = value[r][c]
        for macro_row in range(2):
            for gap in gaps:
                rr = macro_row * height + gap
                rows[rr] = [self.line_colour for _ in range(2 * width)]
        prediction = tuple(tuple(row) for row in rows)
        return {"gap_rows": gaps, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "gap_rows": list(analysis["gap_rows"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "line_colour": self.line_colour},
            definitions=[
                {"name": "RepeatedRowGap", "type": "Grid -> RowIndexSet"},
                {"name": "DiagonalMacroRoles", "type": "Grid -> 2x2 MacroGrid"},
                {"name": "SeparatorLineEmitter", "type": "RowIndexSet x Colour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DetectRepeatedRowGaps", "effect": "bind blank rows between identical foreground rows"},
                {"index": 2, "definition": "PlaceDiagonalSourceCopies", "effect": "place the source in the two diagonal macro roles"},
                {"index": 3, "definition": "ExtendGapLines", "effect": "paint each bound gap across the complete macro width"},
            ],
            corollary="repeated-row gaps induce separator lines across a diagonal source wallpaper",
            common_notions=[{"name": "gap_row_diagonal_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class SparseLatticeDensificationProgram:
    background_colour: int
    stride_row: int
    stride_col: int
    offset_row: int
    offset_col: int
    block_height: int
    block_width: int
    kind: str = "sparse_lattice_densification"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background_colour,
            self.stride_row,
            self.stride_col,
            self.offset_row,
            self.offset_col,
            self.block_height,
            self.block_width,
        )

    @property
    def description_length(self):
        return 8

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height % self.stride_row or width % self.stride_col:
            raise Inapplicable("source does not align to the learned sparse lattice")
        logical_height = height // self.stride_row
        logical_width = width // self.stride_col
        rows = [[self.background_colour for _ in range(logical_width * self.block_width)] for _ in range(logical_height * self.block_height)]
        logical_markers = []
        for r, row in enumerate(value):
            for c, cell in enumerate(row):
                if cell == self.background_colour:
                    continue
                if (r % self.stride_row, c % self.stride_col) != (self.offset_row, self.offset_col):
                    raise Inapplicable("foreground lies outside the learned residue class")
        for lr in range(logical_height):
            for lc in range(logical_width):
                colour = value[lr * self.stride_row + self.offset_row][lc * self.stride_col + self.offset_col]
                if colour == self.background_colour:
                    continue
                logical_markers.append((lr, lc, colour))
                for rr in range(lr * self.block_height, (lr + 1) * self.block_height):
                    for cc in range(lc * self.block_width, (lc + 1) * self.block_width):
                        rows[rr][cc] = colour
        if not logical_markers:
            raise Inapplicable("sparse lattice has no markers")
        prediction = tuple(tuple(row) for row in rows)
        return {"logical_shape": (logical_height, logical_width), "markers": logical_markers, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "logical_shape": list(analysis["logical_shape"]),
                "marker_count": len(analysis["markers"]),
                "block_shape": [self.block_height, self.block_width],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "stride_row": self.stride_row,
                "stride_col": self.stride_col,
                "offset_row": self.offset_row,
                "offset_col": self.offset_col,
                "block_height": self.block_height,
                "block_width": self.block_width,
            },
            definitions=[
                {"name": "SparseResidueLattice", "type": "Grid -> LogicalGrid"},
                {"name": "LogicalMarker", "type": "ResidueCell x Colour"},
                {"name": "SolidBlockEmitter", "type": "LogicalMarker x BlockShape -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "InferResidueClass", "effect": "bind the stride and within-cell marker offset"},
                {"index": 2, "definition": "ConstructLogicalGrid", "effect": "map sparse physical markers to logical cells"},
                {"index": 3, "definition": "DensifyMarkers", "effect": "replace every logical marker with a solid learned-size block"},
            ],
            corollary="a sparse physical lattice is lifted to a dense logical block grid",
            common_notions=[{"name": "sparse_lattice_densification_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class BorderDuplicateExpansionProgram:
    kind: str = "border_duplicate_expansion"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height < 2 or width < 2:
            raise Inapplicable("border duplication requires at least two rows and columns")
        row_indices = (0,) + tuple(range(height)) + (height - 1,)
        col_indices = (0,) + tuple(range(width)) + (width - 1,)
        prediction = tuple(tuple(value[r][c] for c in col_indices) for r in row_indices)
        return {"source_shape": (height, width), "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(analysis["source_shape"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"row_policy": "duplicate_outer", "column_policy": "duplicate_outer"},
            definitions=[
                {"name": "OuterRowRole", "type": "Grid -> RowPair"},
                {"name": "OuterColumnRole", "type": "Grid -> ColumnPair"},
                {"name": "SeparableRepeatEmitter", "type": "Grid x RepeatPolicy -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindOuterRoles", "effect": "identify the first and last row/column roles"},
                {"index": 2, "definition": "DuplicateOuterRows", "effect": "repeat each outer row once"},
                {"index": 3, "definition": "DuplicateOuterColumns", "effect": "repeat each outer column once"},
            ],
            corollary="the output is a separable expansion that duplicates only the outer roles",
            common_notions=[{"name": "border_duplicate_evidence", "evidence": evidence}],
        )


@dataclass(frozen=True)
class ToroidalDiagonalSubstitutionProgram:
    background_colour: int
    auxiliary_colour: int
    kind: str = "toroidal_diagonal_substitution"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.auxiliary_colour

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        colours = _palette(value)
        if height != width or len(colours) != 2 or self.background_colour not in colours:
            raise Inapplicable("toroidal diagonal substitution requires a square binary source")
        foreground = next(colour for colour in colours if colour != self.background_colour)
        coords = tuple((r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell != self.background_colour)
        if not coords:
            raise Inapplicable("missing foreground diagonal evidence")
        residues = tuple(sorted({(r - c) % height for r, c in coords}))
        rows = [[self.background_colour for _ in range(2 * width)] for _ in range(2 * height)]
        identity_kernel = ((self.auxiliary_colour, self.background_colour), (self.background_colour, self.auxiliary_colour))
        for r in range(height):
            for c in range(width):
                if value[r][c] != self.background_colour:
                    kernel = ((foreground, foreground), (foreground, foreground))
                elif (r - c) % height in residues:
                    kernel = identity_kernel
                else:
                    kernel = ((self.background_colour, self.background_colour), (self.background_colour, self.background_colour))
                for rr in range(2):
                    for cc in range(2):
                        rows[2 * r + rr][2 * c + cc] = kernel[rr][cc]
        prediction = tuple(tuple(row) for row in rows)
        return {"foreground_colour": foreground, "residues": residues, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "foreground_colour": analysis["foreground_colour"],
                "cyclic_diagonal_residues": list(analysis["residues"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "auxiliary_colour": self.auxiliary_colour},
            definitions=[
                {"name": "CyclicDiagonalResidue", "type": "Cell -> IntegerModN"},
                {"name": "ForegroundSolidKernel", "type": "Colour -> 2x2 Grid"},
                {"name": "MissingDiagonalKernel", "type": "Colour -> 2x2 Grid"},
                {"name": "SubstitutionEmitter", "type": "Grid x ResidueSet -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "InferCyclicDiagonals", "effect": "bind the toroidal diagonal residues containing foreground evidence"},
                {"index": 2, "definition": "SubstituteForeground", "effect": "replace observed foreground cells with solid 2x2 blocks"},
                {"index": 3, "definition": "CompleteDiagonalRoles", "effect": "replace missing cells on the same cyclic diagonals with the learned identity kernel"},
            ],
            corollary="foreground evidence selects cyclic diagonals whose missing roles receive an auxiliary substitution",
            common_notions=[{"name": "toroidal_diagonal_substitution_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting helpers.
# ---------------------------------------------------------------------------


def _fit_axis_periodic(pairs):
    result = []
    for axis in (0, 1):
        ratios = []
        valid_shape = True
        for source, target in pairs:
            source_height, source_width = _shape(source)
            target_height, target_width = _shape(target)
            source_shape = (source_height, source_width)
            target_shape = (target_height, target_width)
            other = 1 - axis
            if source_shape[other] != target_shape[other] or target_shape[axis] <= source_shape[axis]:
                valid_shape = False
                break
            ratios.append(Fraction(target_shape[axis], source_shape[axis]))
        if not valid_shape or len(set(ratios)) != 1:
            continue
        ratio = ratios[0]

        policies = [("identity", None, None)]
        common_colours = set.intersection(*(_palette(source) for source, _ in pairs))
        for background in sorted(common_colours):
            target_foregrounds = None
            valid = True
            for source, target in pairs:
                source = grid(source)
                target = grid(target)
                if len(_palette(source)) != 2:
                    valid = False
                    break
                source_height, source_width = _shape(source)
                prefix = tuple(target[:source_height]) if axis == 0 else tuple(tuple(row[:source_width]) for row in target)
                foreground_values = {
                    prefix[r][c]
                    for r in range(source_height)
                    for c in range(source_width)
                    if source[r][c] != background
                }
                if any(
                    prefix[r][c] != background
                    for r in range(source_height)
                    for c in range(source_width)
                    if source[r][c] == background
                ) or len(foreground_values) != 1:
                    valid = False
                    break
                local = foreground_values
                target_foregrounds = local if target_foregrounds is None else target_foregrounds & local
            if valid and target_foregrounds:
                policies.append(("foreground_fixed", background, next(iter(target_foregrounds))))

        for colour_policy, background, target_foreground in policies:
            program = AxisPeriodicExtensionProgram(
                axis,
                ratio.numerator,
                ratio.denominator,
                colour_policy,
                background,
                target_foreground,
            )
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    result.append(program)
            except Inapplicable:
                continue
    return result


def _fit_stencil_wallpaper(pairs):
    macro_shape = None
    for source, target in pairs:
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        if target_height % source_height or target_width % source_width:
            return []
        local = (target_height // source_height, target_width // source_width)
        if macro_shape is None:
            macro_shape = local
        elif macro_shape != local:
            return []
    if macro_shape is None or macro_shape == (1, 1):
        return []

    if any(len(_palette(source)) != 2 for source, _ in pairs):
        return []
    common_backgrounds = set.intersection(*(_palette(source) for source, _ in pairs))
    operation_names = tuple(OFFSET_PATTERNS) + ("row_fill", "col_fill")
    result = []
    for background in sorted(common_backgrounds):
        added_colours = set()
        for source, target in pairs:
            added_colours |= _palette(target) - _palette(source)
        if not added_colours or len(added_colours) > 2:
            continue
        for scope in ("pre", "post"):
            for wrap in (False, True):
                if wrap and scope == "post":
                    continue
                for names in permutations(operation_names, len(added_colours)):
                    if len(set(names)) != len(names):
                        continue
                    for colours in permutations(sorted(added_colours)):
                        operations = tuple((name, int(colour)) for name, colour in zip(names, colours))
                        program = StencilWallpaperProgram(
                            int(background), macro_shape[0], macro_shape[1], scope, wrap, operations
                        )
                        try:
                            if all(program.predict(source) == target for source, target in pairs):
                                result.append(program)
                        except Inapplicable:
                            continue
    return result


def _fit_binary_complement_macro(pairs):
    candidates = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        colours = _palette(source)
        if len(colours) != 2:
            return []
        local = set()
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        for background in colours:
            foreground = next(colour for colour in colours if colour != background)
            if target_height % source_height == 0 and target_width % source_width == 0:
                macro_rows = target_height // source_height
                macro_cols = target_width // source_width
                for fill_policy, fills in (
                    ("source_foreground", (None,)),
                    ("fixed", tuple(colour for colour in range(10) if colour not in colours)),
                ):
                    for fill in fills:
                        program = BinaryComplementMacroProgram(
                            "tile_all", fill_policy, int(background), fill, macro_rows, macro_cols, "horizontal"
                        )
                        try:
                            if program.predict(source) == target:
                                local.add(program.schema_key[1:])
                        except Inapplicable:
                            continue
            for orientation in ("horizontal", "vertical"):
                expected = (source_height, 2 * source_width) if orientation == "horizontal" else (2 * source_height, source_width)
                if (target_height, target_width) != expected:
                    continue
                for fill_policy, fills in (
                    ("source_foreground", (None,)),
                    ("fixed", tuple(colour for colour in range(10) if colour not in colours)),
                ):
                    for fill in fills:
                        program = BinaryComplementMacroProgram(
                            "centroid_pair", fill_policy, int(background), fill,
                            1 if orientation == "horizontal" else 2,
                            2 if orientation == "horizontal" else 1,
                            orientation,
                        )
                        try:
                            if program.predict(source) == target:
                                local.add(program.schema_key[1:])
                        except Inapplicable:
                            continue
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        if not candidates:
            return []
    return [BinaryComplementMacroProgram(*candidate) for candidate in sorted(candidates or (), key=repr)]


def _fit_active_axis_fill(pairs):
    candidates = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        if len(_palette(source)) != 2:
            return []
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        if target_height % source_height or target_width % source_width:
            return []
        macro_rows, macro_cols = target_height // source_height, target_width // source_width
        local = set()
        for background in _palette(source):
            for fill in range(10):
                if fill in _palette(source):
                    continue
                for axis in ("row", "column"):
                    program = ActiveAxisFillWallpaperProgram(
                        int(background), fill, axis, macro_rows, macro_cols
                    )
                    try:
                        if program.predict(source) == target:
                            local.add(program.schema_key[1:])
                    except Inapplicable:
                        continue
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        if not candidates:
            return []
    return [ActiveAxisFillWallpaperProgram(*candidate) for candidate in sorted(candidates or (), key=repr)]


def _fit_gap_row_diagonal(pairs):
    candidates = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        local = set()
        for background in _palette(source):
            for line_colour in range(10):
                if line_colour in _palette(source):
                    continue
                program = GapRowDiagonalWallpaperProgram(int(background), line_colour)
                try:
                    if program.predict(source) == target:
                        local.add((int(background), line_colour))
                except Inapplicable:
                    continue
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        if not candidates:
            return []
    return [GapRowDiagonalWallpaperProgram(*candidate) for candidate in sorted(candidates or ())]


def _fit_sparse_lattice(pairs):
    candidates = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        source_height, source_width = _shape(source)
        target_height, target_width = _shape(target)
        local = set()
        for background in _palette(source):
            nonbackground = tuple(
                (r, c)
                for r, row in enumerate(source)
                for c, cell in enumerate(row)
                if cell != background
            )
            if not nonbackground:
                continue
            for stride_row in range(2, min(6, source_height + 1)):
                if source_height % stride_row:
                    continue
                for stride_col in range(2, min(6, source_width + 1)):
                    if source_width % stride_col:
                        continue
                    residues = {(r % stride_row, c % stride_col) for r, c in nonbackground}
                    if len(residues) != 1:
                        continue
                    offset_row, offset_col = next(iter(residues))
                    logical_height = source_height // stride_row
                    logical_width = source_width // stride_col
                    if target_height % logical_height or target_width % logical_width:
                        continue
                    block_height = target_height // logical_height
                    block_width = target_width // logical_width
                    if block_height < 2 or block_width < 2:
                        continue
                    program = SparseLatticeDensificationProgram(
                        int(background), stride_row, stride_col,
                        offset_row, offset_col, block_height, block_width,
                    )
                    try:
                        if program.predict(source) == target:
                            local.add(program.schema_key[1:])
                    except Inapplicable:
                        continue
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        if not candidates:
            return []
    return [SparseLatticeDensificationProgram(*candidate) for candidate in sorted(candidates or ())]


def _fit_border_duplicate(pairs):
    program = BorderDuplicateExpansionProgram()
    try:
        return [program] if all(program.predict(source) == target for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_toroidal_diagonal(pairs):
    candidates = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        local = set()
        if len(_palette(source)) != 2:
            return []
        for background in _palette(source):
            for auxiliary in range(10):
                if auxiliary in _palette(source):
                    continue
                program = ToroidalDiagonalSubstitutionProgram(int(background), auxiliary)
                try:
                    if program.predict(source) == target:
                        local.add((int(background), auxiliary))
                except Inapplicable:
                    continue
        if not local:
            return []
        candidates = local if candidates is None else candidates & local
        if not candidates:
            return []
    return [ToroidalDiagonalSubstitutionProgram(*candidate) for candidate in sorted(candidates or ())]


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, AxisPeriodicExtensionProgram):
        return analysis["axis"], analysis["period"], _shape(source), _serial(source)
    if isinstance(program, StencilWallpaperProgram):
        return _shape(source), _serial(source)
    if isinstance(program, BinaryComplementMacroProgram):
        return analysis["foreground_colour"], analysis["source_side"], _serial(source)
    if isinstance(program, ActiveAxisFillWallpaperProgram):
        return analysis["active_positions"], _serial(source)
    if isinstance(program, GapRowDiagonalWallpaperProgram):
        return analysis["gap_rows"], _serial(source)
    if isinstance(program, SparseLatticeDensificationProgram):
        return analysis["logical_shape"], analysis["markers"]
    if isinstance(program, BorderDuplicateExpansionProgram):
        return analysis["source_shape"], _serial(source)
    if isinstance(program, ToroidalDiagonalSubstitutionProgram):
        return analysis["residues"], analysis["foreground_colour"]
    raise Inapplicable("unknown programme")


def fit_generative_expansion_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    selected = []
    fitters = (
        ("axis_periodic_extension", lambda: _fit_axis_periodic(pairs)),
        ("stencil_wallpaper", lambda: _fit_stencil_wallpaper(pairs)),
        ("binary_complement_macro", lambda: _fit_binary_complement_macro(pairs)),
        ("active_axis_fill_wallpaper", lambda: _fit_active_axis_fill(pairs)),
        ("gap_row_diagonal_wallpaper", lambda: _fit_gap_row_diagonal(pairs)),
        ("sparse_lattice_densification", lambda: _fit_sparse_lattice(pairs)),
        ("border_duplicate_expansion", lambda: _fit_border_duplicate(pairs)),
        ("toroidal_diagonal_substitution", lambda: _fit_toroidal_diagonal(pairs)),
    )
    for kind, fitter in fitters:
        if allowed is not None and kind not in allowed:
            continue
        try:
            selected.extend(fitter())
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    exact = []
    for program in selected:
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            exact.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    unique = {program.schema_key: program for program in exact}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, repr(program.permissiveness_cost)),
    )


# ---------------------------------------------------------------------------
# Inference.
# ---------------------------------------------------------------------------


def infer_generative_expansion(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_generative_expansion_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        groups[predictions].append(program.describe(pairs))
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "unified_generative_expansion_algebra": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "axis_periodic_extension":
        return AxisPeriodicExtensionProgram(
            int(parameters["axis"]), int(parameters["ratio_numerator"]), int(parameters["ratio_denominator"]),
            str(parameters["colour_policy"]), parameters.get("background_colour"), parameters.get("target_foreground_colour"),
        )
    if kind == "stencil_wallpaper":
        return StencilWallpaperProgram(
            int(parameters["background_colour"]), int(parameters["macro_rows"]), int(parameters["macro_cols"]),
            str(parameters["scope"]), bool(parameters["wrap"]),
            tuple((str(name), int(colour)) for name, colour in parameters["operations"]),
        )
    if kind == "binary_complement_macro":
        return BinaryComplementMacroProgram(
            str(parameters["layout_kind"]), str(parameters["fill_policy"]), int(parameters["background_colour"]),
            parameters.get("fill_colour"), int(parameters["macro_rows"]), int(parameters["macro_cols"]), str(parameters["orientation"]),
        )
    if kind == "active_axis_fill_wallpaper":
        return ActiveAxisFillWallpaperProgram(
            int(parameters["background_colour"]), int(parameters["fill_colour"]), str(parameters["axis"]),
            int(parameters["macro_rows"]), int(parameters["macro_cols"]),
        )
    if kind == "gap_row_diagonal_wallpaper":
        return GapRowDiagonalWallpaperProgram(int(parameters["background_colour"]), int(parameters["line_colour"]))
    if kind == "sparse_lattice_densification":
        return SparseLatticeDensificationProgram(
            int(parameters["background_colour"]), int(parameters["stride_row"]), int(parameters["stride_col"]),
            int(parameters["offset_row"]), int(parameters["offset_col"]), int(parameters["block_height"]), int(parameters["block_width"]),
        )
    if kind == "border_duplicate_expansion":
        return BorderDuplicateExpansionProgram()
    if kind == "toroidal_diagonal_substitution":
        return ToroidalDiagonalSubstitutionProgram(int(parameters["background_colour"]), int(parameters["auxiliary_colour"]))
    raise Inapplicable("unknown generative-expansion schema")


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    passed = bool(rows) and all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        relation_necessary = False
        equivariant = True

        if isinstance(program, AxisPeriodicExtensionProgram):
            modified = _array(source)
            modified[0][0] = _fresh_colour(source)
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True
            if program.colour_policy == "foreground_fixed":
                foreground = next(colour for colour in _palette(source) if colour != program.background_colour)
                fresh = _fresh_colour(source, (foreground,))
                equivariant = program.predict(_replace_colour(source, foreground, fresh)) == original

        elif isinstance(program, StencilWallpaperProgram):
            foreground = next(colour for colour in _palette(source) if colour != program.background_colour)
            fresh = _fresh_colour(source, (foreground,))
            recoloured_source = _replace_colour(source, foreground, fresh)
            expected = _replace_colour(original, foreground, fresh)
            try:
                equivariant = program.predict(recoloured_source) == expected
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell != program.background_colour:
                        modified[r][c] = program.background_colour
                        break
                else:
                    continue
                break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, BinaryComplementMacroProgram):
            foreground = next(colour for colour in _palette(source) if colour != program.background_colour)
            fresh = _fresh_colour(source, (foreground,))
            recoloured_source = _replace_colour(source, foreground, fresh)
            try:
                changed = program.predict(recoloured_source)
                relation_necessary = changed != original
                equivariant = True
            except Inapplicable:
                relation_necessary = True
            modified = _array(source)
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell == foreground:
                        modified[r][c] = program.background_colour
                        break
                else:
                    continue
                break
            try:
                relation_necessary = relation_necessary and program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, ActiveAxisFillWallpaperProgram):
            analysis = program.analyse(source)
            modified = _array(source)
            if program.axis == "column":
                c = analysis["active_positions"][0]
                for r in range(len(modified)):
                    modified[r][c] = program.background_colour
            else:
                r = analysis["active_positions"][0]
                modified[r] = [program.background_colour for _ in modified[r]]
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, GapRowDiagonalWallpaperProgram):
            analysis = program.analyse(source)
            modified = _array(source)
            gap = analysis["gap_rows"][0]
            modified[gap][0] = _fresh_colour(source)
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, SparseLatticeDensificationProgram):
            analysis = program.analyse(source)
            lr, lc, colour = analysis["markers"][0]
            fresh = _fresh_colour(source, (colour,))
            physical_r = lr * program.stride_row + program.offset_row
            physical_c = lc * program.stride_col + program.offset_col
            modified = _array(source)
            modified[physical_r][physical_c] = fresh
            try:
                changed = program.predict(tuple(tuple(row) for row in modified))
                expected = _replace_colour(original, colour, fresh)
                equivariant = changed == expected
                relation_necessary = changed != original
            except Inapplicable:
                relation_necessary = True
                equivariant = False

        elif isinstance(program, BorderDuplicateExpansionProgram):
            modified = _array(source)
            fresh = _fresh_colour(source)
            modified[0][0] = fresh
            changed = program.predict(tuple(tuple(row) for row in modified))
            relation_necessary = changed != original
            equivariant = changed[0][0] == fresh and changed[1][1] == fresh

        elif isinstance(program, ToroidalDiagonalSubstitutionProgram):
            analysis = program.analyse(source)
            foreground = analysis["foreground_colour"]
            fresh = _fresh_colour(source, (foreground,))
            recoloured = _replace_colour(source, foreground, fresh)
            changed = program.predict(recoloured)
            equivariant = changed == _replace_colour(original, foreground, fresh)
            modified = _array(source)
            r, c = next((r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell == foreground)
            modified[r][c] = program.background_colour
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        else:
            return {"kind": "unknown", "passed": False}

        rows.append({
            "demonstration": index,
            "relation_necessary": relation_necessary,
            "equivariant_or_stable": equivariant,
        })
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Validation.
# ---------------------------------------------------------------------------


def validate_generative_expansion(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected_tuple = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_generative_expansion_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held_index,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def generative_expansion_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_generative_expansion_programs(pairs)}))


infer = infer_generative_expansion
validate = validate_generative_expansion
