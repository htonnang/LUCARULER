"""LUCA V148: ordered reference-graph extraction.

Three transformations share one consequence operator:

    scene -> ordered colour-structure nodes -> precedence / occlusion edges
          -> ordered reference graph -> palette-strip emission -> proof

The family is task-ID blind and target blind.  It derives the ordering axis,
line precedence, rectangle occlusion graph, output orientation, padding, and
band dimensions from the demonstrations and each current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_ordered_reference_graph_extraction"
LANGUAGE = "spinoza_ordered_reference_graph_extraction_v148"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "ordered_palette_strip",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "ordered_reference_graph": True,
            "shared_palette_strip_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _compress(sequence):
    output = []
    for item in sequence:
        if not output or output[-1] != item:
            output.append(item)
    return tuple(output)


def _strip(sequence, orientation="vertical", thickness=1):
    sequence = tuple(int(item) for item in sequence)
    if not sequence or thickness < 1:
        raise Inapplicable("invalid strip")
    if orientation == "vertical":
        return tuple(tuple(colour for _ in range(thickness)) for colour in sequence)
    if orientation == "horizontal":
        row = tuple(colour for colour in sequence)
        return tuple(row for _ in range(thickness))
    raise Inapplicable("unknown strip orientation")


def _straight_support(cells):
    cells = frozenset(cells)
    if len(cells) < 2:
        return False
    rows = sorted({r for r, _ in cells})
    cols = sorted({c for _, c in cells})
    if len(rows) == 1:
        return len(cols) == max(cols) - min(cols) + 1
    if len(cols) == 1:
        return len(rows) == max(rows) - min(rows) + 1
    differences = {r - c for r, c in cells}
    if len(differences) == 1:
        return len(rows) == len(cols) == len(cells) and len(rows) == max(rows) - min(rows) + 1
    sums = {r + c for r, c in cells}
    if len(sums) == 1:
        return len(rows) == len(cols) == len(cells) and len(rows) == max(rows) - min(rows) + 1
    return False


def _perimeter(box):
    r0, c0, r1, c1 = box
    return frozenset(
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    )


def _unique_topological_order(nodes, edges):
    nodes = tuple(nodes)
    adjacency = {node: set() for node in nodes}
    indegree = {node: 0 for node in nodes}
    for source, target in edges:
        if source == target or target in adjacency[source]:
            continue
        adjacency[source].add(target)
        indegree[target] += 1
    output = []
    for _ in nodes:
        available = [node for node in nodes if indegree[node] == 0 and node not in output]
        if len(available) != 1:
            raise Inapplicable("precedence graph is not a unique total order")
        node = available[0]
        output.append(node)
        for target in adjacency[node]:
            indegree[target] -= 1
    return tuple(output)


# ---------------------------------------------------------------------------
# Shared operator: ordered reference palette emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class JaggedLayerCompressionProgram:
    kind = "jagged_layer_compression"
    operator = "ordered_reference_palette_emission"
    node_vocabulary = "ordered_colour_structure_nodes"
    edge_vocabulary = "axis_precedence_and_occlusion_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        candidates = []

        column_sequences = [_compress(value[r][c] for r in range(h)) for c in range(w)]
        if len(set(column_sequences)) == 1:
            sequence = column_sequences[0]
            if len(sequence) >= 2 and len(set(sequence)) == len(sequence) == len(_palette(value)):
                candidates.append(("vertical", sequence))

        row_sequences = [_compress(value[r][c] for c in range(w)) for r in range(h)]
        if len(set(row_sequences)) == 1:
            sequence = row_sequences[0]
            if len(sequence) >= 2 and len(set(sequence)) == len(sequence) == len(_palette(value)):
                candidates.append(("horizontal", sequence))

        if len(candidates) != 1:
            raise Inapplicable("one jagged layer axis required")
        orientation, sequence = candidates[0]
        return _strip(sequence, orientation, 1)

    def describe(self, pairs):
        return _law(
            self,
            scene="a complete canvas partitioned into jagged but order-consistent colour layers",
            relation_chain=(
                "infer the axis whose every orthogonal scan has one identical compressed colour sequence",
                "construct precedence edges between adjacent layer colours",
                "emit one palette cell per ordered layer along the inferred axis",
            ),
            parameters={},
            corollary="Compress the jagged layer field into its ordered colour strip.",
            notions=["layer order", "axis inference", "run compression", "palette strip"],
        )


@dataclass(frozen=True)
class ExtremalLinePrecedenceProgram:
    slot_count: int
    thickness: int
    orientation: str
    pad_side: str
    kind = "extremal_line_precedence"
    operator = "ordered_reference_palette_emission"
    node_vocabulary = "ordered_colour_structure_nodes"
    edge_vocabulary = "axis_precedence_and_occlusion_edges"

    @property
    def schema_key(self):
        return (self.kind, self.slot_count, self.thickness, self.orientation, self.pad_side)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        counts = Counter(cell for row in value for cell in row)
        if counts[background] <= max((count for colour, count in counts.items() if colour != background), default=0):
            raise Inapplicable("background must dominate the line scene")
        colours = sorted(_palette(value) - {background})
        if not (2 <= len(colours) <= self.slot_count):
            raise Inapplicable("line count incompatible with learned strip slots")

        supports = {}
        for colour in colours:
            cells = frozenset(
                (r, c)
                for r in range(h)
                for c in range(w)
                if value[r][c] == colour
            )
            if not _straight_support(cells):
                raise Inapplicable("every payload colour must form one straight axis or diagonal support")
            supports[colour] = cells

        if self.orientation == "vertical":
            keys = {colour: min(r for r, _ in cells) for colour, cells in supports.items()}
        elif self.orientation == "horizontal":
            keys = {colour: min(c for _, c in cells) for colour, cells in supports.items()}
        else:
            raise Inapplicable("unknown learned strip orientation")
        if len(set(keys.values())) != len(keys):
            raise Inapplicable("line precedence has tied extrema")
        ordered = tuple(sorted(colours, key=lambda colour: (keys[colour], colour)))
        padding = (background,) * (self.slot_count - len(ordered))
        sequence = padding + ordered if self.pad_side == "front" else ordered + padding
        return _strip(sequence, self.orientation, self.thickness)

    def describe(self, pairs):
        return _law(
            self,
            scene="a dominant background with monochrome straight supports at distinct axis extrema",
            relation_chain=(
                "extract one line node per non-background colour",
                "order line nodes by their leading row or column extremum",
                "pad the learned slot frame with background and emit equal-width palette bands",
            ),
            parameters={
                "slot_count": self.slot_count,
                "thickness": self.thickness,
                "orientation": self.orientation,
                "pad_side": self.pad_side,
            },
            corollary="Emit the extremal line precedence order in the learned palette-strip frame.",
            notions=["line node", "extremal precedence", "background padding", "palette bands"],
        )


@dataclass(frozen=True)
class RectangleOcclusionOrderProgram:
    kind = "rectangle_occlusion_order"
    operator = "ordered_reference_palette_emission"
    node_vocabulary = "ordered_colour_structure_nodes"
    edge_vocabulary = "axis_precedence_and_occlusion_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if not (3 <= len(colours) <= 8):
            raise Inapplicable("three to eight rectangle colours required")

        perimeters = {}
        for colour in colours:
            cells = frozenset(
                (r, c)
                for r in range(h)
                for c in range(w)
                if value[r][c] == colour
            )
            box = _bbox(cells)
            r0, c0, r1, c1 = box
            if r1 - r0 < 1 or c1 - c0 < 1:
                raise Inapplicable("every colour must define a non-degenerate rectangle")
            perimeter = _perimeter(box)
            if not cells <= perimeter or len(cells) / len(perimeter) < 0.65:
                raise Inapplicable("colour support is not a sufficiently complete rectangle perimeter")
            corners = ((r0, c0), (r0, c1), (r1, c0), (r1, c1))
            if sum(value[r][c] == colour for r, c in corners) < 3:
                raise Inapplicable("rectangle identity is not stable at its corners")
            perimeters[colour] = perimeter

        edges = set()
        witnessed_pairs = 0
        for index, first in enumerate(colours):
            for second in colours[index + 1 :]:
                intersections = perimeters[first] & perimeters[second]
                directions = set()
                for r, c in intersections:
                    observed = value[r][c]
                    if observed == first:
                        directions.add((second, first))
                    elif observed == second:
                        directions.add((first, second))
                if len(directions) > 1:
                    raise Inapplicable("rectangle pair gives contradictory occlusion directions")
                if directions:
                    witnessed_pairs += 1
                    edges.update(directions)
        if witnessed_pairs < len(colours) - 1:
            raise Inapplicable("insufficient occlusion evidence for a total order")
        ordered = _unique_topological_order(colours, edges)
        return _strip(ordered, "vertical", 1)

    def describe(self, pairs):
        return _law(
            self,
            scene="multiple coloured rectangle perimeters whose crossings reveal drawing precedence",
            relation_chain=(
                "reconstruct one rectangle-perimeter node for each non-background colour",
                "at every perimeter crossing direct an edge from the covered rectangle to the visible rectangle",
                "topologically sort the unique occlusion graph and emit its ordered palette",
            ),
            parameters={},
            corollary="Emit rectangle colours from earliest covered layer to latest visible layer.",
            notions=["rectangle perimeter", "occlusion edge", "unique topological order", "palette strip"],
        )


# ---------------------------------------------------------------------------
# Fitting, counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


def _fit_static(pairs, cls):
    programme = cls()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _output_strip_parameters(target):
    target = grid(target)
    h, w = _shape(target)
    row_uniform = all(len(set(row)) == 1 for row in target)
    col_uniform = all(len({target[r][c] for r in range(h)}) == 1 for c in range(w))
    candidates = []
    if row_uniform and h >= 2:
        candidates.append((h, w, "vertical"))
    if col_uniform and w >= 2:
        candidates.append((w, h, "horizontal"))
    return candidates


def _fit_extremal_line_precedence(pairs):
    pair_parameters = [_output_strip_parameters(target) for _, target in pairs]
    common = set(pair_parameters[0]) if pair_parameters else set()
    for options in pair_parameters[1:]:
        common &= set(options)
    output = []
    for slot_count, thickness, orientation in sorted(common):
        for pad_side in ("front", "back"):
            programme = ExtremalLinePrecedenceProgram(slot_count, thickness, orientation, pad_side)
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return output


_FITTERS = {
    "jagged_layer_compression": lambda pairs: _fit_static(pairs, JaggedLayerCompressionProgram),
    "extremal_line_precedence": _fit_extremal_line_precedence,
    "rectangle_occlusion_order": lambda pairs: _fit_static(pairs, RectangleOcclusionOrderProgram),
}


def fit_ordered_reference_graph_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        palette = sorted(_palette(source))
        counts = Counter(cell for row in source for cell in row)
        # Rare cells, corners, and boundary cells are examined first, but the
        # search remains input-derived and may inspect the complete scene.
        cells = sorted(
            ((r, c) for r in range(len(source)) for c in range(len(source[0]))),
            key=lambda cell: (
                counts[source[cell[0]][cell[1]]],
                0 if cell[0] in (0, len(source) - 1) or cell[1] in (0, len(source[0]) - 1) else 1,
                cell,
            ),
        )
        passed = False
        tested = 0
        witness = None
        for r, c in cells:
            original_colour = source[r][c]
            replacements = [colour for colour in palette if colour != original_colour]
            if not replacements:
                replacements = [(original_colour + 1) % 10]
            for replacement in replacements:
                tested += 1
                work = _array(source)
                work[r][c] = replacement
                try:
                    changed = programme.predict(grid(work)) != original
                except Inapplicable:
                    changed = True
                if changed:
                    passed = True
                    witness = {
                        "cell": [r, c],
                        "from": int(original_colour),
                        "to": int(replacement),
                    }
                    break
                if tested >= 600:
                    break
            if passed or tested >= 600:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "ordered_structure_node_or_precedence_edge" if passed else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_ordered_reference_graph_extraction(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_ordered_reference_graph_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "ordered_reference_graph": True,
            "shared_palette_strip_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_ordered_reference_graph_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_ordered_reference_graph_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_ordered_reference_graph_extraction(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
