"""LUCA V143: parameterised node/edge grammar and bounded relation chains.

Seven input-derived schemas reuse three consequence operators:

    scene -> parameterised nodes -> derived edges -> bounded relation chain
          -> shared operator -> deterministic full grid

The family is task-ID blind and test-target blind. Programmes store only
semantic colour roles, orientation/phase parameters, and local graph policies
learned from demonstrations.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_parameterised_node_edge_relation_chains"
LANGUAGE = "spinoza_parameterised_node_edge_relation_chains_v143"
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Shared evidence language.
# ---------------------------------------------------------------------------


def _law(program, *, scene, relation, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": relation,
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "parameterised_node_edge_vocabulary": True,
            "bounded_relation_chain": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    return counts.most_common(1)[0][0]


def _transpose(value: Grid):
    value = grid(value)
    return grid(zip(*value))


def _canonical_three(value: Grid, orientation: str):
    value = grid(value)
    if orientation == "horizontal":
        if len(value) != 3:
            raise Inapplicable("three-row canonical scene required")
        return value
    if orientation == "vertical":
        if len(value[0]) != 3:
            raise Inapplicable("three-column canonical scene required")
        return _transpose(value)
    raise Inapplicable("unknown orientation")


def _uncanonical_three(value: Grid, orientation: str):
    return grid(value) if orientation == "horizontal" else _transpose(value)


def _single_new_colour(pairs):
    colour = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        extra = _palette(target) - _palette(source)
        if len(extra) != 1:
            raise Inapplicable("one new semantic colour required")
        current = int(next(iter(extra)))
        if colour is None:
            colour = current
        elif colour != current:
            raise Inapplicable("consequence colour changes between demonstrations")
    if colour is None:
        raise Inapplicable("missing consequence colour")
    return colour


def _all_blank(value: Grid):
    return len(_palette(grid(value))) == 1


def _spiral_mask(height: int, width: int, corner: str, clockwise: bool):
    if height != width or height < 5:
        raise Inapplicable("square canvas of side at least five required")
    corners = {
        "top_left": (0, 0),
        "top_right": (0, width - 1),
        "bottom_right": (height - 1, width - 1),
        "bottom_left": (height - 1, 0),
    }
    initial = {
        ("top_left", True): (0, 1),
        ("top_left", False): (1, 0),
        ("top_right", True): (1, 0),
        ("top_right", False): (0, -1),
        ("bottom_right", True): (0, -1),
        ("bottom_right", False): (-1, 0),
        ("bottom_left", True): (-1, 0),
        ("bottom_left", False): (0, 1),
    }
    if corner not in corners:
        raise Inapplicable("unknown start corner")
    directions = [(-1, 0), (0, 1), (1, 0), (0, -1)]
    direction = directions.index(initial[(corner, clockwise)])
    current = corners[corner]
    painted = {current}

    def admissible(candidate, predecessor):
        r, c = candidate
        if not (0 <= r < height and 0 <= c < width) or candidate in painted:
            return False
        for dr, dc in directions:
            neighbour = (r + dr, c + dc)
            if neighbour in painted and neighbour != predecessor:
                return False
        return True

    final_candidate = None
    for _ in range(height * width * 4):
        dr, dc = directions[direction]
        candidate = (current[0] + dr, current[1] + dc)
        if not admissible(candidate, current):
            turned = (direction + 1) % 4 if clockwise else (direction - 1) % 4
            dr, dc = directions[turned]
            candidate = (current[0] + dr, current[1] + dc)
            if not admissible(candidate, current):
                final_candidate = candidate
                break
            direction = turned
        current = candidate
        painted.add(current)

    # Even canvases have one final central cell. It is the only point where
    # the terminating segment may touch the preceding spiral arm.
    if height % 2 == 0 and final_candidate is not None:
        r, c = final_candidate
        if 0 <= r < height and 0 <= c < width and final_candidate not in painted:
            painted.add(final_candidate)
    return painted


# ---------------------------------------------------------------------------
# Shared operator I: dimension-parameterised field emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BlankSpiralFieldProgram:
    paint_colour: int
    corner: str
    clockwise: bool

    kind = "blank_canvas_spiral_field"
    operator = "dimension_parameterised_field_emission"
    node_vocabulary = "canvas_dimension_boundary_nodes"
    edge_vocabulary = "inward_turn_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.corner, self.clockwise

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if not _all_blank(value):
            raise Inapplicable("blank canvas required")
        background = value[0][0]
        if self.paint_colour == background:
            raise Inapplicable("paint role equals background")
        height, width = _shape(value)
        mask = _spiral_mask(height, width, self.corner, self.clockwise)
        output = [[background for _ in range(width)] for _ in range(height)]
        for r, c in mask:
            output[r][c] = self.paint_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a monochrome square canvas whose dimensions are the only input nodes",
            relation="boundary nodes induce a one-cell-gap inward turning successor chain",
            parameters={
                "paint_colour": self.paint_colour,
                "corner": self.corner,
                "clockwise": self.clockwise,
                "gap": 1,
            },
            corollary="Materialise the complete dimension-driven spiral field.",
            notions=["canvas dimension", "boundary node", "successor turn", "one-cell gap"],
        )


@dataclass(frozen=True)
class OddParityLatticeFieldProgram:
    paint_colour: int
    hole_row_parity: int
    hole_column_parity: int

    kind = "blank_canvas_odd_parity_lattice"
    operator = "dimension_parameterised_field_emission"
    node_vocabulary = "canvas_dimension_boundary_nodes"
    edge_vocabulary = "parity_class_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.hole_row_parity, self.hole_column_parity

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if not _all_blank(value):
            raise Inapplicable("blank canvas required")
        background = value[0][0]
        if self.paint_colour == background:
            raise Inapplicable("paint role equals background")
        height, width = _shape(value)
        if height < 5 or width < 5 or height % 2 == 0 or width % 2 == 0:
            raise Inapplicable("odd canvas dimensions of at least five required")
        return grid([
            [
                background
                if r % 2 == self.hole_row_parity and c % 2 == self.hole_column_parity
                else self.paint_colour
                for c in range(width)
            ]
            for r in range(height)
        ])

    def describe(self, pairs):
        return _law(
            self,
            scene="a monochrome odd-dimension canvas",
            relation="row and column parity nodes intersect to define a repeated hole lattice",
            parameters={
                "paint_colour": self.paint_colour,
                "hole_row_parity": self.hole_row_parity,
                "hole_column_parity": self.hole_column_parity,
                "period": 2,
            },
            corollary="Fill the field while retaining the learned parity-intersection holes.",
            notions=["dimension node", "parity class", "Cartesian incidence", "periodic field"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: periodic phase-class emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ZigzagPhaseHighlightProgram:
    paint_colour: int
    orientation: str
    path_phase: int
    selection_phase: int

    kind = "zigzag_turning_phase_highlight"
    operator = "periodic_phase_class_emission"
    node_vocabulary = "periodic_axis_motif_nodes"
    edge_vocabulary = "phase_class_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.orientation, self.path_phase, self.selection_phase

    def predict(self, value: Grid) -> Grid:
        canonical = _canonical_three(value, self.orientation)
        colours = _palette(canonical)
        width = len(canonical[0])
        candidates = [
            colour
            for colour in colours
            if all(sum(canonical[r][c] == colour for r in range(3)) == 1 for c in range(width))
        ]
        if len(candidates) != 1 or len(colours) != 2:
            raise Inapplicable("one single-cell zigzag role and one background role required")
        source = candidates[0]
        background = next(iter(colours - {source}))
        if self.paint_colour in colours:
            raise Inapplicable("highlight role must be new")
        pattern = (0, 1, 2, 1)
        for c in range(width):
            expected = pattern[(c + self.path_phase) % 4]
            if canonical[expected][c] != source:
                raise Inapplicable("zigzag phase mismatch")
            if any(canonical[r][c] != background for r in range(3) if r != expected):
                raise Inapplicable("non-zigzag material present")

        output = _array(canonical)
        emitted = 0
        # Virtual turning points one cell beyond a boundary are included when
        # their triangular consequence intersects the current canvas.
        for c in range(-1, width + 2):
            if (c - self.selection_phase) % 6:
                continue
            turning_row = pattern[(c + self.path_phase) % 4]
            if turning_row == 0:
                consequence = ((1, c), (2, c - 1), (2, c), (2, c + 1))
            elif turning_row == 2:
                consequence = ((1, c), (0, c - 1), (0, c), (0, c + 1))
            else:
                continue
            for r, cc in consequence:
                if 0 <= cc < width and output[r][cc] == background:
                    output[r][cc] = self.paint_colour
                    emitted += 1
        if not emitted:
            raise Inapplicable("empty phase-class consequence")
        return _uncanonical_three(grid(output), self.orientation)

    def describe(self, pairs):
        return _law(
            self,
            scene="a three-cell-wide periodic zigzag path",
            relation="every third turning node belongs to a learned six-column phase class",
            parameters={
                "paint_colour": self.paint_colour,
                "orientation": self.orientation,
                "path_phase": self.path_phase,
                "selection_phase": self.selection_phase,
                "turn_period": 6,
            },
            corollary="Highlight the triangular region opposite each selected turning node.",
            notions=["zigzag node", "turning point", "phase class", "periodic successor"],
        )


@dataclass(frozen=True)
class PeriodicCombPhaseRecolourProgram:
    paint_colour: int
    orientation: str
    phase: int

    kind = "periodic_comb_phase_recolour"
    operator = "periodic_phase_class_emission"
    node_vocabulary = "periodic_axis_motif_nodes"
    edge_vocabulary = "phase_class_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.orientation, self.phase

    def predict(self, value: Grid) -> Grid:
        canonical = _canonical_three(value, self.orientation)
        width = len(canonical[0])
        middle = set(canonical[1])
        if len(middle) != 1:
            raise Inapplicable("uniform comb spine required")
        source = next(iter(middle))
        colours = _palette(canonical)
        if len(colours) != 2 or self.paint_colour in colours:
            raise Inapplicable("binary comb and new consequence role required")
        background = next(iter(colours - {source}))
        for c in range(width):
            top = canonical[0][c] == source
            bottom = canonical[2][c] == source
            if top == bottom:
                raise Inapplicable("one alternating tooth per column required")
            if canonical[0][c] not in (source, background) or canonical[2][c] not in (source, background):
                raise Inapplicable("foreign comb material")
            if c and (canonical[0][c] == source) == (canonical[0][c - 1] == source):
                raise Inapplicable("comb teeth do not alternate")

        output = _array(canonical)
        emitted = 0
        for c in range(width):
            if (c - self.phase) % 3:
                continue
            for r in range(3):
                if output[r][c] == source:
                    output[r][c] = self.paint_colour
                    emitted += 1
        if not emitted:
            raise Inapplicable("empty comb phase consequence")
        return _uncanonical_three(grid(output), self.orientation)

    def describe(self, pairs):
        return _law(
            self,
            scene="a three-cell-wide comb with alternating teeth",
            relation="every third axis node belongs to the recoloured phase class",
            parameters={
                "paint_colour": self.paint_colour,
                "orientation": self.orientation,
                "phase": self.phase,
                "period": 3,
            },
            corollary="Recolour each selected spine-and-tooth motif as one phase-class unit.",
            notions=["comb spine", "alternating tooth", "phase class", "motif unit"],
        )


# ---------------------------------------------------------------------------
# Shared operator III: rectilinear marker-graph materialisation.
# ---------------------------------------------------------------------------


def _singleton_points(value: Grid):
    value = grid(value)
    background = _mode(value)
    points = []
    for r, row in enumerate(value):
        for c, colour in enumerate(row):
            if colour != background:
                points.append((r, c, colour))
    return background, points


@dataclass(frozen=True)
class OrthogonalBandIntersectionProgram:
    intersection_colour: int

    kind = "orthogonal_band_intersection_projection"
    operator = "rectilinear_marker_graph_materialisation"
    node_vocabulary = "axis_extremal_marker_nodes"
    edge_vocabulary = "rectilinear_incidence_edges"

    @property
    def schema_key(self):
        return self.kind, self.intersection_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        height, width = _shape(value)
        background = _mode(value)
        roles = _palette(value) - {background}
        if len(roles) != 2 or self.intersection_colour in _palette(value):
            raise Inapplicable("two source bands and one new intersection role required")

        vertical = horizontal = None
        for colour in roles:
            cells = [(r, c) for r in range(height) for c in range(width) if value[r][c] == colour]
            rows = {r for r, _ in cells}
            columns = {c for _, c in cells}
            if len(columns) == 1 and len(rows) >= 2 and max(rows) - min(rows) + 1 == len(rows):
                if vertical is not None:
                    raise Inapplicable("multiple vertical bands")
                vertical = (colour, next(iter(columns)))
            elif len(rows) == 1 and len(columns) >= 2 and max(columns) - min(columns) + 1 == len(columns):
                if horizontal is not None:
                    raise Inapplicable("multiple horizontal bands")
                horizontal = (colour, next(iter(rows)))
            else:
                raise Inapplicable("source role is not a straight band")
        if vertical is None or horizontal is None:
            raise Inapplicable("orthogonal bands required")

        vertical_colour, column = vertical
        horizontal_colour, row = horizontal
        output = [[background for _ in range(width)] for _ in range(height)]
        for r in range(height):
            output[r][column] = vertical_colour
        for c in range(width):
            output[row][c] = horizontal_colour
        output[row][column] = self.intersection_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one vertical marker segment and one horizontal marker segment",
            relation="axis-extension edges meet at one Cartesian incidence node",
            parameters={"intersection_colour": self.intersection_colour},
            corollary="Extend both bands to the canvas boundaries and mark their intersection.",
            notions=["axis segment", "boundary projection", "Cartesian incidence", "intersection"],
        )


@dataclass(frozen=True)
class CrossMarkerFrameProgram:
    link_colour: int

    kind = "five_marker_frame_and_cross"
    operator = "rectilinear_marker_graph_materialisation"
    node_vocabulary = "axis_extremal_marker_nodes"
    edge_vocabulary = "rectilinear_incidence_edges"

    @property
    def schema_key(self):
        return self.kind, self.link_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        height, width = _shape(value)
        background, points = _singleton_points(value)
        if len(points) != 5 or self.link_colour in _palette(value):
            raise Inapplicable("five singleton markers and one new link role required")
        if len({(r, c) for r, c, _ in points}) != 5:
            raise Inapplicable("marker collision")

        min_row = min(r for r, _, _ in points)
        max_row = max(r for r, _, _ in points)
        min_column = min(c for _, c, _ in points)
        max_column = max(c for _, c, _ in points)
        top = [point for point in points if point[0] == min_row]
        bottom = [point for point in points if point[0] == max_row]
        left = [point for point in points if point[1] == min_column]
        right = [point for point in points if point[1] == max_column]
        if not all(len(group) == 1 for group in (top, bottom, left, right)):
            raise Inapplicable("unique extremal markers required")
        top, bottom, left, right = top[0], bottom[0], left[0], right[0]
        extremes = {(top[0], top[1]), (bottom[0], bottom[1]), (left[0], left[1]), (right[0], right[1])}
        if len(extremes) != 4:
            raise Inapplicable("extremal roles must be distinct")
        centre = [point for point in points if (point[0], point[1]) not in extremes]
        if len(centre) != 1:
            raise Inapplicable("one interior marker required")
        centre = centre[0]
        if not (top[0] < centre[0] < bottom[0] and left[1] < centre[1] < right[1]):
            raise Inapplicable("centre is not strictly interior")
        if not (left[1] < top[1] < right[1] and left[1] < bottom[1] < right[1]):
            raise Inapplicable("top or bottom marker lies outside frame span")
        if not (top[0] < left[0] < bottom[0] and top[0] < right[0] < bottom[0]):
            raise Inapplicable("left or right marker lies outside frame span")

        output = [[background for _ in range(width)] for _ in range(height)]
        # Side interiors first; top and bottom boundaries own the corners.
        for r in range(top[0] + 1, bottom[0]):
            output[r][left[1]] = left[2]
            output[r][right[1]] = right[2]
        for c in range(left[1], right[1] + 1):
            output[top[0]][c] = top[2]
            output[bottom[0]][c] = bottom[2]
        # Interior cross, with the semantic centre restored last.
        for r in range(top[0] + 1, bottom[0]):
            if output[r][centre[1]] == background:
                output[r][centre[1]] = self.link_colour
        for c in range(left[1] + 1, right[1]):
            if output[centre[0]][c] == background:
                output[centre[0]][c] = self.link_colour
        output[centre[0]][centre[1]] = centre[2]
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="four unique extremal markers and one strictly interior marker",
            relation="extremal nodes induce a coloured rectangle while the interior node induces orthogonal incidence edges",
            parameters={"link_colour": self.link_colour},
            corollary="Materialise the coloured boundary frame and the centre-preserving cross.",
            notions=["extremal marker", "interior marker", "rectangle edge", "orthogonal incidence"],
        )


@dataclass(frozen=True)
class CornerMarkerGraphProgram:
    link_colour: int

    kind = "four_corner_marker_graph"
    operator = "rectilinear_marker_graph_materialisation"
    node_vocabulary = "axis_extremal_marker_nodes"
    edge_vocabulary = "rectilinear_incidence_edges"

    @property
    def schema_key(self):
        return self.kind, self.link_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        height, width = _shape(value)
        background, points = _singleton_points(value)
        if len(points) != 4 or self.link_colour in _palette(value):
            raise Inapplicable("four corner markers and one new link role required")
        rows = sorted({r for r, _, _ in points})
        columns = sorted({c for _, c, _ in points})
        if len(rows) != 2 or len(columns) != 2:
            raise Inapplicable("two marker rows and two marker columns required")
        r0, r1 = rows
        c0, c1 = columns
        if r0 < 1 or c0 < 1 or r1 >= height - 1 or c1 >= width - 1:
            raise Inapplicable("one-cell square margin required")
        mapping = {(r, c): colour for r, c, colour in points}
        required = {(r0, c0), (r0, c1), (r1, c0), (r1, c1)}
        if set(mapping) != required:
            raise Inapplicable("all rectangle corners must be marked")
        tl, tr, bl, br = mapping[(r0, c0)], mapping[(r0, c1)], mapping[(r1, c0)], mapping[(r1, c1)]
        if tl != br or tr != bl or tl == tr:
            raise Inapplicable("two diagonal colour roles required")

        output = [[background for _ in range(width)] for _ in range(height)]
        for r, c in required:
            centre_colour = mapping[(r, c)]
            surround_colour = tr if centre_colour == tl else tl
            for rr in range(r - 1, r + 2):
                for cc in range(c - 1, c + 2):
                    output[rr][cc] = surround_colour
            output[r][c] = centre_colour

        def dotted_interval(start, end):
            cells = list(range(start, end + 1))
            length = len(cells)
            return [cell for index, cell in enumerate(cells) if min(index, length - 1 - index) % 2 == 0]

        if c0 + 2 <= c1 - 2:
            for c in dotted_interval(c0 + 2, c1 - 2):
                output[r0][c] = self.link_colour
                output[r1][c] = self.link_colour
        if r0 + 2 <= r1 - 2:
            for r in dotted_interval(r0 + 2, r1 - 2):
                output[r][c0] = self.link_colour
                output[r][c1] = self.link_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="four singleton markers occupying the corners of an axis-aligned rectangle",
            relation="diagonal colour pairing decorates each corner while symmetric parity edges link corresponding sides",
            parameters={"link_colour": self.link_colour, "corner_radius": 1, "link_period": 2},
            corollary="Expand the corner nodes and emit the symmetric dotted rectangle graph.",
            notions=["corner node", "diagonal pairing", "side incidence", "symmetric dotted edge"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and proof obligations.
# ---------------------------------------------------------------------------


def _fit_blank_spiral(pairs):
    try:
        paint = _single_new_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for corner in ("top_left", "top_right", "bottom_right", "bottom_left"):
        for clockwise in (True, False):
            programme = BlankSpiralFieldProgram(paint, corner, clockwise)
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return output


def _fit_odd_lattice(pairs):
    try:
        paint = _single_new_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for row_parity in (0, 1):
        for column_parity in (0, 1):
            programme = OddParityLatticeFieldProgram(paint, row_parity, column_parity)
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return output


def _fit_zigzag(pairs):
    try:
        paint = _single_new_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for orientation in ("horizontal", "vertical"):
        for path_phase in range(4):
            for selection_phase in range(6):
                programme = ZigzagPhaseHighlightProgram(paint, orientation, path_phase, selection_phase)
                try:
                    if all(programme.predict(source) == grid(target) for source, target in pairs):
                        output.append(programme)
                except Inapplicable:
                    pass
    return output


def _fit_comb(pairs):
    try:
        paint = _single_new_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for orientation in ("horizontal", "vertical"):
        for phase in range(3):
            programme = PeriodicCombPhaseRecolourProgram(paint, orientation, phase)
            try:
                if all(programme.predict(source) == grid(target) for source, target in pairs):
                    output.append(programme)
            except Inapplicable:
                pass
    return output


def _fit_single_new(pairs, cls):
    try:
        programme = cls(_single_new_colour(pairs))
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


_FITTERS = {
    "blank_canvas_spiral_field": _fit_blank_spiral,
    "blank_canvas_odd_parity_lattice": _fit_odd_lattice,
    "zigzag_turning_phase_highlight": _fit_zigzag,
    "periodic_comb_phase_recolour": _fit_comb,
    "orthogonal_band_intersection_projection": lambda pairs: _fit_single_new(pairs, OrthogonalBandIntersectionProgram),
    "five_marker_frame_and_cross": lambda pairs: _fit_single_new(pairs, CrossMarkerFrameProgram),
    "four_corner_marker_graph": lambda pairs: _fit_single_new(pairs, CornerMarkerGraphProgram),
}


def fit_parameterised_node_edge_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        colours = sorted(_palette(source))
        passed = False
        tested = 0
        # Mutate both material and background nodes. Blank fields receive a
        # foreign decoy; structured scenes test removal or role substitution.
        for r in range(len(source)):
            for c in range(len(source[0])):
                replacements = [colour for colour in colours if colour != source[r][c]]
                if not replacements:
                    replacements = [programme.paint_colour if hasattr(programme, "paint_colour") else (source[r][c] + 1) % 10]
                for replacement in replacements[:2]:
                    tested += 1
                    work = _array(source)
                    work[r][c] = replacement
                    try:
                        changed = programme.predict(grid(work)) != original
                    except Inapplicable:
                        changed = True
                    if changed:
                        passed = True
                        break
                if passed:
                    break
            if passed:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "parameterised_node_or_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_parameterised_node_edge_relation_chains(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_parameterised_node_edge_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "parameterised_node_edge_vocabulary": True,
            "bounded_relation_chain": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_parameterised_node_edge_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_parameterised_node_edge_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_parameterised_node_edge_relation_chains(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
