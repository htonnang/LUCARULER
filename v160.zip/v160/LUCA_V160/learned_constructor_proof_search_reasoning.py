"""LUCA V140: learned constructor grammar with bounded proof search.

Seven scene schemas share three multi-task consequence operators. Inference
receives demonstrations and test inputs only; task identifiers and test targets
are discarded by ``public_task``.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass
from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _mode, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_learned_constructor_proof_search"
LANGUAGE = "spinoza_learned_constructor_proof_search_v140"
SCHEMA_VERSION = 1


def _background(value): return int(_mode(grid(value)))
def _palette(value): return {x for row in grid(value) for x in row}
def _bbox(cells):
    rs=[r for r,_ in cells]; cs=[c for _,c in cells]
    return min(rs),min(cs),max(rs),max(cs)

def _components(value,predicate,connectivity=4):
    value=grid(value); h,w=_shape(value); seen=set(); out=[]
    dirs=[(-1,0),(1,0),(0,-1),(0,1)]
    if connectivity==8: dirs += [(-1,-1),(-1,1),(1,-1),(1,1)]
    for r in range(h):
        for c in range(w):
            if (r,c) in seen or not predicate(r,c,value[r][c]): continue
            st=[(r,c)]; seen.add((r,c)); cells=[]
            while st:
                rr,cc=st.pop(); cells.append((rr,cc))
                for dr,dc in dirs:
                    nr,nc=rr+dr,cc+dc
                    if 0<=nr<h and 0<=nc<w and (nr,nc) not in seen and predicate(nr,nc,value[nr][nc]):
                        seen.add((nr,nc)); st.append((nr,nc))
            out.append(frozenset(cells))
    return out

def _monochrome_components(value):
    value=grid(value); bg=_background(value); h,w=_shape(value); seen=set(); out=[]
    for r in range(h):
        for c in range(w):
            if (r,c) in seen or value[r][c]==bg: continue
            col=value[r][c]; st=[(r,c)]; seen.add((r,c)); cells=[]
            while st:
                rr,cc=st.pop(); cells.append((rr,cc))
                for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
                    nr,nc=rr+dr,cc+dc
                    if 0<=nr<h and 0<=nc<w and (nr,nc) not in seen and value[nr][nc]==col:
                        seen.add((nr,nc)); st.append((nr,nc))
            out.append({'colour':int(col),'cells':frozenset(cells),'bbox':_bbox(cells)})
    return out

def _canonical(cells):
    r0,c0,_,_=_bbox(cells); return frozenset((r-r0,c-c0) for r,c in cells)
def _solid_rect(comp):
    r0,c0,r1,c1=comp['bbox']; return len(comp['cells'])==(r1-r0+1)*(c1-c0+1)

def _changed_colours(source,target):
    source=grid(source); target=grid(target)
    if _shape(source)!=_shape(target): raise Inapplicable('shape changed')
    vals=set(); n=0
    for r in range(len(source)):
        for c in range(len(source[0])):
            if source[r][c]!=target[r][c]: vals.add(target[r][c]); n+=1
    if not n: raise Inapplicable('identity')
    return vals

def _single_paint(pairs,require_new=True):
    paint=None
    for s,t in pairs:
        s=grid(s); t=grid(t); bg=_background(s); cols=_changed_colours(s,t)
        if len(cols)!=1: raise Inapplicable('not one paint')
        cur=int(next(iter(cols)))
        if cur==bg or (require_new and cur in _palette(s)): raise Inapplicable('invalid paint role')
        for r in range(len(s)):
            for c in range(len(s[0])):
                if s[r][c]!=t[r][c] and (s[r][c]!=bg or t[r][c]!=cur): raise Inapplicable('not bg emission')
        if paint is None: paint=cur
        elif paint!=cur: raise Inapplicable('unstable paint')
    if paint is None: raise Inapplicable('missing paint')
    return paint

def _two_new_paints(pairs):
    seen=None
    for s,t in pairs:
        s=grid(s); t=grid(t); bg=_background(s); cols=_changed_colours(s,t)
        if len(cols)!=2 or any(c==bg or c in _palette(s) for c in cols): raise Inapplicable('not two new paints')
        for r in range(len(s)):
            for c in range(len(s[0])):
                if s[r][c]!=t[r][c] and s[r][c]!=bg: raise Inapplicable('overwrites structure')
        cur=frozenset(int(x) for x in cols)
        if seen is None: seen=cur
        elif seen!=cur: raise Inapplicable('unstable paints')
    return tuple(sorted(seen))

def _law(program,scene,relation,operator,parameters,corollary,notions):
    return {'family':FAMILY,'language':LANGUAGE,'schema_version':SCHEMA_VERSION,'schema':program.kind,
            'algebra':{'scene':scene,'relation':relation,'operator':operator,'emitter':'deterministic_full_grid'},
            'parameters':parameters,'definitions':[],'propositions':[],'corollary':corollary,'common_notions':notions,
            'adequacy':{'exact_training_fit':True,'typed_program':True,'task_ids_used':False,'test_targets_used':False,
                        'absolute_coordinates_stored':False,'input_derived_graph':True,'learned_constructor_grammar':True,
                        'bounded_proof_search':True,'validation_protocol':'held_exact_consensus_with_counterfactual_pruning'}}

@dataclass(frozen=True)
class MaximalEmptySquareMaterialisationProgram:
    paint_colour:int
    kind='maximal_empty_square_materialisation'; operator='component_region_materialisation'
    @property
    def schema_key(self): return self.kind,self.paint_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); bg=_background(value)
        if len(_palette(value))!=2 or min(h,w)<4: raise Inapplicable('binary field required')
        cand=[]
        for k in range(min(h,w),1,-1):
            for r in range(h-k+1):
                for c in range(w-k+1):
                    if all(value[rr][cc]==bg for rr in range(r,r+k) for cc in range(c,c+k)): cand.append((k,r,c))
        occ=set()
        for k,r,c in cand:
            cells={(rr,cc) for rr in range(r,r+k) for cc in range(c,c+k)}
            if cells & occ: continue
            occ |= cells
        if not occ: raise Inapplicable('no square')
        out=_array(value)
        for r,c in occ: out[r][c]=self.paint_colour
        return grid(out)
    def describe(self,pairs): return _law(self,'binary obstacle field','descending-side maximal-square cover with overlap exclusion',self.operator,{'paint_colour':self.paint_colour,'minimum_side':2},'Materialise the deterministic maximal empty-square cover.',['background','maximality','non-overlap'])

@dataclass(frozen=True)
class RectangularJunctionChamberProgram:
    paint_colour:int
    kind='rectangular_junction_chamber_materialisation'; operator='component_region_materialisation'
    @property
    def schema_key(self): return self.kind,self.paint_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); bg=_background(value); pal=_palette(value)
        if len(pal)!=2: raise Inapplicable('one wall colour required')
        wall=next(iter(pal-{bg})); out=_array(value); selected=[]
        for comp in _components(value,lambda r,c,x:x==bg):
            r0,c0,r1,c1=_bbox(comp)
            if len(comp)!=(r1-r0+1)*(c1-c0+1) or r0==0 or r1==h-1: continue
            boundary=set()
            for r,c in comp:
                for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
                    nr,nc=r+dr,c+dc
                    if 0<=nr<h and 0<=nc<w and value[nr][nc]==wall: boundary.add((nr,nc))
            maxdeg=max((sum(0<=r+dr<h and 0<=c+dc<w and value[r+dr][c+dc]==wall for dr,dc in ((-1,0),(1,0),(0,-1),(0,1))) for r,c in boundary),default=0)
            if maxdeg>=3: selected.append(comp)
        if not selected: raise Inapplicable('no chamber')
        for comp in selected:
            for r,c in comp: out[r][c]=self.paint_colour
        return grid(out)
    def describe(self,pairs): return _law(self,'monochrome wall graph','rectangular background component incident to a degree-three-or-higher wall junction',self.operator,{'paint_colour':self.paint_colour,'junction_degree':3},'Materialise every rectangular junction chamber.',['component','rectangle','incidence','degree'])

@dataclass(frozen=True)
class SeededBackgroundFloodProgram:
    seed_colour:int
    kind='seeded_background_component_materialisation'; operator='component_region_materialisation'
    @property
    def schema_key(self): return self.kind,self.seed_colour
    def predict(self,value):
        value=grid(value); bg=_background(value); pal=_palette(value)
        if self.seed_colour==bg or self.seed_colour not in pal or len(pal)<5: raise Inapplicable('seed/barrier field required')
        out=_array(value); selected=[]
        for comp in _components(value,lambda r,c,x:x in (bg,self.seed_colour)):
            if any(value[r][c]==self.seed_colour for r,c in comp) and any(value[r][c]==bg for r,c in comp): selected.append(comp)
        if not selected: raise Inapplicable('no seeded component')
        for comp in selected:
            for r,c in comp:
                if value[r][c]==bg: out[r][c]=self.seed_colour
        return grid(out)
    def describe(self,pairs): return _law(self,'multicolour barrier field','four-connected components in the induced background-plus-seed subgraph',self.operator,{'seed_colour':self.seed_colour,'connectivity':4},'Materialise seed-reachable background components.',['reachability','seed','barrier'])

@dataclass(frozen=True)
class MaximumBackgroundAxisProgram:
    paint_colour:int
    kind='maximum_background_axis_emission'; operator='extremal_axis_emission'
    @property
    def schema_key(self): return self.kind,self.paint_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); bg=_background(value)
        if len(_palette(value))!=3 or self.paint_colour in _palette(value): raise Inapplicable('three-colour field required')
        rc=[sum(x==bg for x in row) for row in value]; cc=[sum(value[r][c]==bg for r in range(h)) for c in range(w)]
        rows={i for i,x in enumerate(rc) if x==max(rc)}; cols={i for i,x in enumerate(cc) if x==max(cc)}
        if len(rows)==h or len(cols)==w: raise Inapplicable('uninformative extrema')
        out=_array(value); n=0
        for r in range(h):
            for c in range(w):
                if value[r][c]==bg and (r in rows or c in cols): out[r][c]=self.paint_colour; n+=1
        if not n: raise Inapplicable('empty')
        return grid(out)
    def describe(self,pairs): return _law(self,'multicolour occupancy field','argmax background-count rows union argmax background-count columns',self.operator,{'paint_colour':self.paint_colour,'extremum':'maximum'},'Emit the maximum-background row/column graph.',['count','argmax','axis'])

@dataclass(frozen=True)
class TerrainExtremaRayProgram:
    high_colour:int; low_colour:int
    kind='terrain_extrema_ray_emission'; operator='extremal_axis_emission'
    @property
    def schema_key(self): return self.kind,self.high_colour,self.low_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); bg=_background(value); pal=_palette(value)
        if len(pal)!=3 or len(set(value[0]))!=1: raise Inapplicable('terrain scene required')
        boundary=value[0][0]
        if boundary==bg: raise Inapplicable('boundary missing')
        terrains=pal-{bg,boundary}
        if len(terrains)!=1 or self.high_colour in pal or self.low_colour in pal or self.high_colour==self.low_colour: raise Inapplicable('roles')
        terrain=next(iter(terrains)); tops=[]
        for c in range(w):
            rs=[r for r in range(h) if value[r][c]==terrain]
            if rs: tops.append((min(rs),c))
        if len(tops)<2: raise Inapplicable('few columns')
        hi=min(r for r,c in tops); lo=max(r for r,c in tops)
        if hi==lo: raise Inapplicable('flat')
        hc=max(c for r,c in tops if r==hi); lc=min(c for r,c in tops if r==lo)
        if hc==lc: raise Inapplicable('collapsed')
        out=_array(value); n=0
        for r in range(hi):
            if value[r][hc]==bg: out[r][hc]=self.high_colour; n+=1
        for r in range(lo):
            if value[r][lc]==bg: out[r][lc]=self.low_colour; n+=1
        if not n: raise Inapplicable('empty')
        return grid(out)
    def describe(self,pairs): return _law(self,'terrain profile below uniform boundary','rightmost highest column and leftmost lowest column under learned tie policies',self.operator,{'high_colour':self.high_colour,'low_colour':self.low_colour,'high_tie':'rightmost','low_tie':'leftmost'},'Emit semantically distinct terrain-extremum rays.',['extremum','tie policy','ray'])

@dataclass(frozen=True)
class CartesianLatticeCompletionProgram:
    paint_colour:int
    kind='cartesian_lattice_completion'; operator='relational_structure_completion'
    @property
    def schema_key(self): return self.kind,self.paint_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); bg=_background(value); comps=_monochrome_components(value)
        if len(_palette(value))!=2 or len(comps)<3 or self.paint_colour in _palette(value): raise Inapplicable('motif lattice required')
        if len({x['colour'] for x in comps})!=1 or len({_canonical(x['cells']) for x in comps})!=1: raise Inapplicable('motif mismatch')
        motif=_canonical(comps[0]['cells']); r0,c0,r1,c1=_bbox(motif)
        if len(motif)<4 or len(motif)==(r1-r0+1)*(c1-c0+1): raise Inapplicable('non-solid motif required')
        pos={(x['bbox'][0],x['bbox'][1]) for x in comps}; rows=sorted({r for r,c in pos}); cols=sorted({c for r,c in pos})
        if len(rows)<2 or len(cols)<2: raise Inapplicable('not 2d')
        missing=[(r,c) for r in rows for c in cols if (r,c) not in pos]
        if not missing: raise Inapplicable('complete')
        out=_array(value)
        for r,c in missing:
            placed={(r+dr,c+dc) for dr,dc in motif}
            if any(not(0<=rr<h and 0<=cc<w) or value[rr][cc]!=bg for rr,cc in placed): raise Inapplicable('obstruction')
            for rr,cc in placed: out[rr][cc]=self.paint_colour
        return grid(out)
    def describe(self,pairs): return _law(self,'repeated equal-shape motifs','Cartesian product of observed motif-anchor rows and columns',self.operator,{'paint_colour':self.paint_colour,'anchor':'top_left'},'Complete the relational motif lattice.',['shape','Cartesian product','completion'])

@dataclass(frozen=True)
class StrictInteriorRectangleMSTProgram:
    paint_colour:int
    kind='strict_interior_rectangle_mst_completion'; operator='relational_structure_completion'
    @property
    def schema_key(self): return self.kind,self.paint_colour
    def predict(self,value):
        value=grid(value); bg=_background(value)
        if self.paint_colour in _palette(value): raise Inapplicable('new connector role required')
        comps=_monochrome_components(value)
        if not comps or any(not _solid_rect(x) for x in comps): raise Inapplicable('solid rectangles required')
        by=defaultdict(list)
        for x in comps: by[x['colour']].append(x)
        selected=[]
        for colour,rs in sorted(by.items()):
            if len(rs)<2: continue
            edges=[]
            for i in range(len(rs)):
                for j in range(i+1,len(rs)):
                    a,b=rs[i]['bbox'],rs[j]['bbox']; cells=set(); gap=None
                    if a[3]<b[1] or b[3]<a[1]:
                        left,right=(a,b) if a[3]<b[1] else (b,a); rr0=max(left[0],right[0])+1; rr1=min(left[2],right[2])-1
                        if rr0<=rr1:
                            c0,c1=left[3]+1,right[1]-1; cells={(r,c) for r in range(rr0,rr1+1) for c in range(c0,c1+1)}; gap=c1-c0+1
                    elif a[2]<b[0] or b[2]<a[0]:
                        top,bottom=(a,b) if a[2]<b[0] else (b,a); cc0=max(top[1],bottom[1])+1; cc1=min(top[3],bottom[3])-1
                        if cc0<=cc1:
                            r0,r1=top[2]+1,bottom[0]-1; cells={(r,c) for r in range(r0,r1+1) for c in range(cc0,cc1+1)}; gap=r1-r0+1
                    if cells and all(value[r][c]==bg for r,c in cells): edges.append((gap,len(cells),i,j,frozenset(cells)))
            parent=list(range(len(rs)))
            def find(x):
                while parent[x]!=x: parent[x]=parent[parent[x]]; x=parent[x]
                return x
            for gap,area,i,j,cells in sorted(edges,key=lambda x:x[:4]):
                ri,rj=find(i),find(j)
                if ri==rj: continue
                parent[ri]=rj; selected.append(cells)
        if not selected: raise Inapplicable('no forest')
        out=_array(value)
        for cells in selected:
            for r,c in cells: out[r][c]=self.paint_colour
        return grid(out)
    def describe(self,pairs): return _law(self,'solid rectangular components','same-colour overlap graph with gap-length-weighted minimum spanning forest',self.operator,{'paint_colour':self.paint_colour,'projection':'strict_overlap_interior','edge_order':'gap_then_area_then_component_order'},'Complete the rectangle graph with an acyclic strict-interior forest.',['rectangle','overlap','MST'])


def _fit_single(pairs,cls,require_new=True):
    try:
        p=cls(_single_paint(pairs,require_new=require_new)); return [p] if all(p.predict(s)==grid(t) for s,t in pairs) else []
    except Inapplicable: return []
def _fit_seed(pairs):
    try:
        col=_single_paint(pairs,require_new=False)
        if any(col not in _palette(s) for s,t in pairs): raise Inapplicable('unwitnessed seed')
        p=SeededBackgroundFloodProgram(col); return [p] if all(p.predict(s)==grid(t) for s,t in pairs) else []
    except Inapplicable: return []
def _fit_terrain(pairs):
    try: a,b=_two_new_paints(pairs)
    except Inapplicable: return []
    out=[]
    for hi,lo in ((a,b),(b,a)):
        p=TerrainExtremaRayProgram(hi,lo)
        try:
            if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
        except Inapplicable: pass
    return out
_FITTERS={
 'maximal_empty_square_materialisation':lambda p:_fit_single(p,MaximalEmptySquareMaterialisationProgram),
 'rectangular_junction_chamber_materialisation':lambda p:_fit_single(p,RectangularJunctionChamberProgram),
 'seeded_background_component_materialisation':_fit_seed,
 'maximum_background_axis_emission':lambda p:_fit_single(p,MaximumBackgroundAxisProgram),
 'terrain_extrema_ray_emission':_fit_terrain,
 'cartesian_lattice_completion':lambda p:_fit_single(p,CartesianLatticeCompletionProgram),
 'strict_interior_rectangle_mst_completion':lambda p:_fit_single(p,StrictInteriorRectangleMSTProgram),
}

def fit_learned_constructor_programs(pairs,minimum_pairs=2,allowed_kinds=None):
    pairs=tuple((grid(s),grid(t)) for s,t in pairs)
    if len(pairs)<minimum_pairs: return []
    kinds=tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS); out=[]; seen=set()
    for kind in kinds:
        f=_FITTERS.get(kind)
        if not f: continue
        try: vals=f(pairs)
        except (Inapplicable,ValueError,IndexError,KeyError,TypeError,ZeroDivisionError,StopIteration): continue
        for p in vals:
            if p.schema_key not in seen: seen.add(p.schema_key); out.append(p)
    return out

def _counterfactual(program,pairs):
    rows=[]
    for idx,(source,_) in enumerate(pairs):
        source=grid(source); bg=_background(source); original=program.predict(source); passed=False; tested=0
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c]==bg: continue
                tested+=1; work=_array(source); work[r][c]=bg
                try: changed=program.predict(grid(work))!=original
                except Inapplicable: changed=True
                if changed: passed=True; break
            if passed: break
        rows.append({'demonstration':idx,'passed':passed,'candidate_nodes_tested':tested,'node_removal_changes_or_rejects':passed,'witness_role':'input_derived_structural_node' if passed else None})
    return {'kind':program.kind,'rows':rows,'passed':bool(rows) and all(x['passed'] for x in rows)}

def infer_learned_constructor_proof_search(task,minimum_pairs=2,allowed_kinds=None):
    clean=public_task(task); pairs=tuple((d['input'],d['output']) for d in clean['train']); programs=fit_learned_constructor_programs(pairs,minimum_pairs,allowed_kinds)
    groups=defaultdict(list); invalid=rejected=0
    for p in programs:
        try:
            cf=_counterfactual(p,pairs)
            if not cf['passed']: rejected+=1; continue
            preds=tuple(p.predict(x['input']) for x in clean['test'])
        except (Inapplicable,ValueError,IndexError,KeyError,TypeError,ZeroDivisionError,StopIteration): invalid+=1; continue
        law=p.describe(pairs); law['adequacy']['counterfactual_passed']=True; groups[preds].append(law)
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'; chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':len(groups)<2,
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None} for i in range(len(clean['test']))],
            'supporting_families':[FAMILY] if chosen else [],'supporting_laws':groups.get(chosen,[])[:100] if chosen else [],
            'witness_predictions':[[[list(r) for r in p] for p in preds] for preds in list(groups)[:2]],
            'stats':{'fitted_programs':len(programs),'inapplicable_programs':invalid,'counterfactual_rejected_programs':rejected,
                     'schemas':sorted({l['schema'] for ls in groups.values() for l in ls}),
                     'scene_relations':sorted({l['algebra']['relation'] for ls in groups.values() for l in ls}),
                     'operators':sorted({l['algebra']['operator'] for ls in groups.values() for l in ls}),
                     'proof_carrying':True,'learned_constructor_grammar':True,'bounded_proof_search':True,'task_ids_used':False,'test_targets_used':False,'absolute_coordinates_stored':False}}

def _programs_for_expected(clean,full):
    expected=tuple(grid(x['prediction']) for x in full['tests']); allowed=tuple(full.get('stats',{}).get('schemas',())); pairs=tuple((d['input'],d['output']) for d in clean['train']); out=[]
    for p in fit_learned_constructor_programs(pairs,2,allowed):
        try:
            if tuple(p.predict(x['input']) for x in clean['test'])==expected and _counterfactual(p,pairs)['passed']: out.append(p)
        except Inapplicable: pass
    return expected,out

def _validate_program(clean,program,expected):
    full_pairs=tuple((d['input'],d['output']) for d in clean['train']); folds=[]
    for hi,held in enumerate(clean['train']):
        remaining=tuple((d['input'],d['output']) for i,d in enumerate(clean['train']) if i!=hi)
        refit=fit_learned_constructor_programs(remaining,1,(program.kind,)); groups=set(); exact=0
        for p in refit:
            try:
                if p.predict(held['input'])!=grid(held['output']) or not _counterfactual(p,full_pairs)['passed']: continue
                exact+=1; groups.add(tuple(p.predict(x['input']) for x in clean['test']))
            except Inapplicable: pass
        stable=len(groups)==1 and next(iter(groups),None)==expected
        folds.append({'held_index':hi,'status':'unique' if exact and stable else 'ambiguous' if len(groups)>1 else 'no_fit','held_example_exact':bool(exact),'test_prediction_stable':stable,'validation_mode':'held_exact_consensus_with_counterfactual_pruning','refitted_programs':len(refit),'held_exact_prediction_groups':len(groups)})
    cf=_counterfactual(program,full_pairs); passed=all(x['held_example_exact'] and x['test_prediction_stable'] for x in folds) and cf['passed']
    return {'passed':passed,'reason':'passed' if passed else 'validation_failure','folds':folds,'counterfactuals':[cf],'validation_protocol':'held_exact_consensus_with_counterfactual_pruning'}

def validate_learned_constructor_proof_search(task,full):
    clean=public_task(task)
    if full.get('status')!='unique': return {'passed':False,'reason':'full_fit_not_unique','folds':[],'counterfactuals':[]}
    expected,programs=_programs_for_expected(clean,full)
    if not programs: return {'passed':False,'reason':'missing_program_schema','folds':[],'counterfactuals':[]}
    checks=[_validate_program(clean,p,expected) for p in programs]; passed=any(x['passed'] for x in checks); selected=next((x for x in checks if x['passed']),checks[0])
    return {'passed':passed,'reason':'passed' if passed else 'validation_failure','folds':selected['folds'],'counterfactuals':[y for x in checks for y in x['counterfactuals']],'validation_protocol':'held_exact_consensus_with_counterfactual_pruning','program_checks':checks}
