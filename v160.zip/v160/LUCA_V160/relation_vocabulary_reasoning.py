"""LUCA V123: learned relation vocabulary and adversarial discovery.

This family learns coordinate-free extraction relations from demonstrations::

    scene -> structural relation -> unique role -> relation-defined projection

Four conservative schemas are exposed:

* ``fundamental_quadrant_projection`` extracts one learned fundamental domain
  from an even bounding box whose quadrants share palette and D4-equivalent
  binary support;
* ``largest_closed_frame_interior`` returns the interior of the unique
  largest complete non-background frame;
* ``framed_pattern_outlier`` returns the sole framed pattern class among
  repeated framed distractors;
* ``instruction_bbox_frame_selector`` uses a non-frame instruction trace to
  bind exactly one clean 3x3 framed object.

No task identifiers, stored demonstration coordinates, or test outputs are
used during inference.  Predictions require exact training fit, output
consensus, held-demonstration refitting, and schema-specific counterfactuals.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_learned_relation_vocabulary"
LANGUAGE = "spinoza_learned_relation_vocabulary_v1"
SCHEMA_VERSION = "learned_relation_vocabulary_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    maximum = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == maximum]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _bbox(cells: Iterable[tuple[int, int]]) -> tuple[int, int, int, int]:
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _crop(value: Grid, box) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = box
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_mask(cells: Iterable[tuple[int, int]]):
    cells = tuple(cells)
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _rotate90(value: Grid) -> Grid:
    value = grid(value)
    return tuple(tuple(row) for row in zip(*value[::-1]))


def _rotate180(value: Grid) -> Grid:
    return _rotate90(_rotate90(value))


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _d4_transforms(value: Grid):
    value = grid(value)
    result = []
    current = value
    for _ in range(4):
        result.append(current)
        result.append(tuple(tuple(reversed(row)) for row in current))
        current = _rotate90(current)
    return tuple(dict.fromkeys(result))


def _binary(value: Grid, background: int) -> Grid:
    return tuple(tuple(int(cell != background) for cell in row) for row in grid(value))


def _is_subgrid(target: Grid, source: Grid) -> bool:
    target = grid(target)
    source = grid(source)
    th, tw = _shape(target)
    sh, sw = _shape(source)
    if th > sh or tw > sw:
        return False
    return any(
        tuple(tuple(source[r0 + r][c0 + c] for c in range(tw)) for r in range(th)) == target
        for r0 in range(sh - th + 1)
        for c0 in range(sw - tw + 1)
    )


def _non_background_bbox(value: Grid, background: int):
    cells = [
        (r, c)
        for r, row in enumerate(grid(value))
        for c, cell in enumerate(row)
        if cell != background
    ]
    return _bbox(cells)


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Rectangular-frame and 3x3-frame perception.
# ---------------------------------------------------------------------------


def _rectangle_frames(value: Grid):
    """Return complete non-background axis-aligned rectangular frames.

    Frames are detected by border evidence rather than colour-component
    isolation, so same-colour material elsewhere cannot hide a valid frame.
    """
    value = grid(value)
    height, width = _shape(value)
    background = _unique_modal(value)
    result = []
    for r0 in range(height - 2):
        for r1 in range(r0 + 2, height):
            by_colour = defaultdict(list)
            for c in range(width):
                colour = value[r0][c]
                if colour != background and value[r1][c] == colour:
                    by_colour[colour].append(c)
            for colour, columns in by_colour.items():
                for index, c0 in enumerate(columns[:-1]):
                    for c1 in columns[index + 1:]:
                        if c1 - c0 < 2:
                            continue
                        if not all(value[r][c0] == colour and value[r][c1] == colour for r in range(r0, r1 + 1)):
                            continue
                        if not all(value[r0][c] == colour and value[r1][c] == colour for c in range(c0, c1 + 1)):
                            continue
                        box = (r0, c0, r1, c1)
                        result.append({
                            "border": colour,
                            "bbox": box,
                            "crop": _crop(value, box),
                            "interior": _crop(value, (r0 + 1, c0 + 1, r1 - 1, c1 - 1)),
                        })
    unique = {}
    for frame in result:
        unique[(frame["border"], frame["bbox"])] = frame
    return tuple(unique[key] for key in sorted(unique, key=repr))


def _clean_3x3_frames(value: Grid):
    value = grid(value)
    height, width = _shape(value)
    background = _unique_modal(value)
    frames = []
    occupied = set()
    for r in range(height - 2):
        for c in range(width - 2):
            outer = [
                value[r + dr][c + dc]
                for dr in range(3)
                for dc in range(3)
                if (dr, dc) != (1, 1)
            ]
            if len(set(outer)) != 1 or outer[0] == background or value[r + 1][c + 1] != background:
                continue
            colour = outer[0]
            ring = {
                (r + dr, c + dc)
                for dr in range(3)
                for dc in range(3)
                if (dr, dc) != (1, 1)
            }
            attached = any(
                0 <= rr + dr < height
                and 0 <= cc + dc < width
                and not (r <= rr + dr <= r + 2 and c <= cc + dc <= c + 2)
                and value[rr + dr][cc + dc] == colour
                for rr, cc in ring
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1))
            )
            if attached:
                continue
            box = (r, c, r + 2, c + 2)
            frames.append({
                "bbox": box,
                "outer": colour,
                "centre": background,
                "position": (r + 1, c + 1),
                "crop": _crop(value, box),
            })
            occupied |= {(r + dr, c + dc) for dr in range(3) for dc in range(3)}
    return tuple(frames), occupied, background


# ---------------------------------------------------------------------------
# Schema I: D4-equivalent quadrants -> learned fundamental domain.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FundamentalQuadrantProjectionProgram:
    corner: int
    kind: str = "fundamental_quadrant_projection"

    @property
    def schema_key(self):
        return self.kind, self.corner

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.corner,

    def analyse(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        box = _non_background_bbox(value, background)
        bounded = _crop(value, box)
        height, width = _shape(bounded)
        if height < 4 or width < 4 or height % 2 or width % 2:
            raise Inapplicable("non-background box does not define four equal quadrants")
        half_h, half_w = height // 2, width // 2
        quadrants = (
            tuple(row[:half_w] for row in bounded[:half_h]),
            tuple(row[half_w:] for row in bounded[:half_h]),
            tuple(row[:half_w] for row in bounded[half_h:]),
            tuple(row[half_w:] for row in bounded[half_h:]),
        )
        if len({frozenset(_palette(quadrant)) for quadrant in quadrants}) != 1:
            raise Inapplicable("quadrants do not share a common palette")
        orbit = set(_d4_transforms(_binary(quadrants[0], background)))
        if not all(_binary(quadrant, background) in orbit for quadrant in quadrants):
            raise Inapplicable("quadrant supports are not D4-equivalent")
        if len(set(quadrants)) < 2:
            raise Inapplicable("trivial repeated quadrants")
        return {
            "background": background,
            "bbox": box,
            "quadrants": quadrants,
            "prediction": quadrants[self.corner],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "bbox": list(analysis["bbox"]),
                "quadrant_shape": list(_shape(analysis["prediction"])),
                "selected_corner": self.corner,
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"corner": self.corner},
            definitions=[
                {"name": "ObjectBoundingBox", "type": "Grid -> Region"},
                {"name": "QuadrantPartition", "type": "Region -> QuadrantSet"},
                {"name": "D4SupportEquivalence", "type": "QuadrantSet -> Bool"},
                {"name": "FundamentalDomainEmitter", "type": "QuadrantRole -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BoundObject", "effect": "derive the non-background object box"},
                {"index": 2, "definition": "PartitionQuadrants", "effect": "create four equal structural roles"},
                {"index": 3, "definition": "VerifyCommonStructure", "effect": "require shared palette and D4-equivalent support"},
                {"index": 4, "definition": "EmitFundamentalDomain", "effect": "return the learned corner role"},
            ],
            corollary="the selected structural quadrant is the fundamental-domain answer",
            common_notions=[{"name": "fundamental_quadrant_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema II: largest closed frame -> interior projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LargestClosedFrameInteriorProgram:
    kind: str = "largest_closed_frame_interior"

    @property
    def schema_key(self):
        return self.kind,

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.kind,

    def analyse(self, value: Grid):
        frames = _rectangle_frames(value)
        if len(frames) < 2:
            raise Inapplicable("frame comparison requires at least two complete frames")
        areas = [_shape(frame["interior"])[0] * _shape(frame["interior"])[1] for frame in frames]
        maximum = max(areas)
        winners = [index for index, area in enumerate(areas) if area == maximum]
        if len(winners) != 1:
            raise Inapplicable("largest frame interior is not unique")
        winner = frames[winners[0]]
        return {
            "frames": frames,
            "areas": tuple(areas),
            "winner": winner,
            "prediction": winner["interior"],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "frame_count": len(analysis["frames"]),
                "interior_areas": list(analysis["areas"]),
                "selected_bbox": list(analysis["winner"]["bbox"]),
                "selected_border": analysis["winner"]["border"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "ClosedFrame", "type": "Grid -> FrameSet"},
                {"name": "InteriorArea", "type": "Frame -> Quantity"},
                {"name": "UniqueMaximum", "type": "QuantitySet -> FrameRole"},
                {"name": "InteriorEmitter", "type": "FrameRole -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DetectFrames", "effect": "derive complete non-background rectangles"},
                {"index": 2, "definition": "MeasureInteriors", "effect": "compare enclosed region areas"},
                {"index": 3, "definition": "BindLargestFrame", "effect": "bind the sole largest frame"},
                {"index": 4, "definition": "EmitInterior", "effect": "return the frame interior"},
            ],
            corollary="the unique largest closed frame instructs the extracted interior",
            common_notions=[{"name": "largest_frame_interior_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema III: repeated framed class -> singleton outlier crop.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FramedPatternOutlierProgram:
    kind: str = "framed_pattern_outlier"

    @property
    def schema_key(self):
        return self.kind,

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.kind,

    def analyse(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        candidates = []
        for frame in _rectangle_frames(value):
            interior_palette = _palette(frame["interior"])
            if background in interior_palette:
                continue
            if not (interior_palette - {frame["border"]}):
                continue
            candidates.append(frame)
        groups = defaultdict(list)
        for frame in candidates:
            groups[(frame["border"], _shape(frame["crop"]))].append(frame)
        eligible = []
        for key, frames in groups.items():
            if len(frames) < 3:
                continue
            class_counts = Counter(frame["crop"] for frame in frames)
            singleton_classes = [pattern for pattern, count in class_counts.items() if count == 1]
            repeated_classes = [pattern for pattern, count in class_counts.items() if count >= 2]
            if len(singleton_classes) == 1 and repeated_classes:
                eligible.append({
                    "group": key,
                    "frames": tuple(frames),
                    "class_counts": class_counts,
                    "prediction": singleton_classes[0],
                })
        if len(eligible) != 1:
            raise Inapplicable("framed outlier relation is not unique")
        return eligible[0]

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "frame_group": [analysis["group"][0], list(analysis["group"][1])],
                "frame_count": len(analysis["frames"]),
                "class_multiplicities": sorted(analysis["class_counts"].values(), reverse=True),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "FramedPattern", "type": "Grid -> PatternClass"},
                {"name": "PatternMultiplicity", "type": "PatternClassSet -> CountMap"},
                {"name": "SingletonOutlier", "type": "CountMap -> UniqueRole"},
                {"name": "FrameCropEmitter", "type": "UniqueRole -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DetectComparableFrames", "effect": "group equal-size equal-border frames"},
                {"index": 2, "definition": "ClassifyPatterns", "effect": "count exact framed-pattern classes"},
                {"index": 3, "definition": "BindSingletonClass", "effect": "select the sole nonrepeated frame pattern"},
                {"index": 4, "definition": "EmitFrame", "effect": "return the complete outlier frame"},
            ],
            corollary="the sole framed pattern outside the repeated classes is the answer",
            common_notions=[{"name": "framed_outlier_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema IV: instruction trace bbox -> framed object.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstructionBBoxFrameSelectorProgram:
    kind: str = "instruction_bbox_frame_selector"

    @property
    def schema_key(self):
        return self.kind,

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return self.kind,

    def analyse(self, value: Grid):
        value = grid(value)
        frames, frame_cells, background = _clean_3x3_frames(value)
        if len(frames) < 4 or len({frame["outer"] for frame in frames}) != len(frames):
            raise Inapplicable("insufficient clean framed alternatives")
        frame_colours = {frame["outer"] for frame in frames}
        witnesses = []
        for colour in sorted(_palette(value) - {background} - frame_colours):
            cells = [
                (r, c)
                for r, row in enumerate(value)
                for c, cell in enumerate(row)
                if cell == colour and (r, c) not in frame_cells
            ]
            if len(cells) < 4:
                continue
            box = _bbox(cells)
            r0, c0, r1, c1 = box
            if r1 - r0 < 2 or c1 - c0 < 2:
                continue
            inside = [
                frame
                for frame in frames
                if r0 <= frame["position"][0] <= r1 and c0 <= frame["position"][1] <= c1
            ]
            if len(inside) == 1:
                witnesses.append({"instruction_colour": colour, "instruction_bbox": box, "frame": inside[0]})
        by_frame = {item["frame"]["bbox"]: item for item in witnesses}
        if len(by_frame) != 1:
            raise Inapplicable("instruction trace does not bind one framed object")
        witness = next(iter(by_frame.values()))
        return {
            "background": background,
            "frames": frames,
            "instruction_colour": witness["instruction_colour"],
            "instruction_bbox": witness["instruction_bbox"],
            "winner": witness["frame"],
            "prediction": witness["frame"]["crop"],
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "frame_count": len(analysis["frames"]),
                "instruction_colour": analysis["instruction_colour"],
                "instruction_bbox": list(analysis["instruction_bbox"]),
                "selected_bbox": list(analysis["winner"]["bbox"]),
                "selected_outer_colour": analysis["winner"]["outer"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={},
            definitions=[
                {"name": "FramedAlternative", "type": "Grid -> FrameSet"},
                {"name": "InstructionTrace", "type": "Grid -> ColouredRegion"},
                {"name": "BoundingRelation", "type": "Region x FrameSet -> UniqueRole"},
                {"name": "FrameEmitter", "type": "UniqueRole -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DetectAlternatives", "effect": "derive clean framed objects"},
                {"index": 2, "definition": "DetectInstructionTrace", "effect": "derive the non-frame trace region"},
                {"index": 3, "definition": "BindContainedCentre", "effect": "select the sole frame centre inside the trace box"},
                {"index": 4, "definition": "EmitSelectedFrame", "effect": "return the selected framed object"},
            ],
            corollary="the instruction trace binds the framed object whose centre lies in its relation box",
            common_notions=[{"name": "instruction_bbox_frame_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and validation.
# ---------------------------------------------------------------------------


def _candidate_programs(allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programmes = []
    if allowed is None or "fundamental_quadrant_projection" in allowed:
        programmes.extend(FundamentalQuadrantProjectionProgram(corner) for corner in range(4))
    if allowed is None or "largest_closed_frame_interior" in allowed:
        programmes.append(LargestClosedFrameInteriorProgram())
    if allowed is None or "framed_pattern_outlier" in allowed:
        programmes.append(FramedPatternOutlierProgram())
    if allowed is None or "instruction_bbox_frame_selector" in allowed:
        programmes.append(InstructionBBoxFrameSelectorProgram())
    return tuple(programmes)


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, FundamentalQuadrantProjectionProgram):
        return analysis["bbox"], _shape(analysis["prediction"]), tuple(sorted(_palette(analysis["prediction"])))
    if isinstance(program, LargestClosedFrameInteriorProgram):
        winner = analysis["winner"]
        return winner["bbox"], winner["border"], _shape(winner["interior"])
    if isinstance(program, FramedPatternOutlierProgram):
        selected = [frame for frame in analysis["frames"] if frame["crop"] == analysis["prediction"]][0]
        return selected["bbox"], analysis["group"], _serial(analysis["prediction"])
    if isinstance(program, InstructionBBoxFrameSelectorProgram):
        return analysis["winner"]["bbox"], analysis["instruction_bbox"], analysis["winner"]["outer"]
    raise Inapplicable("unknown programme")


def fit_relation_vocabulary_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    if not all(_is_subgrid(target, source) for source, target in pairs):
        return []
    selected = []
    for program in _candidate_programs(allowed_kinds):
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            selected.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_relation_vocabulary(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_relation_vocabulary_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        groups[predictions].append(program.describe(pairs))
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:50] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "learned_relation_vocabulary": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "fundamental_quadrant_projection":
        return FundamentalQuadrantProjectionProgram(int(parameters["corner"]))
    if kind == "largest_closed_frame_interior":
        return LargestClosedFrameInteriorProgram()
    if kind == "framed_pattern_outlier":
        return FramedPatternOutlierProgram()
    if kind == "instruction_bbox_frame_selector":
        return InstructionBBoxFrameSelectorProgram()
    raise Inapplicable("unknown relation-vocabulary schema")


def _counterfactual_result(kind, rows):
    passed = all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _translate_non_background(source: Grid, background: int):
    source = grid(source)
    height, width = _shape(source)
    box = _non_background_bbox(source, background)
    r0, c0, r1, c1 = box
    shifts = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    for dr, dc in shifts:
        if not (0 <= r0 + dr and r1 + dr < height and 0 <= c0 + dc and c1 + dc < width):
            continue
        result = [[background for _ in range(width)] for _ in range(height)]
        for r, row in enumerate(source):
            for c, cell in enumerate(row):
                if cell != background:
                    result[r + dr][c + dc] = cell
        return tuple(tuple(row) for row in result)
    raise Inapplicable("object cannot be translated in bounds")


def _quadrant_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        translation_invariant = False
        try:
            translated = _translate_non_background(source, analysis["background"])
            translation_invariant = program.predict(translated) == original
        except Inapplicable:
            translation_invariant = True
        colours = sorted(_palette(original) - {analysis["background"]})
        recolour_equivariant = False
        if colours:
            old = colours[0]
            fresh = _fresh_colour(source, (old,))
            try:
                recolour_equivariant = program.predict(_replace_colour(source, old, fresh)) == _replace_colour(original, old, fresh)
            except Inapplicable:
                recolour_equivariant = False
        # Break one nonselected quadrant's support.
        modified = _array(source)
        r0, c0, r1, c1 = analysis["bbox"]
        half_h = (r1 - r0 + 1) // 2
        half_w = (c1 - c0 + 1) // 2
        break_corner = (program.corner + 1) % 4
        qr = r0 + (half_h if break_corner >= 2 else 0)
        qc = c0 + (half_w if break_corner % 2 else 0)
        cause_necessary = False
        for r in range(qr, qr + half_h):
            for c in range(qc, qc + half_w):
                if source[r][c] != analysis["background"]:
                    modified[r][c] = analysis["background"]
                    try:
                        cause_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
                    except Inapplicable:
                        cause_necessary = True
                    break
            if cause_necessary:
                break
        rows.append({
            "demonstration": index,
            "translation_invariant": translation_invariant,
            "recolour_equivariant": recolour_equivariant,
            "common_quadrant_structure_necessary": cause_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _frame_interior_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        winner = analysis["winner"]
        original = analysis["prediction"]
        background = _unique_modal(source)
        fresh = next((colour for colour in range(10) if colour not in {winner["border"], background}), None)
        if fresh is None:
            raise Inapplicable("no alternate frame colour")
        modified = _array(source)
        r0, c0, r1, c1 = winner["bbox"]
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if r in (r0, r1) or c in (c0, c1):
                    modified[r][c] = fresh
        try:
            border_identity_invariant = program.predict(tuple(tuple(row) for row in modified)) == original
        except Inapplicable:
            border_identity_invariant = False
        broken = _array(source)
        broken[r0][c0] = _unique_modal(source)
        try:
            frame_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            frame_necessary = True
        rows.append({
            "demonstration": index,
            "border_identity_invariant": border_identity_invariant,
            "largest_closed_frame_necessary": frame_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _framed_outlier_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False
        selected = [frame for frame in analysis["frames"] if frame["crop"] == original][0]
        repeated = next(frame for frame in analysis["frames"] if frame["crop"] != original)
        modified = _array(source)
        rr0, rc0, rr1, rc1 = repeated["bbox"]
        for dr, row in enumerate(original):
            for dc, cell in enumerate(row):
                modified[rr0 + dr][rc0 + dc] = cell
        try:
            singleton_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
        except Inapplicable:
            singleton_necessary = True
        colours = sorted(_palette(original) - {_unique_modal(source), selected["border"]})
        recolour_equivariant = False
        if colours:
            old = colours[0]
            fresh = _fresh_colour(source, (old,))
            local = _array(source)
            sr0, sc0, sr1, sc1 = selected["bbox"]
            for r in range(sr0, sr1 + 1):
                for c in range(sc0, sc1 + 1):
                    if local[r][c] == old:
                        local[r][c] = fresh
            try:
                recolour_equivariant = program.predict(tuple(tuple(row) for row in local)) == _replace_colour(original, old, fresh)
            except Inapplicable:
                recolour_equivariant = False
        rows.append({
            "demonstration": index,
            "rotation_equivariant": rotation_equivariant,
            "singleton_class_necessary": singleton_necessary,
            "interior_recolour_equivariant": recolour_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _instruction_bbox_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program.analyse(source)
        original = analysis["prediction"]
        colour = analysis["instruction_colour"]
        fresh = _fresh_colour(source, (colour,))
        try:
            instruction_identity_invariant = program.predict(_replace_colour(source, colour, fresh)) == original
        except Inapplicable:
            instruction_identity_invariant = False
        removed = tuple(tuple(analysis["background"] if cell == colour else cell for cell in row) for row in source)
        try:
            instruction_necessary = program.predict(removed) != original
        except Inapplicable:
            instruction_necessary = True
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "instruction_identity_invariant": instruction_identity_invariant,
            "instruction_necessary": instruction_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_validation(program, pairs):
    if isinstance(program, FundamentalQuadrantProjectionProgram):
        return _quadrant_counterfactuals(program, pairs)
    if isinstance(program, LargestClosedFrameInteriorProgram):
        return _frame_interior_counterfactuals(program, pairs)
    if isinstance(program, FramedPatternOutlierProgram):
        return _framed_outlier_counterfactuals(program, pairs)
    if isinstance(program, InstructionBBoxFrameSelectorProgram):
        return _instruction_bbox_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_relation_vocabulary(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()): 
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (item["input"], item["output"])
            for index, item in enumerate(clean["train"])
            if index != held
        )
        refitted = fit_relation_vocabulary_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(demonstration["input"]) != grid(demonstration["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, test_predictions in held_exact:
            groups[test_predictions].append(program.schema_key)
        expected_tuple = tuple(grid(prediction) for prediction in expected)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def relation_vocabulary_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_relation_vocabulary_programs(pairs)}))


infer = infer_relation_vocabulary
validate = validate_relation_vocabulary
