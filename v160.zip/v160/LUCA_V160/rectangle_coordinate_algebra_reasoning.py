"""LUCA V152: rectangle coordinate algebra and ownership materialisation.

This family anti-unifies three rectangle-centred transformations under one
coordinate/materialisation operator:

    solid rectangles -> strict-interior mask -> hollow frames
    solid rectangles -> parity mask -> checkerboard apertures
    top-level outline frames -> enclosure ownership -> recolour enclosed material

The family is task-ID blind and target blind. Background roles, colours,
periods, parity, rectangle dimensions, positions, and enclosure relations are
inferred from the demonstrations. No absolute demonstration coordinates are
stored.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_rectangle_coordinate_algebra"
LANGUAGE = "spinoza_rectangle_coordinate_algebra_v152"
SCHEMA_VERSION = 1
OPERATOR = "rectangle_coordinate_algebra_materialisation"
NODE_VOCABULARY = "solid_outline_and_enclosure_rectangle_nodes"
EDGE_VOCABULARY = "border_distance_parity_and_enclosure_ownership_edges"


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "rectangle_coordinate_algebra_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_rectangles": True,
            "normalised_rectangle_coordinates": True,
            "shared_rectangle_coordinate_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] == colour
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for neighbour in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    return tuple(output)


def _all_components(value: Grid, background: int):
    output = []
    for colour in sorted(_palette(value) - {background}):
        for component in _components_of_colour(value, colour):
            output.append((colour, component))
    return tuple(output)


def _solid_rectangle(component):
    r0, c0, r1, c1 = _bbox(component)
    support = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
    }
    if set(component) != support:
        raise Inapplicable("component is not a solid rectangle")
    return r0, c0, r1, c1


def _outline_rectangle(component):
    r0, c0, r1, c1 = _bbox(component)
    if r1 - r0 + 1 < 3 or c1 - c0 + 1 < 3:
        raise Inapplicable("outline rectangle is too small")
    border = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }
    if set(component) != border:
        raise Inapplicable("component is not a one-cell outline rectangle")
    return r0, c0, r1, c1


def _solid_rectangles(value: Grid, background: int):
    value = grid(value)
    records = []
    for colour, component in _all_components(value, background):
        r0, c0, r1, c1 = _solid_rectangle(component)
        if min(r1 - r0 + 1, c1 - c0 + 1) < 3:
            raise Inapplicable("solid rectangles require a strict interior")
        records.append((colour, r0, c0, r1, c1))
    if not records:
        raise Inapplicable("at least one solid rectangle is required")
    records.sort(key=lambda item: (item[1], item[2], item[3], item[4], item[0]))
    return tuple(records)


def _contains(outer, inner):
    or0, oc0, or1, oc1 = outer
    ir0, ic0, ir1, ic1 = inner
    return or0 <= ir0 and oc0 <= ic0 and or1 >= ir1 and oc1 >= ic1 and outer != inner


def _intersects(a, b):
    ar0, ac0, ar1, ac1 = a
    br0, bc0, br1, bc1 = b
    return not (ar1 < br0 or br1 < ar0 or ac1 < bc0 or bc1 < ac0)


def _ownership_scene(value: Grid, background: int):
    value = grid(value)
    components = _all_components(value, background)
    if not components:
        raise Inapplicable("non-background material is required")
    frames = []
    for colour, component in components:
        try:
            rectangle = _outline_rectangle(component)
        except Inapplicable:
            continue
        frames.append((colour, rectangle, component))
    if not frames:
        raise Inapplicable("at least one outline frame is required")
    top = []
    for index, item in enumerate(frames):
        if not any(_contains(other[1], item[1]) for j, other in enumerate(frames) if j != index):
            top.append(item)
    if not top:
        raise Inapplicable("missing top-level frames")
    for i, (_, a, _) in enumerate(top):
        for _, b, _ in top[i + 1:]:
            if _intersects(a, b):
                raise Inapplicable("top-level frame regions must be disjoint")
    assignments = []
    changed_witness = False
    for colour, component in components:
        r0, c0, r1, c1 = _bbox(component)
        owners = [item for item in top if _contains(item[1], (r0, c0, r1, c1)) or item[1] == (r0, c0, r1, c1)]
        if len(owners) > 1:
            raise Inapplicable("a component cannot have competing top-level owners")
        if not owners:
            # Material outside all top-level frames is not owned and remains unchanged.
            assignments.append((colour, component, colour))
            continue
        owner_colour = owners[0][0]
        assignments.append((colour, component, owner_colour))
        changed_witness |= colour != owner_colour
    if not changed_witness:
        raise Inapplicable("an enclosed colour-transfer witness is required")
    return tuple(top), tuple(assignments)


def _common_input_colours(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes:
        return ()
    return tuple(sorted(set.intersection(*palettes)))


@dataclass(frozen=True)
class HollowSolidRectanglesProgram:
    background: int

    kind = "solid_rectangle_hollow_field"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        rectangles = _solid_rectangles(value, self.background)
        output = _array(value)
        changed = False
        for _, r0, c0, r1, c1 in rectangles:
            for r in range(r0 + 1, r1):
                for c in range(c0 + 1, c1):
                    changed |= output[r][c] != self.background
                    output[r][c] = self.background
        if not changed:
            raise Inapplicable("strict-interior clearing must change material")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more solid monochrome rectangles on a shared background",
            relation_chain=(
                "extract every solid rectangle node",
                "assign border-distance zero to the one-cell perimeter",
                "select the strict interior by positive border distance",
                "clear the strict interior while preserving each coloured perimeter",
            ),
            parameters={"background": self.background},
            corollary="Convert every solid rectangle into a one-cell hollow frame.",
            notions=["solid rectangle", "strict interior", "preserved perimeter", "coordinate mask"],
        )


@dataclass(frozen=True)
class CheckerboardInteriorMaskProgram:
    background: int
    anchor: str
    parity: int

    kind = "checkerboard_interior_mask_field"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.anchor, self.parity

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        rectangles = _solid_rectangles(value, self.background)
        output = _array(value)
        removed = retained = False
        for _, r0, c0, r1, c1 in rectangles:
            for r in range(r0 + 1, r1):
                for c in range(c0 + 1, c1):
                    rr, cc = r - r0, c - c0
                    h, w = r1 - r0 + 1, c1 - c0 + 1
                    if self.anchor == "top_left":
                        distance = rr + cc
                    elif self.anchor == "top_right":
                        distance = rr + (w - 1 - cc)
                    elif self.anchor == "bottom_left":
                        distance = (h - 1 - rr) + cc
                    elif self.anchor == "bottom_right":
                        distance = (h - 1 - rr) + (w - 1 - cc)
                    else:
                        raise Inapplicable("unknown checkerboard anchor")
                    relative_parity = distance % 2
                    if relative_parity == self.parity:
                        removed |= output[r][c] != self.background
                        output[r][c] = self.background
                    else:
                        retained = True
        if not removed or not retained:
            raise Inapplicable("checkerboard mask needs removed and retained interior cells")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="solid rectangles with a shared background and an interior parity grammar",
            relation_chain=(
                "extract every solid rectangle node",
                "normalise each strict-interior cell to row-plus-column parity",
                f"select parity class {self.parity} relative to the learned {self.anchor} corner role",
                "clear selected cells while preserving the perimeter and opposite parity",
            ),
            parameters={"background": self.background, "anchor_corner": self.anchor, "selected_relative_parity": self.parity},
            corollary="Cut checkerboard apertures into every rectangle interior.",
            notions=["solid rectangle", "relative parity", "strict interior", "coordinate mask"],
        )


@dataclass(frozen=True)
class EnclosureOwnershipProgram:
    background: int

    kind = "outer_frame_ownership_field"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        _, assignments = _ownership_scene(value, self.background)
        output = _array(value)
        changed = False
        for colour, component, owner_colour in assignments:
            for r, c in component:
                changed |= colour != owner_colour
                output[r][c] = owner_colour
        if not changed:
            raise Inapplicable("ownership propagation must recolour enclosed material")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="disjoint top-level outline frames containing nested coloured material",
            relation_chain=(
                "extract outline rectangle nodes and their strict containment graph",
                "select frames with no enclosing frame as top-level owners",
                "assign every enclosed non-background component to one owner",
                "propagate each owner colour through its complete enclosed material support",
            ),
            parameters={"background": self.background},
            corollary="Recolour all material inside each top-level frame with that frame's colour.",
            notions=["outline frame", "strict containment", "ownership", "support-preserving recolour"],
        )


def _fit_hollow(pairs):
    programmes = []
    for background in _common_input_colours(pairs):
        programme = HollowSolidRectanglesProgram(background)
        dimensions = set()
        count = 0
        valid = True
        for source, target in pairs:
            try:
                rectangles = _solid_rectangles(source, background)
                count += len(rectangles)
                dimensions.update((r1 - r0 + 1, c1 - c0 + 1) for _, r0, c0, r1, c1 in rectangles)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and count >= 2 and len(dimensions) >= 2:
            programmes.append(programme)
    return programmes


def _fit_checkerboard(pairs):
    programmes = []
    for background in _common_input_colours(pairs):
        dimensions = set()
        count = 0
        try:
            for source, _ in pairs:
                rectangles = _solid_rectangles(source, background)
                count += len(rectangles)
                dimensions.update((r1 - r0 + 1, c1 - c0 + 1) for _, r0, c0, r1, c1 in rectangles)
        except Inapplicable:
            continue
        if count < 2 or len(dimensions) < 2:
            continue
        for anchor in ("top_left", "top_right", "bottom_left", "bottom_right"):
            for parity in (0, 1):
                programme = CheckerboardInteriorMaskProgram(background, anchor, parity)
                try:
                    if all(programme.predict(source) == grid(target) for source, target in pairs):
                        programmes.append(programme)
                except Inapplicable:
                    pass
    return programmes


def _fit_ownership(pairs):
    programmes = []
    for background in _common_input_colours(pairs):
        programme = EnclosureOwnershipProgram(background)
        total_top = 0
        valid = True
        for source, target in pairs:
            try:
                top, _ = _ownership_scene(source, background)
                total_top += len(top)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and total_top >= 3:
            programmes.append(programme)
    return programmes


_FITTERS = {
    "solid_rectangle_hollow_field": _fit_hollow,
    "checkerboard_interior_mask_field": _fit_checkerboard,
    "outer_frame_ownership_field": _fit_ownership,
}


def fit_rectangle_coordinate_algebra_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, (HollowSolidRectanglesProgram, CheckerboardInteriorMaskProgram)):
                for _, r0, c0, _, _ in _solid_rectangles(source, programme.background):
                    candidates.append((r0, c0, programme.background))
            else:
                top, _ = _ownership_scene(source, programme.background)
                for _, (r0, c0, _, _), _ in top:
                    candidates.append((r0, c0, programme.background))
        except Inapplicable:
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {"cell": [r, c], "from": int(previous), "to": int(replacement)}
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "rectangle_corner_or_enclosure_edge" if passed else None,
            "witness": witness,
        })
    return {"kind": programme.kind, "rows": rows, "passed": bool(rows) and all(row["passed"] for row in rows)}


def infer_rectangle_coordinate_algebra(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_rectangle_coordinate_algebra_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "normalised_rectangle_coordinates": True,
            "shared_rectangle_coordinate_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_rectangle_coordinate_algebra_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_rectangle_coordinate_algebra_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_rectangle_coordinate_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
