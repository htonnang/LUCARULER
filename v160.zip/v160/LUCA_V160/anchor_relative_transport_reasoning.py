"""LUCA V157: anchor-relative transport composition.

This family anti-unifies three transformations in which input-derived anchors
or anchor lattices define a local coordinate system and payload material is
transported without changing its semantic colour or internal shape:

* aligned guide cells are quarter-turned around singleton anchors;
* singleton payloads are compacted to the adjacent side of mapped anchors;
* payload components are centred inside cells of a Cartesian anchor lattice.

The implementation is task-ID blind and target blind. Colours, positions,
turn direction, anchor/payload correspondences, lattice rows and columns,
component shapes, and boundary clipping are inferred from demonstrations or
from the current input. No absolute demonstration coordinates are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations, permutations

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anchor_relative_transport_composition"
LANGUAGE = "spinoza_anchor_relative_transport_composition_v157"
SCHEMA_VERSION = 1
OPERATOR = "anchor_relative_transport_materialisation"
NODE_VOCABULARY = "anchor_payload_guide_and_lattice_nodes"
EDGE_VOCABULARY = "alignment_quarter_turn_adjacency_and_cell_centre_edges"


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "anchor_relative_transport_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "anchor_relative_coordinates": True,
            "payload_shape_preserved": True,
            "shared_transport_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _background(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    return counts.most_common(1)[0][0]


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for point in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if point in remaining:
                    remaining.remove(point)
                    component.add(point)
                    stack.append(point)
        output.append(frozenset(component))
    output.sort(key=lambda cells: (_bbox(cells), len(cells)))
    return tuple(output)


def _positions(value: Grid, colour: int):
    value = grid(value)
    return tuple((r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == colour)


def _constant_pitch(values):
    values = tuple(sorted(values))
    if len(values) < 2:
        raise Inapplicable("at least two lattice coordinates are required")
    differences = {b - a for a, b in zip(values, values[1:])}
    if len(differences) != 1:
        raise Inapplicable("lattice pitch is not constant")
    pitch = next(iter(differences))
    if pitch < 3:
        raise Inapplicable("lattice cells must have a non-empty interior")
    return pitch


def _open_intervals(coordinates, limit):
    coordinates = tuple(sorted(coordinates))
    intervals = []
    previous = -1
    for coordinate in coordinates:
        if previous + 1 <= coordinate - 1:
            intervals.append((previous + 1, coordinate - 1))
        previous = coordinate
    if previous + 1 <= limit - 1:
        intervals.append((previous + 1, limit - 1))
    return tuple(intervals)


@dataclass(frozen=True)
class AxisGuideQuarterTurnTransportProgram:
    background: int
    anchor_colour: int
    guide_colour: int
    emitted_colour: int
    turn: str

    kind = "axis_guide_quarter_turn_transport"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.anchor_colour, self.guide_colour}:
            raise Inapplicable("quarter-turn scenes require background, anchor and guide colours only")
        anchors = _positions(value, self.anchor_colour)
        guides = _positions(value, self.guide_colour)
        if not anchors or not guides:
            raise Inapplicable("anchors and guides are required")
        if any(len(component) != 1 for component in _components_of_colour(value, self.anchor_colour)):
            raise Inapplicable("quarter-turn anchors must be singletons")
        if any(len(component) != 1 for component in _components_of_colour(value, self.guide_colour)):
            raise Inapplicable("quarter-turn guides must be singletons")
        assignments = []
        for guide in guides:
            aligned = [
                anchor for anchor in anchors
                if anchor[0] == guide[0] or anchor[1] == guide[1]
            ]
            if not aligned:
                assignments.append((guide, None))
                continue
            distances = [abs(anchor[0] - guide[0]) + abs(anchor[1] - guide[1]) for anchor in aligned]
            minimum = min(distances)
            nearest = [anchor for anchor, distance in zip(aligned, distances) if distance == minimum]
            assignments.append((guide, nearest[0] if len(nearest) == 1 else None))
        if not any(anchor is not None for _, anchor in assignments):
            raise Inapplicable("no uniquely aligned guide-anchor relation")
        return anchors, guides, tuple(assignments)

    def _rotate(self, dr, dc):
        if self.turn == "ccw":
            return -dc, dr
        if self.turn == "cw":
            return dc, -dr
        raise Inapplicable("unknown turn direction")

    def predict(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        _, guides, assignments = self._scene(value)
        work = _array(value)
        for r, c in guides:
            work[r][c] = self.background
        emitted = set()
        for guide, anchor in assignments:
            if anchor is None:
                continue
            dr, dc = guide[0] - anchor[0], guide[1] - anchor[1]
            rr, cc = self._rotate(dr, dc)
            target = anchor[0] + rr, anchor[1] + cc
            if not (0 <= target[0] < h and 0 <= target[1] < w):
                continue
            if value[target[0]][target[1]] not in {self.background, self.guide_colour}:
                raise Inapplicable("quarter-turn emission collides with protected material")
            emitted.add(target)
        if not emitted:
            raise Inapplicable("quarter-turn scene has no in-bounds consequence")
        for r, c in emitted:
            work[r][c] = self.emitted_colour
        return grid(work)

    def describe(self, pairs):
        return _law(
            self,
            scene="singleton anchors and aligned guide cells on a uniform field",
            relation_chain=(
                "extract singleton anchors and guide cells",
                "bind each guide to its unique nearest row/column-aligned anchor",
                f"rotate the anchor-to-guide vector one quarter turn {self.turn}",
                "erase guides and materialise in-bounds rotated endpoints",
            ),
            parameters={
                "background": self.background,
                "anchor_colour": self.anchor_colour,
                "guide_colour": self.guide_colour,
                "emitted_colour": self.emitted_colour,
                "turn": self.turn,
            },
            corollary="guide distance and direction are converted into an anchor-relative orthogonal displacement",
            notions=(
                "nearest aligned anchor relations are input-derived",
                "ambiguous ties abstain locally and out-of-bounds consequences are clipped",
                "anchor material remains fixed",
            ),
        )


@dataclass(frozen=True)
class AxisAlignedAnchorCompactionProgram:
    background: int
    mappings: tuple

    kind = "axis_aligned_anchor_compaction"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        anchors = {anchor_colour: _positions(value, anchor_colour) for _, anchor_colour in self.mappings}
        payloads = {payload_colour: _positions(value, payload_colour) for payload_colour, _ in self.mappings}
        expected_palette = {self.background} | set(anchors) | set(payloads)
        if _palette(value) != expected_palette:
            raise Inapplicable("compaction scenes require exactly the learned role colours")
        if any(len(points) != 1 for points in anchors.values()):
            raise Inapplicable("every anchor role must be represented by one singleton")
        for colour, points in payloads.items():
            if not points:
                raise Inapplicable("every payload role needs at least one singleton")
            if any(len(component) != 1 for component in _components_of_colour(value, colour)):
                raise Inapplicable("compaction payloads must be singletons")
        moves = []
        destinations = set()
        h, w = _shape(value)
        for payload_colour, anchor_colour in self.mappings:
            anchor = anchors[anchor_colour][0]
            for source in payloads[payload_colour]:
                if source[0] == anchor[0]:
                    direction = 1 if source[1] > anchor[1] else -1
                    destination = anchor[0], anchor[1] + direction
                elif source[1] == anchor[1]:
                    direction = 1 if source[0] > anchor[0] else -1
                    destination = anchor[0] + direction, anchor[1]
                else:
                    raise Inapplicable("every payload must align with its mapped anchor")
                if not (0 <= destination[0] < h and 0 <= destination[1] < w):
                    raise Inapplicable("adjacent compaction destination is outside the canvas")
                if value[destination[0]][destination[1]] != self.background:
                    raise Inapplicable("compaction destination is occupied")
                if destination in destinations:
                    raise Inapplicable("two payloads claim the same adjacent destination")
                destinations.add(destination)
                moves.append((source, destination, payload_colour))
        return anchors, payloads, tuple(moves)

    def predict(self, value: Grid):
        value = grid(value)
        _, payloads, moves = self._scene(value)
        work = _array(value)
        for points in payloads.values():
            for r, c in points:
                work[r][c] = self.background
        for _, (r, c), colour in moves:
            work[r][c] = colour
        return grid(work)

    def describe(self, pairs):
        return _law(
            self,
            scene="singleton anchors with same-axis singleton payloads",
            relation_chain=(
                "extract singleton anchor and payload roles",
                "map each payload colour to its demonstrated anchor colour",
                "preserve the payload side while collapsing its axis distance to one",
                "transport every payload to the adjacent anchor cell",
            ),
            parameters={
                "background": self.background,
                "payload_to_anchor_mappings": [list(item) for item in self.mappings],
            },
            corollary="long-range axis alignment is compressed into a one-cell anchor adjacency relation",
            notions=(
                "payload colour and side are preserved",
                "every payload must have one unambiguous mapped anchor",
                "colliding or non-aligned scenes abstain",
            ),
        )


@dataclass(frozen=True)
class AnchorLatticeCellCentringProgram:
    background: int
    anchor_colour: int
    payload_colour: int

    kind = "anchor_lattice_cell_centring"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.anchor_colour, self.payload_colour}:
            raise Inapplicable("lattice scenes require background, anchor and payload colours only")
        h, w = _shape(value)
        anchor_points = set(_positions(value, self.anchor_colour))
        if any(len(component) != 1 for component in _components_of_colour(value, self.anchor_colour)):
            raise Inapplicable("lattice anchors must be singletons")
        rows = tuple(sorted({r for r, _ in anchor_points}))
        cols = tuple(sorted({c for _, c in anchor_points}))
        if anchor_points != {(r, c) for r in rows for c in cols}:
            raise Inapplicable("anchors must form a complete Cartesian lattice")
        row_pitch = _constant_pitch(rows)
        col_pitch = _constant_pitch(cols)
        if row_pitch != col_pitch:
            raise Inapplicable("row and column lattice pitches must agree")
        row_intervals = _open_intervals(rows, h)
        col_intervals = _open_intervals(cols, w)
        payload_components = _components_of_colour(value, self.payload_colour)
        if not payload_components:
            raise Inapplicable("at least one payload component is required")
        placements = []
        occupied = set()
        for component in payload_components:
            containing = []
            for r0, r1 in row_intervals:
                for c0, c1 in col_intervals:
                    if all(r0 <= r <= r1 and c0 <= c <= c1 for r, c in component):
                        containing.append((r0, c0, r1, c1))
            if len(containing) != 1:
                raise Inapplicable("each payload component must occupy one lattice cell")
            cell_r0, cell_c0, cell_r1, cell_c1 = containing[0]
            r0, c0, r1, c1 = _bbox(component)
            height, width = r1 - r0 + 1, c1 - c0 + 1
            cell_height = cell_r1 - cell_r0 + 1
            cell_width = cell_c1 - cell_c0 + 1
            if height > cell_height or width > cell_width:
                raise Inapplicable("payload does not fit its lattice cell")
            target_r0 = cell_r0 + (cell_height - height) // 2
            target_c0 = cell_c0 + (cell_width - width) // 2
            target = frozenset(
                (target_r0 + (r - r0), target_c0 + (c - c0))
                for r, c in component
            )
            if target & anchor_points or target & occupied:
                raise Inapplicable("centred payloads collide")
            occupied.update(target)
            placements.append((component, target, containing[0]))
        return rows, cols, row_pitch, tuple(placements)

    def predict(self, value: Grid):
        value = grid(value)
        _, _, _, placements = self._scene(value)
        work = _array(value)
        for component, _, _ in placements:
            for r, c in component:
                work[r][c] = self.background
        for _, target, _ in placements:
            for r, c in target:
                work[r][c] = self.payload_colour
        return grid(work)

    def describe(self, pairs):
        return _law(
            self,
            scene="a complete Cartesian lattice of singleton anchors containing payload components",
            relation_chain=(
                "extract lattice rows, columns and open cells",
                "assign each payload component to exactly one lattice cell",
                "preserve component shape while deriving its centred cell coordinate",
                "translate every payload to the centre of its cell",
            ),
            parameters={
                "background": self.background,
                "anchor_colour": self.anchor_colour,
                "payload_colour": self.payload_colour,
                "centering_policy": "bbox_floor_centre",
            },
            corollary="the anchor lattice supplies a coordinate frame that canonically centres each payload",
            notions=(
                "row and column pitches are input-derived and equal",
                "payload shape and colour are preserved",
                "cell assignment and placement must be collision-free",
            ),
        )


def _common_palette(pairs, side):
    values = [grid(source if side == "source" else target) for source, target in pairs]
    if not values:
        return set()
    palettes = [_palette(value) for value in values]
    return set.intersection(*palettes)


def _fit_quarter_turn(pairs):
    source_palettes = [_palette(source) for source, _ in pairs]
    target_palettes = [_palette(target) for _, target in pairs]
    if not all(len(palette) == 3 for palette in source_palettes):
        return ()
    if len({frozenset(palette) for palette in source_palettes}) != 1:
        return ()
    source_palette = set(source_palettes[0])
    target_common = set.intersection(*target_palettes)
    output = []
    for background in source_palette:
        remaining = source_palette - {background}
        for anchor_colour, guide_colour in permutations(remaining, 2):
            emitted_candidates = target_common - source_palette
            for emitted_colour in emitted_candidates:
                for turn in ("ccw", "cw"):
                    programme = AxisGuideQuarterTurnTransportProgram(
                        background, anchor_colour, guide_colour, emitted_colour, turn
                    )
                    try:
                        if all(programme.predict(source) == grid(target) for source, target in pairs):
                            output.append(programme)
                    except Inapplicable:
                        pass
    return tuple(output)


def _fit_axis_compaction(pairs):
    source_palettes = [_palette(source) for source, _ in pairs]
    if not source_palettes or any(len(palette) != 5 for palette in source_palettes):
        return ()
    if len({frozenset(palette) for palette in source_palettes}) != 1:
        return ()
    palette = set(source_palettes[0])
    output = []
    for background in palette:
        roles = tuple(sorted(palette - {background}))
        for anchor_colours in combinations(roles, 2):
            payload_colours = tuple(colour for colour in roles if colour not in anchor_colours)
            for payload_order in permutations(payload_colours):
                for anchor_order in permutations(anchor_colours):
                    mappings = tuple(sorted(zip(payload_order, anchor_order)))
                    programme = AxisAlignedAnchorCompactionProgram(background, mappings)
                    try:
                        if all(programme.predict(source) == grid(target) for source, target in pairs):
                            output.append(programme)
                    except Inapplicable:
                        pass
    return tuple(output)


def _fit_lattice_centring(pairs):
    source_palettes = [_palette(source) for source, _ in pairs]
    if not source_palettes or any(len(palette) != 3 for palette in source_palettes):
        return ()
    if len({frozenset(palette) for palette in source_palettes}) != 1:
        return ()
    palette = tuple(sorted(source_palettes[0]))
    output = []
    for background, anchor_colour, payload_colour in permutations(palette, 3):
        programme = AnchorLatticeCellCentringProgram(background, anchor_colour, payload_colour)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return tuple(output)


def fit_anchor_relative_transport_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return ()
    allowed = set(allowed_kinds or ()) or None
    programmes = []
    fitters = (
        _fit_quarter_turn,
        _fit_axis_compaction,
        _fit_lattice_centring,
    )
    for fitter in fitters:
        try:
            programmes.extend(fitter(pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            pass
    deduplicated = []
    seen = set()
    for programme in programmes:
        if allowed is not None and programme.kind not in allowed:
            continue
        key = (type(programme).__name__, repr(programme))
        if key in seen:
            continue
        seen.add(key)
        deduplicated.append(programme)
    deduplicated.sort(key=lambda programme: (programme.kind, repr(programme)))
    return tuple(deduplicated)


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, AxisGuideQuarterTurnTransportProgram):
                _, _, assignments = programme._scene(source)
                for guide, anchor in assignments:
                    if anchor is not None:
                        candidates.append((guide[0], guide[1], programme.background, "guide_node"))
            elif isinstance(programme, AxisAlignedAnchorCompactionProgram):
                anchors, _, _ = programme._scene(source)
                anchor = next(iter(anchors.values()))[0]
                candidates.append((anchor[0], anchor[1], programme.background, "anchor_node"))
            elif isinstance(programme, AnchorLatticeCellCentringProgram):
                rows_, cols_, _, _ = programme._scene(source)
                candidates.append((rows_[0], cols_[0], programme.background, "lattice_anchor"))
        except (Inapplicable, StopIteration):
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {
                    "cell": [r, c],
                    "from": int(previous),
                    "to": int(replacement),
                    "role": role,
                }
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_anchor_relative_transport_composition(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anchor_relative_transport_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anchor_relative_coordinates": True,
            "payload_shape_preserved": True,
            "shared_transport_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_anchor_relative_transport_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anchor_relative_transport_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_anchor_relative_transport_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
