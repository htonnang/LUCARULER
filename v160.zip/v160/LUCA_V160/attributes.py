"""LUCA V70: one conditional component-attribute -> paint grammar.

The finite vocabulary is structural, not task-ID indexed. All admitted programs
fit every demonstration. Per-feature action alternatives are stored as an exact
Cartesian factorization, so ambiguity is proved without exponential enumeration.
No unknown feature value or unsupported colour mapping falls back to identity.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from itertools import product


from correspondence import grid, Grid
from runtime import public_task


FAMILY = 'object_attributes_v70'
FEATURES = ('area', 'area_rank', 'area_rank_desc', 'area_extremum', 'singleton',
            'area_parity', 'height', 'width', 'bbox_area', 'aspect', 'solid',
            'square', 'border', 'holes', 'topology', 'shape_frequency')
KEEP, BACKGROUND = -1, -2
D4 = ((-1,0),(1,0),(0,-1),(0,1))
D8 = D4 + ((-1,-1),(-1,1),(1,-1),(1,1))

@dataclass(frozen=True)
class Component:
    cells: tuple[tuple[int,int], ...]
    box: tuple[int,int,int,int]


def background(a: Grid, rule: str | int) -> int | None:
    if rule != 'modal': return int(rule) if int(rule) in {v for row in a for v in row} else None
    counts = Counter(v for row in a for v in row)
    best = max(counts.values())
    choices = [v for v, n in counts.items() if n == best]
    return choices[0] if len(choices) == 1 else None


def components(a: Grid, bg: int, connectivity: int, monochrome: bool) -> tuple[Component,...]:
    if connectivity not in (4,8): raise ValueError('connectivity must be 4 or 8')
    h,w=len(a),len(a[0]); seen=set(); found=[]
    for r in range(h):
        for c in range(w):
            if (r,c) in seen or a[r][c] == bg: continue
            seen.add((r,c)); stack=[(r,c)]; cells=[]
            while stack:
                rr,cc=stack.pop(); cells.append((rr,cc))
                for dr,dc in D4 if connectivity==4 else D8:
                    nr,nc=rr+dr,cc+dc
                    if (0<=nr<h and 0<=nc<w and (nr,nc) not in seen and a[nr][nc]!=bg
                            and (not monochrome or a[nr][nc]==a[r][c])):
                        seen.add((nr,nc));stack.append((nr,nc))
            found.append(Component(tuple(sorted(cells)),
                 (min(p[0] for p in cells),min(p[1] for p in cells),
                  max(p[0] for p in cells),max(p[1] for p in cells))))
    return tuple(found)


def normalized_shape(cells):
    """D4-invariant binary shape identity; absolute position and colour excluded."""
    variants=[]
    for swap,sr,sc in product((False,True),(-1,1),(-1,1)):
        pts=[(sr*(c if swap else r),sc*(r if swap else c)) for r,c in cells]
        r0=min(r for r,c in pts);c0=min(c for r,c in pts)
        variants.append(tuple(sorted((r-r0,c-c0) for r,c in pts)))
    return min(variants)


def holes(obj: Component) -> int:
    """4-connected cavities in the object's binary bounding box."""
    r0,c0,r1,c1=obj.box; solid=set(obj.cells)
    rest={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1)}-solid
    count=0
    while rest:
        seed=min(rest);rest.remove(seed);stack=[seed];edge=False
        while stack:
            r,c=stack.pop();edge |= r in (r0,r1) or c in (c0,c1)
            for dr,dc in D4:
                p=(r+dr,c+dc)
                if p in rest:rest.remove(p);stack.append(p)
        count += not edge
    return count


@lru_cache(maxsize=256)
def perceive(a: Grid, rule: str|int, connectivity: int, monochrome: bool):
    bg=background(a,rule)
    if bg is None:return None
    obs=components(a,bg,connectivity,monochrome)
    if not obs:return None
    sizes=sorted({len(o.cells) for o in obs});shapes=[normalized_shape(o.cells) for o in obs]
    freq=Counter(shapes); features=[]
    for obj,shape in zip(obs,shapes):
        r0,c0,r1,c1=obj.box;h,w=r1-r0+1,c1-c0+1;n=len(obj.cells);pts=set(obj.cells)
        endpoints=bends=0
        for r,c in pts:
            ds=[(dr,dc) for dr,dc in D4 if (r+dr,c+dc) in pts]
            endpoints += len(ds)==1
            bends += len(ds)==2 and ds[0]!=(-ds[1][0],-ds[1][1])
        features.append(dict(area=n,area_rank=sizes.index(n),area_rank_desc=len(sizes)-1-sizes.index(n),
          area_extremum='equal' if len(sizes)==1 else 'min' if n==sizes[0] else 'max' if n==sizes[-1] else 'middle',
          singleton=n==1,area_parity=n%2,height=h,width=w,bbox_area=h*w,
          aspect='square' if h==w else 'tall' if h>w else 'wide',solid=n==h*w,
          square=n==h*w and h==w,border=r0==0 or c0==0 or r1==len(a)-1 or c1==len(a[0])-1,
          holes=holes(obj),topology=(int(endpoints),int(bends)),shape_frequency=freq[shape]))
    return bg,obs,tuple(features)


def allowed_actions(a,y,obj,bg):
    src=tuple(a[r][c] for r,c in obj.cells); dst=tuple(y[r][c] for r,c in obj.cells)
    actions=set()
    if src==dst:actions.add(KEEP)
    if len(set(dst))==1:
        actions.add(dst[0])
        if dst[0]==bg:actions.add(BACKGROUND)
    return actions


def paint(a,bg,action,r,c):
    return a[r][c] if action==KEEP else bg if action==BACKGROUND else action


@dataclass(frozen=True)
class AttributeProgram:
    background_rule: str|int
    connectivity: int
    monochrome: bool
    feature: str
    table: tuple[tuple[object,tuple[int,...]], ...]

    def name(self):
        return f'{FAMILY}:{self.feature};bg={self.background_rule};conn={self.connectivity};mono={self.monochrome}'

    def describe(self):
        return {'family':FAMILY,'feature':self.feature,'background_rule':self.background_rule,
                'connectivity':self.connectivity,'monochrome':self.monochrome,
                'action_table':[{'key':k,'actions':list(v)} for k,v in self.table],
                'action_codes':{'-1':'preserve source','-2':'current background','0..9':'constant colour'}}

    def joint(self, inputs):
        """Exact factorization of all test predictions, plus <=2 ambiguity witnesses.

        Every feature key selects ONE action shared by all objects and test inputs.
        Disjoint keys write disjoint cells: varying an effective action necessarily
        changes the joint grid. Hence the product count and uniqueness test are exact.
        """
        arrays=tuple(grid(a) for a in inputs); table=dict(self.table);uses={}; bgs=[]
        for i,a in enumerate(arrays):
            scene=perceive(a,self.background_rule,self.connectivity,self.monochrome)
            if scene is None:return None
            bg,obs,fs=scene;bgs.append(bg)
            for obj,f in zip(obs,fs):
                key=f[self.feature]
                if key not in table:return None
                uses.setdefault(key,[]).extend((i,r,c) for r,c in obj.cells)
        factors=[]; assignments={}; count=1
        for key,cells in uses.items():
            effective={}
            for act in table[key]:
                values=tuple(paint(arrays[i],bgs[i],act,r,c) for i,r,c in cells)
                effective.setdefault(values,[]).append(act)
            options=list(effective.items()); count *= len(options)
            assignments[key]=options[0][1][0]
            factors.append({'key':key,'effective_options':len(options),
                'actions_by_effect':[acts for values,acts in options]})
        def render(acts):
            out=[[list(row) for row in a] for a in arrays]
            for key,cells in uses.items():
                for i,r,c in cells:out[i][r][c]=paint(arrays[i],bgs[i],acts[key],r,c)
            return tuple(grid(a) for a in out)
        first=render(assignments);witnesses=[first]
        if count>1:
            f=next(f for f in factors if f['effective_options']>1)
            alternate=dict(assignments);alternate[f['key']]=f['actions_by_effect'][1][0]
            witnesses.append(render(alternate))
        return {'prediction_count':count,'witnesses':witnesses,'factors':factors,
                'program':self.describe()}

    def predict(self,a):
        result=self.joint((a,))
        return result['witnesses'][0][0] if result and result['prediction_count']==1 else None


def fit(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any(len(a)!=len(y) or len(a[0])!=len(y[0]) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    def background_preserved(a,y,rule):
        bg=background(a,rule)
        return bg is not None and all(a[r][c]!=bg or y[r][c]==bg
                    for r in range(len(a)) for c in range(len(a[0])))
    models=[]
    for rule in ('modal',*sorted(common)):
        # Background cells are preserved; movement/expansion are outside this family.
        if not all(background_preserved(a,y,rule) for a,y in pairs):continue
        for conn,mono in product((4,8),(True,False)):
            observations=[];valid=True
            for a,y in pairs:
                scene=perceive(a,rule,conn,mono)
                if scene is None:valid=False;break
                bg,obs,fs=scene
                for obj,f in zip(obs,fs):
                    acts=allowed_actions(a,y,obj,bg)
                    if not acts:valid=False;break
                    observations.append((f,acts))
                if not valid:break
            if not valid:continue
            for feature in FEATURES:
                table={}
                for fs,acts in observations:
                    k=fs[feature]
                    table[k]=table[k]&acts if k in table else set(acts)
                    if not table[k]:break
                if len(table)<2 or any(not v for v in table.values()):continue
                # Single global paint laws are not the structural-conditional grammar.
                if set.intersection(*table.values()):continue
                models.append(AttributeProgram(rule,conn,mono,feature,
                           tuple((k,tuple(sorted(v))) for k,v in sorted(table.items(),key=lambda kv:repr(kv[0])))))
    return models


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    inputs=tuple(d['input'] for d in clean['test']); witnesses={}; factorizations=[];invalid=0
    for model in models:
        j=model.joint(inputs)
        if j is None:invalid+=1;continue
        factorizations.append({k:v for k,v in j.items() if k!='witnesses'})
        for key in j['witnesses']:
            witnesses.setdefault(key,[]).append(model.describe())
    # Every multi-output factorization has >=2 distinct witnesses, so this test
    # is exact even though the displayed count for a union can be only a lower bound.
    status='unique' if len(witnesses)==1 else 'ambiguous' if witnesses else 'no_fit'
    chosen=next(iter(witnesses)) if status=='unique' else None
    exact_count=all(f['prediction_count']<=2 for f in factorizations)
    return {'status':status,'joint_hypotheses':len(witnesses),'joint_hypotheses_is_exact':exact_count,
       'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
                for i in range(len(inputs))],
       'supporting_families':[FAMILY] if chosen else [],
       'supporting_laws':witnesses[chosen] if chosen else [],
       'witness_predictions':[[[list(r) for r in p] for p in key] for key in witnesses],
       'factorizations':factorizations,
       'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
                'factorized_alternatives':True,'all_alternatives_accounted_for':True}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        f={'train':[d for i,d in enumerate(clean['train']) if i!=held],
           'test':[{'input':demo['input']}]+clean['test']}
        r=infer(f);preds=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
            'held_example_exact':r['status']=='unique' and preds[0]==demo['output'],
            'test_prediction_stable':r['status']=='unique' and preds[1:]==expected,
            'joint_hypotheses':r['joint_hypotheses'],
            'joint_hypotheses_is_exact':r['joint_hypotheses_is_exact']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


