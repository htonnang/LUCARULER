"""LUCA V121: general counterfactual selector algebra.

This proof-carrying research family factors several ARC selection tasks into a
shared typed programme::

    scene -> candidate set -> measure/classify -> compare -> bind -> emit

The implementation deliberately contains no task identifiers, stored
coordinates, or test outputs.  It currently exposes three conservative schema
families:

* ``structured_region_selector_crop`` selects one region/panel through a
  learned structural feature and comparison relation;
* ``separator_grid_dimension_projection`` converts a separator lattice into
  its logical row/column dimensions;
* ``unary_foreground_cell_count_projection`` emits one unary token per
  foreground cell.

Exact demonstration fit is necessary but not sufficient.  Accepted predictions
must also survive output consensus, leave-one-demonstration-out refitting,
schema-specific counterfactual tests, and metadata-leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_general_counterfactual_selector_algebra"
LANGUAGE = "spinoza_general_counterfactual_selector_algebra_v1"
SCHEMA_VERSION = "general_counterfactual_selector_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _directions(connectivity: int):
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    return directions


def _bbox(cells: Iterable[tuple[int, int]]) -> tuple[int, int, int, int]:
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _crop(value: Grid, cells: Iterable[tuple[int, int]]) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = _bbox(cells)
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _rotate90(value: Grid) -> Grid:
    value = grid(value)
    h, w = _shape(value)
    return tuple(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))


def _rotate180(value: Grid) -> Grid:
    return _rotate90(_rotate90(value))


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused counterfactual colour")


def _components_by_predicate(
    value: Grid,
    predicate,
    *,
    connectivity: int,
):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if predicate(value[r][c])}
    result = []
    while remaining:
        start = min(remaining)
        remaining.remove(start)
        component = {start}
        queue = deque([start])
        while queue:
            r, c = queue.popleft()
            for dr, dc in _directions(connectivity):
                neighbour = (r + dr, c + dc)
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        result.append(tuple(sorted(component)))
    return tuple(result)


def _monochrome_components(value: Grid, background: int, connectivity: int):
    value = grid(value)
    result = []
    for colour in sorted(_palette(value) - {background}):
        components = _components_by_predicate(
            value,
            lambda cell, colour=colour: cell == colour,
            connectivity=connectivity,
        )
        result.extend((colour, cells) for cells in components)
    return tuple(result)


def _is_filled_rectangle(cells: Iterable[tuple[int, int]]) -> bool:
    cells = tuple(cells)
    if not cells:
        return False
    r0, c0, r1, c1 = _bbox(cells)
    return len(cells) == (r1 - r0 + 1) * (c1 - c0 + 1)


def _normalised_mask(cells: Iterable[tuple[int, int]]):
    cells = tuple(cells)
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    maximum = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == maximum]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Shared selector primitives.
# ---------------------------------------------------------------------------


def _rectangular_panel_decompositions(value: Grid):
    """Return conservative solid-panel decompositions.

    Every candidate canvas background is tried.  Non-background 4-connected
    components must each be solid rectangles.  The most explanatory
    decomposition maximises the number of panels, then covered material.
    Ambiguous maxima are rejected.
    """
    value = grid(value)
    h, w = _shape(value)
    decompositions = []
    for canvas_background in sorted(_palette(value)):
        components = _components_by_predicate(
            value,
            lambda cell, bg=canvas_background: cell != bg,
            connectivity=4,
        )
        if len(components) < 2 or not all(_is_filled_rectangle(cells) for cells in components):
            continue
        panels = []
        for cells in components:
            r0, c0, r1, c1 = _bbox(cells)
            panel = tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))
            panels.append({
                "cells": cells,
                "bbox": (r0, c0, r1, c1),
                "crop": panel,
                "area": len(cells),
            })
        # A shared panel-background colour must occur in every panel.  Select
        # the unique shared colour with greatest total support.
        shared = set.intersection(*(_palette(panel["crop"]) for panel in panels))
        if not shared:
            continue
        support = {
            colour: sum(cell == colour for panel in panels for row in panel["crop"] for cell in row)
            for colour in shared
        }
        top = max(support.values())
        panel_backgrounds = [colour for colour, count in support.items() if count == top]
        if len(panel_backgrounds) != 1:
            continue
        panel_background = panel_backgrounds[0]
        if all(all(cell == panel_background for row in panel["crop"] for cell in row) for panel in panels):
            continue
        panels = tuple(sorted(panels, key=lambda panel: panel["bbox"]))
        covered = sum(panel["area"] for panel in panels)
        decompositions.append({
            "canvas_background": canvas_background,
            "panel_background": panel_background,
            "panels": panels,
            "score": (len(panels), covered),
        })
    if not decompositions:
        raise Inapplicable("no solid rectangular-panel decomposition")
    best_score = max(item["score"] for item in decompositions)
    winners = [item for item in decompositions if item["score"] == best_score]
    # Equivalent decompositions with identical panel boxes and backgrounds are
    # collapsed; otherwise the scene interpretation is ambiguous.
    unique = {}
    for item in winners:
        key = (
            item["canvas_background"],
            item["panel_background"],
            tuple(panel["bbox"] for panel in item["panels"]),
        )
        unique[key] = item
    if len(unique) != 1:
        raise Inapplicable("ambiguous panel decomposition")
    return next(iter(unique.values()))


def _plus_component_count(panel: Grid, panel_background: int) -> int:
    panel = grid(panel)
    count = 0
    for colour in sorted(_palette(panel) - {panel_background}):
        components = _components_by_predicate(
            panel,
            lambda cell, colour=colour: cell == colour,
            connectivity=4,
        )
        for cells in components:
            mask = _normalised_mask(cells)
            if mask == ((0, 1), (1, 0), (1, 1), (1, 2), (2, 1)):
                count += 1
    return count


def _panel_feature(panel: Grid, panel_background: int, feature: str):
    panel = grid(panel)
    if feature == "foreground_count":
        return sum(cell != panel_background for row in panel for cell in row)
    if feature == "plus_component_count":
        return _plus_component_count(panel, panel_background)
    raise Inapplicable("unknown panel feature")


def _left_right_symmetric(cells: Iterable[tuple[int, int]]) -> bool:
    mask = set(_normalised_mask(cells))
    if not mask:
        return False
    width = max(c for _, c in mask) + 1
    return mask == {(r, width - 1 - c) for r, c in mask}


@dataclass(frozen=True)
class StructuredRegionSelectorCropProgram:
    candidate_mode: str
    feature: str
    comparison: str
    connectivity: int = 4
    kind: str = "structured_region_selector_crop"

    @property
    def schema_key(self):
        return self.kind, self.candidate_mode, self.feature, self.comparison, self.connectivity

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return self.candidate_mode, self.feature, self.comparison, self.connectivity

    def _select(self, candidates):
        values = [candidate["value"] for candidate in candidates]
        if self.comparison == "unique_max":
            target = max(values)
        elif self.comparison == "unique_min":
            target = min(values)
        elif self.comparison == "unique_false":
            if set(values) - {False, True}:
                raise Inapplicable("unique_false requires boolean features")
            target = False
        else:
            raise Inapplicable("unknown comparison")
        winners = [candidate for candidate in candidates if candidate["value"] == target]
        if len(winners) != 1:
            raise Inapplicable("selector has no unique winner")
        # Require contrasting evidence; a vacuous singleton candidate set is
        # not a structural comparison.
        if len(candidates) < 2 or len(set(values)) < 2:
            raise Inapplicable("insufficient comparative evidence")
        return winners[0]

    def _analyse_panels(self, value: Grid):
        decomposition = _rectangular_panel_decompositions(value)
        candidates = []
        for panel in decomposition["panels"]:
            item = dict(panel)
            item["value"] = _panel_feature(
                panel["crop"],
                decomposition["panel_background"],
                self.feature,
            )
            candidates.append(item)
        winner = self._select(candidates)
        return {
            "mode": self.candidate_mode,
            "canvas_background": decomposition["canvas_background"],
            "panel_background": decomposition["panel_background"],
            "candidates": tuple(candidates),
            "winner": winner,
            "prediction": winner["crop"],
        }

    def _analyse_same_colour_components(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        components = _monochrome_components(value, background, self.connectivity)
        colours = {colour for colour, _ in components}
        if len(components) < 3 or len(colours) != 1:
            raise Inapplicable("requires at least three same-colour components")
        colour = next(iter(colours))
        candidates = []
        for _, cells in components:
            if self.feature != "left_right_symmetric":
                raise Inapplicable("unknown component feature")
            candidates.append({
                "colour": colour,
                "cells": cells,
                "bbox": _bbox(cells),
                "crop": _crop(value, cells),
                "value": _left_right_symmetric(cells),
            })
        winner = self._select(candidates)
        return {
            "mode": self.candidate_mode,
            "canvas_background": background,
            "panel_background": None,
            "candidates": tuple(candidates),
            "winner": winner,
            "prediction": winner["crop"],
        }

    def _analyse(self, value: Grid):
        if self.candidate_mode == "rectangular_panels":
            return self._analyse_panels(value)
        if self.candidate_mode == "same_colour_components":
            return self._analyse_same_colour_components(value)
        raise Inapplicable("unknown candidate mode")

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            analysis = self._analyse(source)
            evidence.append({
                "candidate_values": [candidate["value"] for candidate in analysis["candidates"]],
                "winner_bbox": list(analysis["winner"]["bbox"]),
                "winner_value": analysis["winner"]["value"],
                "candidate_count": len(analysis["candidates"]),
            })
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "candidate_mode": self.candidate_mode,
                "feature": self.feature,
                "comparison": self.comparison,
                "connectivity": self.connectivity,
                "emission": "raw_bbox_crop",
            },
            definitions=[
                {"name": "CandidateSet", "type": "Grid -> StructuredRegions"},
                {"name": "FeatureMeasure", "type": "Region -> QuantityOrPredicate"},
                {"name": "UniqueComparison", "type": "FeatureMultiset -> Region"},
                {"name": "CanonicalCrop", "type": "Region -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ConstructCandidates", "effect": "derive panels or same-colour components"},
                {"index": 2, "definition": "MeasureCandidates", "effect": "assign one structural feature to every candidate"},
                {"index": 3, "definition": "CompareAndBind", "effect": "bind the sole extremal or predicate-outlier role"},
                {"index": 4, "definition": "ProjectCrop", "effect": "emit the selected raw bounding-box crop"},
            ],
            corollary="the uniquely selected structured region is the answer",
            common_notions=[{"name": "selector_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema II: separator lattice -> logical dimensions.
# ---------------------------------------------------------------------------


def _runs(indices: Iterable[int]):
    values = sorted(set(indices))
    if not values:
        return tuple()
    result = []
    current = [values[0]]
    for value in values[1:]:
        if value == current[-1] + 1:
            current.append(value)
        else:
            result.append(tuple(current))
            current = [value]
    result.append(tuple(current))
    return tuple(result)


def _separator_decomposition(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    palette = sorted(_palette(value))
    if len(palette) != 2:
        raise Inapplicable("separator projection requires exactly two colours")
    decompositions = []
    for separator in palette:
        field = next(colour for colour in palette if colour != separator)
        full_rows = {r for r in range(h) if all(value[r][c] == separator for c in range(w))}
        full_cols = {c for c in range(w) if all(value[r][c] == separator for r in range(h))}
        if not full_rows or not full_cols:
            continue
        # Every separator cell must belong to a complete separator row or
        # column; otherwise this is an arbitrary two-colour picture rather than
        # a lattice.
        if any(
            value[r][c] == separator and r not in full_rows and c not in full_cols
            for r in range(h) for c in range(w)
        ):
            continue
        if any(
            value[r][c] != field
            for r in range(h) for c in range(w)
            if r not in full_rows and c not in full_cols
        ):
            continue
        row_groups = _runs(r for r in range(h) if r not in full_rows)
        col_groups = _runs(c for c in range(w) if c not in full_cols)
        if not row_groups or not col_groups:
            continue
        output = tuple(tuple(field for _ in col_groups) for _ in row_groups)
        decompositions.append({
            "separator": separator,
            "field": field,
            "full_rows": tuple(sorted(full_rows)),
            "full_cols": tuple(sorted(full_cols)),
            "row_groups": row_groups,
            "col_groups": col_groups,
            "prediction": output,
        })
    if len(decompositions) != 1:
        raise Inapplicable("separator lattice is absent or ambiguous")
    return decompositions[0]


@dataclass(frozen=True)
class SeparatorGridDimensionProjectionProgram:
    kind: str = "separator_grid_dimension_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.kind,)

    def _analyse(self, value: Grid):
        return _separator_decomposition(value)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            analysis = self._analyse(source)
            evidence.append({
                "separator": analysis["separator"],
                "field": analysis["field"],
                "logical_shape": [len(analysis["row_groups"]), len(analysis["col_groups"])],
                "separator_row_bands": len(_runs(analysis["full_rows"])),
                "separator_col_bands": len(_runs(analysis["full_cols"])),
            })
        return _law(
            self,
            parameters={"kind": self.kind, "emission": "uniform_logical_dimension_grid"},
            definitions=[
                {"name": "SeparatorLattice", "type": "Grid -> RowColumnBands"},
                {"name": "LogicalRegions", "type": "RowColumnBands -> LogicalShape"},
                {"name": "FieldColour", "type": "Grid -> Colour"},
                {"name": "DimensionProjection", "type": "LogicalShape × Colour -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "IdentifySeparator", "effect": "find complete row and column separator bands"},
                {"index": 2, "definition": "CountLogicalRegions", "effect": "count contiguous nonseparator row and column groups"},
                {"index": 3, "definition": "ProjectDimensions", "effect": "emit a uniform field-colour grid of the logical dimensions"},
            ],
            corollary="the separator lattice dimensions determine the projected answer",
            common_notions=[{"name": "separator_dimension_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema III: foreground cell count -> unary sequence.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UnaryForegroundCellCountProjectionProgram:
    orientation: str
    kind: str = "unary_foreground_cell_count_projection"

    @property
    def schema_key(self):
        return self.kind, self.orientation

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.orientation,

    def _analyse(self, value: Grid):
        value = grid(value)
        palette = sorted(_palette(value))
        if 0 not in palette or len(palette) != 2:
            raise Inapplicable("unary cell count requires black background and one foreground colour")
        foreground = next(colour for colour in palette if colour != 0)
        count = sum(cell == foreground for row in value for cell in row)
        if count <= 0:
            raise Inapplicable("empty foreground")
        if self.orientation == "row":
            prediction = (tuple(foreground for _ in range(count)),)
        elif self.orientation == "column":
            prediction = tuple((foreground,) for _ in range(count))
        else:
            raise Inapplicable("unknown unary orientation")
        return {"foreground": foreground, "count": count, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            analysis = self._analyse(source)
            evidence.append({"foreground": analysis["foreground"], "count": analysis["count"]})
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "orientation": self.orientation,
                "measure": "foreground_cell_count",
                "emission": "unary_sequence",
            },
            definitions=[
                {"name": "ForegroundSet", "type": "Grid -> Cells"},
                {"name": "CellCount", "type": "Cells -> Integer"},
                {"name": "UnaryEmitter", "type": "Integer × Colour × Orientation -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "IdentifyForeground", "effect": "bind the sole nonzero colour"},
                {"index": 2, "definition": "CountCells", "effect": "measure foreground material"},
                {"index": 3, "definition": "EmitUnary", "effect": "write one foreground token per cell"},
            ],
            corollary="foreground material is represented as a unary sequence",
            common_notions=[{"name": "unary_count_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and validation.
# ---------------------------------------------------------------------------


def _fit_simple(programmes, pairs):
    fitted = []
    for program in programmes:
        try:
            if all(program.predict(source) == target for source, target in pairs):
                fitted.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration):
            continue
    return fitted


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programmes = []
    if allowed is None or "structured_region_selector_crop" in allowed:
        candidates = [
            StructuredRegionSelectorCropProgram("rectangular_panels", "foreground_count", comparison, 4)
            for comparison in ("unique_min", "unique_max")
        ]
        candidates.append(
            StructuredRegionSelectorCropProgram("rectangular_panels", "plus_component_count", "unique_max", 4)
        )
        candidates.append(
            StructuredRegionSelectorCropProgram("same_colour_components", "left_right_symmetric", "unique_false", 8)
        )
        programmes.extend(_fit_simple(candidates, pairs))
    if allowed is None or "separator_grid_dimension_projection" in allowed:
        programmes.extend(_fit_simple([SeparatorGridDimensionProjectionProgram()], pairs))
    if allowed is None or "unary_foreground_cell_count_projection" in allowed:
        orientations = []
        output_shapes = {_shape(target) for _, target in pairs}
        if output_shapes and all(h == 1 for h, _ in output_shapes):
            orientations.append("row")
        if output_shapes and all(w == 1 for _, w in output_shapes):
            orientations.append("column")
        programmes.extend(_fit_simple([UnaryForegroundCellCountProjectionProgram(o) for o in orientations], pairs))
    return programmes


def _role_signature(program, source):
    if isinstance(program, StructuredRegionSelectorCropProgram):
        analysis = program._analyse(source)
        return (
            analysis["winner"]["bbox"],
            analysis["winner"]["value"],
            tuple(candidate["value"] for candidate in analysis["candidates"]),
            analysis["prediction"],
        )
    if isinstance(program, SeparatorGridDimensionProjectionProgram):
        analysis = program._analyse(source)
        return (
            analysis["field"],
            len(analysis["row_groups"]),
            len(analysis["col_groups"]),
            analysis["full_rows"],
            analysis["full_cols"],
        )
    if isinstance(program, UnaryForegroundCellCountProjectionProgram):
        analysis = program._analyse(source)
        return analysis["foreground"], analysis["count"]
    raise Inapplicable("unknown selector programme")


def _role_varies(program, pairs):
    try:
        signatures = [_role_signature(program, source) for source, _ in pairs]
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
        return False
    return len({_serial(signature) for signature in signatures}) >= 2


def fit_selector_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_selector_algebra(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_selector_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration):
            invalid += 1
            continue
        groups[predictions].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:30] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "selector_schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "general_counterfactual_selector_algebra": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "structured_region_selector_crop":
        return StructuredRegionSelectorCropProgram(
            str(parameters["candidate_mode"]),
            str(parameters["feature"]),
            str(parameters["comparison"]),
            int(parameters.get("connectivity", 4)),
        )
    if kind == "separator_grid_dimension_projection":
        return SeparatorGridDimensionProjectionProgram()
    if kind == "unary_foreground_cell_count_projection":
        return UnaryForegroundCellCountProjectionProgram(str(parameters["orientation"]))
    raise Inapplicable("unknown selector schema")


def _counterfactual_result(kind, rows):
    passed = all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _selector_counterfactuals(program: StructuredRegionSelectorCropProgram, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program._analyse(source)
        original = analysis["prediction"]
        try:
            rotation_equivariant = program.predict(_rotate180(source)) == _rotate180(original)
        except Inapplicable:
            rotation_equivariant = False

        cause_necessary = False
        colour_equivariant = True
        if program.candidate_mode == "rectangular_panels":
            winner = analysis["winner"]
            panel_background = analysis["panel_background"]
            modified = _array(source)
            if program.feature == "foreground_count":
                if program.comparison == "unique_max":
                    for r, c in winner["cells"]:
                        if source[r][c] != panel_background:
                            modified[r][c] = panel_background
                    try:
                        cause_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
                    except Inapplicable:
                        cause_necessary = True
                else:  # unique_min
                    competitors = [candidate for candidate in analysis["candidates"] if candidate is not winner]
                    competitor = min(competitors, key=lambda item: item["value"])
                    cells = [cell for cell in competitor["cells"] if source[cell[0]][cell[1]] != panel_background]
                    target_count = max(0, int(winner["value"]) - 1)
                    for r, c in cells[target_count:]:
                        modified[r][c] = panel_background
                    try:
                        cause_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
                    except Inapplicable:
                        cause_necessary = True
            elif program.feature == "plus_component_count":
                plus_colour_cells = [
                    (r, c) for r, c in winner["cells"] if source[r][c] != panel_background
                ]
                for r, c in plus_colour_cells:
                    modified[r][c] = panel_background
                try:
                    cause_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
                except Inapplicable:
                    cause_necessary = True
            else:
                cause_necessary = False
        else:
            # Convert one symmetric comparison object into a second
            # nonsymmetric candidate, which must destroy unique_false binding.
            comparisons = [candidate for candidate in analysis["candidates"] if candidate is not analysis["winner"]]
            target = next((candidate for candidate in comparisons if candidate["value"] is True), None)
            if target is not None:
                # Search deterministic one-cell deletions for a perturbation
                # that breaks the comparison object's reflection relation.
                # This avoids treating deletion of a centre-axis cell as a
                # meaningful asymmetry intervention.
                for r, c in sorted(target["cells"]):
                    modified = _array(source)
                    modified[r][c] = analysis["canvas_background"]
                    try:
                        changed = program.predict(tuple(tuple(row) for row in modified)) != original
                    except Inapplicable:
                        changed = True
                    if changed:
                        cause_necessary = True
                        break
            # Recolour the entire same-colour class; the selected crop should
            # transform equivariantly.
            old_colour = analysis["winner"]["colour"]
            new_colour = _fresh_colour(source, (old_colour,))
            recoloured = _replace_colour(source, old_colour, new_colour)
            expected = _replace_colour(original, old_colour, new_colour)
            try:
                colour_equivariant = program.predict(recoloured) == expected
            except Inapplicable:
                colour_equivariant = False

        rows.append({
            "demonstration": index,
            "cause_necessary": cause_necessary,
            "rotation_equivariant": rotation_equivariant,
            "colour_equivariant": colour_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _separator_counterfactuals(program: SeparatorGridDimensionProjectionProgram, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program._analyse(source)
        original = analysis["prediction"]
        fresh = _fresh_colour(source, (analysis["separator"], analysis["field"]))
        recoloured = _replace_colour(source, analysis["separator"], fresh)
        try:
            separator_identity_invariant = program.predict(recoloured) == original
        except Inapplicable:
            separator_identity_invariant = False

        modified = _array(source)
        # Remove one complete separator band when possible.  The logical shape
        # must change or the programme must reject.
        separator_bands = list(_runs(analysis["full_rows"])) + list(_runs(analysis["full_cols"]))
        if separator_bands:
            # Prefer an interior row band, then an interior column band.
            changed = False
            for band in _runs(analysis["full_rows"]):
                if band[0] > 0 and band[-1] < len(source) - 1:
                    for r in band:
                        for c in range(len(source[0])):
                            modified[r][c] = analysis["field"]
                    changed = True
                    break
            if not changed:
                for band in _runs(analysis["full_cols"]):
                    if band[0] > 0 and band[-1] < len(source[0]) - 1:
                        for c in band:
                            for r in range(len(source)):
                                modified[r][c] = analysis["field"]
                        changed = True
                        break
            try:
                band_necessary = changed and program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                band_necessary = changed
        else:
            band_necessary = False

        try:
            rotation_equivariant = program.predict(_rotate90(source)) == _rotate90(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "separator_identity_invariant": separator_identity_invariant,
            "separator_band_necessary": band_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _unary_counterfactuals(program: UnaryForegroundCellCountProjectionProgram, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        analysis = program._analyse(source)
        original = analysis["prediction"]
        fresh = _fresh_colour(source, (analysis["foreground"],))
        recoloured = _replace_colour(source, analysis["foreground"], fresh)
        expected = _replace_colour(original, analysis["foreground"], fresh)
        try:
            colour_equivariant = program.predict(recoloured) == expected
        except Inapplicable:
            colour_equivariant = False

        modified = _array(source)
        zero = next(((r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell == 0), None)
        if zero is not None:
            modified[zero[0]][zero[1]] = analysis["foreground"]
            try:
                changed = program.predict(tuple(tuple(row) for row in modified))
                quantity_necessary = sum(len(row) for row in changed) == sum(len(row) for row in original) + 1
            except Inapplicable:
                quantity_necessary = False
        else:
            quantity_necessary = False
        try:
            rotation_invariant = program.predict(_rotate180(source)) == original
        except Inapplicable:
            rotation_invariant = False
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "quantity_necessary": quantity_necessary,
            "rotation_invariant": rotation_invariant,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_validation(program, pairs):
    if isinstance(program, StructuredRegionSelectorCropProgram):
        return _selector_counterfactuals(program, pairs)
    if isinstance(program, SeparatorGridDimensionProjectionProgram):
        return _separator_counterfactuals(program, pairs)
    if isinstance(program, UnaryForegroundCellCountProjectionProgram):
        return _unary_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_selector_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [item for index, item in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_selector_algebra(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    for program in programmes:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def selector_algebra_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_selector_programs(pairs)}))


infer = infer_selector_algebra
validate = validate_selector_algebra
