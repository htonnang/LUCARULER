"""V44 reusable object-to-marker relational placement laws.

The selected source is the unique largest or smallest 4/8-connected object.
A singleton marker of a different color anchors a translation. A learned
anchor convention places the source bounding-box origin at, above, to the
left of, or centered on the marker. No ARC IDs or fixed output colors.
"""
from dataclasses import dataclass
from collections import deque
from itertools import product
from geometry import grid


def components(a, bg, conn):
    a=grid(a); h=len(a); w=len(a[0]); used=set();out=[]
    dirs=[(-1,0),(1,0),(0,-1),(0,1)]
    if conn==8: dirs += [(-1,-1),(-1,1),(1,-1),(1,1)]
    for r in range(h):
        for c in range(w):
            if a[r][c]==bg or (r,c) in used:continue
            q=deque([(r,c)]);used.add((r,c));cells=[]
            while q:
                x,y=q.popleft();cells.append((x,y))
                for dr,dc in dirs:
                    nr,nc=x+dr,y+dc
                    if 0<=nr<h and 0<=nc<w and (nr,nc) not in used and a[nr][nc]!=bg:
                        used.add((nr,nc));q.append((nr,nc))
            out.append(tuple(cells))
    return out

@dataclass(frozen=True)
class RelationalLaw:
    bg:int
    conn:int
    selection:str
    anchor:str # one of four positional conventions
    canvas:str # erase source or keep source
    marker_color:int
    def predict(self, raw):
        a=grid(raw);h=len(a);w=len(a[0]);objs=components(a,self.bg,self.conn)
        if not objs:return None
        sizes=[len(z) for z in objs]; n=max(sizes) if self.selection=='largest' else min(sizes)
        selected=[z for z in objs if len(z)==n]
        if len(selected)!=1:return None
        obj=selected[0];r0=min(r for r,c in obj);c0=min(c for r,c in obj)
        bh=max(r for r,c in obj)-r0+1;bw=max(c for r,c in obj)-c0+1
        # Marker must be a unique singleton *component* outside source.
        markers=[o[0] for o in objs if len(o)==1 and o[0] not in obj and a[o[0][0]][o[0][1]]==self.marker_color]
        if len(markers)!=1:return None
        mr,mc=markers[0]
        if self.anchor=='right_of': nr,nc=mr,mc+1
        elif self.anchor=='left_of':nr,nc=mr,mc-bw
        elif self.anchor=='below':nr,nc=mr+1,mc
        elif self.anchor=='above':nr,nc=mr-bh,mc
        elif self.anchor=='below_right':nr,nc=mr+1,mc+1
        else:raise ValueError(self.anchor)
        if not (0<=nr and 0<=nc and nr+bh<=h and nc+bw<=w):return None
        out=[list(row) for row in a]
        if self.canvas=='erase':
            for r,c in obj:out[r][c]=self.bg
        elif self.canvas!='keep':raise ValueError(self.canvas)
        # Do not overwrite occupied unrelated cells or the marker.
        dest=[(nr+r-r0,nc+c-c0,r,c) for r,c in obj]
        for rr,cc,r,c in dest:
            if (rr,cc) not in obj and a[rr][cc]!=self.bg:return None
        for rr,cc,r,c in dest:out[rr][cc]=a[r][c]
        return grid(out)

def candidates(pairs):
    # Constrain marker colors to those visible in all demonstrations.
    shared=set(range(10))
    for x,y in pairs:shared &= {v for row in x for v in row}
    for bg,conn,select,anchor,canvas,marker in product(range(10),(4,8),('largest','smallest'),('right_of','left_of','below','above','below_right'),('erase','keep'),sorted(shared)):
        if bg==marker:continue
        yield RelationalLaw(bg,conn,select,anchor,canvas,marker)

def fit(pairs):
    pairs=[(grid(x),grid(y)) for x,y in pairs]
    if not pairs:return []
    result=[]
    for law in candidates(pairs):
        if all(law.predict(x)==y for x,y in pairs):result.append(law)
    return result
