"""LUCA V144: primitive anti-unification and bounded relation search.

The family deliberately separates reusable structural primitives from their
scene-specific parameterisations:

    scene -> typed nodes -> typed edges -> bounded relation chain
          -> shared operator -> deterministic full grid

The runtime is task-ID blind and test-target blind.  Colours, dimensions,
periods, phases, anchor roles, overlap ownership, and rectangle boundaries are
inferred from the demonstrations and current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import product

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_primitive_anti_unification_relation_search"
LANGUAGE = "spinoza_primitive_anti_unification_relation_search_v144"
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Shared evidence language.
# ---------------------------------------------------------------------------


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    relation = " -> ".join(relation_chain)
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": relation,
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "primitive_anti_unification": True,
            "bounded_two_step_relation_chain": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    return counts.most_common(1)[0][0]


def _transpose(value: Grid):
    return grid(zip(*grid(value)))


def _orient(value: Grid, orientation: str):
    return grid(value) if orientation == "horizontal" else _transpose(value)


def _unorient(value: Grid, orientation: str):
    return grid(value) if orientation == "horizontal" else _transpose(value)


def _single_new_colour(pairs):
    colour = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        extra = _palette(target) - _palette(source)
        if len(extra) != 1:
            raise Inapplicable("one new semantic colour required")
        current = int(next(iter(extra)))
        if colour is None:
            colour = current
        elif colour != current:
            raise Inapplicable("new semantic colour changes across demonstrations")
    if colour is None:
        raise Inapplicable("missing new semantic colour")
    return colour


def _components(value: Grid, colour: int):
    value = grid(value)
    height, width = _shape(value)
    seen = set()
    output = []
    for r in range(height):
        for c in range(width):
            if value[r][c] != colour or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nr, nc = rr + dr, cc + dc
                    if 0 <= nr < height and 0 <= nc < width and value[nr][nc] == colour and (nr, nc) not in seen:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append(tuple(sorted(cells)))
    return output


def _bbox(cells):
    rows = [r for r, _ in cells]
    columns = [c for _, c in cells]
    return min(rows), max(rows), min(columns), max(columns)


def _contiguous_prefix_length(row, background):
    length = 0
    for cell in row:
        if cell == background:
            break
        length += 1
    return length


def _contiguous_suffix_length(row, background):
    length = 0
    for cell in reversed(row):
        if cell == background:
            break
        length += 1
    return length


def _minimal_period(sequence, *, minimum_repeats=2):
    sequence = tuple(sequence)
    # A complete second copy is not required: a witnessed prefix of the next
    # period is sufficient, provided at least two successor positions agree.
    for period in range(1, len(sequence)):
        repeated = len(sequence) - period
        if repeated < max(2, period // 2):
            continue
        if all(sequence[index] == sequence[index % period] for index in range(period, len(sequence))):
            return period
    raise Inapplicable("no repeated period witnessed")


# ---------------------------------------------------------------------------
# Shared operator I: periodic axis continuation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReferenceMappedAxisContinuationProgram:
    orientation: str
    side: str

    kind = "reference_mapped_axis_continuation"
    operator = "periodic_axis_continuation"
    node_vocabulary = "axis_template_seed_nodes"
    edge_vocabulary = "role_mapping_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.side

    def predict(self, value: Grid) -> Grid:
        canonical = _orient(value, self.orientation)
        background = _mode(canonical)
        if self.side == "end":
            canonical = grid(tuple(reversed(row)) for row in canonical)
        height, width = _shape(canonical)
        reference_rows = []
        for r, row in enumerate(canonical):
            if all(cell != background for cell in row) and len(set(row)) >= 2:
                reference_rows.append(r)
        if len(reference_rows) != 1:
            raise Inapplicable("one complete reference axis required")
        reference_index = reference_rows[0]
        reference = canonical[reference_index]
        reference_roles = set(reference)
        if not (2 <= len(reference_roles) <= 5):
            raise Inapplicable("bounded reference role vocabulary required")

        output = _array(canonical)
        targets = 0
        for r, row in enumerate(canonical):
            if r == reference_index or all(cell == background for cell in row):
                continue
            prefix = _contiguous_prefix_length(row, background)
            if prefix == 0 or prefix == width:
                raise Inapplicable("target must be a boundary seed followed by background")
            if any(cell != background for cell in row[prefix:]):
                raise Inapplicable("foreign material after target seed")
            mapping = {}
            reverse = {}
            for c in range(prefix):
                source_role = reference[c]
                target_role = row[c]
                if source_role in mapping and mapping[source_role] != target_role:
                    raise Inapplicable("inconsistent role mapping")
                if target_role in reverse and reverse[target_role] != source_role:
                    raise Inapplicable("non-injective role mapping")
                mapping[source_role] = target_role
                reverse[target_role] = source_role
            if set(mapping) != reference_roles:
                raise Inapplicable("seed does not witness every reference role")
            output[r] = [mapping[cell] for cell in reference]
            targets += 1
        if not targets:
            raise Inapplicable("no target seeds")
        predicted = grid(output)
        if self.side == "end":
            predicted = grid(tuple(reversed(row)) for row in predicted)
        return _unorient(predicted, self.orientation)

    def describe(self, pairs):
        return _law(
            self,
            scene="one complete symbolic axis and one or more boundary seeds",
            relation_chain=(
                "align each seed with the reference positions",
                "infer an injective role map and emit all successor positions",
            ),
            parameters={"orientation": self.orientation, "seed_side": self.side},
            corollary="Continue every seeded axis by applying its input-derived role map to the complete reference pattern.",
            notions=["axis template", "boundary seed", "role map", "successor position"],
        )


@dataclass(frozen=True)
class RepeatedPrefixTilingProgram:
    orientation: str
    side: str

    kind = "repeated_prefix_axis_tiling"
    operator = "periodic_axis_continuation"
    node_vocabulary = "axis_template_seed_nodes"
    edge_vocabulary = "periodic_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.side

    def predict(self, value: Grid) -> Grid:
        canonical = _orient(value, self.orientation)
        background = _mode(canonical)
        if self.side == "end":
            canonical = grid(tuple(reversed(row)) for row in canonical)
        height, width = _shape(canonical)
        active_rows = [r for r, row in enumerate(canonical) if any(cell != background for cell in row)]
        if not active_rows:
            raise Inapplicable("empty scene")
        last = max(c for row in canonical for c, cell in enumerate(row) if cell != background)
        prefix_width = last + 1
        if prefix_width >= width:
            raise Inapplicable("no continuation region")
        if any(any(cell != background for cell in row[prefix_width:]) for row in canonical):
            raise Inapplicable("material outside the witnessed prefix")

        columns = tuple(tuple(canonical[r][c] for r in range(height)) for c in range(prefix_width))
        period = _minimal_period(columns, minimum_repeats=2)
        if prefix_width - period < max(2, period // 2):
            raise Inapplicable("insufficient repeated successor evidence")
        if all(all(cell == background for cell in column) for column in columns[:period]):
            raise Inapplicable("empty period")
        output = [[canonical[r][c % period] for c in range(width)] for r in range(height)]
        predicted = grid(output)
        if self.side == "end":
            predicted = grid(tuple(reversed(row)) for row in predicted)
        return _unorient(predicted, self.orientation)

    def describe(self, pairs):
        return _law(
            self,
            scene="a repeated multi-row prefix followed by an empty axis suffix",
            relation_chain=(
                "anti-unify the shortest repeated prefix block",
                "apply periodic successor edges until the boundary",
            ),
            parameters={"orientation": self.orientation, "seed_side": self.side},
            corollary="Tile the witnessed periodic block across the remaining axis positions.",
            notions=["period block", "prefix witness", "successor edge", "boundary termination"],
        )


@dataclass(frozen=True)
class BoundaryMotifTilingProgram:
    orientation: str
    boundary: str

    kind = "boundary_motif_axis_tiling"
    operator = "periodic_axis_continuation"
    node_vocabulary = "axis_template_seed_nodes"
    edge_vocabulary = "periodic_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.boundary

    def predict(self, value: Grid) -> Grid:
        canonical = _orient(value, self.orientation)
        background = _mode(canonical)
        if self.boundary == "start":
            canonical = grid(reversed(canonical))
        height, width = _shape(canonical)
        active = [r for r, row in enumerate(canonical) if any(cell != background for cell in row)]
        if not active:
            raise Inapplicable("missing boundary motif")
        start = min(active)
        if active != list(range(start, height)):
            raise Inapplicable("motif must be one contiguous boundary suffix")
        if start == 0:
            raise Inapplicable("motif already fills the axis")
        motif = canonical[start:]
        if len(motif) < 2:
            raise Inapplicable("multi-row boundary motif required")
        if any(all(cell == background for cell in row) for row in motif):
            raise Inapplicable("empty row inside motif")
        period = len(motif)
        output = []
        for r in range(height):
            output.append(list(motif[(r - start) % period]))
        predicted = grid(output)
        if self.boundary == "start":
            predicted = grid(reversed(predicted))
        return _unorient(predicted, self.orientation)

    def describe(self, pairs):
        return _law(
            self,
            scene="one multi-row motif touching an axis boundary",
            relation_chain=(
                "treat the boundary motif as one phase-complete period",
                "extend predecessor phases to the opposite boundary",
            ),
            parameters={"orientation": self.orientation, "boundary": self.boundary},
            corollary="Repeat the boundary motif across the entire canvas while preserving its witnessed phase.",
            notions=["boundary motif", "phase", "predecessor edge", "periodic tiling"],
        )


@dataclass(frozen=True)
class AnchoredPeriodicContinuationProgram:
    anchor_colour: int
    maximum_period: int = 4

    kind = "anchored_periodic_ray_continuation"
    operator = "periodic_axis_continuation"
    node_vocabulary = "anchor_and_axis_seed_nodes"
    edge_vocabulary = "away_from_anchor_periodic_edges"

    @property
    def schema_key(self):
        return self.kind, self.anchor_colour, self.maximum_period

    @staticmethod
    def _ray_from_component(value: Grid, cells, anchor_colour, direction):
        height, width = _shape(value)
        r0, r1, c0, c1 = _bbox(cells)
        if direction == "up":
            first = r0 - 1
            if first < 0:
                return None
            candidates = [(c, value[first][c]) for c in range(c0, c1 + 1) if value[first][c] not in (_mode(value), anchor_colour)]
            if not candidates:
                return None
            columns = [c for c, _ in candidates]
            if columns != list(range(min(columns), max(columns) + 1)):
                return None
            span = tuple(range(min(columns), max(columns) + 1))
            vectors = []
            for r in range(first, -1, -1):
                vector = tuple(value[r][c] for c in span)
                if all(cell == _mode(value) for cell in vector):
                    break
                if any(cell in (_mode(value), anchor_colour) for cell in vector):
                    break
                vectors.append(vector)
            return {"direction": direction, "span": span, "vectors": vectors, "limit": r0}
        if direction == "down":
            first = r1 + 1
            if first >= height:
                return None
            candidates = [(c, value[first][c]) for c in range(c0, c1 + 1) if value[first][c] not in (_mode(value), anchor_colour)]
            if not candidates:
                return None
            columns = [c for c, _ in candidates]
            if columns != list(range(min(columns), max(columns) + 1)):
                return None
            span = tuple(range(min(columns), max(columns) + 1))
            vectors = []
            for r in range(first, height):
                vector = tuple(value[r][c] for c in span)
                if all(cell == _mode(value) for cell in vector):
                    break
                if any(cell in (_mode(value), anchor_colour) for cell in vector):
                    break
                vectors.append(vector)
            return {"direction": direction, "span": span, "vectors": vectors, "limit": r1}
        if direction == "left":
            first = c0 - 1
            if first < 0:
                return None
            candidates = [(r, value[r][first]) for r in range(r0, r1 + 1) if value[r][first] not in (_mode(value), anchor_colour)]
            if not candidates:
                return None
            rows = [r for r, _ in candidates]
            if rows != list(range(min(rows), max(rows) + 1)):
                return None
            span = tuple(range(min(rows), max(rows) + 1))
            vectors = []
            for c in range(first, -1, -1):
                vector = tuple(value[r][c] for r in span)
                if all(cell == _mode(value) for cell in vector):
                    break
                if any(cell in (_mode(value), anchor_colour) for cell in vector):
                    break
                vectors.append(vector)
            return {"direction": direction, "span": span, "vectors": vectors, "limit": c0}
        if direction == "right":
            first = c1 + 1
            if first >= width:
                return None
            candidates = [(r, value[r][first]) for r in range(r0, r1 + 1) if value[r][first] not in (_mode(value), anchor_colour)]
            if not candidates:
                return None
            rows = [r for r, _ in candidates]
            if rows != list(range(min(rows), max(rows) + 1)):
                return None
            span = tuple(range(min(rows), max(rows) + 1))
            vectors = []
            for c in range(first, width):
                vector = tuple(value[r][c] for r in span)
                if all(cell == _mode(value) for cell in vector):
                    break
                if any(cell in (_mode(value), anchor_colour) for cell in vector):
                    break
                vectors.append(vector)
            return {"direction": direction, "span": span, "vectors": vectors, "limit": c1}
        return None

    def _period(self, rays):
        longest = max(rays, key=lambda ray: len(ray["vectors"]))
        vectors = longest["vectors"]
        if len(vectors) < 2:
            return 1
        best = None
        for period in range(1, min(self.maximum_period, len(vectors)) + 1):
            template = vectors[:period]
            mismatches = sum(vector != template[index % period] for index, vector in enumerate(vectors))
            score = (mismatches, period)
            if best is None or score < best[0]:
                best = (score, period)
        period = best[1]
        mismatches = best[0][0]
        if mismatches > max(1, len(vectors) // 4):
            raise Inapplicable("no stable global period")
        return period

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _mode(value)
        components = [component for component in _components(value, self.anchor_colour) if len(component) >= 3]
        if len(components) < 2:
            raise Inapplicable("at least two compact anchor components required")
        rays = []
        for component in components:
            candidates = [
                self._ray_from_component(value, component, self.anchor_colour, direction)
                for direction in ("up", "down", "left", "right")
            ]
            candidates = [candidate for candidate in candidates if candidate and candidate["vectors"]]
            if len(candidates) != 1:
                raise Inapplicable("each anchor must expose exactly one ray seed")
            candidate = candidates[0]
            candidate["component"] = component
            rays.append(candidate)
        reference_index = max(range(len(rays)), key=lambda index: len(rays[index]["vectors"]))
        if sum(len(ray["vectors"]) == len(rays[reference_index]["vectors"]) for ray in rays) != 1:
            raise Inapplicable("one unique longest reference ray required")
        period = self._period(rays)
        output = _array(value)
        height, width = _shape(value)
        for index, ray in enumerate(rays):
            # The longest ray is the demonstrated reference sequence.  It
            # teaches the shared period but retains ownership of its observed
            # cells, including any terminal irregularity.
            if index == reference_index:
                continue
            vectors = ray["vectors"]
            if len(vectors) < period:
                raise Inapplicable("ray seed shorter than the global period")
            template = vectors[:period]
            direction = ray["direction"]
            span = ray["span"]
            if direction == "up":
                start = ray["limit"] - 1
                for step, r in enumerate(range(start, -1, -1)):
                    vector = template[step % period]
                    for c, colour in zip(span, vector):
                        if output[r][c] != self.anchor_colour:
                            output[r][c] = colour
            elif direction == "down":
                start = ray["limit"] + 1
                for step, r in enumerate(range(start, height)):
                    vector = template[step % period]
                    for c, colour in zip(span, vector):
                        if output[r][c] != self.anchor_colour:
                            output[r][c] = colour
            elif direction == "left":
                start = ray["limit"] - 1
                for step, c in enumerate(range(start, -1, -1)):
                    vector = template[step % period]
                    for r, colour in zip(span, vector):
                        if output[r][c] != self.anchor_colour:
                            output[r][c] = colour
            else:
                start = ray["limit"] + 1
                for step, c in enumerate(range(start, width)):
                    vector = template[step % period]
                    for r, colour in zip(span, vector):
                        if output[r][c] != self.anchor_colour:
                            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="multiple compact anchors, each with one outward periodic ray seed",
            relation_chain=(
                "infer the shared period from the longest anchor ray",
                "continue each local phase away from its anchor to the boundary",
            ),
            parameters={
                "anchor_colour": self.anchor_colour,
                "maximum_period": self.maximum_period,
                "direction": "away_from_anchor",
                "termination": "canvas_boundary",
                "collision_policy": "periodic_ray_overwrites_non_anchor_cells",
            },
            corollary="Complete and phase-correct every anchored periodic ray without changing anchor cells.",
            notions=["anchor", "axis seed", "period", "phase", "boundary termination", "collision ownership"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: rectilinear relation materialisation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class IntersectionNeighbourhoodProgram:
    fill_colour: int

    kind = "axis_intersection_neighbourhood"
    operator = "rectilinear_relation_materialisation"
    node_vocabulary = "rectilinear_axis_region_nodes"
    edge_vocabulary = "incidence_occlusion_enclosure_edges"

    @property
    def schema_key(self):
        return self.kind, self.fill_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        height, width = _shape(value)
        background = _mode(value)
        if self.fill_colour in _palette(value):
            raise Inapplicable("neighbourhood colour must be new")
        colours = _palette(value) - {background}
        if len(colours) != 2:
            raise Inapplicable("two source axis colours required")

        horizontal = []
        vertical = []
        for r in range(height):
            cells = [value[r][c] for c in range(width) if value[r][c] != background]
            if len(cells) == width and len(set(cells)) <= 2:
                horizontal.append(r)
        for c in range(width):
            cells = [value[r][c] for r in range(height) if value[r][c] != background]
            if len(cells) == height and len(set(cells)) <= 2:
                vertical.append(c)
        if len(horizontal) != 1 or len(vertical) != 1:
            raise Inapplicable("one full horizontal and one full vertical axis required")
        row, column = horizontal[0], vertical[0]
        if not (1 <= row < height - 1 and 1 <= column < width - 1):
            raise Inapplicable("intersection must admit a one-cell neighbourhood")
        output = _array(value)
        centre = value[row][column]
        for r in range(row - 1, row + 2):
            for c in range(column - 1, column + 2):
                output[r][c] = self.fill_colour
        output[row][column] = centre
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one full horizontal axis and one full vertical axis",
            relation_chain=(
                "derive their unique Cartesian incidence node",
                "materialise its radius-one neighbourhood while preserving the centre role",
            ),
            parameters={"fill_colour": self.fill_colour, "radius": 1},
            corollary="Mark the eight neighbouring cells of the axis intersection.",
            notions=["axis node", "Cartesian incidence", "neighbourhood", "centre preservation"],
        )


@dataclass(frozen=True)
class OccludedRectangleCompletionProgram:
    kind = "occluded_rectangle_continuity_completion"
    operator = "rectilinear_relation_materialisation"
    node_vocabulary = "rectilinear_axis_region_nodes"
    edge_vocabulary = "incidence_occlusion_enclosure_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        height, width = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if len(colours) < 2:
            raise Inapplicable("at least two overlapping colours required")
        candidates = []
        bboxes = {}
        for colour in colours:
            cells = [(r, c) for r in range(height) for c in range(width) if value[r][c] == colour]
            if not cells:
                continue
            r0, r1, c0, c1 = _bbox(cells)
            bboxes[colour] = (r0, r1, c0, c1)
            intruders = []
            background_holes = []
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    cell = value[r][c]
                    if cell == background:
                        background_holes.append((r, c))
                    elif cell != colour:
                        intruders.append((r, c))
            if intruders and not background_holes:
                candidates.append((colour, tuple(intruders), (r0, r1, c0, c1)))
        # A one-cell-wide straight path can also be occluded.  Recover only
        # missing positions that are occupied by another foreground colour;
        # background gaps are not guessed.
        line_candidates = []
        for colour in colours:
            cells = [(r, c) for r in range(height) for c in range(width) if value[r][c] == colour]
            if len(cells) < 3:
                continue
            for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
                # All observed cells must share one invariant orthogonal to
                # the proposed direction.
                if dr == 0:
                    invariant = {r for r, _ in cells}
                    ordered = sorted(c for _, c in cells)
                elif dc == 0:
                    invariant = {c for _, c in cells}
                    ordered = sorted(r for r, _ in cells)
                elif dc == 1:
                    invariant = {r - c for r, c in cells}
                    ordered = sorted(r for r, _ in cells)
                else:
                    invariant = {r + c for r, c in cells}
                    ordered = sorted(r for r, _ in cells)
                if len(invariant) != 1 or len(set(ordered)) != len(cells):
                    continue
                start, end = min(ordered), max(ordered)
                missing = []
                for coordinate in range(start, end + 1):
                    if dr == 0:
                        r = next(iter(invariant)); c = coordinate
                    elif dc == 0:
                        r = coordinate; c = next(iter(invariant))
                    elif dc == 1:
                        r = coordinate; c = coordinate - next(iter(invariant))
                    else:
                        r = coordinate; c = next(iter(invariant)) - coordinate
                    if not (0 <= r < height and 0 <= c < width):
                        missing = []
                        break
                    if value[r][c] == background:
                        missing = []
                        break
                    if value[r][c] != colour:
                        missing.append((r, c))
                if missing:
                    line_candidates.append((colour, tuple(missing), (dr, dc)))
                    break

        if not candidates and not line_candidates:
            raise Inapplicable("no fully occluded rectangle or line")

        claims = {}
        for colour, intruders, bbox in candidates:
            r0, r1, c0, c1 = bbox
            # The inferred rectangle must be stripe-like or have a clear axis bias.
            if (r1 - r0 + 1) == 1 or (c1 - c0 + 1) == 1:
                pass
            elif min(r1 - r0 + 1, c1 - c0 + 1) > max(4, max(r1 - r0 + 1, c1 - c0 + 1) - 1):
                raise Inapplicable("occluded region lacks an axis-aligned rectangle role")
            for position in intruders:
                if position in claims and claims[position] != colour:
                    raise Inapplicable("competing occlusion ownership")
                claims[position] = colour
        for colour, intruders, _direction in line_candidates:
            for position in intruders:
                if position in claims and claims[position] != colour:
                    raise Inapplicable("competing occlusion ownership")
                claims[position] = colour
        output = _array(value)
        for (r, c), colour in claims.items():
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="overlapping axis-aligned monochrome rectangles or stripes",
            relation_chain=(
                "infer each colour's complete bounding rectangle",
                "restore cells occupied by an occluding foreground rectangle",
            ),
            parameters={"ownership": "interrupted_rectangle", "background_holes_allowed": False},
            corollary="Complete every uniquely interrupted rectangle across its overlap region.",
            notions=["rectangle node", "occlusion edge", "continuity", "ownership"],
        )


@dataclass(frozen=True)
class LargestEmptyRectangleInteriorProgram:
    empty_colour: int
    fill_colour: int

    kind = "largest_empty_rectangle_interior"
    operator = "rectilinear_relation_materialisation"
    node_vocabulary = "rectilinear_axis_region_nodes"
    edge_vocabulary = "incidence_occlusion_enclosure_edges"

    @property
    def schema_key(self):
        return self.kind, self.empty_colour, self.fill_colour

    @staticmethod
    def _largest_rectangles(value: Grid, empty_colour: int):
        value = grid(value)
        height, width = _shape(value)
        best_area = 0
        best = []
        active = [True] * width
        for r0 in range(height):
            active = [True] * width
            for r1 in range(r0, height):
                for c in range(width):
                    active[c] = active[c] and value[r1][c] == empty_colour
                c = 0
                while c < width:
                    if not active[c]:
                        c += 1
                        continue
                    start = c
                    while c < width and active[c]:
                        c += 1
                    end = c - 1
                    area = (r1 - r0 + 1) * (end - start + 1)
                    if area > best_area:
                        best_area = area
                        best = [(r0, r1, start, end)]
                    elif area == best_area:
                        best.append((r0, r1, start, end))
        # Deduplicate rectangles produced by different row starts/runs.
        return best_area, sorted(set(best))

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if self.fill_colour in _palette(value):
            raise Inapplicable("interior colour must be new")
        area, rectangles = self._largest_rectangles(value, self.empty_colour)
        rectangles = [rect for rect in rectangles if rect[1] - rect[0] + 1 >= 3 and rect[3] - rect[2] + 1 >= 3]
        if len(rectangles) != 1:
            raise Inapplicable("one unique largest empty rectangle required")
        r0, r1, c0, c1 = rectangles[0]
        output = _array(value)
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                output[r][c] = self.fill_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a noisy field containing one unique largest empty rectangle",
            relation_chain=(
                "derive the maximum empty axis-aligned rectangle",
                "materialise only its strict interior",
            ),
            parameters={"empty_colour": self.empty_colour, "fill_colour": self.fill_colour, "border_width": 1},
            corollary="Fill the strict interior of the unique largest empty rectangle.",
            notions=["empty-region node", "maximum rectangle", "enclosure edge", "strict interior"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and proof obligations.
# ---------------------------------------------------------------------------


def _fit_orientation_side(pairs, cls):
    output = []
    for orientation, side in product(("horizontal", "vertical"), ("start", "end")):
        programme = cls(orientation, side)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_boundary_motif(pairs):
    output = []
    for orientation, boundary in product(("horizontal", "vertical"), ("start", "end")):
        programme = BoundaryMotifTilingProgram(orientation, boundary)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_intersection(pairs):
    try:
        programme = IntersectionNeighbourhoodProgram(_single_new_colour(pairs))
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_occlusion(pairs):
    programme = OccludedRectangleCompletionProgram()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_largest_empty_rectangle(pairs):
    try:
        fill_colour = _single_new_colour(pairs)
    except Inapplicable:
        return []
    empty_roles = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        roles = {
            source[r][c]
            for r in range(len(source))
            for c in range(len(source[0]))
            if source[r][c] != target[r][c]
        }
        empty_roles = roles if empty_roles is None else empty_roles & roles
    output = []
    for empty_colour in sorted(empty_roles or ()):
        programme = LargestEmptyRectangleInteriorProgram(empty_colour, fill_colour)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_anchored_periodic(pairs):
    palettes = [set(_palette(source)) for source, _ in pairs]
    candidate_colours = set.intersection(*palettes) if palettes else set()
    output = []
    for colour in sorted(candidate_colours):
        # Fast gate: the semantic anchor must form multiple nontrivial components.
        try:
            if not all(len([component for component in _components(source, colour) if len(component) >= 3]) >= 2 for source, _ in pairs):
                continue
            programme = AnchoredPeriodicContinuationProgram(colour)
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "reference_mapped_axis_continuation": lambda pairs: _fit_orientation_side(pairs, ReferenceMappedAxisContinuationProgram),
    "repeated_prefix_axis_tiling": lambda pairs: _fit_orientation_side(pairs, RepeatedPrefixTilingProgram),
    "boundary_motif_axis_tiling": _fit_boundary_motif,
    "anchored_periodic_ray_continuation": _fit_anchored_periodic,
    "axis_intersection_neighbourhood": _fit_intersection,
    "occluded_rectangle_continuity_completion": _fit_occlusion,
    "largest_empty_rectangle_interior": _fit_largest_empty_rectangle,
}


def fit_primitive_anti_unified_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        colours = sorted(_palette(source))
        passed = False
        tested = 0
        for r in range(len(source)):
            for c in range(len(source[0])):
                replacements = [colour for colour in colours if colour != source[r][c]]
                if not replacements:
                    replacements = [(source[r][c] + 1) % 10]
                for replacement in replacements[:2]:
                    tested += 1
                    work = _array(source)
                    work[r][c] = replacement
                    try:
                        changed = programme.predict(grid(work)) != original
                    except Inapplicable:
                        changed = True
                    if changed:
                        passed = True
                        break
                if passed:
                    break
            if passed:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "anti_unified_node_or_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_primitive_anti_unification_relation_search(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_primitive_anti_unified_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "primitive_anti_unification": True,
            "bounded_two_step_relation_chain": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_primitive_anti_unified_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_primitive_anti_unified_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_primitive_anti_unification_relation_search(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
