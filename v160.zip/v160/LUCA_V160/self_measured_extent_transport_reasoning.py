"""LUCA V158: self-measured extent transport.

This family anti-unifies shape-preserving translations in which each payload
component supplies its own movement distance:

* components translate by their bounding-box extent along the movement axis;
* components adjacent to a full boundary rail translate away from that rail by
  their own cell count.

The implementation is task-ID blind and target blind. Background, component
colours, component geometry, direction, measurement policy, rail side, and test
placements are inferred from demonstrations or the current input. No absolute
training coordinates or official test targets are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_self_measured_extent_transport"
LANGUAGE = "spinoza_self_measured_extent_transport_v158"
SCHEMA_VERSION = 1
OPERATOR = "self_measured_extent_transport_materialisation"
NODE_VOCABULARY = "payload_components_and_boundary_rail_nodes"
EDGE_VOCABULARY = "axis_extent_area_and_cardinal_transport_edges"


DIRECTIONS = {
    "north": (-1, 0),
    "south": (1, 0),
    "west": (0, -1),
    "east": (0, 1),
}


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "self_measured_transport_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "payload_shape_preserved": True,
            "payload_colour_preserved": True,
            "self_measured_displacement": True,
            "shared_transport_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _background(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    most = counts.most_common()
    if len(most) > 1 and most[0][1] == most[1][1]:
        raise Inapplicable("background frequency is tied")
    return most[0][0]


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, background: int, connectivity: int = 4):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] != background
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        colour = value[seed[0]][seed[1]]
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        neighbours = (
            ((-1, 0), (1, 0), (0, -1), (0, 1))
            if connectivity == 4
            else tuple(
                (dr, dc)
                for dr in (-1, 0, 1)
                for dc in (-1, 0, 1)
                if (dr, dc) != (0, 0)
            )
        )
        while stack:
            r, c = stack.pop()
            for dr, dc in neighbours:
                point = (r + dr, c + dc)
                if point in remaining and value[point[0]][point[1]] == colour:
                    remaining.remove(point)
                    component.add(point)
                    stack.append(point)
        output.append((colour, frozenset(component)))
    output.sort(key=lambda item: (_bbox(item[1]), item[0], len(item[1])))
    return tuple(output)


def _translate(cells, dr, dc, amount):
    return frozenset((r + dr * amount, c + dc * amount) for r, c in cells)


def _inside(cells, h, w):
    return all(0 <= r < h and 0 <= c < w for r, c in cells)


def _boundary_rail(component, h, w):
    colour, cells = component
    r0, c0, r1, c1 = _bbox(cells)
    if len(cells) == w and r0 == r1 == 0 and cells == frozenset((0, c) for c in range(w)):
        return "top"
    if len(cells) == w and r0 == r1 == h - 1 and cells == frozenset((h - 1, c) for c in range(w)):
        return "bottom"
    if len(cells) == h and c0 == c1 == 0 and cells == frozenset((r, 0) for r in range(h)):
        return "left"
    if len(cells) == h and c0 == c1 == w - 1 and cells == frozenset((r, w - 1) for r in range(h)):
        return "right"
    return None


def _same_shape(source, target):
    if len(source) != len(target) or len(source[0]) != len(target[0]):
        return False
    return Counter(cell for row in source for cell in row) == Counter(cell for row in target for cell in row)


@dataclass(frozen=True)
class AxisExtentComponentTransportProgram:
    background: int
    direction: str

    kind = "axis_extent_component_transport"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _background(value) != self.background:
            raise Inapplicable("background role changed")
        h, w = _shape(value)
        components = _components(value, self.background, connectivity=8)
        if not components:
            raise Inapplicable("payload components are required")
        if any(_boundary_rail(component, h, w) is not None for component in components):
            raise Inapplicable("axis-extent transport does not move full boundary rails")
        dr, dc = DIRECTIONS[self.direction]
        placements = []
        target_union = set()
        for colour, cells in components:
            r0, c0, r1, c1 = _bbox(cells)
            amount = (r1 - r0 + 1) if dr else (c1 - c0 + 1)
            target = _translate(cells, dr, dc, amount)
            if not _inside(target, h, w):
                raise Inapplicable("self-extent transport leaves the canvas")
            if target_union.intersection(target):
                raise Inapplicable("translated payload components collide")
            target_union.update(target)
            placements.append((colour, cells, target, amount))
        return tuple(placements)

    def predict(self, value: Grid):
        value = grid(value)
        placements = self._scene(value)
        work = _array(value)
        for _, cells, _, _ in placements:
            for r, c in cells:
                work[r][c] = self.background
        for colour, _, target, _ in placements:
            for r, c in target:
                if work[r][c] != self.background:
                    raise Inapplicable("translated payload collides with protected material")
                work[r][c] = colour
        prediction = grid(work)
        if prediction == value:
            raise Inapplicable("transport has no consequence")
        return prediction

    def describe(self, pairs):
        axis = "row" if self.direction in {"north", "south"} else "column"
        return _law(
            self,
            scene="one or more movable monochrome payload components on a uniform background",
            relation_chain=(
                "extract every non-background connected payload component",
                f"measure each payload's bounding-box extent along the {axis} axis",
                f"translate each payload {self.direction} by its own measured extent",
                "erase sources and materialise collision-free shape-preserving targets",
            ),
            parameters={
                "background": self.background,
                "direction": self.direction,
                "distance_measure": "bounding_box_extent_along_motion_axis",
            },
            corollary="each payload's own geometry determines its translation distance",
            notions=(
                "component colour and cell shape are preserved",
                "all payloads share one learned cardinal direction",
                "out-of-bounds or colliding consequences abstain",
            ),
        )


@dataclass(frozen=True)
class BoundaryRailAreaTransportProgram:
    background: int
    rail_side: str

    kind = "boundary_rail_area_transport"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    def _scene(self, value: Grid):
        value = grid(value)
        if _background(value) != self.background:
            raise Inapplicable("background role changed")
        h, w = _shape(value)
        components = _components(value, self.background)
        rails = [(colour, cells) for colour, cells in components if _boundary_rail((colour, cells), h, w) == self.rail_side]
        any_rails = [(colour, cells, _boundary_rail((colour, cells), h, w)) for colour, cells in components if _boundary_rail((colour, cells), h, w) is not None]
        if len(rails) != 1 or len(any_rails) != 1:
            raise Inapplicable("exactly one full boundary rail is required")
        rail_colour, rail_cells = rails[0]
        payloads = [(colour, cells) for colour, cells in components if cells != rail_cells]
        if not payloads:
            raise Inapplicable("payload components are required")
        if self.rail_side == "bottom":
            direction = (-1, 0)
            adjacent = lambda cells: max(r for r, _ in cells) == h - 2
        elif self.rail_side == "top":
            direction = (1, 0)
            adjacent = lambda cells: min(r for r, _ in cells) == 1
        elif self.rail_side == "left":
            direction = (0, 1)
            adjacent = lambda cells: min(c for _, c in cells) == 1
        elif self.rail_side == "right":
            direction = (0, -1)
            adjacent = lambda cells: max(c for _, c in cells) == w - 2
        else:
            raise Inapplicable("unknown rail side")
        if not all(adjacent(cells) for _, cells in payloads):
            raise Inapplicable("every payload must contact the rail-adjacent coordinate")
        placements = []
        target_union = set()
        dr, dc = direction
        for colour, cells in payloads:
            amount = len(cells)
            target = _translate(cells, dr, dc, amount)
            if not _inside(target, h, w):
                raise Inapplicable("area transport leaves the canvas")
            if target.intersection(rail_cells) or target_union.intersection(target):
                raise Inapplicable("area-translated payloads collide")
            target_union.update(target)
            placements.append((colour, cells, target, amount))
        return (rail_colour, rail_cells), tuple(placements), direction

    def predict(self, value: Grid):
        value = grid(value)
        (_, rail_cells), placements, _ = self._scene(value)
        work = _array(value)
        for _, cells, _, _ in placements:
            for r, c in cells:
                work[r][c] = self.background
        for colour, _, target, _ in placements:
            for r, c in target:
                if (r, c) in rail_cells or work[r][c] != self.background:
                    raise Inapplicable("area transport collides with protected material")
                work[r][c] = colour
        prediction = grid(work)
        if prediction == value:
            raise Inapplicable("transport has no consequence")
        return prediction

    def describe(self, pairs):
        away = {"bottom": "north", "top": "south", "left": "east", "right": "west"}[self.rail_side]
        return _law(
            self,
            scene="payload components immediately adjacent to one complete boundary rail",
            relation_chain=(
                "extract the unique full-axis boundary rail and adjacent payload components",
                "measure every payload by its own occupied-cell count",
                f"translate each payload {away}, away from the {self.rail_side} rail, by that count",
                "preserve the rail and materialise collision-free shape-preserving targets",
            ),
            parameters={
                "background": self.background,
                "rail_side": self.rail_side,
                "distance_measure": "component_cell_count",
                "direction_policy": "away_from_boundary_rail",
            },
            corollary="the boundary rail supplies direction while each payload's area supplies distance",
            notions=(
                "rail colour is a structural role and need not be predeclared",
                "payload colour and geometry are preserved",
                "missing rails, non-adjacent payloads, collisions or overflow abstain",
            ),
        )


def _common_background(pairs):
    backgrounds = []
    for source, target in pairs:
        if not _same_shape(source, target):
            raise Inapplicable("transport must preserve canvas shape and colour counts")
        source_background = _background(source)
        target_background = _background(target)
        if source_background != target_background:
            raise Inapplicable("background role changes across the transformation")
        backgrounds.append(source_background)
    if len(set(backgrounds)) != 1:
        raise Inapplicable("demonstrations use inconsistent background roles")
    return backgrounds[0]


def _fit_axis_extent(pairs):
    try:
        background = _common_background(pairs)
    except Inapplicable:
        return ()
    output = []
    for direction in DIRECTIONS:
        programme = AxisExtentComponentTransportProgram(background, direction)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return tuple(output)


def _fit_boundary_rail_area(pairs):
    try:
        background = _common_background(pairs)
    except Inapplicable:
        return ()
    output = []
    for rail_side in ("top", "bottom", "left", "right"):
        programme = BoundaryRailAreaTransportProgram(background, rail_side)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return tuple(output)


def fit_self_measured_extent_transport_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return ()
    allowed = set(allowed_kinds or ()) or None
    programmes = []
    for fitter in (_fit_axis_extent, _fit_boundary_rail_area):
        try:
            programmes.extend(fitter(pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            pass
    deduplicated = []
    seen = set()
    for programme in programmes:
        if allowed is not None and programme.kind not in allowed:
            continue
        key = (type(programme).__name__, repr(programme))
        if key in seen:
            continue
        seen.add(key)
        deduplicated.append(programme)
    deduplicated.sort(key=lambda programme: (programme.kind, repr(programme)))
    return tuple(deduplicated)


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, AxisExtentComponentTransportProgram):
                placements = programme._scene(source)
                _, cells, _, _ = placements[0]
                r, c = sorted(cells)[0]
                candidates.append((r, c, programme.background, "payload_geometry_node"))
            elif isinstance(programme, BoundaryRailAreaTransportProgram):
                (_, rail_cells), _, _ = programme._scene(source)
                r, c = sorted(rail_cells)[len(rail_cells) // 2]
                candidates.append((r, c, programme.background, "boundary_rail_node"))
        except (Inapplicable, StopIteration, IndexError):
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {
                    "cell": [r, c],
                    "from": int(previous),
                    "to": int(replacement),
                    "role": role,
                }
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_self_measured_extent_transport(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_self_measured_extent_transport_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "payload_shape_preserved": True,
            "payload_colour_preserved": True,
            "self_measured_displacement": True,
            "shared_transport_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_self_measured_extent_transport_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_self_measured_extent_transport_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_self_measured_extent_transport(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
