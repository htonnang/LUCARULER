"""LUCA V116: transformational graph propagation.

This proof-carrying research family extends V115 from direct local pattern copy
to four relation-bound propagation programs:

* ``lattice_axis_connection`` completes orthogonal paths between same-colour
  nodes in a separator-defined lattice;
* ``anchor_stencil_propagation`` learns a local stencil around one prototype
  anchor and applies it to every homologous anchor occurrence;
* ``contained_exemplar_shape_colour_transfer`` follows a containment -> shape
  homology -> recolour relation chain from closed frames to free objects;
* ``instructional_motif_completion`` learns a translation-invariant motif from
  one complete instructional instance and completes partial instances.

Programs use no task identifiers, stored demonstration coordinates, or test
targets. Exact demonstration fit is necessary but not sufficient: accepted
predictions must survive leave-one-demonstration-out refitting, schema-specific
counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_transformational_graph_propagation"
LANGUAGE = "spinoza_transformational_graph_language_v1"
SCHEMA_VERSION = "transformational_graph_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _rot180(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(reversed(row)) for row in reversed(a))


@dataclass(frozen=True)
class _Component:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    mask: tuple[tuple[int, int], ...]
    pattern: tuple[tuple[int, int, int], ...]
    palette: tuple[int, ...]

    @property
    def height(self) -> int:
        return self.box[2] - self.box[0] + 1

    @property
    def width(self) -> int:
        return self.box[3] - self.box[1] + 1


def _components(value: Grid, background: int, connectivity: int = 4) -> tuple[_Component, ...]:
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    a = grid(value)
    h, w = _shape(a)
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions.extend([(1, 1), (1, -1), (-1, 1), (-1, -1)])
    seen: set[tuple[int, int]] = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or a[r][c] == background:
                continue
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or a[nr][nc] == background:
                        continue
                    seen.add((nr, nc))
                    queue.append((nr, nc))
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            mask = tuple(sorted((rr - r0, cc - c0) for rr, cc in cells))
            pattern = tuple(sorted((rr - r0, cc - c0, a[rr][cc]) for rr, cc in cells))
            palette = tuple(sorted({a[rr][cc] for rr, cc in cells}))
            result.append(_Component(tuple(sorted(cells)), (r0, c0, r1, c1), mask, pattern, palette))
    return tuple(result)


def _normalise(points: Iterable[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    points = tuple(points)
    if not points:
        return ()
    r0 = min(r for r, _ in points)
    c0 = min(c for _, c in points)
    return tuple(sorted((r - r0, c - c0) for r, c in points))


def _d4_masks(component: _Component) -> tuple[tuple[tuple[int, int], ...], ...]:
    h, w = component.height, component.width
    functions = (
        lambda r, c: (r, c),
        lambda r, c: (c, h - 1 - r),
        lambda r, c: (h - 1 - r, w - 1 - c),
        lambda r, c: (w - 1 - c, r),
        lambda r, c: (r, w - 1 - c),
        lambda r, c: (h - 1 - r, c),
        lambda r, c: (c, r),
        lambda r, c: (w - 1 - c, h - 1 - r),
    )
    values = {_normalise(function(r, c) for r, c in component.mask) for function in functions}
    return tuple(sorted(values))


def _canonical_mask(component: _Component) -> tuple[tuple[int, int], ...]:
    return min(_d4_masks(component))


def _strictly_contains(outer: tuple[int, int, int, int], inner: tuple[int, int, int, int]) -> bool:
    r0, c0, r1, c1 = outer
    a0, b0, a1, b1 = inner
    return r0 < a0 and c0 < b0 and a1 < r1 and b1 < c1


def _inside_or_equal(outer: tuple[int, int, int, int], inner: tuple[int, int, int, int]) -> bool:
    r0, c0, r1, c1 = outer
    a0, b0, a1, b1 = inner
    return r0 <= a0 and c0 <= b0 and a1 <= r1 and b1 <= c1


def _is_rectangular_frame(component: _Component) -> bool:
    h, w = component.height, component.width
    if h < 3 or w < 3:
        return False
    perimeter = (
        {(0, c) for c in range(w)}
        | {(h - 1, c) for c in range(w)}
        | {(r, 0) for r in range(h)}
        | {(r, w - 1) for r in range(h)}
    )
    return set(component.mask) == perimeter


# ---------------------------------------------------------------------------
# Shared separator-lattice representation
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _Lattice:
    separator_colour: int
    background: int
    row_bands: tuple[tuple[int, int], ...]
    col_bands: tuple[tuple[int, int], ...]
    tokens: tuple[tuple[int, ...], ...]


def _bands(lines: Iterable[int], extent: int) -> tuple[tuple[int, int], ...]:
    result = []
    previous = -1
    for value in tuple(sorted(lines)) + (extent,):
        if value - previous > 1:
            result.append((previous + 1, value - 1))
        previous = value
    return tuple(result)


def _parse_lattice(value: Grid) -> _Lattice:
    a = grid(value)
    h, w = _shape(a)
    full_rows = [r for r in range(h) if len(set(a[r])) == 1]
    full_cols = [c for c in range(w) if len({a[r][c] for r in range(h)}) == 1]
    rows_by_colour: dict[int, list[int]] = defaultdict(list)
    cols_by_colour: dict[int, list[int]] = defaultdict(list)
    for r in full_rows:
        rows_by_colour[a[r][0]].append(r)
    for c in full_cols:
        cols_by_colour[a[0][c]].append(c)
    candidates = [
        colour for colour, rows in rows_by_colour.items()
        if len(rows) >= 2 and len(cols_by_colour.get(colour, ())) >= 2
    ]
    if len(candidates) != 1:
        raise Inapplicable("grid does not contain one separator lattice")
    separator = candidates[0]
    row_bands = _bands(rows_by_colour[separator], h)
    col_bands = _bands(cols_by_colour[separator], w)
    if len(row_bands) < 2 or len(col_bands) < 2:
        raise Inapplicable("lattice has too few logical cells")
    if len({r1 - r0 + 1 for r0, r1 in row_bands}) != 1:
        raise Inapplicable("lattice row bands are not uniform")
    if len({c1 - c0 + 1 for c0, c1 in col_bands}) != 1:
        raise Inapplicable("lattice column bands are not uniform")
    tokens = []
    for r0, r1 in row_bands:
        row = []
        for c0, c1 in col_bands:
            values = {a[r][c] for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
            if len(values) != 1:
                raise Inapplicable("one logical lattice cell is not uniform")
            row.append(next(iter(values)))
        tokens.append(tuple(row))
    counts = Counter(cell for row in tokens for cell in row)
    if not counts:
        raise Inapplicable("empty logical lattice")
    top = max(counts.values())
    backgrounds = [colour for colour, count in counts.items() if count == top and colour != separator]
    if len(backgrounds) != 1:
        raise Inapplicable("logical lattice background is not uniquely modal")
    return _Lattice(separator, backgrounds[0], row_bands, col_bands, tuple(tokens))


def _render_lattice(source: Grid, lattice: _Lattice, tokens: tuple[tuple[int, ...], ...]) -> Grid:
    output = _array(source)
    for i, (r0, r1) in enumerate(lattice.row_bands):
        for j, (c0, c1) in enumerate(lattice.col_bands):
            colour = tokens[i][j]
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    output[r][c] = colour
    return tuple(tuple(row) for row in output)


def _token_components(tokens: tuple[tuple[int, ...], ...], background: int, connectivity: int):
    if connectivity not in (4, 8):
        raise Inapplicable("token connectivity must be 4 or 8")
    h, w = len(tokens), len(tokens[0])
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions.extend([(1, 1), (1, -1), (-1, 1), (-1, -1)])
    seen = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or tokens[r][c] == background:
                continue
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if 0 <= nr < h and 0 <= nc < w and (nr, nc) not in seen and tokens[nr][nc] != background:
                        seen.add((nr, nc))
                        queue.append((nr, nc))
            result.append(tuple(sorted(cells)))
    return tuple(result)


# ---------------------------------------------------------------------------
# Schema I: connect same-colour lattice nodes along witnessed axes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LatticeAxisConnectionProgram:
    kind: str = "lattice_axis_connection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        lattice = _parse_lattice(value)
        tokens = lattice.tokens
        h, w = len(tokens), len(tokens[0])
        output = [list(row) for row in tokens]
        additions = []
        witnesses = []
        colours = sorted({cell for row in tokens for cell in row} - {lattice.background})
        for colour in colours:
            seeds = {(r, c) for r in range(h) for c in range(w) if tokens[r][c] == colour}
            fill = set(seeds)
            for r in range(h):
                columns = sorted(c for rr, c in seeds if rr == r)
                if len(columns) >= 2:
                    fill.update((r, c) for c in range(columns[0], columns[-1] + 1))
                    witnesses.append((colour, "row", r, columns[0], columns[-1]))
            for c in range(w):
                rows = sorted(r for r, cc in seeds if cc == c)
                if len(rows) >= 2:
                    fill.update((r, c) for r in range(rows[0], rows[-1] + 1))
                    witnesses.append((colour, "column", c, rows[0], rows[-1]))
            for r, c in fill:
                if output[r][c] not in (lattice.background, colour):
                    raise Inapplicable("axis connection would overwrite another colour")
                if output[r][c] == lattice.background:
                    additions.append((r, c, colour))
                output[r][c] = colour
        if not additions:
            raise Inapplicable("lattice axis connection has no effect")
        return lattice, tuple(tuple(row) for row in output), tuple(additions), tuple(witnesses)

    def predict(self, value: Grid) -> Grid:
        lattice, tokens, _, _ = self._analyse(value)
        return _render_lattice(value, lattice, tokens)

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            lattice, _, additions, witnesses = self._analyse(source)
            evidence.append({
                "logical_shape": [len(lattice.tokens), len(lattice.tokens[0])],
                "additions": len(additions),
                "axis_witnesses": len(witnesses),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {"kind": self.kind},
            "definitions": [
                {"name": "SeparatorLattice", "type": "Grid -> LogicalGrid"},
                {"name": "AlignedSameColourNodes", "type": "LogicalGrid -> AxisWitnesses"},
                {"name": "OrthogonalPath", "type": "AxisWitness -> FilledSegment"},
            ],
            "propositions": [
                {"index": 1, "definition": "ParseLattice", "effect": "recover logical cells from separator rows and columns"},
                {"index": 2, "definition": "BindAlignedEndpoints", "effect": "identify same-colour nodes sharing a row or column"},
                {"index": 3, "definition": "CompleteAxisSegments", "effect": "fill every witnessed interval"},
            ],
            "corollary": "same-colour lattice nodes determine their orthogonal connecting paths",
            "common_notions": [{"name": "lattice_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema II: learn one anchor-centred stencil and stamp it at homologous anchors
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AnchorStencilPropagationProgram:
    connectivity: int = 4
    kind: str = "anchor_stencil_propagation"

    @property
    def schema_key(self):
        return (self.kind, self.connectivity)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        lattice = _parse_lattice(value)
        tokens = lattice.tokens
        h, w = len(tokens), len(tokens[0])
        components = _token_components(tokens, lattice.background, self.connectivity)
        component_index = {cell: index for index, component in enumerate(components) for cell in component}
        candidates = []
        colours = sorted({cell for row in tokens for cell in row} - {lattice.background})
        for anchor_colour in colours:
            positions = [(r, c) for r in range(h) for c in range(w) if tokens[r][c] == anchor_colour]
            if len(positions) < 2:
                continue
            prototype_positions = [p for p in positions if len(components[component_index[p]]) > 1]
            singleton_positions = [p for p in positions if len(components[component_index[p]]) == 1]
            if len(prototype_positions) != 1 or len(singleton_positions) != len(positions) - 1:
                continue
            anchor = prototype_positions[0]
            prototype = components[component_index[anchor]]
            if sum(1 for p in prototype if tokens[p[0]][p[1]] == anchor_colour) != 1:
                continue
            other_cells = {
                (r, c) for r in range(h) for c in range(w)
                if tokens[r][c] not in (lattice.background, anchor_colour)
            }
            if not other_cells or other_cells != set(prototype) - {anchor}:
                continue
            stencil = tuple(sorted(
                (r - anchor[0], c - anchor[1], tokens[r][c]) for r, c in prototype
            ))
            candidates.append((anchor_colour, anchor, tuple(singleton_positions), prototype, stencil))
        if len(candidates) != 1:
            raise Inapplicable("requires one anchor-centred instructional stencil")
        anchor_colour, anchor, recipients, prototype, stencil = candidates[0]
        output = [list(row) for row in tokens]
        additions = []
        for rr, cc in recipients:
            for dr, dc, colour in stencil:
                r, c = rr + dr, cc + dc
                if not (0 <= r < h and 0 <= c < w):
                    continue
                if dr == 0 and dc == 0:
                    if output[r][c] != anchor_colour:
                        raise Inapplicable("anchor role is not preserved")
                    continue
                if output[r][c] not in (lattice.background, colour):
                    raise Inapplicable("stencil would overwrite unrelated evidence")
                if output[r][c] == lattice.background:
                    additions.append((r, c, colour))
                output[r][c] = colour
        if not additions:
            raise Inapplicable("anchor stencil has no effect")
        return lattice, tuple(tuple(row) for row in output), anchor_colour, anchor, recipients, prototype, stencil, tuple(additions)

    def predict(self, value: Grid) -> Grid:
        lattice, tokens, *_ = self._analyse(value)
        return _render_lattice(value, lattice, tokens)

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            lattice, _, anchor_colour, anchor, recipients, prototype, stencil, additions = self._analyse(source)
            evidence.append({
                "logical_shape": [len(lattice.tokens), len(lattice.tokens[0])],
                "anchor_colour": anchor_colour,
                "prototype_anchor": list(anchor),
                "recipient_anchors": [list(p) for p in recipients],
                "stencil_cells": len(stencil),
                "additions": len(additions),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {"kind": self.kind, "connectivity": self.connectivity},
            "definitions": [
                {"name": "PrototypeAnchor", "type": "LogicalGrid -> Anchor"},
                {"name": "LocalStencil", "type": "AnchorNeighbourhood -> OffsetColourMap"},
                {"name": "HomologousAnchor", "type": "LogicalGrid -> AnchorSet"},
            ],
            "propositions": [
                {"index": 1, "definition": "BindPrototype", "effect": "select the only anchor embedded in a multicolour motif"},
                {"index": 2, "definition": "ExtractStencil", "effect": "express the motif as anchor-relative offsets"},
                {"index": 3, "definition": "PropagateStencil", "effect": "stamp the stencil at every isolated homologous anchor"},
            ],
            "corollary": "one anchor-centred motif determines the neighbourhood of every homologous anchor",
            "common_notions": [{"name": "stencil_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema III: closed frames contain shape-to-colour instructions
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ContainedExemplarShapeColourProgram:
    recipient_colour: int
    frame_colour: int
    connectivity: int = 4
    shape_mode: str = "exact"
    kind: str = "contained_exemplar_shape_colour_transfer"

    @property
    def schema_key(self):
        return (self.kind, self.recipient_colour, self.frame_colour, self.connectivity, self.shape_mode)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (0 if self.shape_mode == "exact" else 1, self.connectivity, self.recipient_colour, self.frame_colour)

    def _signature(self, component: _Component):
        if self.shape_mode == "exact":
            return component.mask
        if self.shape_mode == "dihedral":
            return _canonical_mask(component)
        raise Inapplicable("unknown shape correspondence mode")

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        if len({background, self.recipient_colour, self.frame_colour}) != 3:
            raise Inapplicable("background, frame, and recipient roles must be distinct")
        components = _components(a, background, self.connectivity)
        frames = [
            component for component in components
            if component.palette == (self.frame_colour,) and _is_rectangular_frame(component)
        ]
        if not frames:
            raise Inapplicable("no closed instructional frame")
        exemplars = []
        for frame in frames:
            inside = [
                component for component in components
                if component is not frame and _strictly_contains(frame.box, component.box)
            ]
            if len(inside) != 1:
                raise Inapplicable("each closed frame must contain one exemplar")
            exemplar = inside[0]
            if len(exemplar.palette) != 1 or exemplar.palette == (self.recipient_colour,):
                raise Inapplicable("framed exemplar must be monochrome and non-recipient")
            exemplars.append(exemplar)
        mapping = {}
        for exemplar in exemplars:
            signature = self._signature(exemplar)
            colour = exemplar.palette[0]
            if signature in mapping and mapping[signature] != colour:
                raise Inapplicable("same exemplar shape maps to conflicting colours")
            mapping[signature] = colour
        recipients = []
        for component in components:
            if component.palette != (self.recipient_colour,):
                continue
            if any(_inside_or_equal(frame.box, component.box) for frame in frames):
                continue
            signature = self._signature(component)
            if signature in mapping:
                recipients.append((component, mapping[signature]))
        if not recipients:
            raise Inapplicable("no free recipient matches a framed exemplar")
        return background, components, tuple(frames), tuple(exemplars), tuple(recipients), mapping

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        _, _, _, _, recipients, _ = self._analyse(a)
        output = _array(a)
        for component, colour in recipients:
            for r, c in component.cells:
                output[r][c] = colour
        predicted = tuple(tuple(row) for row in output)
        if predicted == a:
            raise Inapplicable("contained exemplar transfer has no effect")
        return predicted

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, components, frames, exemplars, recipients, mapping = self._analyse(source)
            evidence.append({
                "nodes": len(components),
                "closed_frames": len(frames),
                "exemplars": len(exemplars),
                "matched_recipients": len(recipients),
                "shape_colour_rules": len(mapping),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "recipient_colour": self.recipient_colour,
                "frame_colour": self.frame_colour,
                "connectivity": self.connectivity,
                "shape_mode": self.shape_mode,
            },
            "definitions": [
                {"name": "ClosedFrame", "type": "Component -> Boolean"},
                {"name": "ContainedExemplar", "type": "Frame -> ShapeColourInstruction"},
                {"name": "FreeHomologousObject", "type": "Instruction x Component -> Boolean"},
            ],
            "propositions": [
                {"index": 1, "definition": "ContainmentBinding", "effect": "bind one exemplar inside every closed frame"},
                {"index": 2, "definition": "ShapeColourLaw", "effect": "map exemplar support shape to exemplar colour"},
                {"index": 3, "definition": "SelectiveTransfer", "effect": "recolour only free objects with an instructed shape"},
            ],
            "corollary": "closed framed exemplars determine the colours of homologous free objects",
            "common_notions": [{"name": "containment_shape_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema IV: complete partial copies of one instructional motif
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InstructionalMotifCompletionProgram:
    completion_colour: int
    strict_bbox: bool = True
    kind: str = "instructional_motif_completion"

    @property
    def schema_key(self):
        return (self.kind, self.completion_colour, self.strict_bbox)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (0 if self.strict_bbox else 1, self.completion_colour)

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        background = _unique_modal(a)
        completion_cells = [
            (r, c) for r in range(h) for c in range(w)
            if a[r][c] == self.completion_colour
        ]
        if len(completion_cells) < 2:
            raise Inapplicable("completion colour lacks a complete instructional motif")
        r0 = min(r for r, _ in completion_cells)
        r1 = max(r for r, _ in completion_cells)
        c0 = min(c for _, c in completion_cells)
        c1 = max(c for _, c in completion_cells)
        height, width = r1 - r0 + 1, c1 - c0 + 1
        if height > 8 or width > 8:
            raise Inapplicable("instructional motif span is too large")
        pattern = tuple(
            (r - r0, c - c0, a[r][c])
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if a[r][c] != background
        )
        evidence = tuple(item for item in pattern if item[2] != self.completion_colour)
        fill = tuple(item for item in pattern if item[2] == self.completion_colour)
        if len(fill) < 2 or len(evidence) < 2 or len({item[2] for item in evidence}) < 2:
            raise Inapplicable("motif lacks a sufficiently specific visible instruction")
        support = {(r, c) for r, c, _ in pattern}
        additions = set()
        matches = []
        for rr0 in range(h - height + 1):
            for cc0 in range(w - width + 1):
                if not all(a[rr0 + r][cc0 + c] == colour for r, c, colour in evidence):
                    continue
                if not all(
                    a[rr0 + r][cc0 + c] in (background, self.completion_colour)
                    for r, c, _ in fill
                ):
                    continue
                if self.strict_bbox:
                    outside_clear = all(
                        (r, c) in support or a[rr0 + r][cc0 + c] == background
                        for r in range(height) for c in range(width)
                    )
                    if not outside_clear:
                        continue
                missing = {
                    (rr0 + r, cc0 + c)
                    for r, c, _ in fill
                    if a[rr0 + r][cc0 + c] == background
                }
                if missing:
                    additions.update(missing)
                    matches.append((rr0, cc0, len(missing)))
        if not additions:
            raise Inapplicable("no partial instructional motif occurrence")
        return background, (r0, c0, r1, c1), pattern, evidence, fill, tuple(sorted(matches)), tuple(sorted(additions))

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        _, _, _, _, _, _, additions = self._analyse(a)
        output = _array(a)
        for r, c in additions:
            output[r][c] = self.completion_colour
        return tuple(tuple(row) for row in output)

    def describe(self, pairs):
        evidence_rows = []
        for source, _ in pairs:
            _, box, pattern, evidence, fill, matches, additions = self._analyse(source)
            evidence_rows.append({
                "prototype_box": list(box),
                "prototype_cells": len(pattern),
                "visible_instruction_cells": len(evidence),
                "completion_cells": len(fill),
                "partial_matches": len(matches),
                "added_cells": len(additions),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "completion_colour": self.completion_colour,
                "strict_bbox": self.strict_bbox,
                "transform_group": "translation",
            },
            "definitions": [
                {"name": "CompleteInstructionalMotif", "type": "Grid -> LocalPattern"},
                {"name": "VisibleMotifEvidence", "type": "LocalPattern -> RequiredCells"},
                {"name": "MissingCompletionRole", "type": "PatternPlacement -> CellSet"},
            ],
            "propositions": [
                {"index": 1, "definition": "ExtractCompleteMotif", "effect": "bound the prototype by its completion-colour cells"},
                {"index": 2, "definition": "MatchVisibleEvidence", "effect": "find translated occurrences of the non-completion pattern"},
                {"index": 3, "definition": "CompleteMissingRoles", "effect": "write only the absent completion-colour cells"},
            ],
            "corollary": "one complete motif determines the missing cells of every translated partial occurrence",
            "common_notions": [{"name": "motif_completion_evidence", "evidence": evidence_rows}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Fitting and consensus inference
# ---------------------------------------------------------------------------


def _fit_lattice_axis(pairs):
    program = LatticeAxisConnectionProgram()
    try:
        return [program] if all(program.predict(source) == target for source, target in pairs) else []
    except (Inapplicable, ValueError, IndexError, TypeError):
        return []


def _fit_anchor_stencil(pairs):
    result = []
    for connectivity in (4, 8):
        program = AnchorStencilPropagationProgram(connectivity)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                result.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    return result


def _fit_contained_exemplar(pairs):
    common_colours = None
    try:
        for source, _ in pairs:
            colours = _palette(source) - {_unique_modal(source)}
            common_colours = colours if common_colours is None else common_colours & colours
    except (Inapplicable, ValueError, IndexError, TypeError):
        return []
    result = []
    for recipient_colour in sorted(common_colours or ()): 
        for frame_colour in sorted((common_colours or set()) - {recipient_colour}):
            for connectivity in (4, 8):
                for shape_mode in ("exact", "dihedral"):
                    program = ContainedExemplarShapeColourProgram(
                        recipient_colour, frame_colour, connectivity, shape_mode
                    )
                    try:
                        if all(program.predict(source) == target for source, target in pairs):
                            result.append(program)
                    except (Inapplicable, ValueError, IndexError, TypeError):
                        continue
    return result


def _fit_motif_completion(pairs):
    common_colours = None
    try:
        for source, _ in pairs:
            colours = _palette(source) - {_unique_modal(source)}
            common_colours = colours if common_colours is None else common_colours & colours
    except (Inapplicable, ValueError, IndexError, TypeError):
        return []
    result = []
    for colour in sorted(common_colours or ()):
        program = InstructionalMotifCompletionProgram(colour, True)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                result.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    return result


def _role_varies(program, pairs):
    evidence = []
    try:
        for source, _ in pairs:
            if isinstance(program, LatticeAxisConnectionProgram):
                lattice, _, additions, witnesses = program._analyse(source)
                evidence.append((len(lattice.tokens), len(lattice.tokens[0]), additions, witnesses))
            elif isinstance(program, AnchorStencilPropagationProgram):
                _, _, anchor_colour, anchor, recipients, _, stencil, _ = program._analyse(source)
                evidence.append((anchor_colour, anchor, recipients, stencil))
            elif isinstance(program, ContainedExemplarShapeColourProgram):
                _, _, frames, exemplars, recipients, mapping = program._analyse(source)
                evidence.append((tuple(frame.box for frame in frames), tuple(exemplar.mask for exemplar in exemplars), tuple(component.box for component, _ in recipients), tuple(sorted((repr(key), value) for key, value in mapping.items()))))
            elif isinstance(program, InstructionalMotifCompletionProgram):
                _, box, pattern, _, _, matches, _ = program._analyse(source)
                evidence.append((box, pattern, matches))
            else:
                return False
    except (Inapplicable, ValueError, IndexError, TypeError):
        return False
    return len({_serial(item) for item in evidence}) >= 2


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "lattice_axis_connection" in allowed:
        programs.extend(_fit_lattice_axis(pairs))
    if allowed is None or "anchor_stencil_propagation" in allowed:
        programs.extend(_fit_anchor_stencil(pairs))
    if allowed is None or "contained_exemplar_shape_colour_transfer" in allowed:
        programs.extend(_fit_contained_exemplar(pairs))
    if allowed is None or "instructional_motif_completion" in allowed:
        programs.extend(_fit_motif_completion(pairs))
    return programs


def fit_transformational_graph_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_transformational_graph(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_transformational_graph_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "transformational_graph_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "transformational_graph_propagation": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery and validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    if kind == "lattice_axis_connection":
        return LatticeAxisConnectionProgram()
    if kind == "anchor_stencil_propagation":
        return AnchorStencilPropagationProgram(int(parameters.get("connectivity", 4)))
    if kind == "contained_exemplar_shape_colour_transfer":
        return ContainedExemplarShapeColourProgram(
            int(parameters["recipient_colour"]),
            int(parameters["frame_colour"]),
            int(parameters.get("connectivity", 4)),
            str(parameters.get("shape_mode", "exact")),
        )
    if kind == "instructional_motif_completion":
        return InstructionalMotifCompletionProgram(
            int(parameters["completion_colour"]),
            bool(parameters.get("strict_bbox", True)),
        )
    raise Inapplicable("unknown transformational graph schema")


def _lattice_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        lattice, _, _, witnesses = program._analyse(a)
        colour, axis, fixed, start, end = witnesses[0]
        tokens = [list(row) for row in lattice.tokens]
        endpoint = (fixed, start) if axis == "row" else (start, fixed)
        tokens[endpoint[0]][endpoint[1]] = lattice.background
        removed = _render_lattice(a, lattice, tuple(tuple(row) for row in tokens))
        try:
            endpoint_necessary = program.predict(removed) != original
        except Inapplicable:
            endpoint_necessary = True
        replacement = next((value for value in range(10) if value not in _palette(a)), (colour + 1) % 10)
        recoloured_tokens = [list(row) for row in lattice.tokens]
        for r in range(len(recoloured_tokens)):
            for c in range(len(recoloured_tokens[0])):
                if recoloured_tokens[r][c] == colour:
                    recoloured_tokens[r][c] = replacement
        recoloured = _render_lattice(a, lattice, tuple(tuple(row) for row in recoloured_tokens))
        try:
            recolour_propagates = program.predict(recoloured) != original
        except Inapplicable:
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "endpoint_necessary": endpoint_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["endpoint_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _stencil_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        lattice, _, anchor_colour, anchor, recipients, prototype, stencil, _ = program._analyse(a)
        tokens = [list(row) for row in lattice.tokens]
        removable = next((cell for cell in prototype if cell != anchor), None)
        if removable is None:
            raise Inapplicable("stencil lacks a removable instruction cell")
        tokens[removable[0]][removable[1]] = lattice.background
        removed = _render_lattice(a, lattice, tuple(tuple(row) for row in tokens))
        try:
            instruction_necessary = program.predict(removed) != original
        except Inapplicable:
            instruction_necessary = True
        used = _palette(a)
        colour_map = {}
        available = iter([value for value in range(10) if value not in used and value != lattice.background])
        for _, _, colour in stencil:
            if colour == anchor_colour or colour in colour_map:
                continue
            colour_map[colour] = next(available, (colour + 1) % 10)
        recoloured_tokens = [list(row) for row in lattice.tokens]
        for r, c in prototype:
            if recoloured_tokens[r][c] in colour_map:
                recoloured_tokens[r][c] = colour_map[recoloured_tokens[r][c]]
        recoloured = _render_lattice(a, lattice, tuple(tuple(row) for row in recoloured_tokens))
        try:
            recolour_propagates = program.predict(recoloured) != original
        except Inapplicable:
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "instruction_necessary": instruction_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
            "recipient_count": len(recipients),
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["instruction_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _contained_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, _, frames, exemplars, recipients, _ = program._analyse(a)
        broken = _array(a)
        frame_cell = frames[0].cells[0]
        broken[frame_cell[0]][frame_cell[1]] = background
        try:
            frame_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            frame_necessary = True
        recoloured = _array(a)
        exemplar = exemplars[0]
        old_colour = exemplar.palette[0]
        replacement = next((value for value in range(10) if value not in _palette(a)), (old_colour + 1) % 10)
        for r, c in exemplar.cells:
            recoloured[r][c] = replacement
        try:
            changed = program.predict(tuple(tuple(row) for row in recoloured))
            recolour_propagates = changed != original and any(
                changed[r][c] == replacement for component, _ in recipients for r, c in component.cells
            )
        except Inapplicable:
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "closed_frame_necessary": frame_necessary,
            "exemplar_recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["closed_frame_necessary"] and row["exemplar_recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _motif_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, box, pattern, evidence, fill, matches, _ = program._analyse(a)
        r0, c0, _, _ = box
        removed = _array(a)
        er, ec, _ = evidence[0]
        removed[r0 + er][c0 + ec] = background
        try:
            evidence_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            evidence_necessary = True
        recoloured = _array(a)
        replacement = next((value for value in range(10) if value not in _palette(a)), (program.completion_colour + 1) % 10)
        for fr, fc, _ in fill:
            recoloured[r0 + fr][c0 + fc] = replacement
        try:
            completion_identity_necessary = program.predict(tuple(tuple(row) for row in recoloured)) != original
        except Inapplicable:
            completion_identity_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "visible_evidence_necessary": evidence_necessary,
            "completion_identity_necessary": completion_identity_necessary,
            "rotation_equivariant": rotation_equivariant,
            "partial_matches": len(matches),
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["visible_evidence_necessary"] and row["completion_identity_necessary"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, LatticeAxisConnectionProgram):
        return _lattice_counterfactuals(program, pairs)
    if isinstance(program, AnchorStencilPropagationProgram):
        return _stencil_counterfactuals(program, pairs)
    if isinstance(program, ContainedExemplarShapeColourProgram):
        return _contained_counterfactuals(program, pairs)
    if isinstance(program, InstructionalMotifCompletionProgram):
        return _motif_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_transformational_graph(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_transformational_graph(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def transformational_graph_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_transformational_graph_programs(pairs)}))


infer = infer_transformational_graph
validate = validate_transformational_graph
