"""LUCA V130: anti-unified multi-stage composition.

This research family composes structural perception, relation binding and a
local transformation into one conservative proof-carrying programme::

    scene -> structural relation -> semantic roles -> local operator -> emit

Schemas:

* ``concentric_palette_program`` (reverse or periodic palette shift);
* ``framed_reference_homology_recolour``;
* ``cyclic_region_palette_rotation``;
* ``cyclic_framed_motif_recolour``.

No task identifier, official test target or stored demonstration coordinate is
available during inference.  Exact training fit is necessary but not
sufficient: programmes must agree on unseen predictions, survive held-example
refitting and pass schema-specific counterfactual tests.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations
import json
import math
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_anti_unified_multi_stage_composition"
LANGUAGE = "spinoza_anti_unified_multi_stage_composition_v1"
SCHEMA_VERSION = "anti_unified_multi_stage_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {int(cell) for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    best = max(counts.values())
    modes = [int(colour) for colour, count in counts.items() if count == best]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _candidate_backgrounds(pairs) -> list[int]:
    candidates = None
    for source, _ in pairs:
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_unique_mode(source))
        except Inapplicable:
            pass
        candidates = values if candidates is None else candidates & values
    return sorted(candidates or ())


def _dirs(connectivity: int):
    rows = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        rows += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return rows


def _components_same_colour(value: Grid, *, background: int, connectivity: int = 4):
    value = grid(value)
    height, width = _shape(value)
    seen = set()
    rows = []
    for row in range(height):
        for col in range(width):
            colour = value[row][col]
            if colour == background or (row, col) in seen:
                continue
            stack = [(row, col)]
            seen.add((row, col))
            cells = []
            while stack:
                current = stack.pop()
                cells.append(current)
                for dr, dc in _dirs(connectivity):
                    nr, nc = current[0] + dr, current[1] + dc
                    if not (0 <= nr < height and 0 <= nc < width):
                        continue
                    if (nr, nc) in seen or value[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            bbox = _bbox_for_cells(cells)
            rows.append({
                "colour": int(colour),
                "cells": tuple(sorted(cells)),
                "bbox": bbox,
                "mask": _normalised_mask(cells),
            })
    rows.sort(key=lambda item: item["bbox"])
    return rows


def _bbox_for_cells(cells):
    return (
        min(row for row, _ in cells),
        min(col for _, col in cells),
        max(row for row, _ in cells),
        max(col for _, col in cells),
    )


def _normalised_mask(cells):
    r0, c0, r1, c1 = _bbox_for_cells(cells)
    occupied = set(cells)
    return tuple(
        tuple(1 if (row, col) in occupied else 0 for col in range(c0, c1 + 1))
        for row in range(r0, r1 + 1)
    )


def _crop(value: Grid, bbox) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = bbox
    return tuple(tuple(value[row][col] for col in range(c0, c1 + 1)) for row in range(r0, r1 + 1))


def _global_colour_mapping(source: Grid, target: Grid):
    if _shape(source) != _shape(target):
        return None
    mapping = {}
    for source_row, target_row in zip(grid(source), grid(target)):
        for left, right in zip(source_row, target_row):
            if left in mapping and mapping[left] != right:
                return None
            mapping[left] = right
    return mapping


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


# ---------------------------------------------------------------------------
# Concentric palette programmes.
# ---------------------------------------------------------------------------


def _ring_sequence(value: Grid):
    value = grid(value)
    height, width = _shape(value)
    if height != width or height < 4:
        raise Inapplicable("concentric palette programme requires a square grid")
    sequence = []
    for depth in range((height + 1) // 2):
        r0 = c0 = depth
        r1, c1 = height - 1 - depth, width - 1 - depth
        cells = []
        for col in range(c0, c1 + 1):
            cells.append(value[r0][col])
            if r1 != r0:
                cells.append(value[r1][col])
        for row in range(r0 + 1, r1):
            cells.append(value[row][c0])
            if c1 != c0:
                cells.append(value[row][c1])
        if len(set(cells)) != 1:
            raise Inapplicable("a concentric layer is not uniform")
        sequence.append(int(cells[0]))
    if len(sequence) < 3 or len(set(sequence)) < 2:
        raise Inapplicable("insufficient concentric palette evidence")
    return tuple(sequence)


def _minimal_period(sequence):
    for period in range(1, len(sequence) + 1):
        if all(sequence[index] == sequence[index % period] for index in range(len(sequence))):
            return period
    return len(sequence)


def _render_rings(sequence, height, width):
    return tuple(
        tuple(sequence[min(row, col, height - 1 - row, width - 1 - col)] for col in range(width))
        for row in range(height)
    )


@dataclass(frozen=True)
class ConcentricPaletteProgram:
    operation: str
    shift: int = 0
    kind: str = "concentric_palette_program"

    @property
    def schema_key(self):
        return self.kind, self.operation, self.shift

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        sequence = _ring_sequence(value)
        if self.operation == "reverse":
            output_sequence = tuple(reversed(sequence))
            period = None
        elif self.operation == "period_shift":
            period = _minimal_period(sequence)
            if period < 2:
                raise Inapplicable("the palette period is trivial")
            base = sequence[:period]
            output_sequence = tuple(base[(index + self.shift) % period] for index in range(len(sequence)))
        else:
            raise Inapplicable("unknown concentric palette operation")
        prediction = _render_rings(output_sequence, *_shape(value))
        return {
            "input_sequence": sequence,
            "output_sequence": output_sequence,
            "period": period,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"operation": self.operation, "shift": self.shift},
            definitions=[
                {"name": "ConcentricLayer", "type": "Grid x Depth -> Colour"},
                {"name": "PaletteProgramme", "type": "ColourSequence -> ColourSequence"},
            ],
            propositions=[
                {"name": "UniformLayerEvidence", "description": "Every concentric layer is monochrome."},
                {"name": "SharedPaletteOperator", "description": "One reversal or cyclic shift explains every demonstration."},
            ],
            corollary="Apply the learned palette programme to the unseen concentric layers.",
            common_notions=["concentricity", "palette role", "sequence transformation", "whole-grid emission"],
        )


# ---------------------------------------------------------------------------
# Framed-reference homology transfer.
# ---------------------------------------------------------------------------


def _l_orientation(component):
    cells = set(component["cells"])
    r0, c0, r1, c1 = component["bbox"]
    if r1 - r0 + 1 < 3 or c1 - c0 + 1 < 3:
        return None
    candidates = {
        "top_left": {(r0, col) for col in range(c0, c1 + 1)} | {(row, c0) for row in range(r0, r1 + 1)},
        "top_right": {(r0, col) for col in range(c0, c1 + 1)} | {(row, c1) for row in range(r0, r1 + 1)},
        "bottom_left": {(r1, col) for col in range(c0, c1 + 1)} | {(row, c0) for row in range(r0, r1 + 1)},
        "bottom_right": {(r1, col) for col in range(c0, c1 + 1)} | {(row, c1) for row in range(r0, r1 + 1)},
    }
    for orientation, expected in candidates.items():
        if cells == expected:
            return orientation
    return None


@dataclass(frozen=True)
class FramedReferenceHomologyProgram:
    connectivity: int = 4
    kind: str = "framed_reference_homology_recolour"

    @property
    def schema_key(self):
        return self.kind, self.connectivity

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        background = _unique_mode(value)
        components = _components_same_colour(value, background=background, connectivity=self.connectivity)
        candidates = []
        for instruction in components:
            orientation = _l_orientation(instruction)
            if orientation is None:
                continue
            r0, c0, r1, c1 = instruction["bbox"]
            inside = [
                component for component in components
                if component is not instruction
                and all(r0 <= row <= r1 and c0 <= col <= c1 for row, col in component["cells"])
            ]
            if len(inside) != 1:
                continue
            reference = inside[0]
            targets = [
                component for component in components
                if component is not instruction and component is not reference
                and component["mask"] == reference["mask"]
            ]
            if len(targets) != 1:
                continue
            target = targets[0]
            work = _array(value)
            for row, col in target["cells"]:
                work[row][col] = instruction["colour"]
            candidates.append({
                "background": background,
                "instruction": instruction,
                "orientation": orientation,
                "reference": reference,
                "target": target,
                "prediction": tuple(tuple(row) for row in work),
            })
        groups = defaultdict(list)
        for candidate in candidates:
            groups[candidate["prediction"]].append(candidate)
        if len(groups) != 1:
            raise Inapplicable("framed reference relation is not uniquely bound")
        prediction, rows = next(iter(groups.items()))
        chosen = rows[0]
        chosen["prediction"] = prediction
        return chosen

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"connectivity": self.connectivity},
            definitions=[
                {"name": "InstructionBracket", "type": "Grid -> LFrame"},
                {"name": "ReferenceObject", "type": "LFrame -> Component"},
                {"name": "HomologousTarget", "type": "ComponentMask x Scene -> Component"},
            ],
            propositions=[
                {"name": "BracketedExample", "description": "The L frame binds one enclosed reference object."},
                {"name": "TranslatedHomology", "description": "Exactly one external component has the same normalised mask."},
            ],
            corollary="Recolour the homologous target with the instruction-frame colour.",
            common_notions=["instruction", "homology", "containment", "semantic recolouring"],
        )


# ---------------------------------------------------------------------------
# Cyclic region palette rotation.
# ---------------------------------------------------------------------------


def _regions_excluding(value: Grid, skeleton_colours):
    value = grid(value)
    height, width = _shape(value)
    skeleton_colours = set(skeleton_colours)
    seen = set()
    rows = []
    for row in range(height):
        for col in range(width):
            if value[row][col] in skeleton_colours or (row, col) in seen:
                continue
            stack = [(row, col)]
            seen.add((row, col))
            cells = []
            while stack:
                current = stack.pop()
                cells.append(current)
                for dr, dc in _dirs(4):
                    nr, nc = current[0] + dr, current[1] + dc
                    if not (0 <= nr < height and 0 <= nc < width):
                        continue
                    if (nr, nc) in seen or value[nr][nc] in skeleton_colours:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            colours = {int(value[r][c]) for r, c in cells}
            if len(colours) != 1:
                raise Inapplicable("a structural region contains multiple palette roles")
            rows.append({
                "cells": tuple(cells),
                "colour": next(iter(colours)),
                "centroid": (
                    sum(r for r, _ in cells) / len(cells),
                    sum(c for _, c in cells) / len(cells),
                ),
            })
    return rows


@dataclass(frozen=True)
class CyclicRegionPaletteProgram:
    skeleton_colours: tuple[int, ...]
    kind: str = "cyclic_region_palette_rotation"

    @property
    def schema_key(self):
        return self.kind, self.skeleton_colours

    @property
    def description_length(self):
        return 3 + len(self.skeleton_colours)

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if not self.skeleton_colours or not set(self.skeleton_colours) <= _palette(value):
            raise Inapplicable("the structural skeleton is absent")
        regions = _regions_excluding(value, self.skeleton_colours)
        if len(regions) < 2:
            raise Inapplicable("at least two palette regions are required")
        height, width = _shape(value)
        centre = ((height - 1) / 2, (width - 1) / 2)
        for region in regions:
            row, col = region["centroid"]
            region["angle"] = math.atan2(row - centre[0], col - centre[1])
        regions.sort(key=lambda region: region["angle"])
        if any(abs(regions[index]["angle"] - regions[index - 1]["angle"]) < 1e-9 for index in range(1, len(regions))):
            raise Inapplicable("region angular order is ambiguous")
        work = _array(value)
        for index, region in enumerate(regions):
            replacement = regions[(index - 1) % len(regions)]["colour"]
            for row, col in region["cells"]:
                work[row][col] = replacement
        return {
            "regions": tuple(regions),
            "prediction": tuple(tuple(row) for row in work),
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"skeleton_colours": list(self.skeleton_colours), "direction": "previous_angular_region"},
            definitions=[
                {"name": "StructuralSkeleton", "type": "Grid x ColourSet -> CellSet"},
                {"name": "PaletteRegion", "type": "Grid minus Skeleton -> Component"},
                {"name": "AngularOrder", "type": "RegionSet -> Cycle"},
            ],
            propositions=[
                {"name": "InvariantSkeleton", "description": "Skeleton colours remain unchanged."},
                {"name": "CyclicRoleTransfer", "description": "Each region receives the previous angular region's colour."},
            ],
            corollary="Rotate semantic palette roles around the invariant skeleton.",
            common_notions=["region", "cyclic order", "invariant skeleton", "palette transport"],
        )


# ---------------------------------------------------------------------------
# Cyclic framed-motif recolouring.
# ---------------------------------------------------------------------------


def _is_rectangular_perimeter(component):
    r0, c0, r1, c1 = component["bbox"]
    if r1 - r0 + 1 < 3 or c1 - c0 + 1 < 3:
        return False
    expected = {
        (row, col)
        for row in range(r0, r1 + 1)
        for col in range(c0, c1 + 1)
        if row in (r0, r1) or col in (c0, c1)
    }
    return set(component["cells"]) == expected


@dataclass(frozen=True)
class CyclicFramedMotifProgram:
    background_colour: int
    frame_colour: int
    kind: str = "cyclic_framed_motif_recolour"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.frame_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        components = _components_same_colour(value, background=self.background_colour, connectivity=4)
        frames = []
        for component in components:
            if component["colour"] != self.frame_colour or not _is_rectangular_perimeter(component):
                continue
            r0, c0, r1, c1 = component["bbox"]
            interior = [
                (row, col)
                for row in range(r0 + 1, r1)
                for col in range(c0 + 1, c1)
                if value[row][col] not in (self.background_colour, self.frame_colour)
            ]
            payload_colours = {int(value[row][col]) for row, col in interior}
            if len(payload_colours) != 1 or not interior:
                continue
            frames.append({
                "component": component,
                "centre": ((r0 + r1) / 2, (c0 + c1) / 2),
                "payload_colour": next(iter(payload_colours)),
                "payload_cells": tuple(interior),
            })
        if len(frames) < 3:
            raise Inapplicable("at least three framed motif roles are required")
        global_centre = (
            sum(frame["centre"][0] for frame in frames) / len(frames),
            sum(frame["centre"][1] for frame in frames) / len(frames),
        )
        for frame in frames:
            row, col = frame["centre"]
            frame["angle"] = math.atan2(row - global_centre[0], col - global_centre[1])
        frames.sort(key=lambda frame: frame["angle"])
        if any(abs(frames[index]["angle"] - frames[index - 1]["angle"]) < 1e-9 for index in range(1, len(frames))):
            raise Inapplicable("frame angular order is ambiguous")
        work = _array(value)
        for index, frame in enumerate(frames):
            replacement = frames[(index + 1) % len(frames)]["payload_colour"]
            for row, col in frame["payload_cells"]:
                work[row][col] = replacement
        return {
            "frames": tuple(frames),
            "prediction": tuple(tuple(row) for row in work),
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background_colour": self.background_colour,
                "frame_colour": self.frame_colour,
                "direction": "next_angular_frame",
            },
            definitions=[
                {"name": "FramedMotif", "type": "Grid x FrameColour -> Motif"},
                {"name": "AngularFrameOrder", "type": "MotifSet -> Cycle"},
            ],
            propositions=[
                {"name": "FrameInvariant", "description": "Frame geometry is preserved."},
                {"name": "PayloadCycle", "description": "Each frame receives the next angular payload colour."},
            ],
            corollary="Rotate motif palette roles around the framed-object cycle.",
            common_notions=["frame", "motif", "cyclic order", "palette role"],
        )


# ---------------------------------------------------------------------------
# Fitting.
# ---------------------------------------------------------------------------


def _fit_concentric(pairs):
    try:
        sequences = [_ring_sequence(source) for source, _ in pairs]
        targets = [_ring_sequence(target) for _, target in pairs]
        if any(_shape(source) != _shape(target) for source, target in pairs):
            return []
    except Inapplicable:
        return []
    programmes = []
    reverse = ConcentricPaletteProgram("reverse", 0)
    try:
        if all(reverse.predict(source) == target for source, target in pairs):
            programmes.append(reverse)
    except Inapplicable:
        pass
    offsets = []
    for shift in range(-9, 10):
        program = ConcentricPaletteProgram("period_shift", shift)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                offsets.append(shift)
        except Inapplicable:
            continue
    if offsets:
        canonical = min(offsets, key=lambda value: (abs(value), value))
        programmes.append(ConcentricPaletteProgram("period_shift", canonical))
    return programmes


def _fit_framed_reference(pairs):
    program = FramedReferenceHomologyProgram()
    try:
        return [program] if all(program.predict(source) == target for source, target in pairs) else []
    except Inapplicable:
        return []


def _fixed_colours_across_pairs(pairs):
    common = None
    for source, target in pairs:
        if _shape(source) != _shape(target):
            return []
        fixed = set()
        for colour in _palette(source):
            cells = [
                (row, col)
                for row, values in enumerate(source)
                for col, value in enumerate(values)
                if value == colour
            ]
            if cells and all(target[row][col] == colour for row, col in cells):
                fixed.add(int(colour))
        common = fixed if common is None else common & fixed
    return sorted(common or ())


def _fit_region_cycle(pairs):
    if any(_global_colour_mapping(source, target) is None for source, target in pairs):
        return []
    fixed = _fixed_colours_across_pairs(pairs)
    programmes = []
    for size in range(1, min(4, len(fixed) + 1)):
        for skeleton in combinations(fixed, size):
            program = CyclicRegionPaletteProgram(tuple(skeleton))
            try:
                analyses = [program.analyse(source) for source, _ in pairs]
                if all(row["prediction"] == target for row, (_, target) in zip(analyses, pairs)):
                    if max(len(row["regions"]) for row in analyses) >= 3:
                        programmes.append(program)
            except Inapplicable:
                continue
    return programmes


def _fit_framed_cycle(pairs):
    if any(_global_colour_mapping(source, target) is None for source, target in pairs):
        return []
    common_colours = set.intersection(*(_palette(source) for source, _ in pairs)) if pairs else set()
    programmes = []
    for background in _candidate_backgrounds(pairs):
        for frame_colour in sorted(common_colours - {background}):
            program = CyclicFramedMotifProgram(background, frame_colour)
            try:
                analyses = [program.analyse(source) for source, _ in pairs]
                if all(row["prediction"] == target for row, (_, target) in zip(analyses, pairs)):
                    programmes.append(program)
            except Inapplicable:
                continue
    return programmes


FITTERS = {
    "concentric_palette_program": _fit_concentric,
    "framed_reference_homology_recolour": _fit_framed_reference,
    "cyclic_region_palette_rotation": _fit_region_cycle,
    "cyclic_framed_motif_recolour": _fit_framed_cycle,
}


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, ConcentricPaletteProgram):
        return analysis["input_sequence"], _shape(source)
    if isinstance(program, FramedReferenceHomologyProgram):
        return (
            analysis["orientation"],
            analysis["instruction"]["colour"],
            analysis["reference"]["mask"],
            analysis["target"]["bbox"],
        )
    if isinstance(program, CyclicRegionPaletteProgram):
        return tuple((row["colour"], len(row["cells"])) for row in analysis["regions"])
    if isinstance(program, CyclicFramedMotifProgram):
        return tuple((row["payload_colour"], row["component"]["bbox"]) for row in analysis["frames"])
    return program.schema_key


def fit_multi_stage_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds or FITTERS)
    programmes = []
    for kind, fitter in FITTERS.items():
        if kind not in allowed:
            continue
        programmes.extend(fitter(pairs))
    unique = {}
    for program in programmes:
        try:
            if require_role_variation and len({_serial(_role_signature(program, source)) for source, _ in pairs}) < 2:
                continue
            if not all(program.predict(source) == target for source, target in pairs):
                continue
        except Inapplicable:
            continue
        unique[program.schema_key] = program
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.schema_key)))


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    return {"kind": kind, "rows": rows, "passed": bool(rows) and all(row.get("passed") for row in rows)}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}

        if isinstance(program, ConcentricPaletteProgram):
            analysis = program.analyse(source)
            colour = analysis["input_sequence"][0]
            fresh = _fresh_colour(source)
            recoloured = _replace_colour(source, colour, fresh)
            try:
                changed = program.predict(recoloured)
                equivariant = changed != original and fresh in _palette(changed)
            except Inapplicable:
                equivariant = False
            broken = _array(source)
            broken[0][0] = fresh
            try:
                program.predict(tuple(tuple(row) for row in broken))
                conflict_rejected = False
            except Inapplicable:
                conflict_rejected = True
            passed = equivariant and conflict_rejected
            details = {
                "palette_recolour_equivariance": equivariant,
                "nonuniform_ring_rejected": conflict_rejected,
            }

        elif isinstance(program, FramedReferenceHomologyProgram):
            analysis = program.analyse(source)
            fresh = _fresh_colour(source)
            work = _array(source)
            for row, col in analysis["instruction"]["cells"]:
                work[row][col] = fresh
            try:
                changed = program.predict(tuple(tuple(row) for row in work))
                equivariant = changed != original and fresh in _palette(changed)
            except Inapplicable:
                equivariant = False
            broken = _array(source)
            row, col = analysis["instruction"]["cells"][0]
            broken[row][col] = analysis["background"]
            try:
                program.predict(tuple(tuple(values) for values in broken))
                bracket_rejected = False
            except Inapplicable:
                bracket_rejected = True
            passed = equivariant and bracket_rejected
            details = {
                "instruction_recolour_equivariance": equivariant,
                "broken_bracket_rejected": bracket_rejected,
            }

        elif isinstance(program, CyclicRegionPaletteProgram):
            analysis = program.analyse(source)
            fresh = _fresh_colour(source, set(program.skeleton_colours))
            work = _array(source)
            for row, col in analysis["regions"][0]["cells"]:
                work[row][col] = fresh
            try:
                changed = program.predict(tuple(tuple(values) for values in work))
                equivariant = changed != original and fresh in _palette(changed)
            except Inapplicable:
                equivariant = False
            rotated_source = tuple(tuple(reversed(row)) for row in reversed(source))
            rotated_expected = tuple(tuple(reversed(row)) for row in reversed(original))
            try:
                rotational = program.predict(rotated_source) == rotated_expected
            except Inapplicable:
                rotational = False
            passed = equivariant and rotational
            details = {
                "region_recolour_equivariance": equivariant,
                "half_turn_equivariance": rotational,
            }

        elif isinstance(program, CyclicFramedMotifProgram):
            analysis = program.analyse(source)
            fresh = _fresh_colour(source, {program.background_colour, program.frame_colour})
            work = _array(source)
            for row, col in analysis["frames"][0]["payload_cells"]:
                work[row][col] = fresh
            try:
                changed = program.predict(tuple(tuple(values) for values in work))
                equivariant = changed != original and fresh in _palette(changed)
            except Inapplicable:
                equivariant = False
            broken = _array(source)
            row, col = analysis["frames"][0]["component"]["cells"][0]
            broken[row][col] = program.background_colour
            try:
                broken_prediction = program.predict(tuple(tuple(values) for values in broken))
                frame_changed = broken_prediction != original
            except Inapplicable:
                frame_changed = True
            passed = equivariant and frame_changed
            details = {
                "payload_recolour_equivariance": equivariant,
                "broken_frame_changes_or_rejects": frame_changed,
            }

        rows.append({"demonstration": index, "passed": passed, **details})
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Inference and validation.
# ---------------------------------------------------------------------------


def infer_multi_stage_composition(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_multi_stage_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programmes:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_multi_stage_composition": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "concentric_palette_program":
        return ConcentricPaletteProgram(str(parameters["operation"]), int(parameters.get("shift", 0)))
    if kind == "framed_reference_homology_recolour":
        return FramedReferenceHomologyProgram(int(parameters.get("connectivity", 4)))
    if kind == "cyclic_region_palette_rotation":
        return CyclicRegionPaletteProgram(tuple(int(value) for value in parameters["skeleton_colours"]))
    if kind == "cyclic_framed_motif_recolour":
        return CyclicFramedMotifProgram(int(parameters["background_colour"]), int(parameters["frame_colour"]))
    raise Inapplicable("unknown multi-stage schema")


def validate_multi_stage_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_multi_stage_programs(
            remaining,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                counterfactual = _counterfactual_validation(program, full_pairs)
                if not counterfactual.get("passed"):
                    continue
                predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        })

    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, full_pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def multi_stage_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_multi_stage_programs(pairs)}))


infer = infer_multi_stage_composition
validate = validate_multi_stage_composition
