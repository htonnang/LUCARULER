"""LUCA V110: causal trigger induction over marker and repetition affordances.

V110 separates *what transformation is executed* from *why it is applicable*.
A prediction is accepted only when a reusable trigger establishes the action:

* ``marker_attachment`` -- a unique external marker touches one of several
  alternative same-colour objects and thereby selects it for canonical crop;
* ``repetition_prototype`` -- exact or reflection-consistent repetition
  establishes a canonical prototype panel to extract.

Training outputs are used to fit and verify typed programs. Task identifiers and
all test-output fields are removed by ``runtime.public_task`` before inference.
Official solutions are never imported by this module. Ambiguous explanations
remain ambiguous; failed triggers return no-fit.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable, Mapping, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_causal_trigger_induction"
LANGUAGE = "spinoza_causal_trigger_program_v1"
SCHEMA_VERSION = "causal_trigger_schema_v1"


# ---------------------------------------------------------------------------
# Shared grid utilities
# ---------------------------------------------------------------------------


def _unique_modal_background(value: Grid) -> int:
    a = grid(value)
    counts = Counter(v for row in a for v in row)
    if not counts:
        raise Inapplicable("empty grid")
    ranked = counts.most_common()
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal background")
    return ranked[0][0]


def _steps(connectivity: int):
    if connectivity == 4:
        return ((1, 0), (-1, 0), (0, 1), (0, -1))
    if connectivity == 8:
        return tuple(
            (dr, dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr, dc) != (0, 0)
        )
    raise Inapplicable("connectivity must be 4 or 8")


@dataclass(frozen=True)
class MonoComponent:
    colour: int
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]

    @property
    def area(self) -> int:
        return len(self.cells)

    @property
    def top(self) -> int:
        return self.box[0]

    @property
    def left(self) -> int:
        return self.box[1]

    @property
    def height(self) -> int:
        return self.box[2] - self.box[0] + 1

    @property
    def width(self) -> int:
        return self.box[3] - self.box[1] + 1

    def to_dict(self):
        return {
            "colour": self.colour,
            "area": self.area,
            "box": list(self.box),
            "height": self.height,
            "width": self.width,
        }


def extract_monochrome_components(value: Grid, connectivity: int = 4):
    """Return same-colour non-background components and the modal background."""
    a = grid(value)
    background = _unique_modal_background(a)
    steps = _steps(connectivity)
    height, width = len(a), len(a[0])
    seen = set()
    components = []
    for r in range(height):
        for c in range(width):
            if (r, c) in seen or a[r][c] == background:
                continue
            colour = a[r][c]
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in steps:
                    q = (rr + dr, cc + dc)
                    if not (0 <= q[0] < height and 0 <= q[1] < width):
                        continue
                    if q in seen or a[q[0]][q[1]] != colour:
                        continue
                    seen.add(q)
                    stack.append(q)
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            components.append(
                MonoComponent(colour, tuple(sorted(cells)), (r0, c0, r1, c1))
            )
    components.sort(key=lambda component: (component.top, component.left, component.box))
    return tuple(components), background


def _touches(a: MonoComponent, b: MonoComponent, connectivity: int) -> bool:
    target = set(b.cells)
    return any(
        (r + dr, c + dc) in target
        for r, c in a.cells
        for dr, dc in _steps(connectivity)
    )


def _component_crop(value: Grid, component: MonoComponent, background: int):
    """Canonical component crop; all non-target material is removed."""
    a = grid(value)
    selected = set(component.cells)
    r0, c0, r1, c1 = component.box
    return tuple(
        tuple(a[r][c] if (r, c) in selected else background for c in range(c0, c1 + 1))
        for r in range(r0, r1 + 1)
    )


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


# ---------------------------------------------------------------------------
# Marker-triggered object selection
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MarkerAttachmentProgram:
    component_connectivity: int
    relation_connectivity: int
    minimum_same_colour_objects: int = 2

    kind: str = "marker_attachment"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.component_connectivity,
            self.relation_connectivity,
            self.minimum_same_colour_objects,
        )

    @property
    def description_length(self) -> int:
        return 3

    @property
    def permissiveness_cost(self):
        return (
            0 if self.relation_connectivity == 4 else 1,
            0 if self.component_connectivity == 4 else 1,
        )

    def analyse(self, value: Grid):
        a = grid(value)
        components, background = extract_monochrome_components(
            a, self.component_connectivity
        )
        colour_counts = Counter(v for row in a for v in row)
        markers = [
            component
            for component in components
            if component.area == 1 and colour_counts[component.colour] == 1
        ]
        if len(markers) != 1:
            raise Inapplicable("requires one unique singleton-colour marker")
        marker = markers[0]
        touched = [
            component
            for component in components
            if component != marker
            and component.colour != marker.colour
            and component.area >= 2
            and _touches(marker, component, self.relation_connectivity)
        ]
        if len(touched) != 1:
            raise Inapplicable("marker must bind exactly one target object")
        target = touched[0]
        alternatives = [
            component
            for component in components
            if component.colour == target.colour and component.area >= 2
        ]
        if len(alternatives) < self.minimum_same_colour_objects:
            raise Inapplicable("marker must choose among same-colour alternatives")
        return {
            "background": background,
            "marker": marker,
            "target": target,
            "alternatives": tuple(alternatives),
        }

    def predict(self, value: Grid):
        analysis = self.analyse(value)
        return _component_crop(value, analysis["target"], analysis["background"])

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):
        proofs = []
        positions = []
        target_colours = []
        for index, (a, y) in enumerate(training_pairs):
            try:
                analysis = self.analyse(a)
                predicted = self.predict(a)
                target = analysis["target"]
                marker = analysis["marker"]
                positions.append((target.top, target.left))
                target_colours.append(target.colour)
                proofs.append(
                    {
                        "demonstration": index,
                        "exact": predicted == grid(y),
                        "trigger": {
                            "kind": "unique_external_marker_touch",
                            "marker": marker.to_dict(),
                            "target": target.to_dict(),
                            "alternatives": len(analysis["alternatives"]),
                        },
                    }
                )
            except Inapplicable as exc:
                proofs.append(
                    {"demonstration": index, "exact": False, "error": str(exc)}
                )
        return {
            "language": LANGUAGE,
            "family": FAMILY,
            "schema": self.kind,
            "definitions": [
                {
                    "name": "UniqueExternalMarker",
                    "input_type": "Grid",
                    "output_type": "Marker",
                    "contract": [
                        "one singleton colour occurrence",
                        "input-derived",
                        "no task identifier",
                    ],
                },
                {
                    "name": "MarkerTouchBinding",
                    "input_type": "Marker x ObjectSet",
                    "output_type": "Object",
                    "contract": [
                        "exactly one touched object",
                        "at least one same-colour alternative",
                    ],
                },
                {
                    "name": "CanonicalComponentCrop",
                    "input_type": "Object",
                    "output_type": "Grid",
                    "contract": ["remove trigger", "preserve selected object colours"],
                },
            ],
            "axioms": [
                "training_demonstrations_exact",
                "marker_is_necessary",
                "marker_motion_changes_selected_object",
                "unique_binding_required",
                "no_task_identifier",
                "no_test_target_access",
            ],
            "propositions": [
                {
                    "definition": "detect_marker_trigger",
                    "parameters": [self.component_connectivity],
                    "cause": "one uniquely coloured singleton is present",
                    "effect": "bind the external instruction marker",
                },
                {
                    "definition": "bind_touched_object",
                    "parameters": [
                        self.relation_connectivity,
                        self.minimum_same_colour_objects,
                    ],
                    "cause": "the marker touches exactly one of several alternatives",
                    "effect": "select that object",
                },
                {
                    "definition": "canonical_crop",
                    "parameters": ["component_mask"],
                    "cause": "a uniquely triggered object has been selected",
                    "effect": "emit the selected object without the marker",
                },
            ],
            "corollary": "detect_marker_trigger -> bind_touched_object -> canonical_crop",
            "parameters": {
                "kind": self.kind,
                "component_connectivity": self.component_connectivity,
                "relation_connectivity": self.relation_connectivity,
                "minimum_same_colour_objects": self.minimum_same_colour_objects,
            },
            "adequacy": {
                "demonstrations_exact": all(p.get("exact") for p in proofs)
                if proofs
                else None,
                "target_positions_vary": len(set(positions)) >= 2 if positions else None,
                "target_colours_vary": len(set(target_colours)) >= 2
                if target_colours
                else None,
                "description_length": self.description_length,
                "permissiveness_cost": list(self.permissiveness_cost),
            },
            "proofs": proofs,
        }


def candidate_marker_programs():
    return tuple(
        MarkerAttachmentProgram(component_connectivity, relation_connectivity)
        for component_connectivity in (4, 8)
        for relation_connectivity in (4, 8)
    )


def _marker_role_varies(
    program: MarkerAttachmentProgram, pairs: Sequence[tuple[Grid, Grid]]
):
    positions = []
    colours = []
    for a, _ in pairs:
        analysis = program.analyse(a)
        target = analysis["target"]
        positions.append((target.top, target.left))
        colours.append(target.colour)
    return len(set(positions)) >= 2 and len(set(colours)) >= 2


# ---------------------------------------------------------------------------
# Repetition-triggered prototype extraction
# ---------------------------------------------------------------------------


def _horizontal_flip(value: Grid):
    return tuple(tuple(reversed(row)) for row in grid(value))


def _vertical_flip(value: Grid):
    return tuple(reversed(grid(value)))


def _rotate_90(value: Grid):
    a = grid(value)
    return tuple(tuple(row) for row in zip(*reversed(a)))


def _dihedral_same_shape(value: Grid):
    a = grid(value)
    candidates = []
    current = a
    for _ in range(4):
        if len(current) == len(a) and len(current[0]) == len(a[0]):
            candidates.append(current)
        reflected = _horizontal_flip(current)
        if len(reflected) == len(a) and len(reflected[0]) == len(a[0]):
            candidates.append(reflected)
        current = _rotate_90(current)
    unique = []
    seen = set()
    for candidate in candidates:
        if candidate not in seen:
            seen.add(candidate)
            unique.append(candidate)
    return tuple(unique)


@dataclass(frozen=True)
class RepetitionPrototypeProgram:
    panel_count: int
    relation_group: str

    kind: str = "repetition_prototype"

    @property
    def schema_key(self):
        return (self.kind, self.panel_count, self.relation_group)

    @property
    def description_length(self) -> int:
        return 2

    @property
    def permissiveness_cost(self):
        order = {"identity": 0, "axis_reflection": 1, "dihedral": 2}
        return (order[self.relation_group], self.panel_count)

    def _equivalent(self, prototype: Grid, panel: Grid, axis: str) -> bool:
        prototype, panel = grid(prototype), grid(panel)
        if panel == prototype:
            return True
        if self.relation_group == "identity":
            return False
        if self.relation_group == "axis_reflection":
            expected = (
                _horizontal_flip(prototype)
                if axis == "horizontal"
                else _vertical_flip(prototype)
            )
            return panel == expected
        if self.relation_group == "dihedral":
            return panel in _dihedral_same_shape(prototype)
        raise Inapplicable("unknown repetition relation group")

    def decompositions(self, value: Grid):
        a = grid(value)
        height, width = len(a), len(a[0])
        candidates = []
        if width % self.panel_count == 0:
            panel_width = width // self.panel_count
            panels = tuple(
                tuple(tuple(row[index * panel_width : (index + 1) * panel_width]) for row in a)
                for index in range(self.panel_count)
            )
            if all(
                self._equivalent(panels[0], panel, "horizontal")
                for panel in panels[1:]
            ):
                candidates.append(
                    {
                        "axis": "horizontal",
                        "prototype": panels[0],
                        "panel_shape": [height, panel_width],
                    }
                )
        if height % self.panel_count == 0:
            panel_height = height // self.panel_count
            panels = tuple(
                tuple(a[index * panel_height : (index + 1) * panel_height])
                for index in range(self.panel_count)
            )
            if all(
                self._equivalent(panels[0], panel, "vertical")
                for panel in panels[1:]
            ):
                candidates.append(
                    {
                        "axis": "vertical",
                        "prototype": panels[0],
                        "panel_shape": [panel_height, width],
                    }
                )
        return tuple(candidates)

    def analyse(self, value: Grid):
        candidates = self.decompositions(value)
        by_output = defaultdict(list)
        for candidate in candidates:
            by_output[candidate["prototype"]].append(candidate)
        if len(by_output) != 1:
            raise Inapplicable("repetition trigger is absent or output-ambiguous")
        prototype = next(iter(by_output))
        return {
            "prototype": prototype,
            "witnesses": tuple(by_output[prototype]),
        }

    def predict(self, value: Grid):
        return self.analyse(value)["prototype"]

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):
        proofs = []
        axes = []
        prototype_shapes = []
        prototype_palettes = []
        for index, (a, y) in enumerate(training_pairs):
            try:
                analysis = self.analyse(a)
                predicted = analysis["prototype"]
                axes.extend(witness["axis"] for witness in analysis["witnesses"])
                prototype_shapes.append((len(predicted), len(predicted[0])))
                prototype_palettes.append(
                    tuple(sorted({v for row in predicted for v in row}))
                )
                proofs.append(
                    {
                        "demonstration": index,
                        "exact": predicted == grid(y),
                        "trigger": {
                            "kind": "repetition_consensus",
                            "panel_count": self.panel_count,
                            "relation_group": self.relation_group,
                            "witnesses": list(analysis["witnesses"]),
                        },
                    }
                )
            except Inapplicable as exc:
                proofs.append(
                    {"demonstration": index, "exact": False, "error": str(exc)}
                )
        return {
            "language": LANGUAGE,
            "family": FAMILY,
            "schema": self.kind,
            "definitions": [
                {
                    "name": "PanelDecomposition",
                    "input_type": "Grid",
                    "output_type": "PanelSequence",
                    "contract": ["equal panels", "axis inferred from input"],
                },
                {
                    "name": "RepetitionConsensus",
                    "input_type": "PanelSequence",
                    "output_type": "Prototype",
                    "contract": ["all panels equivalent under fitted group"],
                },
                {
                    "name": "CanonicalPrototype",
                    "input_type": "Prototype",
                    "output_type": "Grid",
                    "contract": ["first witnessed orientation", "no coordinate template"],
                },
            ],
            "axioms": [
                "training_demonstrations_exact",
                "repetition_is_necessary",
                "panel_geometry_varies_across_demonstrations",
                "no_task_identifier",
                "no_test_target_access",
            ],
            "propositions": [
                {
                    "definition": "decompose_repetition",
                    "parameters": [self.panel_count],
                    "cause": "the input admits an equal-panel decomposition",
                    "effect": "construct a panel sequence",
                },
                {
                    "definition": "infer_prototype",
                    "parameters": [self.relation_group],
                    "cause": "all panels agree under the fitted equivalence group",
                    "effect": "bind the first panel as the canonical prototype",
                },
            ],
            "corollary": "decompose_repetition -> infer_prototype",
            "parameters": {
                "kind": self.kind,
                "panel_count": self.panel_count,
                "relation_group": self.relation_group,
            },
            "adequacy": {
                "demonstrations_exact": all(p.get("exact") for p in proofs)
                if proofs
                else None,
                "axes_observed": sorted(set(axes)),
                "prototype_shapes_vary": len(set(prototype_shapes)) >= 2
                if prototype_shapes
                else None,
                "prototype_palettes_vary": len(set(prototype_palettes)) >= 2
                if prototype_palettes
                else None,
                "description_length": self.description_length,
                "permissiveness_cost": list(self.permissiveness_cost),
            },
            "proofs": proofs,
        }


def candidate_repetition_programs():
    return tuple(
        RepetitionPrototypeProgram(panel_count, relation_group)
        for panel_count in (2, 3, 4, 5)
        for relation_group in ("identity", "axis_reflection", "dihedral")
    )


def _repetition_role_varies(
    program: RepetitionPrototypeProgram, pairs: Sequence[tuple[Grid, Grid]]
):
    prototypes = []
    shapes = []
    axes = []
    for a, _ in pairs:
        analysis = program.analyse(a)
        prototype = analysis["prototype"]
        prototypes.append(_serial(prototype))
        shapes.append((len(prototype), len(prototype[0])))
        axes.extend(witness["axis"] for witness in analysis["witnesses"])
    # Reject a fixed-window memorization: at least two prototypes and either
    # prototype geometry or observed axis must vary across demonstrations.
    return len(set(prototypes)) >= 2 and (
        len(set(shapes)) >= 2 or len(set(axes)) >= 2
    )


# ---------------------------------------------------------------------------
# Fitting, inference and validation
# ---------------------------------------------------------------------------


def _program_from_schema_key(key):
    if not key:
        raise Inapplicable("missing causal-trigger schema")
    if key[0] == "marker_attachment":
        return MarkerAttachmentProgram(int(key[1]), int(key[2]), int(key[3]))
    if key[0] == "repetition_prototype":
        return RepetitionPrototypeProgram(int(key[1]), str(key[2]))
    raise Inapplicable("unknown causal-trigger schema")


def fit_causal_trigger_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 3,
    allowed_schemas: Iterable[tuple] | None = None,
):
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(tuple(schema) for schema in allowed_schemas) if allowed_schemas else None
    by_kind = defaultdict(list)
    candidates = candidate_marker_programs() + candidate_repetition_programs()
    for program in candidates:
        if allowed is not None and program.schema_key not in allowed:
            continue
        try:
            if not all(program.predict(a) == y for a, y in pairs):
                continue
            if isinstance(program, MarkerAttachmentProgram):
                if not _marker_role_varies(program, pairs):
                    continue
            elif isinstance(program, RepetitionPrototypeProgram):
                if not _repetition_role_varies(program, pairs):
                    continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        by_kind[program.kind].append(program)

    # Retain the least permissive exact explanation inside each trigger class.
    selected = []
    for kind, programs in by_kind.items():
        best = min(
            (program.description_length, program.permissiveness_cost)
            for program in programs
        )
        selected.extend(
            program
            for program in programs
            if (program.description_length, program.permissiveness_cost) == best
        )
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (
            program.kind,
            program.description_length,
            program.permissiveness_cost,
            repr(program.schema_key),
        ),
    )


def infer_causal_trigger(task, *, minimum_pairs: int = 3, allowed_schemas=None):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_causal_trigger_programs(
        pairs, minimum_pairs=minimum_pairs, allowed_schemas=allowed_schemas
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        predictions = []
        try:
            for case in clean["test"]:
                predictions.append(program.predict(case["input"]))
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(v) for v in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "trigger_kinds": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "causal_trigger_induction": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def _marker_counterfactuals(
    program: MarkerAttachmentProgram, pairs: Sequence[tuple[Grid, Grid]]
):
    ablations = []
    relocations = []
    duplicate_rejections = []
    for index, (a, _) in enumerate(pairs):
        a = [list(row) for row in grid(a)]
        analysis = program.analyse(a)
        background = analysis["background"]
        marker = analysis["marker"]
        target = analysis["target"]
        mr, mc = marker.cells[0]

        removed = [row[:] for row in a]
        removed[mr][mc] = background
        try:
            removed_prediction = program.predict(removed)
        except Inapplicable:
            removed_prediction = None
        ablations.append(
            {"demonstration": index, "marker_removed_inapplicable": removed_prediction is None}
        )

        relocated = None
        for alternative in analysis["alternatives"]:
            if alternative == target:
                continue
            alt_cells = set(alternative.cells)
            for r, c in alternative.cells:
                for dr, dc in _steps(program.relation_connectivity):
                    q = (r + dr, c + dc)
                    if not (0 <= q[0] < len(a) and 0 <= q[1] < len(a[0])):
                        continue
                    if a[q[0]][q[1]] != background:
                        continue
                    candidate = [row[:] for row in a]
                    candidate[mr][mc] = background
                    candidate[q[0]][q[1]] = marker.colour
                    try:
                        prediction = program.predict(candidate)
                    except Inapplicable:
                        continue
                    expected = _component_crop(candidate, alternative, background)
                    if prediction == expected:
                        relocated = {
                            "demonstration": index,
                            "marker_moved": [q[0], q[1]],
                            "selection_changed": expected
                            != _component_crop(a, target, background),
                            "prediction_matches_new_target": True,
                        }
                        break
                if relocated:
                    break
            if relocated:
                break
        relocations.append(
            relocated
            or {
                "demonstration": index,
                "marker_moved": None,
                "selection_changed": False,
                "prediction_matches_new_target": False,
            }
        )

        duplicate = None
        for alternative in analysis["alternatives"]:
            if alternative == target:
                continue
            for r, c in alternative.cells:
                for dr, dc in _steps(program.relation_connectivity):
                    q = (r + dr, c + dc)
                    if not (0 <= q[0] < len(a) and 0 <= q[1] < len(a[0])):
                        continue
                    if a[q[0]][q[1]] != background:
                        continue
                    candidate = [row[:] for row in a]
                    candidate[q[0]][q[1]] = marker.colour
                    try:
                        prediction = program.predict(candidate)
                    except Inapplicable:
                        prediction = None
                    duplicate = prediction is None
                    break
                if duplicate is not None:
                    break
            if duplicate is not None:
                break
        duplicate_rejections.append(
            {"demonstration": index, "duplicate_marker_rejected": bool(duplicate)}
        )

    return {
        "kind": program.kind,
        "marker_ablation": ablations,
        "marker_relocation": relocations,
        "duplicate_marker": duplicate_rejections,
        "passed": all(row["marker_removed_inapplicable"] for row in ablations)
        and any(
            row["selection_changed"] and row["prediction_matches_new_target"]
            for row in relocations
        )
        and all(row["duplicate_marker_rejected"] for row in duplicate_rejections),
    }


def _fresh_colour(value: Grid, current: int):
    palette = {v for row in value for v in row}
    for colour in range(10):
        if colour not in palette:
            return colour
    return (current + 1) % 10


def _repetition_counterfactuals(
    program: RepetitionPrototypeProgram, pairs: Sequence[tuple[Grid, Grid]]
):
    rows = []
    for index, (a, _) in enumerate(pairs):
        a = [list(row) for row in grid(a)]
        analysis = program.analyse(a)
        witness = analysis["witnesses"][0]
        axis = witness["axis"]
        mutated = [row[:] for row in a]
        if axis == "horizontal":
            panel_width = len(a[0]) // program.panel_count
            r = len(a) // 2
            c = (program.panel_count - 1) * panel_width + panel_width // 2
        else:
            panel_height = len(a) // program.panel_count
            r = (program.panel_count - 1) * panel_height + panel_height // 2
            c = len(a[0]) // 2
        mutated[r][c] = _fresh_colour(mutated, mutated[r][c])
        try:
            prediction = program.predict(mutated)
        except Inapplicable:
            prediction = None
        rows.append(
            {
                "demonstration": index,
                "axis": axis,
                "mutated_cell": [r, c],
                "broken_repetition_inapplicable": prediction is None,
            }
        )
    return {
        "kind": program.kind,
        "broken_repetition": rows,
        "passed": all(row["broken_repetition_inapplicable"] for row in rows),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, MarkerAttachmentProgram):
        return _marker_counterfactuals(program, pairs)
    if isinstance(program, RepetitionPrototypeProgram):
        return _repetition_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_causal_trigger(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {
            "passed": False,
            "reason": "full_fit_not_unique",
            "folds": [],
            "counterfactuals": [],
        }
    if len(clean["train"]) < 3:
        return {
            "passed": False,
            "reason": "requires_three_demonstrations",
            "folds": [],
            "counterfactuals": [],
        }
    expected = [entry["prediction"] for entry in full["tests"]]
    schema_keys = []
    programs = []
    for law in full.get("supporting_laws", ()):
        p = law.get("parameters", {})
        if p.get("kind") == "marker_attachment":
            key = (
                "marker_attachment",
                p.get("component_connectivity"),
                p.get("relation_connectivity"),
                p.get("minimum_same_colour_objects"),
            )
        elif p.get("kind") == "repetition_prototype":
            key = (
                "repetition_prototype",
                p.get("panel_count"),
                p.get("relation_group"),
            )
        else:
            continue
        schema_keys.append(key)
        programs.append(_program_from_schema_key(key))
    allowed = tuple(sorted(set(schema_keys), key=repr))
    if not allowed:
        return {
            "passed": False,
            "reason": "missing_program_schema",
            "folds": [],
            "counterfactuals": [],
        }

    folds = []
    for held, demo in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demo["input"]}] + clean["test"],
        }
        result = infer_causal_trigger(fold, minimum_pairs=2, allowed_schemas=allowed)
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append(
            {
                "held_index": held,
                "status": result["status"],
                "held_example_exact": result["status"] == "unique"
                and predictions[0] == demo["output"],
                "test_prediction_stable": result["status"] == "unique"
                and predictions[1:] == expected,
                "joint_hypotheses": result["joint_hypotheses"],
            }
        )

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError) as exc:
            counterfactuals.append(
                {"kind": program.kind, "passed": False, "error": str(exc)}
            )

    folds_passed = all(
        fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds
    )
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": (
            "passed"
            if passed
            else "leave_one_demonstration_out_failure"
            if not folds_passed
            else "causal_counterfactual_failure"
        ),
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def trigger_affordances(task):
    """Return conservative fitted trigger kinds; used for audit/routing reports."""
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(
        sorted({program.kind for program in fit_causal_trigger_programs(pairs)})
    )
