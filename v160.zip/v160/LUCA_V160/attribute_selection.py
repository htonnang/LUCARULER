"""LUCA V71: conditional object selection and coordinate-based output construction.

One finite grammar reuses V70's segmentation and 16 structural attributes.
No task identifiers, target lookups, arbitrary coordinate tie-breaks or first-fit
acceptance. Every selected object is retained when a predicate matches ties.
Source views are selected-pixel or contextual bounding boxes. These views can
be reoriented, cropped, kept at their original origin, or aligned to a canvas.
Nonidentity orientations and anchored moves require an observed effect in at
least one demonstration. This is an explicit grammar prior, NOT a claim that
unobserved effects cannot occur on unseen inputs.
The canvas is freshly initialized: this is extraction/placement, not collision-
aware insertion into an otherwise preserved scene.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from collections import defaultdict, Counter


from attributes import perceive, FEATURES
from oriented_panels import orient, orientation_name
from correspondence import grid
from runtime import public_task


FAMILY = 'attribute_selection_v71'
SOURCE_VIEWS = ('selected', 'context')
SCALAR_FEATURES = ('area', 'area_rank', 'area_rank_desc', 'height', 'width',
                   'bbox_area', 'holes', 'shape_frequency')
ANCHORS = tuple(product(('low', 'center', 'high'), repeat=2))

@dataclass(frozen=True)
class Selector:
    feature: str
    operator: str
    value: object = None

    def indices(self, features):
        values = tuple(f[self.feature] for f in features)
        if not values: return ()
        if self.operator == 'min': target = min(values)
        elif self.operator == 'max': target = max(values)
        elif self.operator in ('eq', 'ne'): target = self.value
        else: raise ValueError('unknown selector operator')
        return tuple(i for i,v in enumerate(values)
                     if (v != target if self.operator == 'ne' else v == target))

    def describe(self):
        return {'feature':self.feature, 'operator':self.operator, 'value':self.value,
                'tie_policy':'select all matches; never position-based tie-breaking'}


def selector_candidates(scenes):
    """Task-independent operators; equality constants must occur in every demo."""
    for feature in FEATURES:
        if feature in SCALAR_FEATURES:
            yield Selector(feature, 'min')
            yield Selector(feature, 'max')
        common = set.intersection(*(set(f[feature] for f in fs) for bg,obs,fs in scenes))
        for value in sorted(common, key=repr):
            yield Selector(feature, 'eq', value)
            yield Selector(feature, 'ne', value)


def extract_view(a, scene, selected, kind):
    if not selected: return None
    bg, objects, _ = scene
    cells = tuple(p for i in selected for p in objects[i].cells)
    r0=min(r for r,c in cells);c0=min(c for r,c in cells)
    r1=max(r for r,c in cells);c1=max(c for r,c in cells)
    if kind == 'context':
        patch = tuple(tuple(row[c0:c1+1]) for row in a[r0:r1+1])
    elif kind == 'selected':
        out = [[bg]*(c1-c0+1) for _ in range(r1-r0+1)]
        for r,c in cells: out[r-r0][c-c0] = a[r][c]
        patch = grid(out)
    else: raise ValueError('unknown source view')
    return patch, (r0,c0)


def anchor_offset(space, rule):
    if space < 0: return None
    if rule == 'low': return 0
    if rule == 'high': return space
    if rule == 'center': return space//2 if space%2 == 0 else None
    raise ValueError('unknown anchor')

@dataclass(frozen=True)
class Construction:
    source_view: str
    orientation: int
    placement: str
    row_anchor: str = 'low'
    col_anchor: str = 'low'

    def render(self, a, scene, selected):
        v=extract_view(a,scene,selected,self.source_view)
        if v is None:return None
        patch,origin=v
        patch=orient(patch,self.orientation)
        if self.placement == 'crop': return patch
        h,w=len(a),len(a[0]);ph,pw=len(patch),len(patch[0])
        if self.placement == 'original': rr,cc=origin
        elif self.placement == 'canvas':
            rr=anchor_offset(h-ph,self.row_anchor)
            cc=anchor_offset(w-pw,self.col_anchor)
            if rr is None or cc is None:return None
        else:raise ValueError('unknown placement')
        if rr < 0 or cc < 0 or rr+ph > h or cc+pw > w:return None
        out=[[scene[0]]*w for _ in range(h)]
        for r,row in enumerate(patch): out[rr+r][cc:cc+pw]=row
        return grid(out)

    def describe(self):
        return {'source_view':self.source_view, 'orientation':orientation_name(self.orientation),
                'orientation_code':self.orientation,'placement':self.placement,
                'row_anchor':self.row_anchor,'col_anchor':self.col_anchor,
                'canvas_policy':'new input-sized background canvas; exact integer centering only'}

@dataclass(frozen=True)
class SelectionProgram:
    background_rule: str|int
    connectivity: int
    monochrome: bool
    selector: Selector
    construction: Construction

    def predict(self,a):
        a=grid(a);scene=perceive(a,self.background_rule,self.connectivity,self.monochrome)
        if scene is None:return None
        indices=self.selector.indices(scene[2])
        return self.construction.render(a,scene,indices)

    def describe(self):
        return {'family':FAMILY,'background_rule':self.background_rule,
                'connectivity':self.connectivity,'monochrome':self.monochrome,
                'selector':self.selector.describe(),'construction':self.construction.describe()}

    def trace(self,a):
        a=grid(a);scene=perceive(a,self.background_rule,self.connectivity,self.monochrome)
        if scene is None:return None
        selected=self.selector.indices(scene[2]);out=self.construction.render(a,scene,selected)
        return {'program':self.describe(),'background':scene[0],
                'components':[{'index':i,'selected':i in selected,'box':list(obj.box),
                               'feature_value':fs[self.selector.feature], 'area':len(obj.cells)}
                              for i,(obj,fs) in enumerate(zip(scene[1],scene[2]))],
                'prediction':[list(r) for r in out] if out is not None else None}


def construction_candidates(first, scenes, selected, target):
    """Shape-prune using demonstrations only; every admitted construction is tested."""
    input_shape=(len(first),len(first[0]));output_shape=(len(target),len(target[0]))
    target_counts=Counter(v for row in target for v in row)
    for kind in SOURCE_VIEWS:
        patch,_=extract_view(first,scenes[0],selected[0],kind)
        patch_counts=Counter(v for row in patch for v in row)
        # D4 operations and movement preserve colour multiplicities exactly.
        # A fresh canvas contributes only extra background cells. These necessary
        # conditions prune impossible renderings, not the hypothesis language.
        crop_possible=patch_counts==target_counts
        canvas_counts=patch_counts.copy()
        extra=input_shape[0]*input_shape[1]-len(patch)*len(patch[0])
        canvas_counts[scenes[0][0]]+=extra
        canvas_possible=output_shape==input_shape and canvas_counts==target_counts
        if not crop_possible and not canvas_possible:continue
        for code in range(8):
            ph,pw=len(patch),len(patch[0])
            if code%2:ph,pw=pw,ph
            if crop_possible and (ph,pw)==output_shape: yield Construction(kind,code,'crop')
            if canvas_possible and ph<=input_shape[0] and pw<=input_shape[1]:
                yield Construction(kind,code,'original')
                for ra,ca in ANCHORS:yield Construction(kind,code,'canvas',ra,ca)


def fit(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    # This grammar preserves colours and can only extract or use the input canvas.
    if any(not {v for row in y for v in row}.issubset({v for row in a for v in row})
           or len(y)*len(y[0]) > len(a)*len(a[0]) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    models=[]
    for bg in ('modal',*sorted(common)):
        for conn,mono in product((4,8),(True,False)):
            scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
            if any(s is None for s in scenes) or not any(len(s[1])>=2 for s in scenes):continue
            groups=defaultdict(list)
            for selector in selector_candidates(scenes):
                indices=tuple(selector.indices(s[2]) for s in scenes)
                if any(not x for x in indices):continue
                # Some observed choice must exist; selecting everything is not this family.
                if not any(len(x)<len(s[1]) for x,s in zip(indices,scenes)):continue
                groups[indices].append(selector)
            for indices,selectors in groups.items():
                for construction in construction_candidates(pairs[0][0],scenes,indices,pairs[0][1]):
                    if construction.orientation != 0:
                        patches=[extract_view(a,s,x,construction.source_view)[0]
                                 for (a,y),s,x in zip(pairs,scenes,indices)]
                        if all(orient(patch,construction.orientation)==patch for patch in patches):continue
                    if construction.placement == 'canvas':
                        observed_move=False
                        for (a,y),scene,idx in zip(pairs,scenes,indices):
                            patch,origin=extract_view(a,scene,idx,construction.source_view)
                            patch=orient(patch,construction.orientation)
                            destination=(anchor_offset(len(a)-len(patch),construction.row_anchor),
                                         anchor_offset(len(a[0])-len(patch[0]),construction.col_anchor))
                            observed_move |= destination != origin
                        if not observed_move:continue
                    if not all(construction.render(a,s,x)==y for (a,y),s,x in zip(pairs,scenes,indices)):continue
                    # Demonstration-equivalent predicates share work but are NOT discarded.
                    models.extend(SelectionProgram(bg,conn,mono,sel,construction) for sel in selectors)
    return models


def infer(task):
    clean=public_task(task)
    models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0
    for model in models:
        predictions=tuple(model.predict(t['input']) for t in clean['test'])
        if any(p is None for p in predictions):invalid+=1;continue
        groups.setdefault(predictions,[]).append(model.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
      'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
               for i in range(len(clean['test']))],
      'supporting_families':[FAMILY] if chosen else [],
      'supporting_laws':groups[chosen][:20] if chosen else [],
      'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
      'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
               'all_joint_predictions_retained':True,'reporting_cap_not_search_cap':20}}


def validate(task, full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer(fold);preds=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
            'held_example_exact':r['status']=='unique' and preds[0]==demo['output'],
            'test_prediction_stable':r['status']=='unique' and preds[1:]==expected,
            'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


