"""LUCA V151: rectangle coordinate-field materialisation.

This family learns colour fields over solid monochrome rectangular objects.
It shares one consequence operator across three conservative constructors:

    solid rectangles -> border-distance phase edges
                     -> alternating concentric field

    solid rectangles -> quadrant and inset-core coordinate edges
                     -> quadrant/core field

    two solid rectangles -> strict area-rank edge
                         -> ranked interior field

The family is task-ID blind and target blind. Background/source roles, output
colours, inset thickness, and size ordering are inferred from demonstrations.
No absolute demonstration coordinates are stored.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_rectangle_coordinate_field"
LANGUAGE = "spinoza_rectangle_coordinate_field_v151"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "rectangle_coordinate_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_rectangles": True,
            "normalised_coordinate_roles": True,
            "shared_rectangle_field_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty rectangle support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] == colour
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for neighbour in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    return tuple(output)


def _solid_rectangles(value: Grid, background: int, source: int):
    value = grid(value)
    if background == source:
        raise Inapplicable("background and source roles must differ")
    if _palette(value) != {background, source}:
        raise Inapplicable("exactly background and one rectangle colour required")
    rectangles = []
    for component in _components_of_colour(value, source):
        r0, c0, r1, c1 = _bbox(component)
        support = {
            (r, c)
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
        }
        if set(component) != support:
            raise Inapplicable("every source component must be a solid rectangle")
        rectangles.append((r0, c0, r1, c1))
    if not rectangles:
        raise Inapplicable("at least one source rectangle required")
    rectangles.sort()
    return tuple(rectangles)


def _background_unchanged(source: Grid, target: Grid, background: int):
    source = grid(source)
    target = grid(target)
    if _shape(source) != _shape(target):
        return False
    for r, row in enumerate(source):
        for c, colour in enumerate(row):
            if colour == background and target[r][c] != background:
                return False
    return True


def _role_pairs(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes or any(len(item) != 2 for item in palettes):
        return []
    common = set.intersection(*palettes)
    if len(common) != 2 or any(item != common for item in palettes):
        return []
    a, b = sorted(common)
    return [(a, b), (b, a)]


@dataclass(frozen=True)
class ConcentricDistancePhaseProgram:
    background: int
    source: int
    odd_colour: int
    even_colour: int

    kind = "concentric_distance_phase_field"
    operator = "rectangle_coordinate_field_materialisation"
    node_vocabulary = "solid_monochrome_rectangle_nodes"
    edge_vocabulary = "normalised_rectangle_coordinate_and_area_rank_edges"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background,
            self.source,
            self.odd_colour,
            self.even_colour,
        )

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        rectangles = _solid_rectangles(value, self.background, self.source)
        output = _array(value)
        even_witness = False
        for r0, c0, r1, c1 in rectangles:
            if min(r1 - r0 + 1, c1 - c0 + 1) < 3:
                raise Inapplicable("rectangle too thin for an interior phase")
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    distance = min(r - r0, c - c0, r1 - r, c1 - c)
                    if distance == 0:
                        colour = self.source
                    elif distance % 2:
                        colour = self.odd_colour
                    else:
                        colour = self.even_colour
                        even_witness = True
                    output[r][c] = colour
        if not even_witness:
            raise Inapplicable("an even interior layer is required")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more solid monochrome rectangles on a uniform background",
            relation_chain=(
                "extract solid rectangle nodes",
                "assign every rectangle cell its minimum border-distance coordinate",
                "preserve distance zero and alternate two learned colours over positive distances",
                "materialise the complete rectangle coordinate field",
            ),
            parameters={
                "background": self.background,
                "source": self.source,
                "odd_distance_colour": self.odd_colour,
                "even_distance_colour": self.even_colour,
            },
            corollary="Colour concentric rectangle layers by an alternating border-distance phase.",
            notions=["solid rectangle", "border distance", "alternating phase", "complete field"],
        )


@dataclass(frozen=True)
class QuadrantCoreFieldProgram:
    background: int
    source: int
    top_left: int
    top_right: int
    bottom_left: int
    bottom_right: int
    core: int
    inset: int

    kind = "quadrant_core_overlap_field"
    operator = "rectangle_coordinate_field_materialisation"
    node_vocabulary = "solid_monochrome_rectangle_nodes"
    edge_vocabulary = "normalised_rectangle_coordinate_and_area_rank_edges"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background,
            self.source,
            self.top_left,
            self.top_right,
            self.bottom_left,
            self.bottom_right,
            self.core,
            self.inset,
        )

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        rectangles = _solid_rectangles(value, self.background, self.source)
        output = _array(value)
        dimensions = set()
        for r0, c0, r1, c1 in rectangles:
            h, w = r1 - r0 + 1, c1 - c0 + 1
            dimensions.add((h, w))
            if h % 2 or w % 2 or min(h, w) <= 2 * self.inset:
                raise Inapplicable("even rectangles with a nonempty inset core required")
            for rr in range(h):
                for cc in range(w):
                    if self.inset <= rr < h - self.inset and self.inset <= cc < w - self.inset:
                        colour = self.core
                    elif rr < h // 2 and cc < w // 2:
                        colour = self.top_left
                    elif rr < h // 2:
                        colour = self.top_right
                    elif cc < w // 2:
                        colour = self.bottom_left
                    else:
                        colour = self.bottom_right
                    output[r0 + rr][c0 + cc] = colour
        if not dimensions:
            raise Inapplicable("missing rectangle dimensions")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="solid even-sided rectangles that share a quadrant and inset-core colour grammar",
            relation_chain=(
                "extract solid rectangle nodes",
                "normalise every rectangle to top/bottom and left/right half coordinates",
                f"overlay an inset core after removing a border of thickness {self.inset}",
                "materialise the learned quadrant and core colours",
            ),
            parameters={
                "background": self.background,
                "source": self.source,
                "top_left": self.top_left,
                "top_right": self.top_right,
                "bottom_left": self.bottom_left,
                "bottom_right": self.bottom_right,
                "core": self.core,
                "inset": self.inset,
            },
            corollary="Render four quadrant roles and one inset core in every rectangle.",
            notions=["rectangle half", "quadrant role", "inset core", "normalised coordinates"],
        )


@dataclass(frozen=True)
class AreaRankedInteriorProgram:
    background: int
    source: int
    smaller_colour: int
    larger_colour: int

    kind = "area_ranked_interior_field"
    operator = "rectangle_coordinate_field_materialisation"
    node_vocabulary = "solid_monochrome_rectangle_nodes"
    edge_vocabulary = "normalised_rectangle_coordinate_and_area_rank_edges"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background,
            self.source,
            self.smaller_colour,
            self.larger_colour,
        )

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        rectangles = _solid_rectangles(value, self.background, self.source)
        if len(rectangles) != 2:
            raise Inapplicable("exactly two source rectangles required")
        records = []
        for rectangle in rectangles:
            r0, c0, r1, c1 = rectangle
            h, w = r1 - r0 + 1, c1 - c0 + 1
            if min(h, w) < 3:
                raise Inapplicable("each rectangle needs a strict interior")
            records.append((h * w, rectangle))
        records.sort()
        if records[0][0] == records[1][0]:
            raise Inapplicable("rectangle areas must have a strict order")
        output = _array(value)
        for index, (_, (r0, c0, r1, c1)) in enumerate(records):
            fill = self.smaller_colour if index == 0 else self.larger_colour
            for r in range(r0 + 1, r1):
                for c in range(c0 + 1, c1):
                    output[r][c] = fill
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="two solid monochrome rectangles with distinct areas and nonempty strict interiors",
            relation_chain=(
                "extract the two solid rectangle nodes",
                "order the rectangles by complete support area",
                "preserve each one-cell source border",
                "fill the smaller and larger strict interiors with their learned role colours",
            ),
            parameters={
                "background": self.background,
                "source": self.source,
                "smaller_interior_colour": self.smaller_colour,
                "larger_interior_colour": self.larger_colour,
            },
            corollary="Fill strict rectangle interiors according to a learned two-node area order.",
            notions=["solid rectangle", "strict area order", "preserved border", "role colour"],
        )


def _fit_concentric(pairs):
    programmes = []
    for background, source in _role_pairs(pairs):
        odd_colours, even_colours = set(), set()
        valid = True
        even_witness = False
        rectangle_count = 0
        for source_grid, target_grid in pairs:
            source_grid, target_grid = grid(source_grid), grid(target_grid)
            try:
                rectangles = _solid_rectangles(source_grid, background, source)
            except Inapplicable:
                valid = False
                break
            rectangle_count += len(rectangles)
            if not _background_unchanged(source_grid, target_grid, background):
                valid = False
                break
            for r0, c0, r1, c1 in rectangles:
                if min(r1 - r0 + 1, c1 - c0 + 1) < 3:
                    valid = False
                    break
                for r in range(r0, r1 + 1):
                    for c in range(c0, c1 + 1):
                        distance = min(r - r0, c - c0, r1 - r, c1 - c)
                        colour = target_grid[r][c]
                        if distance == 0:
                            if colour != source:
                                valid = False
                                break
                        elif distance % 2:
                            odd_colours.add(colour)
                        else:
                            even_colours.add(colour)
                            even_witness = True
                    if not valid:
                        break
                if not valid:
                    break
            if not valid:
                break
        if (
            valid
            and rectangle_count >= 2
            and even_witness
            and len(odd_colours) == 1
            and len(even_colours) == 1
        ):
            odd = next(iter(odd_colours))
            even = next(iter(even_colours))
            if len({background, source, odd, even}) == 4:
                programme = ConcentricDistancePhaseProgram(background, source, odd, even)
                try:
                    if all(programme.predict(a) == grid(b) for a, b in pairs):
                        programmes.append(programme)
                except Inapplicable:
                    pass
    return programmes


def _fit_quadrant_core(pairs):
    programmes = []
    for background, source in _role_pairs(pairs):
        dimensions = set()
        try:
            all_rectangles = [
                _solid_rectangles(source_grid, background, source)
                for source_grid, _ in pairs
            ]
        except Inapplicable:
            continue
        if sum(map(len, all_rectangles)) < 2:
            continue
        for rectangles in all_rectangles:
            for r0, c0, r1, c1 in rectangles:
                dimensions.add((r1 - r0 + 1, c1 - c0 + 1))
        if len(dimensions) < 2:
            continue
        max_inset = min(min(h, w) // 2 - 1 for h, w in dimensions)
        for inset in range(1, max_inset + 1):
            role_colours = {name: set() for name in ("tl", "tr", "bl", "br", "core")}
            valid = True
            for (source_grid, target_grid), rectangles in zip(pairs, all_rectangles):
                source_grid, target_grid = grid(source_grid), grid(target_grid)
                if not _background_unchanged(source_grid, target_grid, background):
                    valid = False
                    break
                for r0, c0, r1, c1 in rectangles:
                    h, w = r1 - r0 + 1, c1 - c0 + 1
                    if h % 2 or w % 2 or min(h, w) <= 2 * inset:
                        valid = False
                        break
                    for rr in range(h):
                        for cc in range(w):
                            if inset <= rr < h - inset and inset <= cc < w - inset:
                                role = "core"
                            elif rr < h // 2 and cc < w // 2:
                                role = "tl"
                            elif rr < h // 2:
                                role = "tr"
                            elif cc < w // 2:
                                role = "bl"
                            else:
                                role = "br"
                            role_colours[role].add(target_grid[r0 + rr][c0 + cc])
                if not valid:
                    break
            if valid and all(len(values) == 1 for values in role_colours.values()):
                colours = [next(iter(role_colours[name])) for name in ("tl", "tr", "bl", "br", "core")]
                if len(set(colours + [background, source])) != 7:
                    continue
                programme = QuadrantCoreFieldProgram(background, source, *colours, inset)
                try:
                    if all(programme.predict(a) == grid(b) for a, b in pairs):
                        programmes.append(programme)
                except Inapplicable:
                    pass
    return programmes


def _fit_area_ranked(pairs):
    programmes = []
    for background, source in _role_pairs(pairs):
        smaller_colours, larger_colours = set(), set()
        valid = True
        for source_grid, target_grid in pairs:
            source_grid, target_grid = grid(source_grid), grid(target_grid)
            try:
                rectangles = _solid_rectangles(source_grid, background, source)
            except Inapplicable:
                valid = False
                break
            if len(rectangles) != 2 or not _background_unchanged(source_grid, target_grid, background):
                valid = False
                break
            records = []
            for rectangle in rectangles:
                r0, c0, r1, c1 = rectangle
                h, w = r1 - r0 + 1, c1 - c0 + 1
                if min(h, w) < 3:
                    valid = False
                    break
                border = {
                    target_grid[r][c]
                    for r in range(r0, r1 + 1)
                    for c in range(c0, c1 + 1)
                    if r in (r0, r1) or c in (c0, c1)
                }
                interior = {
                    target_grid[r][c]
                    for r in range(r0 + 1, r1)
                    for c in range(c0 + 1, c1)
                }
                if border != {source} or len(interior) != 1:
                    valid = False
                    break
                records.append((h * w, next(iter(interior))))
            if not valid:
                break
            records.sort()
            if records[0][0] == records[1][0]:
                valid = False
                break
            smaller_colours.add(records[0][1])
            larger_colours.add(records[1][1])
        if valid and len(smaller_colours) == len(larger_colours) == 1:
            smaller = next(iter(smaller_colours))
            larger = next(iter(larger_colours))
            if len({background, source, smaller, larger}) != 4:
                continue
            programme = AreaRankedInteriorProgram(background, source, smaller, larger)
            try:
                if all(programme.predict(a) == grid(b) for a, b in pairs):
                    programmes.append(programme)
            except Inapplicable:
                pass
    return programmes


_FITTERS = {
    "concentric_distance_phase_field": _fit_concentric,
    "quadrant_core_overlap_field": _fit_quadrant_core,
    "area_ranked_interior_field": _fit_area_ranked,
}


def fit_rectangle_coordinate_field_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        rectangles = _solid_rectangles(source, programme.background, programme.source)
        passed = False
        witness = None
        tested = 0
        for r0, c0, r1, c1 in rectangles:
            for r, c in ((r0, c0), (r0, c1), (r1, c0), (r1, c1)):
                tested += 1
                work = _array(source)
                work[r][c] = programme.background
                try:
                    changed = programme.predict(grid(work)) != original
                except Inapplicable:
                    changed = True
                if changed:
                    passed = True
                    witness = {
                        "cell": [r, c],
                        "from": int(programme.source),
                        "to": int(programme.background),
                    }
                    break
            if passed:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "rectangle_corner_or_coordinate_edge" if passed else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_rectangle_coordinate_field(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_rectangle_coordinate_field_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "normalised_coordinate_roles": True,
            "shared_rectangle_field_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_rectangle_coordinate_field_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_rectangle_coordinate_field_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_rectangle_coordinate_field(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }