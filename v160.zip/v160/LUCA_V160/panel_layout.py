"""V64 general panel algebra family, guided by V38's six-operation panel kernel.

One compositional program: infer equal-sized panels and separators -> derive
foreground masks -> combine n-ary Boolean masks -> paint with inferred colour
roles. Supports 2/3/4 panels, not one-off puzzle handlers. All fitting uses
training demonstrations; no task identifiers or test targets. Hypotheses are
not discarded just because they agree on demonstrations.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from itertools import product
from correspondence import grid

OPS=('AND','OR','XOR','NAND','NOR','XNOR')
LAYOUTS=((1,2),(2,1),(1,3),(3,1),(1,4),(4,1),(2,2))


def truth(bits, operation):
    if operation not in OPS or not 2<=len(bits)<=4: raise ValueError('invalid panel algebra')
    if operation=='AND':return all(bits)
    if operation=='OR':return any(bits)
    if operation=='XOR':return sum(bits)%2==1
    if operation=='NAND':return not all(bits)
    if operation=='NOR':return not any(bits)
    return sum(bits)%2==0


@dataclass(frozen=True)
class Layout:
    rows: int
    columns: int
    row_gap: int=0
    col_gap: int=0

    def split(self,raw):
        a=grid(raw);h,w=len(a),len(a[0])
        if (self.rows,self.columns) not in LAYOUTS: raise ValueError('unsupported panel layout')
        if self.row_gap not in (0,1,2) or self.col_gap not in (0,1,2):raise ValueError('unsupported separator thickness')
        hh=h-(self.rows-1)*self.row_gap;ww=w-(self.columns-1)*self.col_gap
        if hh<=0 or ww<=0 or hh%self.rows or ww%self.columns:return None
        ph,pw=hh//self.rows,ww//self.columns
        for k in range(1,self.rows):
            for r in range(k*ph+(k-1)*self.row_gap,k*(ph+self.row_gap)):
                if len(set(a[r]))!=1:return None
        for k in range(1,self.columns):
            for c in range(k*pw+(k-1)*self.col_gap,k*(pw+self.col_gap)):
                if len({row[c] for row in a})!=1:return None
        return tuple(tuple(tuple(a[rr*(ph+self.row_gap)+r][cc*(pw+self.col_gap):cc*(pw+self.col_gap)+pw])
                           for r in range(ph)) for rr,cc in product(range(self.rows),range(self.columns)))

    def name(self):return f'{self.rows}x{self.columns},gaps=({self.row_gap},{self.col_gap})'


@dataclass(frozen=True)
class Background:
    role: str='shared_panel_color'
    color: int=0

    def value(self,a,panels):
        if self.role=='constant':
            return self.color if any(self.color in row for row in a) else None
        if self.role=='shared_panel_color':
            common=set.intersection(*({v for row in p for v in row} for p in panels))
            return next(iter(common)) if len(common)==1 else None
        if self.role=='unique_modal':
            counts=Counter(v for row in a for v in row);largest=max(counts.values())
            choices=[v for v,n in counts.items() if n==largest]
            return choices[0] if len(choices)==1 else None
        raise ValueError('unknown background role')

    def name(self):return f'color:{self.color}' if self.role=='constant' else self.role


@dataclass(frozen=True)
class Paint:
    role: str='constant'
    value: int=0

    def color(self,bg,panels):
        if self.role=='constant':return self.value
        if self.role=='background':return bg
        if self.role=='panel_foreground':
            choices={v for row in panels[self.value] for v in row if v!=bg}
            return next(iter(choices)) if len(choices)==1 else None
        raise ValueError('unknown paint role')

    def name(self):return f'{self.role}:{self.value}' if self.role!='background' else 'background'


@dataclass(frozen=True)
class PanelProgram:
    layout: Layout
    background: Background
    operation: str
    false_paint: Paint
    true_paint: Paint

    def predict(self,raw):
        a=grid(raw);panels=self.layout.split(a)
        if panels is None:return None
        bg=self.background.value(a,panels)
        if bg is None:return None
        false=self.false_paint.color(bg,panels);true=self.true_paint.color(bg,panels)
        if false is None or true is None or false==true:return None
        h,w=len(panels[0]),len(panels[0][0])
        return tuple(tuple(true if truth([p[r][c]!=bg for p in panels],self.operation) else false
                           for c in range(w)) for r in range(h))

    def name(self):
        return (f'split_panels({self.layout.name()}) -> masks({self.background.name()}) -> '
                f'{self.operation} -> paint(false={self.false_paint.name()},true={self.true_paint.name()})')

    def template(self):return 'panel_partition -> Boolean_mask_algebra -> symbolic_paint'


def _paint_options(records,bit):
    # Record: (panels, inferred background, boolean grid, target).
    # Each Boolean state must have an observed output label somewhere in training.
    observations=[]
    for panels,bg,bits,target in records:
        values={target[r][c] for r in range(len(target)) for c in range(len(target[0])) if bits[r][c]==bit}
        if len(values)>1:return []
        if values:observations.append((panels,bg,next(iter(values))))
    if not observations:return []
    candidates=[]
    constants={v for panels,bg,v in observations}
    if len(constants)==1:candidates.append(Paint('constant',next(iter(constants))))
    candidates.append(Paint('background'))
    candidates += [Paint('panel_foreground',i) for i in range(len(records[0][0]))]
    return [p for p in candidates if all(p.color(bg,panels)==v for panels,bg,v in observations)]


def fit(raw_pairs):
    pairs=[(grid(a),grid(y)) for a,y in raw_pairs]
    if not pairs:return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    backgrounds=[Background(),Background('unique_modal')]+[Background('constant',c) for c in sorted(common)]
    programs=[]
    for rows,cols in LAYOUTS:
        for rg,cg in product((0,1,2) if rows>1 else (0,),(0,1,2) if cols>1 else (0,)):
            layout=Layout(rows,cols,rg,cg)
            if any(len(a)!=rows*len(y)+(rows-1)*rg or len(a[0])!=cols*len(y[0])+(cols-1)*cg for a,y in pairs):continue
            splits=[layout.split(a) for a,y in pairs]
            if any(p is None for p in splits):continue
            for bg_rule in backgrounds:
                bgs=[bg_rule.value(a,p) for (a,y),p in zip(pairs,splits)]
                if any(bg is None for bg in bgs):continue
                for operation in OPS:
                    records=[]
                    for ((a,y),panels,bg) in zip(pairs,splits,bgs):
                        h,w=len(y),len(y[0])
                        bits=tuple(tuple(truth([p[r][c]!=bg for p in panels],operation) for c in range(w)) for r in range(h))
                        records.append((panels,bg,bits,y))
                    for false,true in product(_paint_options(records,False),_paint_options(records,True)):
                        law=PanelProgram(layout,bg_rule,operation,false,true)
                        if all(law.predict(a)==y for a,y in pairs):programs.append(law)
    return programs
