"""LUCA V108: Spinoza-inspired proof-carrying causal composition.

This module translates five philosophical ideas into falsifiable solver contracts:

* geometrical method -> typed definitions, axioms, propositions and derivations;
* causality -> every accepted prediction records an applicable cause (program step);
* common notions -> invariant/transition properties shared by every demonstration;
* adequate knowledge -> exact fit, causal minimality and held-demonstration stability;
* unity -> one typed language composes the validated V103-V107 relation registry.

The terminology is an engineering metaphor, not a claim that Spinoza supplied an
algorithm.  Programs contain no task identifiers, example coordinates, or test targets.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from itertools import permutations
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import (
    Inapplicable,
    RELATIONAL_TRANSPORT_RELATIONS,
    RelationalTransportProgram,
)
import scene_programs

SPINOZA_FAMILY = "spinoza_causal_composition"
LANGUAGE = "spinoza_geometric_program_v1"


@dataclass(frozen=True)
class Definition:
    """A typed primitive in the shared reasoning language."""

    name: str
    input_type: str
    output_type: str
    kind: str
    contract: tuple[str, ...]

    def to_dict(self):
        return {
            "name": self.name,
            "input_type": self.input_type,
            "output_type": self.output_type,
            "kind": self.kind,
            "contract": list(self.contract),
        }


@dataclass(frozen=True)
class CommonNotion:
    """A relation that is witnessed in every training demonstration."""

    name: str
    value: str
    evidence_count: int

    def to_dict(self):
        return {"name": self.name, "value": self.value, "evidence_count": self.evidence_count}


@dataclass(frozen=True)
class CausalStep:
    """One proposition: under a registry-defined precondition, apply an effect."""

    relation: str
    parameters: tuple
    motion: str
    source_policy: str

    @classmethod
    def from_program(cls, p: RelationalTransportProgram):
        return cls(p.relation, tuple(p.parameters), p.motion, p.source_policy)

    def program(self):
        return RelationalTransportProgram(
            self.relation, tuple(self.parameters), self.motion, self.source_policy
        )

    def to_dict(self):
        d = self.program().describe()
        return {
            "definition": self.relation,
            "parameters": list(self.parameters),
            "motion": self.motion,
            "source_policy": self.source_policy,
            "kind": d.get("kind"),
            "operators": d.get("operators", []),
            "cause": "registry preconditions are satisfied on the current state",
            "effect": "apply the registered transport edit plan atomically",
        }


@dataclass(frozen=True)
class DerivationTrace:
    """Compact proof trace for one input; grids are not embedded in the law."""

    step_index: int
    relation: str
    before_fingerprint: tuple
    after_fingerprint: tuple
    changed_cells: int
    added_cells: int
    removed_cells: int
    recoloured_cells: int

    def to_dict(self):
        return {
            "step_index": self.step_index,
            "relation": self.relation,
            "before_fingerprint": list(self.before_fingerprint),
            "after_fingerprint": list(self.after_fingerprint),
            "changed_cells": self.changed_cells,
            "added_cells": self.added_cells,
            "removed_cells": self.removed_cells,
            "recoloured_cells": self.recoloured_cells,
        }


@dataclass(frozen=True)
class CausalProgram:
    """A minimal ordered composition of typed registry propositions."""

    steps: tuple[CausalStep, ...]
    common_notions: tuple[CommonNotion, ...] = ()

    def predict(self, value: Grid):
        current = grid(value)
        for step in self.steps:
            nxt = step.program().predict(current)
            if nxt is None or nxt == current:
                return None
            current = grid(nxt)
        return current

    def derive(self, value: Grid):
        current = grid(value)
        traces = []
        for index, step in enumerate(self.steps, 1):
            nxt = step.program().predict(current)
            if nxt is None or nxt == current:
                return None, ()
            nxt = grid(nxt)
            stats = _transition_stats(current, nxt)
            traces.append(
                DerivationTrace(
                    index,
                    step.relation,
                    _fingerprint(current),
                    _fingerprint(nxt),
                    stats["changed"],
                    stats["added"],
                    stats["removed"],
                    stats["recoloured"],
                )
            )
            current = nxt
        return current, tuple(traces)

    def causally_minimal_for(self, pairs: Sequence[tuple[Grid, Grid]]):
        """Every step must be necessary for at least one demonstration.

        For the current length-two composer this tests both one-step ablations.
        The implementation is generic for longer programs by deleting each step.
        """
        if len(self.steps) < 2:
            return False
        for omit in range(len(self.steps)):
            reduced = CausalProgram(self.steps[:omit] + self.steps[omit + 1 :])
            if all(reduced.predict(a) == y for a, y in pairs):
                return False
        return True

    @property
    def description_length(self):
        return len(self.steps) + sum(len(step.parameters) for step in self.steps)

    @property
    def permissiveness_cost(self):
        """Prefer the narrowest causal gate when exact explanations tie.

        Four-neighbour contact is stricter than eight-neighbour contact.  This is
        not a score hack: it is a general explanatory preference for fewer states
        satisfying a cause, analogous to selecting a more informative condition.
        """
        cost = 0
        for step in self.steps:
            if step.relation in ("homologous_reference", "homologous_reference_set"):
                if len(step.parameters) >= 3 and step.parameters[2] == 8:
                    cost += 1
        return cost

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):  # proof-carrying law
        proofs = []
        if training_pairs:
            for i, (a, y) in enumerate(training_pairs):
                predicted, trace = self.derive(a)
                proofs.append(
                    {
                        "demonstration": i,
                        "exact": predicted == y,
                        "derivation": [t.to_dict() for t in trace],
                    }
                )
        return {
            "language": LANGUAGE,
            "family": SPINOZA_FAMILY,
            "definitions": [definition_for(step.relation).to_dict() for step in self.steps],
            "axioms": [
                "typed_composition",
                "registered_preconditions",
                "atomic_effect_execution",
                "all_demonstrations_exact",
                "causal_step_minimality",
                "no_task_identifier",
                "no_test_target_access",
            ],
            "propositions": [step.to_dict() for step in self.steps],
            "corollary": "compose propositions from left to right",
            "common_notions": [n.to_dict() for n in self.common_notions],
            "adequacy": {
                "demonstrations_exact": all(p["exact"] for p in proofs) if proofs else None,
                "causally_minimal": self.causally_minimal_for(training_pairs) if training_pairs else None,
                "description_length": self.description_length,
                "permissiveness_cost": self.permissiveness_cost,
            },
            "proofs": proofs,
        }


# ---------------------------------------------------------------------------
# Definitions and common notions
# ---------------------------------------------------------------------------


def definition_for(relation: str):
    spec = RELATIONAL_TRANSPORT_RELATIONS.get(relation)
    if spec is None:
        raise Inapplicable("unknown definition: " + relation)
    return Definition(
        relation,
        "Grid",
        "Grid",
        spec.kind,
        (
            "provider preconditions must hold",
            "result remains in the original coordinate frame",
            "conflicting writes are rejected",
            "effect is emitted through the shared transport executor",
        ),
    )


def definitions_registry():
    return tuple(definition_for(name) for name in sorted(RELATIONAL_TRANSPORT_RELATIONS))


def _modal(g: Grid):
    counts = Counter(v for row in g for v in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = counts.most_common()
    if len(top) > 1 and top[0][1] == top[1][1]:
        raise Inapplicable("ambiguous modal background")
    return top[0][0]


def _fingerprint(g: Grid):
    g = grid(g)
    counts = Counter(v for row in g for v in row)
    return (len(g), len(g[0]), tuple(sorted(counts.items())))


def _transition_stats(a: Grid, y: Grid):
    a, y = grid(a), grid(y)
    if len(a) != len(y) or len(a[0]) != len(y[0]):
        return {"changed": 0, "added": 0, "removed": 0, "recoloured": 0}
    try:
        bg_a, bg_y = _modal(a), _modal(y)
    except Inapplicable:
        bg_a = bg_y = None
    changed = added = removed = recoloured = 0
    for r, row in enumerate(a):
        for c, v in enumerate(row):
            w = y[r][c]
            if v == w:
                continue
            changed += 1
            if bg_a is not None and v == bg_a and w != bg_y:
                added += 1
            elif bg_y is not None and v != bg_a and w == bg_y:
                removed += 1
            else:
                recoloured += 1
    return {"changed": changed, "added": added, "removed": removed, "recoloured": recoloured}


def mine_common_notions(pairs: Iterable[tuple[Grid, Grid]]):
    """Mine conservative transition properties common to every demonstration."""
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs:
        return ()
    notions = []
    n = len(pairs)
    if all(len(a) == len(y) and len(a[0]) == len(y[0]) for a, y in pairs):
        notions.append(CommonNotion("canvas_shape", "preserved", n))
    palette_relations = []
    count_signs = []
    for a, y in pairs:
        pa = {v for row in a for v in row}
        py = {v for row in y for v in row}
        if py == pa:
            palette_relations.append("equal")
        elif py <= pa:
            palette_relations.append("no_novel_colours")
        else:
            palette_relations.append("novel_colours")
        try:
            ba, by = _modal(a), _modal(y)
            ca = sum(v != ba for row in a for v in row)
            cy = sum(v != by for row in y for v in row)
            count_signs.append("preserved" if ca == cy else "increased" if cy > ca else "decreased")
        except Inapplicable:
            count_signs.append("unresolved")
    if len(set(palette_relations)) == 1:
        notions.append(CommonNotion("palette_relation", palette_relations[0], n))
    if len(set(count_signs)) == 1:
        notions.append(CommonNotion("nonbackground_material", count_signs[0], n))
    if all(a != y for a, y in pairs):
        notions.append(CommonNotion("effect", "non_identity", n))
    return tuple(notions)


# ---------------------------------------------------------------------------
# Input-only primitive discovery
# ---------------------------------------------------------------------------


def _program_key(p: RelationalTransportProgram):
    return (p.relation, tuple(p.parameters), p.motion, p.source_policy)


def _program_sort_key(p: RelationalTransportProgram):
    relation_order = {
        "dual_anchor": 10,
        "periodic_guide": 20,
        "pivot_hinge": 30,
        "support_path": 40,
        "homologous_reference": 50,
        "homologous_reference_set": 60,
        "contained_reference_set": 70,
        "aligned_reference_set": 80,
        "dihedral_completion": 90,
    }
    return (relation_order.get(p.relation, 999), len(p.parameters), repr(p.parameters), p.source_policy)


def _candidate_programs_from_input(value: Grid, allowed_relations=None):
    """Enumerate applicable primitive causes using only the current input state."""
    a = grid(value)
    allowed = set(allowed_relations) if allowed_relations is not None else set(RELATIONAL_TRANSPORT_RELATIONS)
    candidates = []

    def add(relation, parameters, motion="translate", policies=("move", "copy")):
        if relation not in allowed:
            return
        for policy in policies:
            p = RelationalTransportProgram(relation, tuple(parameters), motion, policy)
            try:
                predicted = p.predict(a)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
            if predicted is not None and grid(predicted) != a:
                candidates.append(p)

    # The candidate generators below are input-derived and already used by the
    # validated V101-V107 fitters.  No demonstration output or task ID is used.
    try:
        bg = _modal(a)
        colours = sorted({v for row in a for v in row if v != bg})
    except Inapplicable:
        return ()

    if "dual_anchor" in allowed:
        for anchor in sorted({v for row in a for v in row}):
            add("dual_anchor", (anchor,))

    if "periodic_guide" in allowed:
        for params in scene_programs._rt_guide_params_from_input(a):
            add("periodic_guide", params)

    if "pivot_hinge" in allowed and len(colours) == 3:
        for roles in permutations(colours, 3):
            add("pivot_hinge", roles, "quarter_turn_tail")

    if "support_path" in allowed:
        for params in scene_programs._rt_support_params_from_input(a):
            add("support_path", params)

    if "homologous_reference" in allowed:
        for params in scene_programs._rt_homologous_params_from_input(a):
            add("homologous_reference", params)

    if "homologous_reference_set" in allowed:
        for params in scene_programs._rt_homologous_set_params_from_input(a):
            add("homologous_reference_set", params)

    if "contained_reference_set" in allowed:
        for params in scene_programs._rt_graph_role_params_from_input(a, "contains", 2):
            add("contained_reference_set", params)

    if "aligned_reference_set" in allowed:
        for axis, relation in (("row", "aligned_row_center"), ("col", "aligned_col_center")):
            for reference, payload, minimum in scene_programs._rt_graph_role_params_from_input(a, relation, 2):
                add("aligned_reference_set", (reference, payload, axis, minimum))

    if "dihedral_completion" in allowed:
        for params in scene_programs._rt_dihedral_completion_params_from_input(a):
            add("dihedral_completion", params, "dihedral_closure", policies=("copy",))

    # Exact duplicate instructions merge, while structurally distinct programs remain.
    unique = {_program_key(p): p for p in candidates}
    return tuple(sorted(unique.values(), key=_program_sort_key))


def _common_programs(states: Sequence[Grid], allowed_relations=None):
    maps = []
    for state in states:
        here = {_program_key(p): p for p in _candidate_programs_from_input(state, allowed_relations)}
        if not here:
            return ()
        maps.append(here)
    keys = set(maps[0])
    for m in maps[1:]:
        keys &= set(m)
    return tuple(sorted((maps[0][k] for k in keys), key=_program_sort_key))


# ---------------------------------------------------------------------------
# Geometrical search and adequacy
# ---------------------------------------------------------------------------


def fit_spinoza_compositions(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    max_steps: int = 2,
    allowed_relations=None,
    allowed_relation_chains=None,
    max_first_candidates: int = 256,
):
    """Derive minimal exact compositions from common typed primitives.

    V108 intentionally admits only genuinely compositional programs (two steps).
    This prevents the philosophical layer from merely renaming V107 one-step laws.
    """
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if len(pairs) < minimum_pairs or max_steps != 2:
        return []
    if any(len(a) != len(y) or len(a[0]) != len(y[0]) for a, y in pairs):
        return []
    if not any(a != y for a, y in pairs):
        return []

    relation_chains = None
    if allowed_relation_chains is not None:
        relation_chains = {tuple(chain) for chain in allowed_relation_chains}

    notions = mine_common_notions(pairs)
    first_candidates = _common_programs([a for a, _ in pairs], allowed_relations)
    models = []
    examined = 0
    for first in first_candidates[:max_first_candidates]:
        if relation_chains is not None and not any(chain and chain[0] == first.relation for chain in relation_chains):
            continue
        intermediate = []
        failed = False
        for a, _ in pairs:
            try:
                value = first.predict(a)
            except (Inapplicable, ValueError, IndexError, TypeError):
                failed = True
                break
            if value is None or grid(value) == a:
                failed = True
                break
            intermediate.append(grid(value))
        if failed:
            continue

        second_candidates = _common_programs(intermediate, allowed_relations)
        for second in second_candidates:
            examined += 1
            chain = (first.relation, second.relation)
            if relation_chains is not None and chain not in relation_chains:
                continue
            steps = (CausalStep.from_program(first), CausalStep.from_program(second))
            program = CausalProgram(steps, notions)
            try:
                if not all(program.predict(a) == y for a, y in pairs):
                    continue
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
            if not program.causally_minimal_for(pairs):
                continue
            models.append(program)

    # Deduplicate laws and apply an explanatory simplicity prior.  Programs with
    # the minimum description length are retained; output consensus still decides.
    unique = {program.steps: program for program in models}
    models = list(unique.values())
    if models:
        best = min((p.description_length, p.permissiveness_cost) for p in models)
        models = [p for p in models if (p.description_length, p.permissiveness_cost) == best]
    models.sort(key=lambda p: tuple((s.relation, repr(s.parameters), s.source_policy) for s in p.steps))
    return models


def infer_spinoza(task, *, minimum_pairs=2, allowed_relation_chains=None):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    models = fit_spinoza_compositions(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_relation_chains=allowed_relation_chains,
    )
    groups = {}
    invalid = 0
    for model in models:
        predictions = []
        traces = []
        try:
            for case in clean["test"]:
                predicted, trace = model.derive(case["input"])
                if predicted is None:
                    raise Inapplicable("composition inapplicable to test input")
                predictions.append(predicted)
                traces.append(tuple(t.to_dict() for t in trace))
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups.setdefault(key, []).append(
            {
                **model.describe(tuple((grid(a), grid(y)) for a, y in pairs)),
                "test_derivations": [list(trace) for trace in traces],
            }
        )
        if len(groups) >= 2:
            break

    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    supporting = groups[chosen] if chosen else []
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[i]] if chosen else None,
            }
            for i in range(len(clean["test"]))
        ],
        "supporting_families": [SPINOZA_FAMILY] if chosen else [],
        "supporting_laws": supporting[:20],
        "witness_predictions": [
            [[[int(v) for v in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(models),
            "inapplicable_programs": invalid,
            "composition_depth": 2,
            "definitions_available": len(definitions_registry()),
            "proof_carrying": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def validate_spinoza(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterexamples": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "requires_two_demonstrations", "folds": [], "counterexamples": []}

    expected = [t["prediction"] for t in full["tests"]]
    chains = []
    for law in full.get("supporting_laws", ()):
        propositions = law.get("propositions", ())
        chain = tuple(p.get("definition") for p in propositions if p.get("definition"))
        if chain:
            chains.append(chain)
    allowed = tuple(sorted(set(chains)))

    folds = []
    for held, demo in enumerate(clean["train"]):
        fold = {
            "train": [d for i, d in enumerate(clean["train"]) if i != held],
            "test": [{"input": demo["input"]}] + clean["test"],
        }
        result = infer_spinoza(fold, minimum_pairs=1, allowed_relation_chains=allowed)
        predictions = [t["prediction"] for t in result["tests"]]
        folds.append(
            {
                "held_index": held,
                "status": result["status"],
                "held_example_exact": result["status"] == "unique" and predictions[0] == demo["output"],
                "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
                "joint_hypotheses": result["joint_hypotheses"],
            }
        )

    counterexamples = []
    for law in full.get("supporting_laws", ()):
        propositions = law.get("propositions", ())
        counterexamples.append(
            {
                "law": [p.get("definition") for p in propositions],
                "step_ablation_passed": bool(law.get("adequacy", {}).get("causally_minimal")),
                "all_training_proofs_exact": bool(law.get("adequacy", {}).get("demonstrations_exact")),
            }
        )

    passed = all(f["held_example_exact"] and f["test_prediction_stable"] for f in folds)
    passed = passed and all(
        c["step_ablation_passed"] and c["all_training_proofs_exact"] for c in counterexamples
    )
    return {
        "passed": passed,
        "reason": "passed" if passed else "adequacy_or_counterexample_failure",
        "folds": folds,
        "counterexamples": counterexamples,
    }
