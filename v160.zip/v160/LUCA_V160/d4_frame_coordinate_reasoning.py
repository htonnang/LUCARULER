"""LUCA V154: D4-aware frame-coordinate materialisation.

This family unifies four rectangle/frame-relative transformations under one
proof-carrying consequence operator:

    outline square + internal marker -> Chebyshev-distance phase field
    square outlines -> parity-conditioned interior fill
    solid/outline rectangles -> exterior buffer and enclosed-hole fill
    outer frame + parallel rails + payload -> perpendicular boundary bands

The family is task-ID blind and target blind. Colours, orientations, sizes,
marker positions, rail directions and object counts are inferred from the
training demonstrations or current input. No absolute demonstration
coordinates are stored.
"""
from __future__ import annotations

from dataclasses import dataclass
from collections import defaultdict
from itertools import permutations

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_d4_frame_coordinate_grammar"
LANGUAGE = "spinoza_d4_frame_coordinate_grammar_v154"
SCHEMA_VERSION = 1
OPERATOR = "d4_frame_coordinate_materialisation"
NODE_VOCABULARY = "outline_square_rectangle_marker_and_rail_nodes"
EDGE_VOCABULARY = "chebyshev_border_size_parity_enclosure_and_projection_edges"


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "d4_frame_coordinate_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "d4_frame_coordinates": True,
            "shared_frame_coordinate_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _common_input_colours(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes:
        return ()
    return tuple(sorted(set.intersection(*palettes)))


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int, connectivity: int = 4):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            neighbours = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
            if connectivity == 8:
                neighbours += [(r - 1, c - 1), (r - 1, c + 1), (r + 1, c - 1), (r + 1, c + 1)]
            for point in neighbours:
                if point in remaining:
                    remaining.remove(point)
                    component.add(point)
                    stack.append(point)
        output.append(frozenset(component))
    output.sort(key=lambda comp: (_bbox(comp), len(comp)))
    return tuple(output)


def _outline_cells(box):
    r0, c0, r1, c1 = box
    return {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }


def _solid_cells(box):
    r0, c0, r1, c1 = box
    return {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}


def _outline_rectangle(component, *, square=False):
    box = _bbox(component)
    r0, c0, r1, c1 = box
    height, width = r1 - r0 + 1, c1 - c0 + 1
    if height < 3 or width < 3:
        raise Inapplicable("outline rectangle is too small")
    if square and height != width:
        raise Inapplicable("a square outline is required")
    if set(component) != _outline_cells(box):
        raise Inapplicable("component is not a one-cell outline rectangle")
    return box


def _strict_interior(box):
    r0, c0, r1, c1 = box
    return {(r, c) for r in range(r0 + 1, r1) for c in range(c0 + 1, c1)}


def _periodic_coordinate_extension(coordinates, length):
    coordinates = sorted(set(coordinates))
    if not coordinates:
        raise Inapplicable("payload coordinates are required")
    runs = []
    start = previous = coordinates[0]
    for value in coordinates[1:]:
        if value == previous + 1:
            previous = value
            continue
        runs.append((start, previous))
        start = previous = value
    runs.append((start, previous))
    if len(runs) < 2:
        raise Inapplicable("at least two repeated payload runs are required")
    widths = {end - start + 1 for start, end in runs}
    if len(widths) != 1:
        raise Inapplicable("payload runs must share one width")
    width = next(iter(widths))
    starts = [start for start, _ in runs]
    periods = {b - a for a, b in zip(starts, starts[1:])}
    if len(periods) != 1:
        raise Inapplicable("payload runs must share one period")
    period = next(iter(periods))
    if period <= width:
        raise Inapplicable("payload runs require a nonempty gap")
    expected_observed = {x for x in range(coordinates[0], coordinates[-1] + 1) if (x - starts[0]) % period < width}
    if expected_observed != set(coordinates):
        raise Inapplicable("payload coordinates do not form a complete periodic phase")
    extended = tuple(x for x in range(length) if (x - starts[0]) % period < width)
    return period, width, extended


def _expanded_perimeter(box, h, w):
    r0, c0, r1, c1 = box
    expanded = (r0 - 1, c0 - 1, r1 + 1, c1 + 1)
    er0, ec0, er1, ec1 = expanded
    if er0 < 0 or ec0 < 0 or er1 >= h or ec1 >= w:
        raise Inapplicable("one-cell exterior buffer must fit inside the canvas")
    return expanded, _outline_cells(expanded)


@dataclass(frozen=True)
class MarkerChebyshevPhaseProgram:
    background: int
    frame_colour: int
    odd_colour: int
    even_colour: int

    kind = "marker_chebyshev_phase_field"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.frame_colour, self.odd_colour, self.even_colour

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.frame_colour}:
            raise Inapplicable("the input must contain one frame role and one background role")
        h, w = _shape(value)
        coloured = {(r, c) for r in range(h) for c in range(w) if value[r][c] == self.frame_colour}
        box = _bbox(coloured)
        r0, c0, r1, c1 = box
        if r1 - r0 != c1 - c0 or r1 - r0 + 1 < 5:
            raise Inapplicable("a square frame of side at least five is required")
        border = _outline_cells(box)
        if not all(value[r][c] == self.frame_colour for r, c in border):
            raise Inapplicable("the complete outer square frame is required")
        interior_markers = sorted(coloured - border)
        if len(interior_markers) != 1:
            raise Inapplicable("exactly one same-colour interior marker is required")
        marker = interior_markers[0]
        interior = _strict_interior(box)
        if marker not in interior:
            raise Inapplicable("the marker must lie strictly inside the frame")
        if any(value[r][c] != self.background for r, c in interior - {marker}):
            raise Inapplicable("all non-marker interior cells must be background")
        if any(value[r][c] != self.background for r in range(h) for c in range(w) if (r, c) not in border | interior):
            raise Inapplicable("material outside the square frame is not supported")
        return box, marker

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        box, (mr, mc) = self._scene(value)
        output = _array(value)
        for r, c in _strict_interior(box):
            if (r, c) == (mr, mc):
                continue
            distance = max(abs(r - mr), abs(c - mc))
            output[r][c] = self.odd_colour if distance % 2 else self.even_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a square outline with one same-colour marker in its strict interior",
            relation_chain=(
                "extract the complete square frame and unique interior marker",
                "assign every strict-interior cell its Chebyshev distance from the marker",
                "partition positive distances by odd/even phase",
                "materialise the two learned phase colours while preserving frame and marker",
            ),
            parameters={
                "background": self.background,
                "frame_colour": self.frame_colour,
                "odd_distance_colour": self.odd_colour,
                "even_distance_colour": self.even_colour,
            },
            corollary="Fill the framed interior by marker-centred Chebyshev-distance parity.",
            notions=["square frame", "interior marker", "Chebyshev distance", "phase parity", "D4 equivariance"],
        )


@dataclass(frozen=True)
class SquareSizeParityFillProgram:
    background: int
    outline_colour: int
    odd_colour: int
    even_colour: int

    kind = "square_size_parity_interior_fill"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.outline_colour, self.odd_colour, self.even_colour

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.outline_colour}:
            raise Inapplicable("the input must contain square outlines on one background")
        boxes = []
        for component in _components_of_colour(value, self.outline_colour):
            box = _outline_rectangle(component, square=True)
            if any(value[r][c] != self.background for r, c in _strict_interior(box)):
                raise Inapplicable("square interiors must be empty in the input")
            boxes.append(box)
        if not boxes:
            raise Inapplicable("at least one square outline is required")
        return tuple(boxes)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        boxes = self._scene(value)
        output = _array(value)
        for box in boxes:
            side = box[2] - box[0] + 1
            fill = self.odd_colour if side % 2 else self.even_colour
            for r, c in _strict_interior(box):
                output[r][c] = fill
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more empty square outlines on a shared background",
            relation_chain=(
                "extract each one-cell square outline and its side length",
                "classify the square by odd/even side-length parity",
                "map parity to the two learned semantic fill colours",
                "fill each strict interior while preserving the outline",
            ),
            parameters={
                "background": self.background,
                "outline_colour": self.outline_colour,
                "odd_side_fill": self.odd_colour,
                "even_side_fill": self.even_colour,
            },
            corollary="Fill each square according to the parity of its side length.",
            notions=["square outline", "side-length parity", "strict interior", "size-invariant materialisation"],
        )


@dataclass(frozen=True)
class RectangleBufferHoleProgram:
    background: int
    source_colour: int
    buffer_colour: int
    hole_colour: int

    kind = "rectangle_exterior_buffer_and_hole_fill"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.source_colour, self.buffer_colour, self.hole_colour

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.source_colour}:
            raise Inapplicable("the input must contain one rectangle colour and one background")
        h, w = _shape(value)
        records = []
        expanded_sets = []
        for component in _components_of_colour(value, self.source_colour):
            box = _bbox(component)
            border = _outline_cells(box)
            if not border.issubset(component):
                raise Inapplicable("each component must contain a complete rectangle perimeter")
            if not set(component).issubset(_solid_cells(box)):
                raise Inapplicable("rectangle material must remain inside its bounding box")
            holes = frozenset((r, c) for r, c in _strict_interior(box) if value[r][c] == self.background)
            solid = not holes
            outline_or_partial = bool(holes)
            expanded_box, expanded_border = _expanded_perimeter(box, h, w)
            if any(value[r][c] != self.background for r, c in expanded_border):
                raise Inapplicable("the exterior buffer must be empty in the input")
            for other in expanded_sets:
                if expanded_border & other:
                    raise Inapplicable("expanded rectangle buffers must not overlap")
            expanded_sets.append(expanded_border)
            records.append((box, solid, outline_or_partial, expanded_box, expanded_border, holes))
        if not records:
            raise Inapplicable("at least one rectangle is required")
        return tuple(records)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        records = self._scene(value)
        output = _array(value)
        for box, _, outline_or_partial, _, expanded_border, holes in records:
            for r, c in expanded_border:
                output[r][c] = self.buffer_colour
            if outline_or_partial:
                for r, c in holes:
                    output[r][c] = self.hole_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="disjoint solid and outline rectangles with one-cell exterior clearance",
            relation_chain=(
                "extract every solid or one-cell outline rectangle",
                "construct its one-cell exterior perimeter",
                "materialise the learned buffer colour around every rectangle",
                "fill only enclosed outline interiors with the learned hole colour",
            ),
            parameters={
                "background": self.background,
                "source_colour": self.source_colour,
                "buffer_colour": self.buffer_colour,
                "hole_colour": self.hole_colour,
            },
            corollary="Buffer every rectangle externally and fill only enclosed holes.",
            notions=["rectangle support", "exterior perimeter", "enclosure", "strict interior", "ownership"],
        )


@dataclass(frozen=True)
class FrameRailProjectionProgram:
    background: int
    rail_colour: int
    payload_colour: int

    kind = "frame_rail_payload_projection"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.rail_colour, self.payload_colour

    def _scene(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        palette = _palette(value)
        if self.background not in palette or self.rail_colour not in palette or self.payload_colour not in palette:
            raise Inapplicable("background, rail and payload roles are required")
        remaining = palette - {self.background, self.rail_colour, self.payload_colour}
        if len(remaining) != 1:
            raise Inapplicable("one dynamic outer-frame colour is required")
        frame_colour = next(iter(remaining))
        perimeter = {(0, c) for c in range(w)} | {(h - 1, c) for c in range(w)} | {(r, 0) for r in range(h)} | {(r, w - 1) for r in range(h)}
        if not all(value[r][c] == frame_colour for r, c in perimeter):
            raise Inapplicable("the complete canvas perimeter must be the dynamic frame")

        rail_cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] == self.rail_colour}
        payload_cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] == self.payload_colour}
        if not rail_cells or not payload_cells:
            raise Inapplicable("parallel rails and payload material are required")

        rail_rows = sorted({r for r, _ in rail_cells})
        rail_cols = sorted({c for _, c in rail_cells})
        vertical = len(rail_cols) == 2 and rail_rows == list(range(1, h - 1)) and rail_cells == {(r, c) for r in range(1, h - 1) for c in rail_cols}
        horizontal = len(rail_rows) == 2 and rail_cols == list(range(1, w - 1)) and rail_cells == {(r, c) for r in rail_rows for c in range(1, w - 1)}
        if vertical == horizontal:
            raise Inapplicable("exactly one rail orientation is required")

        if vertical:
            low, high = rail_cols
            if high - low < 2:
                raise Inapplicable("vertical rails must enclose payload columns")
            if any(not (1 <= r < h - 1 and low < c < high) for r, c in payload_cells):
                raise Inapplicable("payload must lie strictly between vertical rails")
            if any(value[r][c] != self.background for r in range(1, h - 1) for c in range(1, w - 1)
                   if (r, c) not in rail_cells | payload_cells):
                raise Inapplicable("unsupported interior material")
            period, width, projected = _periodic_coordinate_extension({r for r, _ in payload_cells}, h)
            return frame_colour, "vertical", tuple(rail_cols), payload_cells, period, width, projected

        low, high = rail_rows
        if high - low < 2:
            raise Inapplicable("horizontal rails must enclose payload rows")
        if any(not (1 <= c < w - 1 and low < r < high) for r, c in payload_cells):
            raise Inapplicable("payload must lie strictly between horizontal rails")
        if any(value[r][c] != self.background for r in range(1, h - 1) for c in range(1, w - 1)
               if (r, c) not in rail_cells | payload_cells):
            raise Inapplicable("unsupported interior material")
        period, width, projected = _periodic_coordinate_extension({c for _, c in payload_cells}, w)
        return frame_colour, "horizontal", tuple(rail_rows), payload_cells, period, width, projected

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        frame_colour, orientation, rails, payload_cells, _, _, projected = self._scene(value)
        output = [[self.background for _ in range(w)] for _ in range(h)]
        if orientation == "vertical":
            for r in projected:
                for c in range(w):
                    output[r][c] = frame_colour
            for c in rails:
                for r in range(h):
                    output[r][c] = self.rail_colour
            low, high = rails
            for r in projected:
                for c in range(low + 1, high):
                    output[r][c] = self.payload_colour
        else:
            for c in projected:
                for r in range(h):
                    output[r][c] = frame_colour
            for r in rails:
                for c in range(w):
                    output[r][c] = self.rail_colour
            low, high = rails
            for c in projected:
                for r in range(low + 1, high):
                    output[r][c] = self.payload_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a dynamic outer frame, two parallel rails and payload material strictly between the rails",
            relation_chain=(
                "extract the perimeter colour and the orientation of the two complete parallel rails",
                "identify the rows or columns occupied by the payload between the rails",
                "project the perimeter colour through those orthogonal coordinates across the full canvas",
                "extend the rails through the canvas and restore the payload material",
            ),
            parameters={
                "background": self.background,
                "rail_colour": self.rail_colour,
                "payload_colour": self.payload_colour,
                "frame_colour": "input-derived perimeter role",
            },
            corollary="Convert payload coordinates between parallel rails into perpendicular full-canvas frame-colour bands.",
            notions=["outer frame", "parallel rails", "payload coordinate", "orthogonal projection", "D4 orientation"],
        )


def _candidate_added_colours(pairs, excluded):
    added = set()
    for source, target in pairs:
        added.update(_palette(target) - set(excluded) - _palette(source))
    return tuple(sorted(added))


def _fit_marker_phase(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background in common:
        for frame_colour in common:
            if frame_colour == background:
                continue
            added = sorted(set().union(*(_palette(t) for _, t in pairs)) - {background, frame_colour})
            if len(added) != 2:
                continue
            for odd_colour, even_colour in permutations(added):
                programme = MarkerChebyshevPhaseProgram(background, frame_colour, odd_colour, even_colour)
                markers = set()
                valid = True
                for source, target in pairs:
                    try:
                        _, marker = programme._scene(source)
                        markers.add(marker)
                        if programme.predict(source) != grid(target):
                            valid = False
                            break
                    except Inapplicable:
                        valid = False
                        break
                if valid and len(markers) >= min(2, len(pairs)):
                    output.append(programme)
    return output


def _fit_size_parity(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background in common:
        for outline_colour in common:
            if outline_colour == background:
                continue
            added = sorted(set().union(*(_palette(t) for _, t in pairs)) - {background, outline_colour})
            if len(added) != 2:
                continue
            for odd_colour, even_colour in permutations(added):
                programme = SquareSizeParityFillProgram(background, outline_colour, odd_colour, even_colour)
                parities = set()
                sizes = set()
                total = 0
                valid = True
                for source, target in pairs:
                    try:
                        boxes = programme._scene(source)
                        total += len(boxes)
                        for box in boxes:
                            side = box[2] - box[0] + 1
                            sizes.add(side)
                            parities.add(side % 2)
                        if programme.predict(source) != grid(target):
                            valid = False
                            break
                    except Inapplicable:
                        valid = False
                        break
                if valid and total >= 3 and parities == {0, 1} and len(sizes) >= 3:
                    output.append(programme)
    return output


def _fit_buffer_hole(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background in common:
        for source_colour in common:
            if source_colour == background:
                continue
            added = sorted(set().union(*(_palette(t) for _, t in pairs)) - {background, source_colour})
            if len(added) != 2:
                continue
            for buffer_colour, hole_colour in permutations(added):
                programme = RectangleBufferHoleProgram(background, source_colour, buffer_colour, hole_colour)
                kinds = set()
                boxes = set()
                valid = True
                for source, target in pairs:
                    try:
                        records = programme._scene(source)
                        for box, solid, outline_or_partial, _, _, holes in records:
                            kinds.add("solid" if solid else "outline_or_partial")
                            boxes.add((box[2] - box[0] + 1, box[3] - box[1] + 1, solid, outline_or_partial, len(holes)))
                        if programme.predict(source) != grid(target):
                            valid = False
                            break
                    except Inapplicable:
                        valid = False
                        break
                if valid and kinds == {"solid", "outline_or_partial"} and len(boxes) >= 3:
                    output.append(programme)
    return output


def _fit_rail_projection(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background, rail_colour, payload_colour in permutations(common, 3):
        programme = FrameRailProjectionProgram(background, rail_colour, payload_colour)
        orientations = set()
        frame_colours = set()
        valid = True
        for source, target in pairs:
            try:
                frame_colour, orientation, _, _, _, _, _ = programme._scene(source)
                frame_colours.add(frame_colour)
                orientations.add(orientation)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        orientation_evidence = orientations == {"vertical", "horizontal"} if len(pairs) >= 3 else bool(orientations)
        if valid and orientation_evidence and len(frame_colours) >= min(3, len(pairs)):
            output.append(programme)
    return output


_FITTERS = {
    "marker_chebyshev_phase_field": _fit_marker_phase,
    "square_size_parity_interior_fill": _fit_size_parity,
    "rectangle_exterior_buffer_and_hole_fill": _fit_buffer_hole,
    "frame_rail_payload_projection": _fit_rail_projection,
}


def fit_d4_frame_coordinate_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, MarkerChebyshevPhaseProgram):
                _, (r, c) = programme._scene(source)
                candidates.append((r, c, programme.background, "interior_marker"))
            elif isinstance(programme, SquareSizeParityFillProgram):
                box = programme._scene(source)[0]
                candidates.append((box[0], box[1], programme.background, "outline_corner"))
            elif isinstance(programme, RectangleBufferHoleProgram):
                box = programme._scene(source)[0][0]
                candidates.append((box[0], box[1], programme.background, "rectangle_corner"))
            elif isinstance(programme, FrameRailProjectionProgram):
                _, orientation, rails, _, _, _, _ = programme._scene(source)
                if orientation == "vertical":
                    candidates.append((1, rails[0], programme.background, "rail_cell"))
                else:
                    candidates.append((rails[0], 1, programme.background, "rail_cell"))
        except Inapplicable:
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {"cell": [r, c], "from": int(previous), "to": int(replacement), "role": role}
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {"kind": programme.kind, "rows": rows, "passed": bool(rows) and all(row["passed"] for row in rows)}


def infer_d4_frame_coordinate_grammar(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_d4_frame_coordinate_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "d4_frame_coordinates": True,
            "shared_frame_coordinate_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_d4_frame_coordinate_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_d4_frame_coordinate_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_d4_frame_coordinate_grammar(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
