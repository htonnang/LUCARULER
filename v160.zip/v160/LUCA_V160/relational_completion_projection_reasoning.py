"""LUCA V133: relational completion and projection algebra.

The family expresses a collection of ARC transformations through typed stages:
scene -> candidate/relation -> feature or instruction -> operator -> emission.
No task identifiers or test targets are available to inference.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from typing import Iterable

from runtime import public_task

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_relational_completion_projection_algebra"
LANGUAGE = "spinoza_relational_completion_projection_v1"
SCHEMA_VERSION = 1


class Inapplicable(ValueError):
    pass


def grid(value) -> Grid:
    return tuple(tuple(int(cell) for cell in row) for row in value)


def _array(value: Grid):
    return [list(row) for row in grid(value)]


def _shape(value: Grid):
    value = grid(value)
    return len(value), len(value[0])


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _candidate_backgrounds(pairs):
    candidates = None
    for source, _ in pairs:
        source = grid(source)
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_mode(source))
        except Inapplicable:
            pass
        corners = {source[0][0], source[0][-1], source[-1][0], source[-1][-1]}
        if len(corners) == 1:
            values.add(int(next(iter(corners))))
        candidates = values if candidates is None else candidates & values
    return tuple(sorted(candidates or ()))


def _dirs(connectivity=4):
    if connectivity == 4:
        return ((-1, 0), (1, 0), (0, -1), (0, 1))
    return tuple((dr, dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr, dc) != (0, 0))


def _bbox(cells):
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _crop(value: Grid, bbox):
    value = grid(value)
    r0, c0, r1, c1 = bbox
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_binary(cells):
    r0, c0, r1, c1 = _bbox(cells)
    support = set(cells)
    return tuple(tuple(1 if (r, c) in support else 0 for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _rot90(mask):
    return tuple(tuple(mask[len(mask) - 1 - r][c] for r in range(len(mask))) for c in range(len(mask[0])))


def _flip_h(mask):
    return tuple(tuple(reversed(row)) for row in mask)


def _d4_signature(mask):
    values = []
    current = tuple(tuple(int(x) for x in row) for row in mask)
    for _ in range(4):
        values.append(current)
        values.append(_flip_h(current))
        current = _rot90(current)
    return min(repr(value) for value in values)


def _components_same_colour(value: Grid, *, background: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or value[r][c] == background:
                continue
            colour = int(value[r][c])
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or value[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            box = _bbox(cells)
            components.append({
                "colour": colour,
                "cells": tuple(sorted(cells)),
                "bbox": box,
                "area": len(cells),
                "mask": _normalised_binary(cells),
            })
    components.sort(key=lambda item: item["bbox"])
    return components


def _components_foreground(value: Grid, *, background: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or value[r][c] == background:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or value[nr][nc] == background:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            box = _bbox(cells)
            components.append({
                "cells": tuple(sorted(cells)),
                "bbox": box,
                "area": len(cells),
                "mask": _normalised_binary(cells),
                "colours": tuple(sorted({value[rr][cc] for rr, cc in cells})),
            })
    components.sort(key=lambda item: item["bbox"])
    return components


def _hole_count(component):
    mask = component["mask"]
    h, w = len(mask), len(mask[0])
    seen = set()
    holes = 0
    for r in range(h):
        for c in range(w):
            if mask[r][c] or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            touches = False
            while stack:
                rr, cc = stack.pop()
                if rr in (0, h - 1) or cc in (0, w - 1):
                    touches = True
                for dr, dc in _dirs(4):
                    nr, nc = rr + dr, cc + dc
                    if 0 <= nr < h and 0 <= nc < w and not mask[nr][nc] and (nr, nc) not in seen:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            if not touches:
                holes += 1
    return holes


def _solid_rectangle(component):
    r0, c0, r1, c1 = component["bbox"]
    return component["area"] == (r1 - r0 + 1) * (c1 - c0 + 1)


def _fresh_colour(value, forbidden=()):
    used = _palette(value) | set(forbidden)
    for colour in range(1, 10):
        if colour not in used:
            return colour
    raise Inapplicable("no fresh ARC colour")


def _law(program, *, parameters, definitions, propositions, corollary, common_notions, validation_protocol=None):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "validation_protocol": validation_protocol or "held_exact_consensus_with_counterfactual_pruning",
        },
    }


# ---------------------------------------------------------------------------
# Component feature -> colour mapping.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ComponentFeatureRecolourProgram:
    background: int
    connectivity: int
    feature_kind: str
    mapping: tuple[tuple[int, int], ...]

    kind = "component_feature_recolour"

    @property
    def schema_key(self):
        return self.kind, self.background, self.connectivity, self.feature_kind, self.mapping

    def mapping_dict(self):
        return dict(self.mapping)

    def _features(self, value):
        value = grid(value)
        colours = _palette(value) - {self.background}
        if len(colours) != 1:
            raise Inapplicable("requires one source component colour")
        components = _components_same_colour(value, background=self.background, connectivity=self.connectivity)
        if len(components) < 2:
            raise Inapplicable("requires multiple components")
        if self.feature_kind == "hole_count":
            features = [_hole_count(component) for component in components]
        elif self.feature_kind == "is_singleton":
            features = [1 if component["area"] == 1 else 0 for component in components]
        elif self.feature_kind == "d4_class_frequency":
            signatures = [_d4_signature(component["mask"]) for component in components]
            counts = Counter(signatures)
            features = [counts[signature] for signature in signatures]
        else:
            raise Inapplicable("unknown component feature")
        return components, features

    def signatures(self, value):
        _, features = self._features(value)
        return tuple(sorted(set(features)))

    def predict(self, value):
        value = grid(value)
        components, features = self._features(value)
        mapping = self.mapping_dict()
        if any(feature not in mapping for feature in features):
            raise Inapplicable("unwitnessed component feature")
        work = _array(value)
        for component, feature in zip(components, features):
            colour = mapping[feature]
            for r, c in component["cells"]:
                work[r][c] = colour
        return tuple(tuple(row) for row in work)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "connectivity": self.connectivity,
                        "feature_kind": self.feature_kind,
                        "mapping": [{"feature": key, "colour": colour} for key, colour in self.mapping]},
            definitions={"candidate": "same-colour connected component", "feature": self.feature_kind,
                         "codebook": "witnessed mapping from feature value to output colour"},
            propositions=["Component support is preserved.", "Absolute position is irrelevant.",
                          "An unwitnessed feature value is rejected."],
            corollary="Recolour every component according to the witnessed structural feature codebook.",
            common_notions=["component", "structural feature", "codebook", "support preservation"],
            validation_protocol="witnessed_feature_codebook_plus_redundant_lodo",
        )


def _fit_component_feature_recolour(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        for connectivity in (4, 8):
            for feature_kind in ("hole_count", "is_singleton", "d4_class_frequency"):
                mapping = {}
                valid = True
                all_features = []
                source_colours = set()
                for source, target in pairs:
                    source, target = grid(source), grid(target)
                    if _shape(source) != _shape(target):
                        valid = False; break
                    colours = _palette(source) - {background}
                    if len(colours) != 1:
                        valid = False; break
                    source_colour = next(iter(colours)); source_colours.add(source_colour)
                    try:
                        probe = ComponentFeatureRecolourProgram(background, connectivity, feature_kind, tuple())
                        components, features = probe._features(source)
                    except Inapplicable:
                        valid = False; break
                    support = {cell for component in components for cell in component["cells"]}
                    target_support = {(r, c) for r, row in enumerate(target) for c, colour in enumerate(row) if colour != background}
                    if support != target_support:
                        valid = False; break
                    for component, feature in zip(components, features):
                        out_colours = {target[r][c] for r, c in component["cells"]}
                        if len(out_colours) != 1:
                            valid = False; break
                        out_colour = int(next(iter(out_colours)))
                        if feature in mapping and mapping[feature] != out_colour:
                            valid = False; break
                        mapping[feature] = out_colour
                        all_features.append(feature)
                    if not valid:
                        break
                if valid and len(mapping) >= 2 and len(set(all_features)) >= 2 and any(colour not in source_colours for colour in mapping.values()):
                    program = ComponentFeatureRecolourProgram(background, connectivity, feature_kind, tuple(sorted(mapping.items())))
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programs.append(program)
    return programs


# ---------------------------------------------------------------------------
# Swap two palette roles independently inside every object.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ComponentPaletteSwapProgram:
    background: int
    connectivity: int

    kind = "component_palette_swap"

    @property
    def schema_key(self):
        return self.kind, self.background, self.connectivity

    def predict(self, value):
        value = grid(value)
        components = _components_foreground(value, background=self.background, connectivity=self.connectivity)
        if not components:
            raise Inapplicable("no objects")
        work = _array(value)
        for component in components:
            colours = component["colours"]
            if len(colours) != 2:
                raise Inapplicable("every object must have two colours")
            first, second = colours
            for r, c in component["cells"]:
                work[r][c] = second if value[r][c] == first else first
        return tuple(tuple(row) for row in work)

    def describe(self, pairs):
        return _law(self, parameters={"background": self.background, "connectivity": self.connectivity},
            definitions={"object": "connected nonbackground component", "palette_roles": "the two colours inside one object"},
            propositions=["Object support is preserved.", "The two local palette roles are exchanged.", "The operation is involutive."],
            corollary="Swap the two colours independently inside each object.",
            common_notions=["object", "local palette", "involution"])


def _fit_component_palette_swap(pairs):
    programs=[]
    for background in _candidate_backgrounds(pairs):
        for connectivity in (4,8):
            program=ComponentPaletteSwapProgram(background,connectivity)
            try:
                if all(program.predict(source)==grid(target) for source,target in pairs):
                    # At least two object palettes across the task prevents a single fixed colour swap.
                    palettes=set()
                    for source,_ in pairs:
                        for component in _components_foreground(source,background=background,connectivity=connectivity):
                            palettes.add(component["colours"])
                    if len(palettes)>=2:
                        programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# Connect equal-colour border endpoints.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BorderPairConnectionProgram:
    background: int
    axis: str

    kind="matching_border_pair_connection"

    @property
    def schema_key(self): return self.kind,self.background,self.axis

    def predict(self,value):
        value=grid(value); h,w=_shape(value); work=_array(value); filled=0
        if self.axis=="horizontal":
            allowed={(r,0) for r in range(h)}|{(r,w-1) for r in range(h)}
            if any(value[r][c]!=self.background and (r,c) not in allowed for r in range(h) for c in range(w)):
                raise Inapplicable("interior evidence present")
            for r in range(h):
                left,right=value[r][0],value[r][w-1]
                if left!=self.background and left==right:
                    for c in range(w): work[r][c]=left
                    filled+=1
        else:
            allowed={(0,c) for c in range(w)}|{(h-1,c) for c in range(w)}
            if any(value[r][c]!=self.background and (r,c) not in allowed for r in range(h) for c in range(w)):
                raise Inapplicable("interior evidence present")
            for c in range(w):
                top,bottom=value[0][c],value[h-1][c]
                if top!=self.background and top==bottom:
                    for r in range(h): work[r][c]=top
                    filled+=1
        # Some demonstrations intentionally contain no matching pair.  They are
        # negative witnesses for the same relation, so the transformation is an
        # identity on that example rather than inapplicable.
        endpoint_count = sum(
            1 for r in range(h) for c in range(w)
            if value[r][c] != self.background and (
                (self.axis == "horizontal" and c in (0, w - 1)) or
                (self.axis == "vertical" and r in (0, h - 1))
            )
        )
        if endpoint_count < 4:
            raise Inapplicable("insufficient border endpoint evidence")
        return tuple(tuple(row) for row in work)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"axis":self.axis},
            definitions={"endpoint_pair":"same-colour cells on opposite borders"},
            propositions=["Only equal-colour endpoint pairs activate.","The complete interval between endpoints is filled."],
            corollary="Connect every matching border pair along the inferred axis.",
            common_notions=["border","correspondence","line completion"])


def _fit_border_pair_connection(pairs):
    programs=[]
    for bg in _candidate_backgrounds(pairs):
        for axis in ("horizontal","vertical"):
            p=BorderPairConnectionProgram(bg,axis)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): programs.append(p)
            except Inapplicable: pass
    return programs


# ---------------------------------------------------------------------------
# Block-lattice cross propagation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LatticeCrossPropagationProgram:
    background:int
    connectivity:int=4

    kind="lattice_cross_propagation"
    @property
    def schema_key(self): return self.kind,self.background,self.connectivity

    def analyse(self,value):
        value=grid(value)
        comps=_components_same_colour(value,background=self.background,connectivity=self.connectivity)
        if len(comps)<6 or not all(_solid_rectangle(c) for c in comps): raise Inapplicable("not a block lattice")
        row_origins=sorted({c["bbox"][0] for c in comps})
        col_origins=sorted({c["bbox"][1] for c in comps})
        if len(row_origins)<2 or len(col_origins)<2 or len(comps)!=len(row_origins)*len(col_origins):
            raise Inapplicable("components do not form a complete block lattice")
        if {(c["bbox"][0],c["bbox"][1]) for c in comps}!={(r,c) for r in row_origins for c in col_origins}:
            raise Inapplicable("missing lattice role")
        # Edge blocks may be clipped by the canvas.  Interior blocks must share
        # the maximal dimensions and all blocks must be positive rectangles.
        heights=[c["bbox"][2]-c["bbox"][0]+1 for c in comps]
        widths=[c["bbox"][3]-c["bbox"][1]+1 for c in comps]
        max_h,max_w=max(heights),max(widths)
        if max_h<1 or max_w<1 or any(h not in (max_h,1) for h in heights) or any(w not in (max_w,1) for w in widths):
            raise Inapplicable("inconsistent clipped block dimensions")
        counts=Counter(c["colour"] for c in comps)
        if len(counts)!=2: raise Inapplicable("requires base and marker colours")
        marker_colours=[colour for colour,count in counts.items() if count==1]
        if len(marker_colours)!=1: raise Inapplicable("marker colour not unique")
        marker_colour=marker_colours[0]
        marker=next(c for c in comps if c["colour"]==marker_colour)
        base_colour=next(colour for colour in counts if colour!=marker_colour)
        return comps,marker,marker_colour,base_colour

    def predict(self,value):
        value=grid(value); comps,marker,marker_colour,base_colour=self.analyse(value); work=_array(value)
        mr,mc,_,_=marker["bbox"]
        for comp in comps:
            r0,c0,_,_=comp["bbox"]
            colour=marker_colour if r0==mr or c0==mc else base_colour
            for r,c in comp["cells"]: work[r][c]=colour
        return tuple(tuple(row) for row in work)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background},
            definitions={"lattice_block":"solid congruent connected component","marker":"the unique minority-colour block"},
            propositions=["Block geometry is preserved.","Marker colour propagates along its logical block row and column."],
            corollary="Colour the marker's complete lattice cross.",common_notions=["lattice","row/column relation","propagation"])


def _fit_lattice_cross(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        p=LatticeCrossPropagationProgram(bg)
        try:
            if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
        except Inapplicable: pass
    return out


# ---------------------------------------------------------------------------
# Flood passable regions from coloured seeds.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SeedRegionFloodProgram:
    background:int
    barrier:int

    kind="seed_region_flood_fill"
    @property
    def schema_key(self): return self.kind,self.background,self.barrier

    def predict(self,value):
        value=grid(value); h,w=_shape(value); work=_array(value); seen=set(); filled=0; seeds=0
        for r in range(h):
            for c in range(w):
                if (r,c) in seen or value[r][c]==self.barrier: continue
                stack=[(r,c)]; seen.add((r,c)); cells=[]; seed_colours=set()
                while stack:
                    rr,cc=stack.pop(); cells.append((rr,cc))
                    if value[rr][cc] not in (self.background,self.barrier): seed_colours.add(value[rr][cc])
                    for dr,dc in _dirs(4):
                        nr,nc=rr+dr,cc+dc
                        if 0<=nr<h and 0<=nc<w and (nr,nc) not in seen and value[nr][nc]!=self.barrier:
                            seen.add((nr,nc)); stack.append((nr,nc))
                if len(seed_colours)>1: raise Inapplicable("conflicting seeds in one region")
                if len(seed_colours)==1:
                    colour=next(iter(seed_colours)); seeds+=1
                    for rr,cc in cells:
                        if work[rr][cc]==self.background:
                            work[rr][cc]=colour; filled+=1
        if seeds<1 or filled<1: raise Inapplicable("no seeded fill")
        return tuple(tuple(row) for row in work)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"barrier":self.barrier},
            definitions={"region":"4-connected cells not occupied by the barrier","seed":"nonbackground nonbarrier colour inside a region"},
            propositions=["Barrier cells are immutable.","A region with one seed colour is flooded by that colour.","Conflicting seeds are rejected."],
            corollary="Flood each barrier-bounded region from its unique seed colour.",common_notions=["region","barrier","seed","flood fill"])


def _fit_seed_flood(pairs):
    programs=[]
    for bg in _candidate_backgrounds(pairs):
        common=set.intersection(*(_palette(grid(s)) for s,_ in pairs)) if pairs else set()
        for barrier in sorted(common-{bg}):
            p=SeedRegionFloodProgram(bg,barrier)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): programs.append(p)
            except Inapplicable: pass
    return programs


# ---------------------------------------------------------------------------
# Aligned instruction compartments recolour payload compartments.
# ---------------------------------------------------------------------------


def _full_separator_lines(value, colour):
    value=grid(value); h,w=_shape(value)
    rows=[r for r in range(h) if all(value[r][c]==colour for c in range(w))]
    cols=[c for c in range(w) if all(value[r][c]==colour for r in range(h))]
    return rows,cols


def _intervals(length, separators):
    separators=set(separators); result=[]; start=0
    for index in range(length+1):
        if index==length or index in separators:
            if start<index: result.append((start,index-1))
            start=index+1
    return result


@dataclass(frozen=True)
class SeparatorAlignedMarkerRecolourProgram:
    background:int
    separator:int
    pattern_colour:int
    orientation:str

    kind="separator_aligned_marker_recolour"
    @property
    def schema_key(self): return self.kind,self.background,self.separator,self.pattern_colour,self.orientation

    def _regions(self,value):
        value=grid(value); h,w=_shape(value); rows,cols=_full_separator_lines(value,self.separator)
        if not rows and not cols: raise Inapplicable("no separator lattice")
        rints=_intervals(h,rows); cints=_intervals(w,cols)
        return rints,cints

    def predict(self,value):
        value=grid(value); work=_array(value); rints,cints=self._regions(value); paired=0

        def classify(cells):
            non=[(r,c,value[r][c]) for r,c in cells if value[r][c] not in (self.background,self.separator)]
            markers=[x for x in non if x[2]!=self.pattern_colour]
            patterns=[(r,c) for r,c,col in non if col==self.pattern_colour]
            if len(markers)==1 and not patterns:
                return ("marker",markers[0][2],())
            if patterns and not markers:
                return ("pattern",None,tuple(patterns))
            if not non:
                return ("empty",None,())
            return ("mixed",None,())

        if len(cints)==2 and len(rints)>=2:
            for r0,r1 in rints:
                compartments=[]
                for c0,c1 in cints:
                    cells=[(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1)]
                    compartments.append(classify(cells))
                kinds=[x[0] for x in compartments]
                if sorted(kinds)==["marker","pattern"]:
                    marker=next(x for x in compartments if x[0]=="marker")
                    pattern=next(x for x in compartments if x[0]=="pattern")
                    for r,c in pattern[2]: work[r][c]=marker[1]
                    paired+=1
                elif kinds!=["empty","empty"]:
                    raise Inapplicable("unaligned instruction/payload compartments")
        elif len(rints)==2 and len(cints)>=2:
            for c0,c1 in cints:
                compartments=[]
                for r0,r1 in rints:
                    cells=[(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1)]
                    compartments.append(classify(cells))
                kinds=[x[0] for x in compartments]
                if sorted(kinds)==["marker","pattern"]:
                    marker=next(x for x in compartments if x[0]=="marker")
                    pattern=next(x for x in compartments if x[0]=="pattern")
                    for r,c in pattern[2]: work[r][c]=marker[1]
                    paired+=1
                elif kinds!=["empty","empty"]:
                    raise Inapplicable("unaligned instruction/payload compartments")
        else:
            raise Inapplicable("no unique two-side instruction/payload layout")
        if paired<2: raise Inapplicable("insufficient aligned instruction/payload pairs")
        return tuple(tuple(row) for row in work)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"separator":self.separator,"pattern_colour":self.pattern_colour,"orientation":self.orientation},
            definitions={"instruction_compartment":"logical cell containing one marker","payload_compartment":"aligned cell containing the pattern colour"},
            propositions=["Separator material and marker cells are preserved.","The aligned payload is recoloured by its instruction marker."],
            corollary="Transfer each marker colour to the aligned payload compartment.",common_notions=["separator lattice","alignment","instruction","recolour"])


def _fit_separator_marker(pairs):
    programs=[]
    for bg in _candidate_backgrounds(pairs):
        common=set.intersection(*(_palette(grid(s)) for s,_ in pairs))
        for sep in sorted(common-{bg}):
            for pattern in sorted(common-{bg,sep}):
                for orientation in ("adaptive",):
                    p=SeparatorAlignedMarkerRecolourProgram(bg,sep,pattern,orientation)
                    try:
                        if all(p.predict(s)==grid(t) for s,t in pairs): programs.append(p)
                    except Inapplicable: pass
    return programs


# ---------------------------------------------------------------------------
# Compact layout projections.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ObjectFrequencyStaircaseProgram:
    background:int
    connectivity:int

    kind="object_frequency_staircase"
    @property
    def schema_key(self): return self.kind,self.background,self.connectivity

    def predict(self,value):
        value=grid(value); comps=_components_same_colour(value,background=self.background,connectivity=self.connectivity)
        if len(comps)<6 or not all(_solid_rectangle(c) for c in comps): raise Inapplicable("requires solid object inventory")
        counts=Counter(c["colour"] for c in comps)
        if len(counts)<3 or len(set(counts.values()))!=len(counts): raise Inapplicable("frequencies must be strict")
        ordered=sorted(counts.items(),key=lambda item:(-item[1],item[0])); width=ordered[0][1]
        rows=[]
        for colour,count in ordered:
            rows.append(tuple([self.background]*(width-count)+[colour]*count))
        return tuple(rows)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"connectivity":self.connectivity},
            definitions={"object_count":"number of solid connected objects of one colour"},
            propositions=["Colours are ordered by strictly decreasing object frequency.","Each row is a right-aligned unary count."],
            corollary="Emit the colour-frequency staircase.",common_notions=["object inventory","frequency","ranking","unary emission"])


def _fit_frequency_staircase(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        for conn in (4,8):
            p=ObjectFrequencyStaircaseProgram(bg,conn)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


@dataclass(frozen=True)
class ComponentHeightHistogramProgram:
    background:int
    connectivity:int

    kind="component_height_histogram"
    @property
    def schema_key(self): return self.kind,self.background,self.connectivity

    def predict(self,value):
        value=grid(value); comps=_components_same_colour(value,background=self.background,connectivity=self.connectivity)
        by_colour=defaultdict(list)
        for comp in comps: by_colour[comp["colour"]].append(comp)
        if len(by_colour)<3 or any(len(items)!=1 for items in by_colour.values()): raise Inapplicable("one object per colour required")
        records=[]
        for colour,items in by_colour.items():
            r0,c0,r1,c1=items[0]["bbox"]; records.append((r1-r0+1,colour))
        if len({height for height,_ in records})!=len(records): raise Inapplicable("heights must be strict")
        records.sort(reverse=True); height=records[0][0]; width=len(records)
        out=[[self.background]*width for _ in range(height)]
        for c,(extent,colour) in enumerate(records):
            for r in range(extent): out[r][c]=colour
        return tuple(tuple(row) for row in out)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"connectivity":self.connectivity},
            definitions={"height":"bounding-box height of the sole object of a colour"},
            propositions=["Object colours are ordered by strictly decreasing height.","Each output column is a top-aligned unary bar."],
            corollary="Emit the component-height histogram.",common_notions=["component","height","ranking","histogram"])


def _fit_height_histogram(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        for conn in (4,8):
            p=ComponentHeightHistogramProgram(bg,conn)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


@dataclass(frozen=True)
class ObjectQuadrantMontageProgram:
    background:int
    connectivity:int=8

    kind="object_quadrant_montage"
    @property
    def schema_key(self): return self.kind,self.background,self.connectivity

    def predict(self,value):
        value=grid(value); comps=_components_same_colour(value,background=self.background,connectivity=self.connectivity)
        if len(comps)!=4 or len({c["colour"] for c in comps})!=1: raise Inapplicable("requires four same-colour objects")
        dims={(c["bbox"][2]-c["bbox"][0]+1,c["bbox"][3]-c["bbox"][1]+1) for c in comps}
        if len(dims)!=1: raise Inapplicable("object boxes differ")
        oh,ow=next(iter(dims)); centers=[((c["bbox"][0]+c["bbox"][2])/2,(c["bbox"][1]+c["bbox"][3])/2,c) for c in comps]
        row_values=sorted(x[0] for x in centers); col_values=sorted(x[1] for x in centers)
        if row_values[1]>=row_values[2] or col_values[1]>=col_values[2]: raise Inapplicable("quadrants not separable")
        rcut=(row_values[1]+row_values[2])/2; ccut=(col_values[1]+col_values[2])/2
        slots={}
        for rr,cc,comp in centers:
            key=(0 if rr<rcut else 1,0 if cc<ccut else 1)
            if key in slots: raise Inapplicable("quadrant collision")
            slots[key]=_crop(value,comp["bbox"])
        if len(slots)!=4: raise Inapplicable("incomplete quadrants")
        out=[[self.background]*(2*ow+1) for _ in range(2*oh+1)]
        for (qr,qc),crop in slots.items():
            r0=qr*(oh+1); c0=qc*(ow+1)
            for r in range(oh):
                for c in range(ow): out[r0+r][c0+c]=crop[r][c]
        return tuple(tuple(row) for row in out)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background},
            definitions={"quadrant_object":"one of four equal-box same-colour 8-connected objects"},
            propositions=["Spatial rank determines one of four montage roles.","Each object crop is preserved."],
            corollary="Compress four spatially ranked objects into a 2×2 montage.",common_notions=["spatial rank","quadrant","canonical montage"])


def _fit_quadrant_montage(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        p=ObjectQuadrantMontageProgram(bg)
        try:
            if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
        except Inapplicable: pass
    return out


# ---------------------------------------------------------------------------
# Rectangular frame relations.
# ---------------------------------------------------------------------------


def _rectangular_frames(value,background):
    value=grid(value); frames=[]
    for comp in _components_same_colour(value,background=background,connectivity=4):
        r0,c0,r1,c1=comp["bbox"]; h=r1-r0+1; w=c1-c0+1
        if h<3 or w<3: continue
        border={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if r in (r0,r1) or c in (c0,c1)}
        if set(comp["cells"])==border:
            frames.append({**comp,"interior_shape":(h-2,w-2),"outer_shape":(h,w)})
    frames.sort(key=lambda x:x["bbox"])
    return frames


@dataclass(frozen=True)
class FrameInteriorExtractProgram:
    background:int
    fill_colour:int

    kind="frame_interior_extraction"
    @property
    def schema_key(self): return self.kind,self.background,self.fill_colour

    def predict(self,value):
        value=grid(value); frames=_rectangular_frames(value,self.background)
        if not frames: raise Inapplicable("no complete frames")
        h,w=_shape(value); out=[[self.background]*w for _ in range(h)]
        for frame in frames:
            r0,c0,r1,c1=frame["bbox"]
            for r in range(r0+1,r1):
                for c in range(c0+1,c1): out[r][c]=self.fill_colour
        return tuple(tuple(row) for row in out)

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"fill_colour":self.fill_colour},
            definitions={"frame":"complete monochrome rectangular border"},
            propositions=["Frame borders and unrelated objects are removed.","Every strict frame interior is projected in one learned colour."],
            corollary="Extract and colour all frame interiors.",common_notions=["frame","interior","projection"])


def _fit_frame_interior_extract(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        fill_candidates=None
        valid_frames=True
        for source,target in pairs:
            if not _rectangular_frames(source,bg): valid_frames=False; break
            colours=_palette(grid(target))-{bg}
            fill_candidates=colours if fill_candidates is None else fill_candidates & colours
        if not valid_frames: continue
        for fill in sorted(fill_candidates or ()): 
            p=FrameInteriorExtractProgram(bg,fill)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


@dataclass(frozen=True)
class LargestFrameMarkerCropProgram:
    background:int

    kind="largest_frame_marker_crop"
    @property
    def schema_key(self): return self.kind,self.background

    def predict(self,value):
        value=grid(value); frames=_rectangular_frames(value,self.background)
        if len(frames)<2: raise Inapplicable("requires multiple frames")
        areas=[((f["bbox"][2]-f["bbox"][0]+1)*(f["bbox"][3]-f["bbox"][1]+1),f) for f in frames]
        maximum=max(area for area,_ in areas); winners=[f for area,f in areas if area==maximum]
        if len(winners)!=1: raise Inapplicable("largest frame tied")
        frame=winners[0]; r0,c0,r1,c1=frame["bbox"]; crop=_crop(value,frame["bbox"])
        marker_colours=_palette(crop)-{self.background,frame["colour"]}
        if len(marker_colours)!=1: raise Inapplicable("marker colour not unique")
        marker=next(iter(marker_colours))
        out=tuple(tuple(marker if cell!=self.background else self.background for cell in row) for row in crop)
        return out

    def describe(self,pairs):
        return _law(self,parameters={"background":self.background},
            definitions={"selected_frame":"unique frame with maximum outer area","marker_colour":"unique non-frame colour inside the selected frame"},
            propositions=["The support inside the selected frame is preserved.","All selected support is recoloured by the marker."],
            corollary="Crop the largest frame and project its marker colour onto all material.",common_notions=["frame extremum","marker","crop","recolour"])


def _fit_largest_frame_crop(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        p=LargestFrameMarkerCropProgram(bg)
        try:
            if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
        except Inapplicable: pass
    return out


@dataclass(frozen=True)
class FrameDimensionCodebookProgram:
    background:int
    mapping:tuple[tuple[int,int],...]

    kind="frame_dimension_fill_codebook"
    @property
    def schema_key(self): return self.kind,self.background,self.mapping
    def mapping_dict(self): return dict(self.mapping)
    def signatures(self,value):
        frames=_rectangular_frames(value,self.background)
        if not frames: raise Inapplicable("no frames")
        return tuple(sorted({f["interior_shape"][0] for f in frames if f["interior_shape"][0]==f["interior_shape"][1]}))
    def predict(self,value):
        value=grid(value); frames=_rectangular_frames(value,self.background); mapping=self.mapping_dict(); work=_array(value)
        if not frames: raise Inapplicable("no frames")
        occupied=[]
        for f in frames:
            ih,iw=f["interior_shape"]
            if ih!=iw or ih not in mapping: raise Inapplicable("unwitnessed frame dimension")
            r0,c0,r1,c1=f["bbox"]; interior={(r,c) for r in range(r0+1,r1) for c in range(c0+1,c1)}
            if any(interior & prior for prior in occupied): raise Inapplicable("overlapping interiors")
            occupied.append(interior); colour=mapping[ih]
            for r,c in interior:
                if work[r][c]==self.background: work[r][c]=colour
        return tuple(tuple(row) for row in work)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"mapping":[{"interior_side":s,"fill_colour":c} for s,c in self.mapping]},
            definitions={"size_code":"witnessed square-frame interior side to fill-colour mapping"},
            propositions=["Frame material is preserved.","Only background interior cells are filled.","Unwitnessed dimensions are rejected."],
            corollary="Fill each square-frame interior according to the witnessed dimension codebook.",common_notions=["frame","dimension codebook","interior"],
            validation_protocol="witnessed_feature_codebook_plus_redundant_lodo")


def _fit_frame_dimension_codebook(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        mapping={}; valid=True; seen=0
        for source,target in pairs:
            source,target=grid(source),grid(target)
            if _shape(source)!=_shape(target): valid=False; break
            frames=_rectangular_frames(source,bg)
            if not frames: valid=False; break
            for f in frames:
                ih,iw=f["interior_shape"]
                if ih!=iw: valid=False; break
                r0,c0,r1,c1=f["bbox"]
                colours={target[r][c] for r in range(r0+1,r1) for c in range(c0+1,c1)}
                if len(colours)!=1: valid=False; break
                colour=next(iter(colours))
                if colour in (bg,f["colour"]): valid=False; break
                if ih in mapping and mapping[ih]!=colour: valid=False; break
                mapping[ih]=colour; seen+=1
            if not valid: break
        if valid and seen>=2 and len(mapping)>=2:
            p=FrameDimensionCodebookProgram(bg,tuple(sorted(mapping.items())))
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


# ---------------------------------------------------------------------------
# Geometric selectors and completion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BarExtremaRecolourProgram:
    background:int
    source_colour:int
    longest_colour:int
    shortest_colour:int

    kind="bar_extrema_recolour"
    @property
    def schema_key(self): return self.kind,self.background,self.source_colour,self.longest_colour,self.shortest_colour
    def _bars(self,value):
        value=grid(value); comps=_components_same_colour(value,background=self.background,connectivity=4)
        if len(comps)<3 or any(c["colour"]!=self.source_colour for c in comps): raise Inapplicable("requires monochrome bar inventory")
        for c in comps:
            r0,c0,r1,c1=c["bbox"]
            if c0!=c1 or c["area"]!=r1-r0+1: raise Inapplicable("requires vertical bars")
        return comps
    def predict(self,value):
        value=grid(value); comps=self._bars(value); lengths=[c["area"] for c in comps]; mn=min(lengths); mx=max(lengths)
        if lengths.count(mn)!=1 or lengths.count(mx)!=1 or mn==mx: raise Inapplicable("extrema tied")
        h,w=_shape(value); out=[[self.background]*w for _ in range(h)]
        for c in comps:
            colour=self.longest_colour if c["area"]==mx else self.shortest_colour if c["area"]==mn else self.background
            if colour!=self.background:
                for r,col in c["cells"]: out[r][col]=colour
        return tuple(tuple(row) for row in out)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"source_colour":self.source_colour,"longest_colour":self.longest_colour,"shortest_colour":self.shortest_colour},
            definitions={"bar":"vertical monochrome line component"},
            propositions=["Only the unique longest and shortest bars remain.","Their identities are recoloured by learned extremum roles."],
            corollary="Project the longest and shortest bars in their role colours.",common_notions=["bar","minimum","maximum","projection"])


def _fit_bar_extrema(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        source_colours=set.intersection(*((_palette(grid(s))-{bg}) for s,_ in pairs))
        for sc in source_colours:
            output_colours=set.intersection(*((_palette(grid(t))-{bg}) for _,t in pairs))
            for lc in output_colours:
                for shc in output_colours-{lc}:
                    p=BarExtremaRecolourProgram(bg,sc,lc,shc)
                    try:
                        if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
                    except Inapplicable: pass
    return out


@dataclass(frozen=True)
class CenterPayloadInMarkerBoxProgram:
    background:int
    marker_colour:int

    kind="centre_payload_in_marker_box"
    @property
    def schema_key(self): return self.kind,self.background,self.marker_colour
    def analyse(self,value):
        value=grid(value); markers=[]
        for comp in _components_same_colour(value,background=self.background,connectivity=4):
            if comp["colour"]==self.marker_colour and comp["area"]==1: markers.append(comp["cells"][0])
        if len(markers)!=4: raise Inapplicable("requires four corner markers")
        rows=sorted({r for r,c in markers}); cols=sorted({c for r,c in markers})
        if len(rows)!=2 or len(cols)!=2 or set(markers)!={(r,c) for r in rows for c in cols}: raise Inapplicable("markers do not form rectangle corners")
        payloads=[c for c in _components_same_colour(value,background=self.background,connectivity=4) if c["colour"]!=self.marker_colour]
        if len(payloads)!=1: raise Inapplicable("requires one payload")
        return rows,cols,payloads[0]
    def predict(self,value):
        value=grid(value); rows,cols,payload=self.analyse(value); h,w=_shape(value); out=_array(value)
        for r,c in payload["cells"]: out[r][c]=self.background
        r0,c0,r1,c1=payload["bbox"]; ph=r1-r0+1; pw=c1-c0+1
        nr0=(rows[0]+rows[1]-ph+1)//2; nc0=(cols[0]+cols[1]-pw+1)//2
        shift=(nr0-r0,nc0-c0)
        for r,c in payload["cells"]:
            nr,nc=r+shift[0],c+shift[1]
            if not (0<=nr<h and 0<=nc<w) or out[nr][nc]!=self.background: raise Inapplicable("centred payload collision")
            out[nr][nc]=payload["colour"]
        return tuple(tuple(row) for row in out)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"marker_colour":self.marker_colour},
            definitions={"marker_box":"four singleton markers at rectangle corners","payload":"the sole other connected object"},
            propositions=["Marker cells are preserved.","Payload shape and colour are preserved.","Payload bounding box is centred in the marker rectangle."],
            corollary="Centre the payload inside the four-marker box.",common_notions=["corner markers","centering","translation"])


def _fit_center_payload(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        marker_candidates=set.intersection(*((_palette(grid(s))-{bg}) for s,_ in pairs))
        for marker in marker_candidates:
            p=CenterPayloadInMarkerBoxProgram(bg,marker)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


@dataclass(frozen=True)
class BoundingBoxCompletionProgram:
    background:int
    fill_colour:int
    connectivity:int=4

    kind="component_bbox_completion"
    @property
    def schema_key(self): return self.kind,self.background,self.fill_colour,self.connectivity
    def predict(self,value):
        value=grid(value); comps=_components_same_colour(value,background=self.background,connectivity=self.connectivity)
        if len(comps)<2 or len({c["colour"] for c in comps})!=1: raise Inapplicable("requires multiple monochrome objects")
        work=_array(value); changed=0
        for comp in comps:
            r0,c0,r1,c1=comp["bbox"]
            for r in range(r0,r1+1):
                for c in range(c0,c1+1):
                    if work[r][c]==self.background: work[r][c]=self.fill_colour; changed+=1
        if changed<1: raise Inapplicable("nothing to complete")
        return tuple(tuple(row) for row in work)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"fill_colour":self.fill_colour,"connectivity":self.connectivity},
            definitions={"object_box":"bounding rectangle of one connected object"},
            propositions=["Original object cells are preserved.","Missing cells inside each object box receive the learned completion colour."],
            corollary="Complete every object bounding box.",common_notions=["component","bounding box","completion"])


def _fit_bbox_completion(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        common_out=set.intersection(*((_palette(grid(t))-{bg}) for _,t in pairs))
        candidates=[]
        for conn in (4,8):
            counts=[len(_components_same_colour(grid(s),background=bg,connectivity=conn)) for s,_ in pairs]
            # A stable object inventory is evidence for the intended connectivity;
            # this removes diagonal-fragment alternatives that only coincide on
            # the observed outputs.
            if len(set(counts))!=1 or counts[0]<2:
                continue
            for fill in common_out:
                p=BoundingBoxCompletionProgram(bg,fill,conn)
                try:
                    if all(p.predict(s)==grid(t) for s,t in pairs): candidates.append(p)
                except Inapplicable: pass
        out.extend(candidates)
    return out


@dataclass(frozen=True)
class GravityRightProgram:
    background:int

    kind="rigid_component_gravity_right"
    @property
    def schema_key(self): return self.kind,self.background
    def predict(self,value):
        value=grid(value); h,w=_shape(value); comps=_components_same_colour(value,background=self.background,connectivity=4)
        if len(comps)<3: raise Inapplicable("requires multiple rigid objects")
        comps=sorted(comps,key=lambda c:c["bbox"][3],reverse=True); out=[[self.background]*w for _ in range(h)]; occupied=set(); moved=0
        for comp in comps:
            max_shift=w-1-max(c for r,c in comp["cells"]); chosen=None
            for shift in range(max_shift,-1,-1):
                # A rigid object may not pass through an object that started to
                # its right.  Require the complete horizontal sweep, not only
                # the final placement, to be collision-free.
                sweep=set()
                for step in range(shift+1):
                    sweep.update((r,c+step) for r,c in comp["cells"])
                if not sweep & occupied:
                    chosen=shift; break
            if chosen is None: raise Inapplicable("no collision-free placement")
            moved += chosen
            for r,c in comp["cells"]:
                out[r][c+chosen]=comp["colour"]; occupied.add((r,c+chosen))
        if moved==0: raise Inapplicable("no object moves")
        return tuple(tuple(row) for row in out)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"direction":"right","connectivity":4},
            definitions={"rigid_object":"same-colour 4-connected component"},
            propositions=["Objects preserve shape and row coordinates.","Rightmost objects settle first.","Each object moves maximally right without overlap."],
            corollary="Apply rigid gravity to the right.",common_notions=["rigid object","gravity","collision"])


def _fit_gravity_right(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        p=GravityRightProgram(bg)
        try:
            if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
        except Inapplicable: pass
    return out


# ---------------------------------------------------------------------------
# Adjacent marker recolours a component and is removed.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AdjacentMarkerComponentRecolourProgram:
    background:int
    payload_colour:int

    kind="adjacent_marker_component_recolour"
    @property
    def schema_key(self): return self.kind,self.background,self.payload_colour
    def predict(self,value):
        value=grid(value); h,w=_shape(value); work=_array(value)
        payloads=[c for c in _components_same_colour(value,background=self.background,connectivity=4) if c["colour"]==self.payload_colour]
        markers=[c for c in _components_same_colour(value,background=self.background,connectivity=4) if c["colour"]!=self.payload_colour]
        if not payloads or not markers or any(m["area"]!=1 for m in markers): raise Inapplicable("requires payload components and singleton markers")
        changed=0
        for marker in markers:
            mr,mc=marker["cells"][0]; adjacent=[]
            for payload in payloads:
                if any(abs(r-mr)+abs(c-mc)==1 for r,c in payload["cells"]): adjacent.append(payload)
            work[mr][mc]=self.background
            if len(adjacent)==1:
                for r,c in adjacent[0]["cells"]: work[r][c]=marker["colour"]
                changed+=1
            elif len(adjacent)>1:
                raise Inapplicable("marker touches multiple payloads")
        if changed<1: raise Inapplicable("no marker recolours a payload")
        return tuple(tuple(row) for row in work)
    def describe(self,pairs):
        return _law(self,parameters={"background":self.background,"payload_colour":self.payload_colour},
            definitions={"marker":"singleton nonpayload colour","payload":"connected component in the shared payload colour"},
            propositions=["All markers are removed.","A marker recolours the unique payload component sharing an edge with it.","Nonadjacent payloads remain unchanged."],
            corollary="Transfer each adjacent marker colour to its payload.",common_notions=["adjacency","marker","payload","recolour"])


def _fit_adjacent_marker(pairs):
    out=[]
    for bg in _candidate_backgrounds(pairs):
        common=set.intersection(*((_palette(grid(s))-{bg}) for s,_ in pairs))
        for payload in common:
            p=AdjacentMarkerComponentRecolourProgram(bg,payload)
            try:
                if all(p.predict(s)==grid(t) for s,t in pairs): out.append(p)
            except Inapplicable: pass
    return out


# ---------------------------------------------------------------------------
# Fitting, inference, counterfactuals, validation.
# ---------------------------------------------------------------------------


FITTERS=(
    _fit_component_feature_recolour,
    _fit_component_palette_swap,
    _fit_border_pair_connection,
    _fit_lattice_cross,
    _fit_seed_flood,
    _fit_separator_marker,
    _fit_frequency_staircase,
    _fit_height_histogram,
    _fit_quadrant_montage,
    _fit_frame_interior_extract,
    _fit_largest_frame_crop,
    _fit_frame_dimension_codebook,
    _fit_bar_extrema,
    _fit_center_payload,
    _fit_bbox_completion,
    _fit_gravity_right,
    _fit_adjacent_marker,
)


def fit_relational_completion_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs=tuple((grid(s),grid(t)) for s,t in pairs)
    if len(pairs)<minimum_pairs: return ()
    programs=[]; seen=set()
    for fitter in FITTERS:
        for program in fitter(pairs):
            if allowed_kinds and program.kind not in allowed_kinds: continue
            if program.schema_key in seen: continue
            seen.add(program.schema_key); programs.append(program)
    return tuple(sorted(programs,key=lambda p:repr(p.schema_key)))


def _counterfactual(program,pairs):
    rows=[]
    for index,(source,target) in enumerate(pairs):
        source=grid(source); original=program.predict(source); passed=False; details={}
        try:
            if isinstance(program,ComponentFeatureRecolourProgram):
                comps,_=program._features(source); work=_array(source); r,c=comps[0]["cells"][0]; work[r][c]=program.background
                try: changed=program.predict(tuple(tuple(row) for row in work)); passed=changed!=original
                except Inapplicable: passed=True
                details={"feature_perturbation_changes_or_rejects":passed}
            elif isinstance(program,ComponentPaletteSwapProgram):
                passed=program.predict(original)==source; details={"involution":passed}
            elif isinstance(program,BorderPairConnectionProgram):
                work=_array(source); h,w=_shape(source); altered=False
                if program.axis=="horizontal":
                    matches=[r for r in range(h) if source[r][0]!=program.background and source[r][0]==source[r][w-1]]
                    if matches:
                        work[matches[0]][w-1]=_fresh_colour(source); altered=True
                    else:
                        mismatch=next((r for r in range(h) if source[r][0]!=program.background and source[r][w-1]!=program.background and source[r][0]!=source[r][w-1]),None)
                        if mismatch is not None: work[mismatch][w-1]=source[mismatch][0]; altered=True
                else:
                    matches=[c for c in range(w) if source[0][c]!=program.background and source[0][c]==source[h-1][c]]
                    if matches:
                        work[h-1][matches[0]]=_fresh_colour(source); altered=True
                    else:
                        mismatch=next((c for c in range(w) if source[0][c]!=program.background and source[h-1][c]!=program.background and source[0][c]!=source[h-1][c]),None)
                        if mismatch is not None: work[h-1][mismatch]=source[0][mismatch]; altered=True
                if not altered: raise Inapplicable("no endpoint intervention available")
                try: passed=program.predict(tuple(tuple(row) for row in work))!=original
                except Inapplicable: passed=True
                details={"endpoint_relation_changes_or_rejects":passed}
            elif isinstance(program,LatticeCrossPropagationProgram):
                comps,marker,marker_colour,base=program.analyse(source); fresh=_fresh_colour(source); work=_array(source)
                for r,c in marker["cells"]: work[r][c]=fresh
                changed=program.predict(tuple(tuple(row) for row in work)); passed=fresh in _palette(changed) and changed!=original
                details={"marker_recolour_equivariance":passed}
            elif isinstance(program,SeedRegionFloodProgram):
                seed=next((c for c in _components_same_colour(source,background=program.background,connectivity=4) if c["colour"]!=program.barrier),None)
                fresh=_fresh_colour(source); work=_array(source)
                for r,c in seed["cells"]: work[r][c]=fresh
                changed=program.predict(tuple(tuple(row) for row in work)); passed=fresh in _palette(changed) and changed!=original
                details={"seed_recolour_equivariance":passed}
            elif isinstance(program,SeparatorAlignedMarkerRecolourProgram):
                fresh=_fresh_colour(source); work=_array(source); changed_cell=None
                for r,row in enumerate(source):
                    for c,colour in enumerate(row):
                        if colour not in (program.background,program.separator,program.pattern_colour): changed_cell=(r,c); break
                    if changed_cell: break
                work[changed_cell[0]][changed_cell[1]]=fresh
                changed=program.predict(tuple(tuple(row) for row in work)); passed=fresh in _palette(changed) and changed!=original
                details={"instruction_recolour_equivariance":passed}
            elif isinstance(program,(ObjectFrequencyStaircaseProgram,ComponentHeightHistogramProgram)):
                comps=_components_same_colour(source,background=program.background,connectivity=program.connectivity); work=_array(source)
                comp=comps[0]
                for r,c in comp["cells"]: work[r][c]=program.background
                try: passed=program.predict(tuple(tuple(row) for row in work))!=original
                except Inapplicable: passed=True
                details={"inventory_change_changes_or_rejects":passed}
            elif isinstance(program,ObjectQuadrantMontageProgram):
                fresh=_fresh_colour(source); colour=next(iter(_palette(source)-{program.background})); recol=tuple(tuple(fresh if x==colour else x for x in row) for row in source)
                expected=tuple(tuple(fresh if x==colour else x for x in row) for row in original); passed=program.predict(recol)==expected
                details={"foreground_recolour_equivariance":passed}
            elif isinstance(program,FrameInteriorExtractProgram):
                frame=_rectangular_frames(source,program.background)[0]; work=_array(source); r,c=frame["cells"][0]; work[r][c]=program.background
                try: passed=program.predict(tuple(tuple(row) for row in work))!=original
                except Inapplicable: passed=True
                details={"frame_break_changes_or_rejects":passed}
            elif isinstance(program,LargestFrameMarkerCropProgram):
                frames=_rectangular_frames(source,program.background); frame=max(frames,key=lambda f:(f["bbox"][2]-f["bbox"][0]+1)*(f["bbox"][3]-f["bbox"][1]+1)); crop=_crop(source,frame["bbox"]); marker=next(iter(_palette(crop)-{program.background,frame["colour"]})); fresh=_fresh_colour(source); work=_array(source)
                r0,c0,r1,c1=frame["bbox"]
                for r in range(r0,r1+1):
                    for c in range(c0,c1+1):
                        if work[r][c]==marker: work[r][c]=fresh
                changed=program.predict(tuple(tuple(row) for row in work)); passed=fresh in _palette(changed) and changed!=original
                details={"marker_recolour_equivariance":passed}
            elif isinstance(program,FrameDimensionCodebookProgram):
                frame=_rectangular_frames(source,program.background)[0]; work=_array(source); r,c=frame["cells"][0]; work[r][c]=program.background
                try: passed=program.predict(tuple(tuple(row) for row in work))!=original
                except Inapplicable: passed=True
                details={"frame_break_changes_or_rejects":passed}
            elif isinstance(program,BarExtremaRecolourProgram):
                bars=sorted(program._bars(source),key=lambda c:c["area"],reverse=True)
                longest,second=bars[0],bars[1]; work=_array(source)
                # Shorten the unique longest bottom-anchored bar until it ties the
                # second longest.  The selector must then reject or change.
                remove=max(1,longest["area"]-second["area"])
                for r,c in sorted(longest["cells"])[:remove]: work[r][c]=program.background
                try: passed=program.predict(tuple(tuple(row) for row in work))!=original
                except Inapplicable: passed=True
                details={"extremum_tie_changes_or_rejects":passed}
            elif isinstance(program,CenterPayloadInMarkerBoxProgram):
                marker_rows,marker_cols,payload=program.analyse(source); work=_array(source)
                # Move payload one cell toward an available direction; output should re-centre identically.
                for r,c in payload["cells"]: work[r][c]=program.background
                shift=(0,1) if payload["bbox"][3]+1<_shape(source)[1] else (0,-1)
                ok=True
                for r,c in payload["cells"]:
                    nr,nc=r+shift[0],c+shift[1]
                    if work[nr][nc]!=program.background: ok=False; break
                if ok:
                    for r,c in payload["cells"]: work[r+shift[0]][c+shift[1]]=payload["colour"]
                    passed=program.predict(tuple(tuple(row) for row in work))==original
                details={"payload_translation_invariance":passed}
            elif isinstance(program,BoundingBoxCompletionProgram):
                colour=next(iter(_palette(source)-{program.background})); fresh=_fresh_colour(source); recol=tuple(tuple(fresh if x==colour else x for x in row) for row in source)
                changed=program.predict(recol); passed=changed!=original and fresh in _palette(changed)
                details={"source_recolour_equivariance":passed}
            elif isinstance(program,GravityRightProgram):
                # A settled result is a fixed point.  The implementation reports
                # no movement as inapplicable, which is an equivalent safe fixed
                # point witness.
                try: passed=program.predict(original)==original
                except Inapplicable: passed=True
                details={"gravity_fixed_point":passed}
            elif isinstance(program,AdjacentMarkerComponentRecolourProgram):
                payloads=[c for c in _components_same_colour(source,background=program.background,connectivity=4) if c["colour"]==program.payload_colour]
                markers=[c for c in _components_same_colour(source,background=program.background,connectivity=4) if c["colour"]!=program.payload_colour and c["area"]==1]
                marker=None
                for candidate in markers:
                    mr,mc=candidate["cells"][0]
                    adjacent=[payload for payload in payloads if any(abs(r-mr)+abs(c-mc)==1 for r,c in payload["cells"])]
                    if len(adjacent)==1:
                        marker=candidate; break
                if marker is None: raise Inapplicable("no causal marker")
                fresh=_fresh_colour(source); work=_array(source); r,c=marker["cells"][0]
                work[r][c]=fresh; changed=program.predict(tuple(tuple(row) for row in work)); passed=fresh in _palette(changed) and changed!=original
                details={"causal_marker_recolour_equivariance":passed}
        except (Inapplicable,StopIteration,IndexError,KeyError,ValueError):
            passed=False
        rows.append({"demonstration":index,"passed":bool(passed),**details})
    return {"kind":program.kind,"rows":rows,"passed":bool(rows) and all(row["passed"] for row in rows)}


def infer_relational_completion_projection(task, *, minimum_pairs=2, allowed_kinds=None):
    clean=public_task(task); pairs=tuple((d["input"],d["output"]) for d in clean["train"])
    programs=fit_relational_completion_programs(pairs,minimum_pairs=minimum_pairs,allowed_kinds=allowed_kinds)
    groups=defaultdict(list); invalid=0; rejected=0
    for program in programs:
        try:
            cf=_counterfactual(program,pairs)
            if not cf.get("passed"):
                rejected+=1; continue
            predictions=tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable,ValueError,IndexError,KeyError,TypeError,StopIteration,ZeroDivisionError):
            invalid+=1; continue
        law=program.describe(pairs); law["adequacy"]["counterfactual_passed"]=True
        groups[predictions].append(law)
    status="unique" if len(groups)==1 else "ambiguous" if groups else "no_fit"
    chosen=next(iter(groups)) if status=="unique" else None
    return {
        "status":status,"joint_hypotheses":len(groups),"joint_hypotheses_is_exact":len(groups)<2,
        "tests":[{"status":status,"prediction":[list(row) for row in chosen[i]] if chosen else None} for i in range(len(clean["test"]))],
        "supporting_families":[FAMILY] if chosen else [],"supporting_laws":groups.get(chosen,[])[:100] if chosen else [],
        "witness_predictions":[[[list(row) for row in pred] for pred in predictions] for predictions in list(groups)[:2]],
        "stats":{"fitted_programs":len(programs),"inapplicable_programs":invalid,"counterfactual_rejected_programs":rejected,
                 "schemas":sorted({law["schema"] for laws in groups.values() for law in laws}),"proof_carrying":True,
                 "relational_completion_projection_algebra":True,"task_ids_used":False,"test_targets_used":False,
                 "absolute_coordinates_stored":False},
    }


def _codebook_signatures(program,value):
    if isinstance(program,ComponentFeatureRecolourProgram): return program.signatures(value)
    if isinstance(program,FrameDimensionCodebookProgram): return program.signatures(value)
    return None


def _programs_for_expected(clean,full):
    expected=tuple(grid(x["prediction"]) for x in full["tests"])
    allowed=tuple(full.get("stats",{}).get("schemas",()))
    pairs=tuple((d["input"],d["output"]) for d in clean["train"])
    programs=[]
    for p in fit_relational_completion_programs(pairs,minimum_pairs=2,allowed_kinds=allowed):
        try:
            if tuple(p.predict(case["input"]) for case in clean["test"])==expected and _counterfactual(p,pairs).get("passed"):
                programs.append(p)
        except Inapplicable: pass
    return expected,programs


def _validate_program(clean,program,expected):
    full_pairs=tuple((d["input"],d["output"]) for d in clean["train"])
    signatures=[_codebook_signatures(program,d["input"]) for d in clean["train"]]
    codebook=all(sig is not None for sig in signatures)
    total=Counter(x for sig in signatures if sig is not None for x in sig)
    folds=[]
    for held_index,held in enumerate(clean["train"]):
        direct=False
        if codebook:
            counts=Counter(signatures[held_index]); direct=any(total[x]<=count for x,count in counts.items())
        if direct:
            exact=program.predict(held["input"])==grid(held["output"])
            folds.append({"held_index":held_index,"status":"unique" if exact else "no_fit","held_example_exact":exact,
                          "test_prediction_stable":True,"validation_mode":"singleton_direct_code_witness","signature_redundant":False})
            continue
        remaining=tuple((d["input"],d["output"]) for i,d in enumerate(clean["train"]) if i!=held_index)
        refitted=fit_relational_completion_programs(remaining,minimum_pairs=1,allowed_kinds=(program.kind,))
        groups=set(); held_exact=0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"])!=grid(held["output"]): continue
                if not _counterfactual(candidate,full_pairs).get("passed"): continue
                held_exact+=1; groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable: pass
        stable=len(groups)==1 and next(iter(groups),None)==expected
        folds.append({"held_index":held_index,"status":"unique" if held_exact and stable else "ambiguous" if len(groups)>1 else "no_fit",
                      "held_example_exact":bool(held_exact),"test_prediction_stable":stable,
                      "validation_mode":"redundant_witness_lodo" if codebook else "held_exact_consensus_with_counterfactual_pruning",
                      "signature_redundant":bool(codebook),"refitted_programs":len(refitted),"held_exact_prediction_groups":len(groups)})
    test_witnessed=True
    if codebook:
        mapping=set(dict(program.mapping).keys()) if hasattr(program,"mapping") else set()
        for case in clean["test"]:
            if any(sig not in mapping for sig in _codebook_signatures(program,case["input"])): test_witnessed=False
    cf=_counterfactual(program,full_pairs)
    passed=all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds) and test_witnessed and cf.get("passed")
    return {"passed":passed,"reason":"passed" if passed else "validation_failure","folds":folds,"counterfactuals":[cf],
            "validation_protocol":"mixed_witnessed_codebook_and_held_exact_consensus" if codebook else "held_exact_consensus_with_counterfactual_pruning",
            "test_signatures_witnessed":test_witnessed}


def validate_relational_completion_projection(task,full):
    clean=public_task(task)
    if full.get("status")!="unique": return {"passed":False,"reason":"full_fit_not_unique","folds":[],"counterfactuals":[]}
    expected,programs=_programs_for_expected(clean,full)
    if not programs: return {"passed":False,"reason":"missing_program_schema","folds":[],"counterfactuals":[]}
    checks=[_validate_program(clean,p,expected) for p in programs]
    passed=[c for c in checks if c.get("passed")]
    return passed[0] if passed else checks[0]


def relational_completion_projection_affordances(task):
    clean=public_task(task); pairs=tuple((d["input"],d["output"]) for d in clean["train"])
    return tuple(sorted({p.kind for p in fit_relational_completion_programs(pairs)}))


infer=infer_relational_completion_projection
validate=validate_relational_completion_projection
