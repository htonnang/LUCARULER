"""LUCA V141: reusable node/edge grammar and bounded two-step proof search.

Nine structurally distinct schemas reuse three consequence operators:

    scene -> typed nodes -> typed edges/relation -> shared operator -> grid

Inference is task-ID blind and test-target blind. Programmes store only semantic
roles, local tie policies, and input-derived graph constructions.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid
from learned_constructor_proof_search_reasoning import (
    _background, _palette, _bbox, _components, _monochrome_components,
    _canonical, _changed_colours,
)

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_reusable_node_edge_proof_search"
LANGUAGE = "spinoza_reusable_node_edge_proof_search_v141"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation, operator, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": relation,
            "operator": operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "reusable_node_edge_grammar": True,
            "bounded_two_step_proof_search": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _single_background_emission(pairs, *, require_new=True):
    paint = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        if _shape(source) != _shape(target):
            raise Inapplicable("shape changed")
        background = _background(source)
        colours = _changed_colours(source, target)
        if len(colours) != 1:
            raise Inapplicable("changes do not share one consequence colour")
        current = int(next(iter(colours)))
        if current == background or (require_new and current in _palette(source)):
            raise Inapplicable("invalid consequence role")
        changed = 0
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] != target[r][c]:
                    changed += 1
                    if source[r][c] != background or target[r][c] != current:
                        raise Inapplicable("not a background-only emission")
        if not changed:
            raise Inapplicable("identity")
        if paint is None:
            paint = current
        elif paint != current:
            raise Inapplicable("consequence role changes between demonstrations")
    if paint is None:
        raise Inapplicable("missing consequence role")
    return paint


def _runs(row, value):
    output = []
    start = None
    extended = list(row) + [None]
    for index, cell in enumerate(extended):
        if cell == value and start is None:
            start = index
        if start is not None and cell != value:
            output.append((start, index - 1))
            start = None
    return output


# ---------------------------------------------------------------------------
# Shared operator I: shape-envelope materialisation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LineDiameterDiamondProgram:
    paint_colour: int

    kind = "line_diameter_diamond_envelope"
    operator = "shape_envelope_materialisation"
    node_vocabulary = "monochrome_straight_segment"
    edge_vocabulary = "segment_endpoint_pair_as_diamond_diameter"

    @property
    def schema_key(self): return self.kind, self.paint_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _background(value)
        components = _monochrome_components(value)
        if len(_palette(value)) != 2 or not components or self.paint_colour in _palette(value):
            raise Inapplicable("binary segment field and new envelope role required")
        if len({component["colour"] for component in components}) != 1:
            raise Inapplicable("segment role is not unique")
        output = _array(value)
        emitted = 0
        h, w = _shape(value)
        for component in components:
            r0, c0, r1, c1 = component["bbox"]
            cells = component["cells"]
            if r0 == r1:
                if len(cells) != c1 - c0 + 1 or c1 - c0 < 2:
                    raise Inapplicable("horizontal segment is not solid or is too short")
                length = c1 - c0 + 1
                for distance in range(1, (length + 1) // 2):
                    lo, hi = c0 + distance, c1 - distance
                    if lo > hi: break
                    for r in (r0 - distance, r0 + distance):
                        if not 0 <= r < h: raise Inapplicable("diamond leaves canvas")
                        for c in range(lo, hi + 1):
                            if output[r][c] != background: raise Inapplicable("diamond collision")
                            output[r][c] = self.paint_colour; emitted += 1
            elif c0 == c1:
                if len(cells) != r1 - r0 + 1 or r1 - r0 < 2:
                    raise Inapplicable("vertical segment is not solid or is too short")
                length = r1 - r0 + 1
                for distance in range(1, (length + 1) // 2):
                    lo, hi = r0 + distance, r1 - distance
                    if lo > hi: break
                    for c in (c0 - distance, c0 + distance):
                        if not 0 <= c < w: raise Inapplicable("diamond leaves canvas")
                        for r in range(lo, hi + 1):
                            if output[r][c] != background: raise Inapplicable("diamond collision")
                            output[r][c] = self.paint_colour; emitted += 1
            else:
                raise Inapplicable("foreground component is not a straight segment")
        if not emitted: raise Inapplicable("empty envelope")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="straight monochrome segments over background",
            relation="segment endpoints define one axis-aligned diameter of a filled Manhattan diamond",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour},
            corollary="Materialise every non-diameter cell of the endpoint-defined diamond.",
            notions=["segment", "endpoint", "Manhattan envelope", "diameter"],
        )


@dataclass(frozen=True)
class ClippedDiamondCompletionProgram:
    paint_colour: int

    kind = "clipped_diamond_envelope_completion"
    operator = "shape_envelope_materialisation"
    node_vocabulary = "row_and_column_convex_component"
    edge_vocabulary = "constant_interval_midpoint_constraints"

    @property
    def schema_key(self): return self.kind, self.paint_colour

    @staticmethod
    def _diamond(value, cells):
        h, w = _shape(value)
        r0, c0, r1, c1 = _bbox(cells)
        row_sums, col_sums = set(), set()
        for r in range(r0, r1 + 1):
            columns = sorted(c for rr, c in cells if rr == r)
            if columns:
                if columns != list(range(columns[0], columns[-1] + 1)):
                    raise Inapplicable("component is not row-convex")
                row_sums.add(columns[0] + columns[-1])
        for c in range(c0, c1 + 1):
            rows = sorted(r for r, cc in cells if cc == c)
            if rows:
                if rows != list(range(rows[0], rows[-1] + 1)):
                    raise Inapplicable("component is not column-convex")
                col_sums.add(rows[0] + rows[-1])
        row_candidates = set(row_sums)
        col_candidates = set(col_sums)
        row_candidates |= {x - 1 for x in tuple(row_candidates)} | {x + 1 for x in tuple(row_candidates)}
        col_candidates |= {x - 1 for x in tuple(col_candidates)} | {x + 1 for x in tuple(col_candidates)}
        candidates = set()
        frozen = frozenset(cells)
        for center_r2 in col_candidates:
            for center_c2 in row_candidates:
                minimum_radius2 = max(abs(2 * r - center_r2) + abs(2 * c - center_c2) for r, c in cells)
                for radius2 in (minimum_radius2, minimum_radius2 + 1):
                    diamond = frozenset(
                        (r, c)
                        for r in range(h)
                        for c in range(w)
                        if abs(2 * r - center_r2) + abs(2 * c - center_c2) <= radius2
                    )
                    clipped = frozenset((r, c) for r, c in diamond if r0 <= r <= r1 and c0 <= c <= c1)
                    if clipped == frozen:
                        candidates.add(diamond)
        if len(candidates) != 1:
            raise Inapplicable("clipped component does not determine one diamond")
        return next(iter(candidates))

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _background(value)
        components = _monochrome_components(value)
        if len(_palette(value)) != 2 or not components or self.paint_colour in _palette(value):
            raise Inapplicable("binary clipped-shape field required")
        if len({component["colour"] for component in components}) != 1:
            raise Inapplicable("shape role is not unique")
        output = _array(value)
        emitted = 0
        for component in components:
            envelope = self._diamond(value, component["cells"])
            for r, c in envelope:
                if value[r][c] == background:
                    if output[r][c] != background: raise Inapplicable("envelope overlap")
                    output[r][c] = self.paint_colour; emitted += 1
        if not emitted: raise Inapplicable("no clipped envelope extension")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="row-and-column-convex components representing clipped Manhattan diamonds",
            relation="interval midpoint constraints recover a unique full diamond envelope",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour},
            corollary="Materialise the uniquely implied portion of each clipped diamond.",
            notions=["convex component", "interval midpoint", "clipping", "unique envelope"],
        )


@dataclass(frozen=True)
class NearestReferenceSquareProgram:
    paint_colour: int
    marker_colour: int
    reference_colour: int

    kind = "nearest_reference_square_envelope"
    operator = "shape_envelope_materialisation"
    node_vocabulary = "semantic_marker_and_reference_points"
    edge_vocabulary = "nearest_reference_under_Chebyshev_metric"

    @property
    def schema_key(self): return self.kind, self.paint_colour, self.marker_colour, self.reference_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        palette = _palette(value)
        if palette != {background, self.marker_colour, self.reference_colour} or self.paint_colour in palette:
            raise Inapplicable("three-role marker/reference scene required")
        markers = [(r, c) for r in range(h) for c in range(w) if value[r][c] == self.marker_colour]
        references = [(r, c) for r in range(h) for c in range(w) if value[r][c] == self.reference_colour]
        if not markers or not references: raise Inapplicable("missing marker or reference")
        output = _array(value)
        emitted = 0
        for r, c in markers:
            distance = min(max(abs(r - rr), abs(c - cc)) for rr, cc in references)
            if distance < 2: raise Inapplicable("reference is too close")
            radius = distance - 1
            for rr in range(max(0, r - radius), min(h, r + radius + 1)):
                for cc in range(max(0, c - radius), min(w, c + radius + 1)):
                    if output[rr][cc] == background:
                        output[rr][cc] = self.paint_colour; emitted += 1
        if not emitted: raise Inapplicable("empty square envelope")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="semantic marker points with spatial reference points",
            relation="nearest-reference Chebyshev distance defines square radius minus one",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour, "marker_colour": self.marker_colour, "reference_colour": self.reference_colour, "radius_rule": "distance_minus_one"},
            corollary="Materialise the marker-centred square implied by its nearest reference.",
            notions=["marker", "nearest reference", "Chebyshev distance", "square envelope"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: node/edge graph emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class OrderedGapChainProgram:
    kind = "ordered_gap_chain_completion"
    operator = "node_edge_graph_emission"
    node_vocabulary = "horizontal_one_cell_gaps_and_bottom_touching_vertical_seeds"
    edge_vocabulary = "same_column_total_order"

    @property
    def schema_key(self): return (self.kind,)

    @staticmethod
    def _runs_by_colour(row, background):
        result = defaultdict(list)
        start = None; colour = None
        for index, cell in enumerate(tuple(row) + (background,)):
            if cell != background and start is None:
                start, colour = index, cell
            if start is not None and (cell == background or cell != colour):
                result[int(colour)].append((start, index - 1))
                start = None; colour = None
                if cell != background:
                    start, colour = index, cell
        return result

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        nodes = defaultdict(list)
        for r, row in enumerate(value):
            for colour, runs in self._runs_by_colour(row, background).items():
                for left, right in zip(runs, runs[1:]):
                    if right[0] == left[1] + 2:
                        nodes[left[1] + 1].append((r, colour))
        seeds = {}
        for c in range(w):
            if value[h - 1][c] == background: continue
            colour = value[h - 1][c]
            start = h - 1
            while start - 1 >= 0 and value[start - 1][c] == colour:
                start -= 1
            seeds[c] = (start, int(colour))
        if not nodes or any(c not in seeds for c in nodes):
            raise Inapplicable("gap columns lack bottom seed roles")
        output = _array(value)
        for c, records in nodes.items():
            rowmap = {}
            for r, colour in records:
                if r in rowmap and rowmap[r] != colour:
                    raise Inapplicable("conflicting node colour at one row")
                rowmap[r] = colour
            ordered = sorted(rowmap.items())
            seed_start, seed_colour = seeds[c]
            if ordered[-1][0] >= seed_start:
                raise Inapplicable("seed does not follow the gap chain")
            for r in range(h):
                target = next((colour for rr, colour in ordered if rr >= r), seed_colour)
                if value[r][c] == background:
                    output[r][c] = target
                elif value[r][c] != target:
                    raise Inapplicable("chain crosses incompatible structural material")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="broken horizontal colour lanes and bottom-touching vertical seed lanes",
            relation="gap nodes and seed nodes form a top-to-bottom total order in each shared column",
            operator=self.operator,
            parameters={"interval_policy": "colour_of_next_node_below"},
            corollary="Complete every ordered vertical gap chain with the colour of its next node.",
            notions=["gap node", "seed node", "column order", "piecewise edge"],
        )


@dataclass(frozen=True)
class ObstacleRelocatedSpineProgram:
    spine_colour: int
    obstacle_colour: int

    kind = "obstacle_relocated_vertical_spines"
    operator = "node_edge_graph_emission"
    node_vocabulary = "top_touching_spines_and_horizontal_obstacle_runs"
    edge_vocabulary = "minimum_displacement_continuation_assignment"

    @property
    def schema_key(self): return self.kind, self.spine_colour, self.obstacle_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        if _palette(value) != {background, self.spine_colour, self.obstacle_colour}:
            raise Inapplicable("three-role spine/obstacle scene required")
        spines, ends = [], []
        for c in range(w):
            if value[0][c] != self.spine_colour: continue
            r = 0
            while r + 1 < h and value[r + 1][c] == self.spine_colour:
                r += 1
            spines.append(c); ends.append(r)
        if len(spines) < 2 or len(set(ends)) != 1:
            raise Inapplicable("top spines do not share one depth")
        top_end = ends[0]
        obstacle_rows = [r for r in range(top_end + 1, h) if self.obstacle_colour in value[r]]
        if len(obstacle_rows) != 1:
            raise Inapplicable("requires one obstacle row")
        obstacle_row = obstacle_rows[0]
        obstacle_runs = _runs(value[obstacle_row], self.obstacle_colour)
        if not obstacle_runs: raise Inapplicable("missing obstacle runs")
        mapping = {c: c for c in spines}
        for start, end in obstacle_runs:
            inside = sorted(c for c in spines if start <= c <= end)
            if not inside: continue
            targets = [c for c in (start - 1, end + 1) if 0 <= c < w]
            if len(inside) > len(targets) or len(inside) > 2:
                raise Inapplicable("obstacle cannot assign unique continuations")
            if len(inside) == 1:
                source = inside[0]
                mapping[source] = min(targets, key=lambda target: (abs(source - target), -target))
            else:
                targets = sorted(targets)
                mapping[inside[0]], mapping[inside[1]] = targets[0], targets[1]
        output = _array(value)
        for source in spines:
            target = mapping[source]
            start_row = top_end + 1 if source == target else obstacle_row - 1
            if source != target:
                for c in range(min(source, target), max(source, target) + 1):
                    if output[obstacle_row - 1][c] == background:
                        output[obstacle_row - 1][c] = self.spine_colour
                    elif output[obstacle_row - 1][c] != self.spine_colour:
                        raise Inapplicable("relocation cap collision")
            for r in range(start_row, h):
                if output[r][target] == background:
                    output[r][target] = self.spine_colour
                elif output[r][target] != self.spine_colour:
                    raise Inapplicable("continuation collision")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="top-touching parallel spines above one row of horizontal obstacles",
            relation="intersecting spines are assigned to nearest free outside columns with rightward tie-breaking",
            operator=self.operator,
            parameters={"spine_colour": self.spine_colour, "obstacle_colour": self.obstacle_colour, "tie_policy": "rightmost"},
            corollary="Relocate blocked spine continuations and emit their connecting caps and downward edges.",
            notions=["spine node", "obstacle interval", "assignment", "continuation edge"],
        )


@dataclass(frozen=True)
class BoundaryMarkerCartesianGridProgram:
    paint_colour: int
    marker_colour: int

    kind = "boundary_marker_cartesian_grid"
    operator = "node_edge_graph_emission"
    node_vocabulary = "top_boundary_columns_and_right_boundary_rows"
    edge_vocabulary = "Cartesian_incidence"

    @property
    def schema_key(self): return self.kind, self.paint_colour, self.marker_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        if _palette(value) != {background, self.marker_colour} or self.paint_colour in _palette(value):
            raise Inapplicable("binary boundary-marker field required")
        columns = [c for c in range(w) if value[0][c] == self.marker_colour]
        rows = [r for r in range(h) if value[r][w - 1] == self.marker_colour]
        if not columns or not rows:
            raise Inapplicable("both boundary node sets are required")
        output = _array(value)
        emitted = 0
        for r in rows:
            for c in columns:
                if output[r][c] == background:
                    output[r][c] = self.paint_colour; emitted += 1
        if not emitted: raise Inapplicable("empty Cartesian incidence")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="marker nodes on the top and right canvas boundaries",
            relation="Cartesian product of top-column nodes and right-row nodes",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour, "marker_colour": self.marker_colour},
            corollary="Emit one edge-incidence cell at every boundary-node intersection.",
            notions=["boundary node", "row coordinate", "column coordinate", "Cartesian incidence"],
        )


# ---------------------------------------------------------------------------
# Shared operator III: anchor-role projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class InvertedUToBoundaryProgram:
    paint_colour: int

    kind = "inverted_u_centre_boundary_projection"
    operator = "anchor_role_projection"
    node_vocabulary = "inverted_U_components"
    edge_vocabulary = "component_centre_to_bottom_boundary"

    @property
    def schema_key(self): return self.kind, self.paint_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, _ = _shape(value)
        background = _background(value)
        components = _monochrome_components(value)
        if not components or self.paint_colour in _palette(value):
            raise Inapplicable("new boundary marker role required")
        output = _array(value)
        for component in components:
            r0, c0, r1, c1 = component["bbox"]
            mask = _canonical(component["cells"])
            expected = frozenset({(0,0),(0,1),(0,2),(1,0),(1,2)})
            if (r1 - r0, c1 - c0) != (1, 2) or mask != expected:
                raise Inapplicable("component is not the canonical inverted U")
            column = (c0 + c1) // 2
            if output[h - 1][column] != background:
                raise Inapplicable("bottom anchor is occupied")
            output[h - 1][column] = self.paint_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one or more canonical inverted-U components",
            relation="horizontal centre of each component projected to the bottom canvas boundary",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour, "boundary": "bottom"},
            corollary="Emit one semantic marker at each component-centre boundary anchor.",
            notions=["component", "centre", "boundary projection"],
        )


@dataclass(frozen=True)
class DiagonalPairFrameProjectionProgram:
    paint_colour: int

    kind = "diagonal_pair_frame_projection"
    operator = "anchor_role_projection"
    node_vocabulary = "equal_square_components"
    edge_vocabulary = "adjacent_diagonal_pair"

    @property
    def schema_key(self): return self.kind, self.paint_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        components = _monochrome_components(value)
        if len(_palette(value)) != 2 or not components or self.paint_colour in _palette(value):
            raise Inapplicable("binary equal-square scene required")
        if len({component["colour"] for component in components}) != 1:
            raise Inapplicable("square role is not unique")
        anchors, sizes = [], []
        for component in components:
            r0, c0, r1, c1 = component["bbox"]
            if r1 - r0 != c1 - c0:
                raise Inapplicable("component is not square")
            side = r1 - r0 + 1
            if len(component["cells"]) != side * side:
                raise Inapplicable("square is not solid")
            anchors.append((r0, c0)); sizes.append(side)
        if len(set(sizes)) != 1:
            raise Inapplicable("square sizes differ")
        side = sizes[0]
        edges = []
        degrees = Counter()
        for i, j in combinations(range(len(anchors)), 2):
            dr = anchors[j][0] - anchors[i][0]
            dc = anchors[j][1] - anchors[i][1]
            if abs(dr) == side and abs(dc) == side:
                edges.append((i, j)); degrees[i] += 1; degrees[j] += 1
        if any(degrees[i] != 1 for i in range(len(anchors))):
            raise Inapplicable("diagonal pairing is not unique")
        output = _array(value)
        used = set()
        for i, j in edges:
            if i in used or j in used: continue
            used.update((i, j))
            r1, c1 = anchors[i]; r2, c2 = anchors[j]
            min_r, max_r = sorted((r1, r2)); min_c, max_c = sorted((c1, c2))
            same_diagonal = (r2 - r1) * (c2 - c1) > 0
            targets = (
                ((min_r - side, max_c + side), (max_r + side, min_c - side))
                if same_diagonal
                else ((min_r - side, min_c - side), (max_r + side, max_c + side))
            )
            for r0, c0 in targets:
                for r in range(r0, r0 + side):
                    for c in range(c0, c0 + side):
                        if 0 <= r < h and 0 <= c < w:
                            if output[r][c] != background:
                                raise Inapplicable("projected square collides")
                            output[r][c] = self.paint_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="equal solid squares paired on adjacent diagonal anchors",
            relation="one-step outward expansion defines the opposite diagonal corners of a larger frame",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour, "step": "square_side"},
            corollary="Project equal squares to the opposite expanded-frame corners, clipped by the canvas.",
            notions=["square node", "diagonal pair", "frame corner", "clipping"],
        )


@dataclass(frozen=True)
class OrthogonalDominoMidpointProgram:
    paint_colour: int

    kind = "orthogonal_domino_midpoint_projection"
    operator = "anchor_role_projection"
    node_vocabulary = "horizontal_and_vertical_dominoes"
    edge_vocabulary = "equal_three_cell_gap_midpoints"

    @property
    def schema_key(self): return self.kind, self.paint_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        palette = _palette(value)
        if len(palette) != 2 or self.paint_colour in palette:
            raise Inapplicable("binary domino field required")
        foreground = next(iter(palette - {background}))
        output = _array(value)
        emitted = 0
        offsets = ((0,-3),(0,-2),(0,2),(0,3),(-3,0),(-2,0),(2,0),(3,0))
        for r in range(h):
            for c in range(w):
                if value[r][c] != background: continue
                if all(0 <= r + dr < h and 0 <= c + dc < w and value[r + dr][c + dc] == foreground for dr, dc in offsets):
                    output[r][c] = self.paint_colour; emitted += 1
        if not emitted: raise Inapplicable("no orthogonal domino midpoint")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="horizontal and vertical foreground domino pairs",
            relation="midpoints of equal three-cell gaps intersect orthogonally",
            operator=self.operator,
            parameters={"paint_colour": self.paint_colour, "gap": 3, "domino_length": 2},
            corollary="Project the semantic role to every orthogonal domino-gap midpoint intersection.",
            notions=["domino node", "midpoint", "orthogonal intersection"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and validation.
# ---------------------------------------------------------------------------


def _fit_single(pairs, cls):
    try:
        program = cls(_single_background_emission(pairs, require_new=True))
        return [program] if all(program.predict(s) == grid(t) for s, t in pairs) else []
    except Inapplicable:
        return []


def _fit_nearest_square(pairs):
    try:
        paint = _single_background_emission(pairs, require_new=True)
    except Inapplicable:
        return []
    common = None
    for source, _ in pairs:
        roles = _palette(source) - {_background(source)}
        common = set(roles) if common is None else common & set(roles)
    if not common or len(common) != 2:
        return []
    a, b = sorted(common)
    output = []
    for marker, reference in ((a, b), (b, a)):
        program = NearestReferenceSquareProgram(paint, marker, reference)
        try:
            if all(program.predict(s) == grid(t) for s, t in pairs): output.append(program)
        except Inapplicable:
            pass
    return output


def _fit_gap_chain(pairs):
    program = OrderedGapChainProgram()
    try:
        return [program] if all(program.predict(s) == grid(t) for s, t in pairs) else []
    except Inapplicable:
        return []


def _fit_relocated_spines(pairs):
    try:
        spine = _single_background_emission(pairs, require_new=False)
    except Inapplicable:
        return []
    obstacle = None
    for source, _ in pairs:
        roles = _palette(source) - {_background(source), spine}
        if len(roles) != 1: return []
        current = next(iter(roles))
        if obstacle is None: obstacle = current
        elif obstacle != current: return []
    program = ObstacleRelocatedSpineProgram(spine, int(obstacle))
    try:
        return [program] if all(program.predict(s) == grid(t) for s, t in pairs) else []
    except Inapplicable:
        return []


def _fit_boundary_grid(pairs):
    try:
        paint = _single_background_emission(pairs, require_new=True)
    except Inapplicable:
        return []
    marker = None
    for source, _ in pairs:
        roles = _palette(source) - {_background(source)}
        if len(roles) != 1: return []
        current = next(iter(roles))
        if marker is None: marker = current
        elif marker != current: return []
    program = BoundaryMarkerCartesianGridProgram(paint, int(marker))
    try:
        return [program] if all(program.predict(s) == grid(t) for s, t in pairs) else []
    except Inapplicable:
        return []


_FITTERS = {
    "line_diameter_diamond_envelope": lambda pairs: _fit_single(pairs, LineDiameterDiamondProgram),
    "clipped_diamond_envelope_completion": lambda pairs: _fit_single(pairs, ClippedDiamondCompletionProgram),
    "nearest_reference_square_envelope": _fit_nearest_square,
    "ordered_gap_chain_completion": _fit_gap_chain,
    "obstacle_relocated_vertical_spines": _fit_relocated_spines,
    "boundary_marker_cartesian_grid": _fit_boundary_grid,
    "inverted_u_centre_boundary_projection": lambda pairs: _fit_single(pairs, InvertedUToBoundaryProgram),
    "diagonal_pair_frame_projection": lambda pairs: _fit_single(pairs, DiagonalPairFrameProjectionProgram),
    "orthogonal_domino_midpoint_projection": lambda pairs: _fit_single(pairs, OrthogonalDominoMidpointProgram),
}


def fit_reusable_node_edge_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(s), grid(t)) for s, t in pairs)
    if len(pairs) < minimum_pairs: return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None: continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key); output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background = _background(source)
        original = programme.predict(source)
        passed = False; tested = 0
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] == background: continue
                tested += 1
                work = _array(source); work[r][c] = background
                try:
                    changed = programme.predict(grid(work)) != original
                except Inapplicable:
                    changed = True
                if changed:
                    passed = True; break
            if passed: break
        rows.append({"demonstration": index, "passed": passed, "candidate_nodes_tested": tested, "node_removal_changes_or_rejects": passed, "witness_role": "input_derived_node_or_edge" if passed else None})
    return {"kind": programme.kind, "rows": rows, "passed": bool(rows) and all(row["passed"] for row in rows)}


def infer_reusable_node_edge_proof_search(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_reusable_node_edge_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list); invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1; continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1; continue
        law = programme.describe(pairs); law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [{"status": status, "prediction": [list(row) for row in chosen[i]] if chosen else None} for i in range(len(clean["test"]))],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [[[[cell for cell in row] for row in prediction] for prediction in predictions] for predictions in list(groups)[:2]],
        "stats": {
            "fitted_programs": len(programmes), "inapplicable_programs": invalid, "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True, "reusable_node_edge_grammar": True, "bounded_two_step_proof_search": True,
            "task_ids_used": False, "test_targets_used": False, "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_reusable_node_edge_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple((demo["input"], demo["output"]) for index, demo in enumerate(clean["train"]) if index != held_index)
        refitted = fit_reusable_node_edge_programs(remaining, 1, (programme.kind,))
        groups = set(); held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]): continue
                if not _counterfactual(candidate, full_pairs)["passed"]: continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {"passed": passed, "reason": "passed" if passed else "validation_failure", "folds": folds, "counterfactuals": [counterfactual], "validation_protocol": "held_exact_consensus_with_counterfactual_pruning"}


def validate_reusable_node_edge_proof_search(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
