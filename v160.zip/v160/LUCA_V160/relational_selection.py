"""LUCA V72: scene-relative colour and enclosure comparisons for object selection.

Reuse V70 components and V71 output construction. A finite selector language
compares colour evidence, peer frequencies, adjacency and bounding-box relations.
There are no coordinates/IDs/answer tables in the grammar. All tied selections
survive; unknown or tied colour roles reject the candidate. Identity-only crop or
in-place extraction is deliberate: this family does not infer object movement.
"""
from __future__ import annotations
from dataclasses import dataclass
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import product


from attributes import perceive
from attribute_selection import Construction
from correspondence import grid
from runtime import public_task


FAMILY = 'relational_selection_v72'
METRICS = ('palette_size', 'dominant_fraction', 'palette_frequency',
           'coloured_shape_frequency', 'oriented_shape_frequency',
           'contains_count', 'contained_by_count', 'contact_count',
           'complete_frame')
ROLE_METRICS = ('colour_count', 'colour_fraction')
PREDICATES = ('min', 'max', 'zero', 'positive')
CONSTRUCTIONS = tuple(Construction(view, 0, place)
                     for view in ('selected','context') for place in ('crop','original'))

@dataclass(frozen=True)
class Measure:
    metric: str
    colour_role: str | int | None = None

    def describe(self):
        return {'metric': self.metric, 'colour_role': self.colour_role}


def resolve_colour(a, bg, role):
    counts = Counter(v for row in a for v in row if v != bg)
    if isinstance(role, int) and not isinstance(role, bool):
        return role if role in counts else None
    if role not in ('rarest', 'commonest'):
        raise ValueError('unknown colour role')
    if not counts: return None
    value = min(counts.values()) if role == 'rarest' else max(counts.values())
    colours = [c for c,n in counts.items() if n == value]
    return colours[0] if len(colours) == 1 else None


@lru_cache(maxsize=256)
def relation_values(a, background_rule, connectivity, monochrome):
    """Input-only relational descriptors; source ordering cannot break ties."""
    scene = perceive(a, background_rule, connectivity, monochrome)
    if scene is None: return None
    bg, objects, _ = scene
    hist = [Counter(a[r][c] for r,c in o.cells) for o in objects]
    palettes = [tuple(sorted(h)) for h in hist]
    pcount = Counter(palettes)
    shapes = [tuple((r-o.box[0], c-o.box[1]) for r,c in o.cells) for o in objects]
    coloured = [tuple((r-o.box[0], c-o.box[1], a[r][c]) for r,c in o.cells) for o in objects]
    sfreq, cfreq = Counter(shapes), Counter(coloured)
    contains=[0]*len(objects); contained=[0]*len(objects)
    for i,o in enumerate(objects):
        a0,b0,a1,b1 = o.box
        for j,p in enumerate(objects):
            if i == j: continue
            c0,d0,c1,d1=p.box
            if a0<=c0 and b0<=d0 and a1>=c1 and b1>=d1 and o.box!=p.box:
                contains[i]+=1;contained[j]+=1
    cell_owner={p:i for i,o in enumerate(objects) for p in o.cells}
    contacts=[set() for o in objects]
    for (r,c),i in cell_owner.items():
        for dr,dc in ((-1,0),(1,0),(0,-1),(0,1)):
            j=cell_owner.get((r+dr,c+dc))
            if j is not None and j!=i:contacts[i].add(j)
    values=[]
    for i,o in enumerate(objects):
        r0,c0,r1,c1=o.box
        border={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1)
                if r in (r0,r1) or c in (c0,c1)}
        # A frame encloses a nonempty interior; solid blocks are not frames.
        frame=(r1-r0>=2 and c1-c0>=2 and border.issubset(o.cells)
               and any((r,c) not in o.cells for r in range(r0+1,r1) for c in range(c0+1,c1)))
        values.append(dict(palette_size=len(hist[i]),
          dominant_fraction=Fraction(max(hist[i].values()),len(o.cells)),
          palette_frequency=pcount[palettes[i]],coloured_shape_frequency=cfreq[coloured[i]],
          oriented_shape_frequency=sfreq[shapes[i]],contains_count=contains[i],
          contained_by_count=contained[i],contact_count=len(contacts[i]),complete_frame=int(frame)))
    return scene,tuple(hist),tuple(values)


def values_for(a, rule, conn, mono, measure):
    result=relation_values(a,rule,conn,mono)
    if result is None:return None
    scene,hist,vs=result
    if measure.metric in METRICS:
        return tuple(v[measure.metric] for v in vs)
    if measure.metric not in ROLE_METRICS:raise ValueError('unknown metric')
    colour=resolve_colour(a,scene[0],measure.colour_role)
    if colour is None:return None
    return tuple(h[colour] if measure.metric=='colour_count'
                 else Fraction(h[colour],sum(h.values())) for h in hist)


def select(values,predicate):
    if not values:return ()
    if predicate=='min':value=min(values);return tuple(i for i,v in enumerate(values) if v==value)
    if predicate=='max':value=max(values);return tuple(i for i,v in enumerate(values) if v==value)
    if predicate=='zero':return tuple(i for i,v in enumerate(values) if v==0)
    if predicate=='positive':return tuple(i for i,v in enumerate(values) if v>0)
    raise ValueError('unknown predicate')


@dataclass(frozen=True)
class RelationalProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    measure: Measure
    predicate: str
    construction: Construction

    def predict(self,a):
        a=grid(a);r=relation_values(a,self.background_rule,self.connectivity,self.monochrome)
        if r is None:return None
        values=values_for(a,self.background_rule,self.connectivity,self.monochrome,self.measure)
        if values is None:return None
        return self.construction.render(a,r[0],select(values,self.predicate))

    def describe(self):
        return {'family':FAMILY,'background_rule':self.background_rule,'connectivity':self.connectivity,
                'monochrome':self.monochrome,'measure':self.measure.describe(),'predicate':self.predicate,
                'tie_policy':'retain all tied objects','construction':self.construction.describe()}

    def trace(self,a):
        a=grid(a);r=relation_values(a,self.background_rule,self.connectivity,self.monochrome)
        if r is None:return None
        values=values_for(a,self.background_rule,self.connectivity,self.monochrome,self.measure)
        if values is None:return None
        selected=select(values,self.predicate);prediction=self.predict(a)
        return {'program':self.describe(),'background':r[0][0],
          'components':[{'index':i,'box':list(o.box),'area':len(o.cells),
             'value':str(values[i]),'selected':i in selected} for i,o in enumerate(r[0][1])],
          'prediction':[list(row) for row in prediction] if prediction is not None else None}


def fit(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any(len(y)>len(a) or len(y[0])>len(a[0]) or
           not {v for row in y for v in row}.issubset({v for row in a for v in row}) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    measures=tuple(Measure(m) for m in METRICS)+tuple(Measure(m,c) for m in ROLE_METRICS
                  for c in ('rarest','commonest',*sorted(common)))
    models=[]
    for bg in ('modal',*sorted(common)):
        for conn,mono in product((4,8),(True,False)):
            scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
            if any(s is None for s in scenes) or not any(len(s[1])>=2 for s in scenes):continue
            grouped=defaultdict(list)
            for measure in measures:
                vectors=tuple(values_for(a,bg,conn,mono,measure) for a,y in pairs)
                if any(v is None for v in vectors):continue
                for pred in PREDICATES:
                    indices=tuple(select(v,pred) for v in vectors)
                    if any(not x for x in indices) or not any(len(x)<len(s[1]) for x,s in zip(indices,scenes)):continue
                    grouped[indices].append((measure,pred))
            for indices,selectors in grouped.items():
                for construction in CONSTRUCTIONS:
                    if not all(construction.render(a,s,x)==y for (a,y),s,x in zip(pairs,scenes,indices)):continue
                    models.extend(RelationalProgram(bg,conn,mono,m,p,construction) for m,p in selectors)
    return models


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0
    for model in models:
        predictions=tuple(model.predict(t['input']) for t in clean['test'])
        if any(p is None for p in predictions):invalid+=1;continue
        groups.setdefault(predictions,[]).append(model.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
      'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
               for i in range(len(clean['test']))],
      'supporting_families':[FAMILY] if chosen else [],'supporting_laws':groups[chosen][:20] if chosen else [],
      'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
      'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'all_joint_predictions_retained':True}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        task_fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
                   'test':[{'input':demo['input']}]+clean['test']}
        r=infer(task_fold);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
          'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
          'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
          'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


