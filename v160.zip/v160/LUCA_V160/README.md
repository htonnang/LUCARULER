# LUCA V160 — Equivariant Family Rewrite

V160 rewrites four validated families so their mechanisms are expressed through relative directions, inferred colour roles, and reusable structural relations. The release retains the predecessor programmes and adds one independently transferred training task to each rewritten family.

Run the complete solver:

```bash
python run.py task.json --output prediction.json
```

See `README_V160.md` and `RUN_V160.txt` for the isolated rewrite modes.
