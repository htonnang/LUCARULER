"""LUCA V149: learned order-graph sequence composition.

Three transformations share one consequence operator:

    scene -> ordered structure nodes -> precedence/reference/selection edges
          -> ordered sequence graph -> compact frame emission -> proof

The family is task-ID blind and target blind. It infers line supports, occlusion
precedence, reference-square line order, connected-component area ranks, output
orientation, and frame dimensions from demonstrations and each current input.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_learned_order_graph_sequence_composition"
LANGUAGE = "spinoza_learned_order_graph_sequence_composition_v149"
SCHEMA_VERSION = 1


def _law(program, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": program.operator,
            "emitter": "ordered_sequence_frame",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "ordered_sequence_graph": True,
            "shared_sequence_frame_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] == colour
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for neighbour in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    return tuple(output)


def _sequence_frame(sequence, orientation, band_thickness=1, repeat=1):
    sequence = tuple(int(colour) for colour in sequence)
    if not sequence or band_thickness < 1 or repeat < 1:
        raise Inapplicable("invalid sequence frame")
    if orientation == "vertical_bands":
        row = tuple(colour for colour in sequence for _ in range(band_thickness))
        return tuple(row for _ in range(repeat))
    if orientation == "horizontal_bands":
        rows = tuple(
            tuple(colour for _ in range(repeat))
            for colour in sequence
            for _ in range(band_thickness)
        )
        return rows
    raise Inapplicable("unknown frame orientation")


def _line_support(cells, h, w):
    cells = frozenset(cells)
    if len(cells) < 2:
        raise Inapplicable("line requires two visible cells")
    rows = {r for r, _ in cells}
    cols = {c for _, c in cells}
    differences = {r - c for r, c in cells}
    sums = {r + c for r, c in cells}
    candidates = []
    if len(rows) == 1:
        r = next(iter(rows))
        candidates.append(frozenset((r, c) for c in range(w)))
    if len(cols) == 1:
        c = next(iter(cols))
        candidates.append(frozenset((r, c) for r in range(h)))
    if len(differences) == 1:
        difference = next(iter(differences))
        candidates.append(frozenset((r, c) for r in range(h) for c in range(w) if r - c == difference))
    if len(sums) == 1:
        total = next(iter(sums))
        candidates.append(frozenset((r, c) for r in range(h) for c in range(w) if r + c == total))
    candidates = tuple(dict.fromkeys(candidates))
    if len(candidates) != 1:
        raise Inapplicable("line support is not unique")
    return candidates[0]


def _weighted_topological_order(nodes, edges, hidden_counts, support_lengths):
    nodes = tuple(nodes)
    adjacency = {node: set() for node in nodes}
    indegree = {node: 0 for node in nodes}
    for source, target in edges:
        if source == target or target in adjacency[source]:
            continue
        adjacency[source].add(target)
        indegree[target] += 1
    output = []
    for _ in nodes:
        available = [node for node in nodes if indegree[node] == 0 and node not in output]
        if not available:
            raise Inapplicable("precedence graph contains a cycle")
        scores = {
            node: (hidden_counts[node], support_lengths[node])
            for node in available
        }
        best = max(scores.values())
        winners = [node for node in available if scores[node] == best]
        if len(winners) != 1:
            raise Inapplicable("precedence graph has an unresolved tie")
        node = winners[0]
        output.append(node)
        for target in adjacency[node]:
            indegree[target] -= 1
    return tuple(output)


@dataclass(frozen=True)
class LineOcclusionSequenceProgram:
    orientation: str
    kind = "line_occlusion_sequence"
    operator = "ordered_sequence_frame_emission"
    node_vocabulary = "ordered_structure_sequence_nodes"
    edge_vocabulary = "precedence_reference_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind, self.orientation)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if not (2 <= len(colours) <= 9):
            raise Inapplicable("two to nine line colours required")

        supports = {}
        hidden_counts = {}
        support_lengths = {}
        for colour in colours:
            cells = frozenset(
                (r, c)
                for r in range(h)
                for c in range(w)
                if value[r][c] == colour
            )
            support = _line_support(cells, h, w)
            supports[colour] = support
            hidden_counts[colour] = len(support) - len(cells)
            support_lengths[colour] = len(support)
        if len(set(supports.values())) != len(supports):
            raise Inapplicable("line supports are not distinct")

        union = frozenset().union(*supports.values())
        non_background = frozenset(
            (r, c)
            for r in range(h)
            for c in range(w)
            if value[r][c] != background
        )
        if union != non_background:
            raise Inapplicable("line support union must equal the foreground")

        edges = set()
        for r, c in union:
            active = [colour for colour, support in supports.items() if (r, c) in support]
            observed = value[r][c]
            if observed not in active:
                raise Inapplicable("observed crossing colour is not an active line")
            for colour in active:
                if colour != observed:
                    edges.add((colour, observed))
        order = _weighted_topological_order(colours, edges, hidden_counts, support_lengths)
        return _sequence_frame(order, self.orientation, 1, 1)

    def describe(self, pairs):
        return _law(
            self,
            scene="a complete union of horizontal, vertical, or diagonal monochrome supports with visible occlusions",
            relation_chain=(
                "reconstruct one full line-support node for every foreground colour",
                "direct precedence edges from covered lines to visible lines at intersections",
                "resolve non-intersecting ties by input-derived hidden-cell and support-span evidence",
                "emit the ordered colour sequence as a one-cell-thick frame",
            ),
            parameters={"orientation": self.orientation},
            corollary="Emit line colours from earliest covered support to latest visible support.",
            notions=["line support", "occlusion precedence", "weighted topological order", "sequence frame"],
        )


@dataclass(frozen=True)
class ReferenceSquareLineSequenceProgram:
    kind = "reference_square_line_sequence"
    operator = "ordered_sequence_frame_emission"
    node_vocabulary = "ordered_structure_sequence_nodes"
    edge_vocabulary = "precedence_reference_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind,)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        square_candidates = []
        for colour in colours:
            components = _components(value, colour)
            if len(components) != 1:
                continue
            component = components[0]
            r0, c0, r1, c1 = _bbox(component)
            side = r1 - r0 + 1
            if side >= 2 and side == c1 - c0 + 1 and len(component) == side * side:
                square_candidates.append((colour, side))
        if len(square_candidates) != 1:
            raise Inapplicable("one solid square reference required")
        reference_colour, side = square_candidates[0]
        line_colours = [colour for colour in colours if colour != reference_colour]
        if len(line_colours) != side:
            raise Inapplicable("line count must equal reference-square side")

        row_keys = {}
        column_keys = {}
        all_rows = True
        all_columns = True
        for colour in line_colours:
            cells = [
                (r, c)
                for r in range(h)
                for c in range(w)
                if value[r][c] == colour
            ]
            if len(cells) < 2:
                raise Inapplicable("each sequence colour needs a visible line segment")
            rows = {r for r, _ in cells}
            cols = {c for _, c in cells}
            if len(rows) == 1:
                row_keys[colour] = next(iter(rows))
            else:
                all_rows = False
            if len(cols) == 1:
                column_keys[colour] = next(iter(cols))
            else:
                all_columns = False
        if all_rows and not all_columns:
            if len(set(row_keys.values())) != side:
                raise Inapplicable("row-line order is tied")
            sequence = tuple(sorted(line_colours, key=lambda colour: row_keys[colour]))
            return _sequence_frame(sequence, "horizontal_bands", 1, side)
        if all_columns and not all_rows:
            if len(set(column_keys.values())) != side:
                raise Inapplicable("column-line order is tied")
            sequence = tuple(sorted(line_colours, key=lambda colour: column_keys[colour]))
            return _sequence_frame(sequence, "vertical_bands", 1, side)
        raise Inapplicable("all non-reference colours must be parallel line nodes")

    def describe(self, pairs):
        return _law(
            self,
            scene="one solid square reference and an equal number of parallel monochrome line nodes",
            relation_chain=(
                "extract the unique solid-square reference node and its side length",
                "order parallel line-colour nodes by row or column coordinate",
                "materialise the ordered colours as unit bands inside a square frame of the reference size",
            ),
            parameters={},
            corollary="Transfer the spatial order of parallel line nodes into the reference-square frame.",
            notions=["solid-square reference", "parallel line order", "reference-sized frame", "ordered bands"],
        )


@dataclass(frozen=True)
class MaximalAreaObjectSequenceProgram:
    orientation: str
    kind = "maximal_area_object_sequence"
    operator = "ordered_sequence_frame_emission"
    node_vocabulary = "ordered_structure_sequence_nodes"
    edge_vocabulary = "precedence_reference_and_selection_edges"

    @property
    def schema_key(self):
        return (self.kind, self.orientation)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _mode(value)
        colours = sorted(_palette(value) - {background})
        if not (2 <= len(colours) <= 9):
            raise Inapplicable("two to nine object colours required")
        objects = []
        for colour in colours:
            components = _components(value, colour)
            if len(components) != 1:
                raise Inapplicable("one connected object per colour required")
            component = components[0]
            if len(component) < 2:
                raise Inapplicable("singleton objects are excluded")
            r0, c0, r1, c1 = _bbox(component)
            objects.append({
                "colour": colour,
                "area": len(component),
                "left": c0,
                "right": c1,
                "top": r0,
                "bottom": r1,
            })
        maximum = max(item["area"] for item in objects)
        if not (3 <= maximum <= 15):
            raise Inapplicable("maximum object area outside the bounded frame language")
        selected = [item for item in objects if item["area"] == maximum]
        selected.sort(key=lambda item: (item["left"], item["right"], item["colour"]))
        if len({item["left"] for item in selected}) != len(selected):
            raise Inapplicable("selected objects have tied horizontal origins")
        if any(first["right"] >= second["left"] for first, second in zip(selected, selected[1:])):
            raise Inapplicable("selected objects do not form a strict left-to-right chain")
        sequence = tuple(item["colour"] for item in selected)
        if self.orientation == "vertical_bands":
            return _sequence_frame(sequence, "vertical_bands", 1, maximum)
        if self.orientation == "horizontal_bands":
            return _sequence_frame(sequence, "horizontal_bands", 1, maximum)
        raise Inapplicable("unknown learned frame orientation")

    def describe(self, pairs):
        return _law(
            self,
            scene="one connected foreground object per colour with an input-derived maximum-area class",
            relation_chain=(
                "extract connected object nodes and their areas",
                "select every object tied for maximum area",
                "order selected objects by their strict left-to-right relation",
                "emit their colours as bands in a frame whose repeated dimension equals the maximum area",
            ),
            parameters={"orientation": self.orientation},
            corollary="Materialise the left-to-right sequence of maximum-area objects in an area-sized frame.",
            notions=["connected object", "maximum-area class", "left-to-right precedence", "area-sized frame"],
        )


# ---------------------------------------------------------------------------
# Fitting, counterfactuals, inference, and validation.
# ---------------------------------------------------------------------------


def _fit_static(pairs, cls):
    programme = cls()
    try:
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_line_occlusion(pairs):
    output = []
    for orientation in ("vertical_bands", "horizontal_bands"):
        programme = LineOcclusionSequenceProgram(orientation)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_maximal_area(pairs):
    output = []
    for orientation in ("vertical_bands", "horizontal_bands"):
        programme = MaximalAreaObjectSequenceProgram(orientation)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "line_occlusion_sequence": _fit_line_occlusion,
    "reference_square_line_sequence": lambda pairs: _fit_static(pairs, ReferenceSquareLineSequenceProgram),
    "maximal_area_object_sequence": _fit_maximal_area,
}


def fit_learned_order_graph_sequence_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, target) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        palette = sorted(_palette(source))
        counts = Counter(cell for row in source for cell in row)
        cells = sorted(
            ((r, c) for r in range(len(source)) for c in range(len(source[0]))),
            key=lambda cell: (
                counts[source[cell[0]][cell[1]]],
                0 if cell[0] in (0, len(source) - 1) or cell[1] in (0, len(source[0]) - 1) else 1,
                cell,
            ),
        )
        passed = False
        tested = 0
        witness = None
        for r, c in cells:
            original_colour = source[r][c]
            replacements = [colour for colour in palette if colour != original_colour]
            if not replacements:
                replacements = [(original_colour + 1) % 10]
            for replacement in replacements:
                tested += 1
                work = _array(source)
                work[r][c] = replacement
                try:
                    changed = programme.predict(grid(work)) != original
                except Inapplicable:
                    changed = True
                if changed:
                    passed = True
                    witness = {"cell": [r, c], "from": int(original_colour), "to": int(replacement)}
                    break
                if tested >= 800:
                    break
            if passed or tested >= 800:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": "ordered_structure_node_or_precedence_reference_selection_edge" if passed else None,
            "witness": witness,
        })
    return {"kind": programme.kind, "rows": rows, "passed": bool(rows) and all(row["passed"] for row in rows)}


def infer_learned_order_graph_sequence_composition(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_learned_order_graph_sequence_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "ordered_sequence_graph": True,
            "shared_sequence_frame_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_learned_order_graph_sequence_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_learned_order_graph_sequence_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_learned_order_graph_sequence_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
