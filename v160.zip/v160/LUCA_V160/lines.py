"""LUCA V67: a reusable aligned-marker-to-line reasoning family.

Language: select foreground cells / cross centres; group by colour or pool;
connect extreme aligned markers or extend their line to the boundary; paint
background only using a shared source/constant colour rule. Crossing rules are
explicit and transactional. V38's line_relations grammar guides the vocabulary;
this module does not import legacy dispatch, use task IDs, or stop at a first fit.
"""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from itertools import product
from typing import Iterable
from correspondence import grid

from panel_layout import Background

Grid=tuple[tuple[int,...],...]
AXES={'rows':((0,1),),'columns':((1,0),),'orthogonal':((0,1),(1,0)),
      'diagonals':((1,1),(1,-1))}
SELECTORS=('foreground_cells','cross_centres')
EXTENTS=('between','full')
CROSSINGS=('reject','vertical','horizontal')
TEMPLATE='select_markers -> group_relations -> aligned_paths -> background_only_render'


@dataclass(frozen=True)
class PathProposal:
    cells: tuple[tuple[int,int],...]
    source_colour: int | None
    dr: int
    dc: int


def select_markers(a:Grid,bg:int,selector:str,source:int|None):
    if selector not in SELECTORS:raise ValueError('unknown marker selector')
    h,w=len(a),len(a[0]);points=[]
    for r,row in enumerate(a):
        for c,v in enumerate(row):
            if v==bg or (source is not None and v!=source):continue
            if selector=='cross_centres':
                if not (0<r<h-1 and 0<c<w-1):continue
                arms=(a[r-1][c],a[r+1][c],a[r][c-1],a[r][c+1])
                if len(set(arms))!=1 or arms[0] in (bg,v):continue
            points.append((r,c,v))
    return tuple(points)


def propose_paths(a:Grid,bg:int,selector:str,source:int|None,grouping:str,extent:str,axes:str):
    """Group selected markers by an alignment invariant, not absolute coordinates."""
    if grouping not in ('by_colour','pooled') or extent not in EXTENTS or axes not in AXES:
        raise ValueError('invalid path grammar')
    points=select_markers(a,bg,selector,source)
    if not points:return None
    groups=defaultdict(list)
    for p in points:groups[p[2] if grouping=='by_colour' else None].append(p)
    h,w=len(a),len(a[0]);proposals=[]
    for pts in groups.values():
        for dr,dc in AXES[axes]:
            aligned=defaultdict(list)
            for r,c,v in pts:aligned[r*dc-c*dr].append((r,c,v))
            for members in aligned.values():
                if extent=='between' and len(members)<2:continue
                r,c,_=min(members);end=max(members)[:2];cells=[]
                if extent=='full':
                    while 0<=r-dr<h and 0<=c-dc<w:r-=dr;c-=dc
                    while 0<=r<h and 0<=c<w:
                        if a[r][c]==bg:cells.append((r,c))
                        r+=dr;c+=dc
                else:
                    while (r,c)!=end:
                        if not (0<=r<h and 0<=c<w):raise AssertionError('nonterminating alignment')
                        if a[r][c]==bg:cells.append((r,c))
                        r+=dr;c+=dc
                    if a[r][c]==bg:cells.append((r,c))
                colours={v for _,_,v in members}
                proposals.append(PathProposal(tuple(cells),next(iter(colours)) if len(colours)==1 else None,dr,dc))
    return tuple(proposals)


def render_paths(a:Grid,proposals:tuple[PathProposal,...],paint:int|None,crossing:str)->Grid|None:
    """Apply writes atomically. None paint means the line's source-marker colour.

    Different colours at equal geometric priority are ambiguous and reject.
    In particular, neither colour-number sorting nor enumeration order breaks a tie.
    """
    if crossing not in CROSSINGS:raise ValueError('invalid crossing policy')
    requests=defaultdict(list)
    for path in proposals:
        colour=path.source_colour if paint is None else paint
        if colour is None:return None
        priority=abs(path.dr) if crossing=='vertical' else abs(path.dc) if crossing=='horizontal' else 0
        for cell in path.cells:requests[cell].append((priority,colour))
    edits={}
    for cell,choices in requests.items():
        best=max(p for p,c in choices)
        colours={c for p,c in choices if p==best}
        if len(colours)!=1:return None
        edits[cell]=next(iter(colours))
    out=[list(r) for r in a]
    for (r,c),v in edits.items():out[r][c]=v
    return tuple(tuple(r) for r in out)


@dataclass(frozen=True)
class LineProgram:
    background: Background
    selector: str
    source: int | None
    grouping: str
    extent: str
    axes: str
    paint: int | None
    crossing: str

    def predict(self,raw)->Grid|None:
        a=grid(raw);bg=self.background.value(a,(a,))
        if bg is None:return None
        proposals=propose_paths(a,bg,self.selector,self.source,self.grouping,self.extent,self.axes)
        if proposals is None:return None
        return render_paths(a,proposals,self.paint,self.crossing)

    def name(self):
        return (f'background({self.background.name()}) -> select({self.selector},source={self.source if self.source is not None else "all"})'
                f' -> group({self.grouping}) -> lines({self.axes},{self.extent})'
                f' -> paint({self.paint if self.paint is not None else "source_colour"},crossing={self.crossing})')

    def template(self):return TEMPLATE

    def trace(self,raw):
        a=grid(raw);bg=self.background.value(a,(a,))
        if bg is None:return None
        proposals=propose_paths(a,bg,self.selector,self.source,self.grouping,self.extent,self.axes)
        if proposals is None:return None
        prediction=render_paths(a,proposals,self.paint,self.crossing)
        return {'background_role':self.background.name(),'background_colour':bg,
                'selector':self.selector,'source_colour':self.source,'grouping':self.grouping,
                'extent':self.extent,'axes':self.axes,'paint':self.paint if self.paint is not None else 'source_colour',
                'crossing':self.crossing,'selected_markers':[list(p) for p in select_markers(a,bg,self.selector,self.source)],
                'paths':[{'cells':[list(c) for c in p.cells],'source_colour':p.source_colour,'direction':[p.dr,p.dc]} for p in proposals],
                'changed_cells':sum(a[r][c]!=prediction[r][c] for r in range(len(a)) for c in range(len(a[0]))) if prediction else None,
                'prediction':[list(r) for r in prediction] if prediction else None}


def fit(raw_pairs:Iterable)->list[LineProgram]:
    pairs=tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs or any((len(a),len(a[0]))!=(len(y),len(y[0])) for a,y in pairs):return []
    changes=tuple({(r,c) for r in range(len(a)) for c in range(len(a[0])) if a[r][c]!=y[r][c]} for a,y in pairs)
    if not any(changes):return [] # This family's explanation must have an observed effect.
    changed_inputs={a[r][c] for (a,y),cells in zip(pairs,changes) for r,c in cells}
    changed_outputs={y[r][c] for (a,y),cells in zip(pairs,changes) for r,c in cells}
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    backgrounds=[Background('unique_modal')]
    if len(changed_inputs)==1:backgrounds += [Background('constant',next(iter(changed_inputs)))]
    programs=[]
    for background in backgrounds:
        bgs=tuple(background.value(a,(a,)) for a,y in pairs)
        if any(bg is None for bg in bgs):continue
        if any(a[r][c]!=bg for (a,y),bg,cells in zip(pairs,bgs,changes) for r,c in cells):continue
        sources=[(None,'by_colour'),(None,'pooled')]+[(c,'by_colour') for c in sorted(common) if any(c!=bg for bg in bgs)]
        paints=[None]+sorted(changed_outputs)
        for selector,(source,grouping),extent,axes in product(SELECTORS,sources,EXTENTS,AXES):
            proposals=tuple(propose_paths(a,bg,selector,source,grouping,extent,axes) for (a,y),bg in zip(pairs,bgs))
            if any(p is None for p in proposals):continue
            footprints=tuple({cell for path in ps for cell in path.cells} for ps in proposals)
            for paint in paints:
                # Every scheduled cell must change unless the constant paint is
                # the background. This exact footprint test prunes impossible
                # geometry before colour/crossing evaluation, never a valid fit.
                if any((set() if paint==bg else footprint)!=changed
                       for footprint,changed,bg in zip(footprints,changes,bgs)):continue
                if paint is None and any(p.source_colour is None for ps in proposals for p in ps):continue
                for crossing in CROSSINGS:
                    if all(render_paths(a,ps,paint,crossing)==y for (a,y),ps in zip(pairs,proposals)):
                        law=LineProgram(background,selector,source,grouping,extent,axes,paint,crossing)
                        programs.append(law)
    return programs


