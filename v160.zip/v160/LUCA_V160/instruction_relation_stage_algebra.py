"""LUCA V132: anti-unified instruction--relation stage algebra.

The family factors five ARC mechanisms through a common programme::

    scene -> instruction/relation -> role binding -> operator -> emission

Schemas
-------
* ``frame_size_fill_codebook``: closed-frame size names an interior fill colour;
* ``framed_payload_diagonal_duplication``: a framed payload is normalised to a
  3x3 motif and duplicated along the main diagonal;
* ``symbolic_turn_path``: ordered 2-row symbols execute left/right/straight
  path instructions;
* ``four_way_object_cross``: one object is composed with two rotations and one
  reflection around a central gap;
* ``mask_kernel_colour_composition``: one binary mask supplies a kernel, a
  second mask supplies macro placement, and two solid panels supply colours.

No task identifier, official test target, or stored demonstration coordinate is
available during inference.  Frame-size codebooks use the same transparent
mixed-witness protocol introduced in V131: redundant signatures are validated
by leave-one-out refitting, while singleton mappings are reported as direct
witnesses and are never extrapolated to unseen sizes.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
from itertools import permutations
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_instruction_relation_stage_algebra"
LANGUAGE = "spinoza_instruction_relation_stage_algebra_v1"
SCHEMA_VERSION = "instruction_relation_stage_algebra_schema_v1"


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _palette(value: Grid) -> set[int]:
    return {int(cell) for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    modes = [int(colour) for colour, count in counts.items() if count == best]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty cell set")
    return (
        min(row for row, _ in cells),
        min(col for _, col in cells),
        max(row for row, _ in cells),
        max(col for _, col in cells),
    )


def _crop(value: Grid, box) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = box
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_binary(cells):
    cells = tuple(cells)
    r0, c0, r1, c1 = _bbox(cells)
    occupied = set(cells)
    return tuple(
        tuple(1 if (r, c) in occupied else 0 for c in range(c0, c1 + 1))
        for r in range(r0, r1 + 1)
    )


def _dirs(connectivity=4):
    values = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        values += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return values


def _components_same_colour(value: Grid, *, background: int, connectivity: int = 4):
    value = grid(value)
    height, width = _shape(value)
    seen = set()
    components = []
    for row in range(height):
        for col in range(width):
            if (row, col) in seen or value[row][col] == background:
                continue
            colour = int(value[row][col])
            stack = [(row, col)]
            seen.add((row, col))
            cells = []
            while stack:
                current = stack.pop()
                cells.append(current)
                for dr, dc in _dirs(connectivity):
                    nr, nc = current[0] + dr, current[1] + dc
                    if not (0 <= nr < height and 0 <= nc < width):
                        continue
                    if (nr, nc) in seen or value[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    stack.append((nr, nc))
            box = _bbox(cells)
            components.append({
                "colour": colour,
                "cells": tuple(sorted(cells)),
                "bbox": box,
                "area": len(cells),
                "mask": _normalised_binary(cells),
            })
    components.sort(key=lambda item: item["bbox"])
    return components


def _candidate_backgrounds(pairs):
    candidates = None
    for source, _ in pairs:
        source = grid(source)
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_unique_mode(source))
        except Inapplicable:
            pass
        corners = {source[0][0], source[0][-1], source[-1][0], source[-1][-1]}
        if len(corners) == 1:
            values.add(int(next(iter(corners))))
        candidates = values if candidates is None else candidates & values
    return sorted(candidates or ())


def _rotate_cw(value: Grid) -> Grid:
    value = grid(value)
    return tuple(tuple(value[len(value) - 1 - r][c] for r in range(len(value))) for c in range(len(value[0])))


def _rotate_ccw(value: Grid) -> Grid:
    value = grid(value)
    h, w = _shape(value)
    return tuple(tuple(value[r][w - 1 - c] for r in range(h)) for c in range(w))


def _flip_horizontal(value: Grid) -> Grid:
    return tuple(tuple(reversed(row)) for row in grid(value))


def _law(program, *, parameters, definitions, propositions, corollary, common_notions, validation_protocol=None):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "validation_protocol": validation_protocol or "held_exact_consensus_with_counterfactual_pruning",
        },
    }


# ---------------------------------------------------------------------------
# Closed-frame size codebook.
# ---------------------------------------------------------------------------


def _rectangular_frame_components(value: Grid, *, background: int):
    value = grid(value)
    frames = []
    for component in _components_same_colour(value, background=background, connectivity=4):
        r0, c0, r1, c1 = component["bbox"]
        height, width = r1 - r0 + 1, c1 - c0 + 1
        if height < 5 or width < 5 or height != width or height % 2 == 0:
            continue
        border = {
            (r, c)
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if r in (r0, r1) or c in (c0, c1)
        }
        if set(component["cells"]) != border:
            continue
        frames.append({**component, "size": height})
    frames.sort(key=lambda item: item["bbox"])
    return frames


@dataclass(frozen=True)
class FrameSizeFillCodebookProgram:
    background: int
    mapping: tuple[tuple[int, int], ...]

    kind = "frame_size_fill_codebook"
    description_length = 9

    @property
    def schema_key(self):
        return self.kind, self.background, self.mapping

    def mapping_dict(self):
        return dict(self.mapping)

    def frame_signatures(self, value: Grid):
        return tuple(frame["size"] for frame in _rectangular_frame_components(value, background=self.background))

    def analyse(self, value: Grid):
        value = grid(value)
        frames = _rectangular_frame_components(value, background=self.background)
        if not frames:
            raise Inapplicable("no complete square frame")
        mapping = self.mapping_dict()
        work = _array(value)
        occupied_interiors = []
        for frame in frames:
            size = frame["size"]
            if size not in mapping:
                raise Inapplicable("unwitnessed frame-size code")
            r0, c0, r1, c1 = frame["bbox"]
            interior = {(r, c) for r in range(r0 + 1, r1) for c in range(c0 + 1, c1)}
            if any(interior & previous for previous in occupied_interiors):
                raise Inapplicable("overlapping frame interiors")
            occupied_interiors.append(interior)
            fill = mapping[size]
            if fill in (self.background, frame["colour"]):
                raise Inapplicable("fill colour must differ from background and frame")
            for r, c in interior:
                if work[r][c] == self.background:
                    work[r][c] = fill
        return {"frames": frames, "prediction": tuple(tuple(row) for row in work)}

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "mapping": [{"frame_size": size, "fill_colour": colour} for size, colour in self.mapping],
            },
            definitions={
                "frame": "a complete odd square monochrome border component",
                "size_code": "a witnessed mapping from frame side length to interior fill colour",
            },
            propositions=[
                "All frame and marker material is preserved.",
                "Only background cells strictly inside a complete frame are filled.",
                "An unseen frame size is rejected rather than extrapolated.",
            ],
            corollary="Fill every witnessed frame interior according to its size codebook.",
            common_notions=["closed frame", "witnessed codebook", "interior", "preservation"],
            validation_protocol="witnessed_codebook_plus_redundant_lodo",
        )


def _fit_frame_size_codebook(pairs):
    candidates = []
    for background in _candidate_backgrounds(pairs):
        mapping = {}
        valid = True
        seen_frames = 0
        for source, target in pairs:
            source, target = grid(source), grid(target)
            if _shape(source) != _shape(target):
                valid = False
                break
            frames = _rectangular_frame_components(source, background=background)
            if not frames:
                valid = False
                break
            seen_frames += len(frames)
            predicted_covered = set()
            for frame in frames:
                r0, c0, r1, c1 = frame["bbox"]
                fills = {
                    int(target[r][c])
                    for r in range(r0 + 1, r1)
                    for c in range(c0 + 1, c1)
                    if source[r][c] == background
                }
                if len(fills) != 1:
                    valid = False
                    break
                fill = next(iter(fills))
                if fill in (background, frame["colour"]):
                    valid = False
                    break
                old = mapping.get(frame["size"])
                if old is not None and old != fill:
                    valid = False
                    break
                mapping[frame["size"]] = fill
                for r in range(r0 + 1, r1):
                    for c in range(c0 + 1, c1):
                        predicted_covered.add((r, c))
            if not valid:
                break
            # Outside fillable background interiors, the source must be preserved.
            for r in range(len(source)):
                for c in range(len(source[0])):
                    if (r, c) not in predicted_covered and source[r][c] != target[r][c]:
                        valid = False
                        break
                if not valid:
                    break
        if valid and seen_frames >= 2 and len(mapping) >= 2:
            program = FrameSizeFillCodebookProgram(background, tuple(sorted(mapping.items())))
            if all(program.predict(source) == target for source, target in pairs):
                candidates.append(program)
    return candidates


# ---------------------------------------------------------------------------
# Framed payload normalisation and diagonal duplication.
# ---------------------------------------------------------------------------


def _frame_payload_scene(value: Grid, background: int):
    value = grid(value)
    h, w = _shape(value)
    if h < 5 or w < 5:
        raise Inapplicable("frame scene is too small")
    if not (value[0][0] == value[0][-1] == value[-1][0] == value[-1][-1] == background):
        raise Inapplicable("frame corners do not expose the background")
    edge_values = [
        value[0][c] for c in range(1, w - 1)
    ] + [value[-1][c] for c in range(1, w - 1)] + [value[r][0] for r in range(1, h - 1)] + [value[r][-1] for r in range(1, h - 1)]
    if not edge_values or len(set(edge_values)) != 1:
        raise Inapplicable("frame border is not monochrome")
    frame_colour = int(edge_values[0])
    if frame_colour == background:
        raise Inapplicable("frame and background coincide")
    interior = tuple(tuple(value[r][c] for c in range(1, w - 1)) for r in range(1, h - 1))
    cells = [(r, c) for r, row in enumerate(interior) for c, cell in enumerate(row) if cell != background]
    if not cells:
        raise Inapplicable("framed payload is empty")
    r0, c0, r1, c1 = _bbox(cells)
    if r1 - r0 + 1 > 3 or c1 - c0 + 1 > 3:
        raise Inapplicable("payload cannot be normalised to 3x3")
    if len(interior) < 3 or len(interior[0]) < 3:
        raise Inapplicable("frame interior is too small")
    row_start = max(0, min(len(interior) - 3, (r0 + r1 - 2) // 2))
    col_start = max(0, min(len(interior[0]) - 3, (c0 + c1 - 2) // 2))
    if not (row_start <= r0 and r1 < row_start + 3 and col_start <= c0 and c1 < col_start + 3):
        raise Inapplicable("cannot centre payload in a 3x3 window")
    payload = tuple(tuple(interior[r][c] for c in range(col_start, col_start + 3)) for r in range(row_start, row_start + 3))
    motif = (
        (background, frame_colour, frame_colour, frame_colour, background),
        (frame_colour, *payload[0], frame_colour),
        (frame_colour, *payload[1], frame_colour),
        (frame_colour, *payload[2], frame_colour),
        (background, frame_colour, frame_colour, frame_colour, background),
    )
    return {"frame_colour": frame_colour, "payload": payload, "motif": motif}


@dataclass(frozen=True)
class FramedPayloadDiagonalDuplicationProgram:
    background: int

    kind = "framed_payload_diagonal_duplication"
    description_length = 7

    @property
    def schema_key(self):
        return self.kind, self.background

    def analyse(self, value: Grid):
        scene = _frame_payload_scene(value, self.background)
        motif = scene["motif"]
        work = [[self.background for _ in range(15)] for _ in range(15)]
        for start in (2, 8):
            for r in range(5):
                for c in range(5):
                    work[start + r][start + c] = motif[r][c]
        return {**scene, "prediction": tuple(tuple(row) for row in work)}

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "payload_window": [3, 3], "motif_size": 5, "layout": "two_main_diagonal_copies"},
            definitions={
                "source_frame": "a full-grid frame with background corners and a monochrome border",
                "payload": "the smallest nonbackground interior support, centred in a 3x3 window",
                "motif": "the normalised payload enclosed by a 5x5 frame",
            },
            propositions=[
                "The payload is normalised by relation to the frame rather than absolute coordinates.",
                "Two identical motifs are placed on the main diagonal of a 15x15 background canvas.",
            ],
            corollary="Emit two diagonally separated copies of the normalised framed payload.",
            common_notions=["frame", "payload normalisation", "duplication", "diagonal layout"],
        )


def _fit_framed_payload_duplication(pairs):
    candidates = []
    for background in _candidate_backgrounds(pairs):
        program = FramedPayloadDiagonalDuplicationProgram(background)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                candidates.append(program)
        except Inapplicable:
            pass
    return candidates


# ---------------------------------------------------------------------------
# Symbolic turn path.
# ---------------------------------------------------------------------------


def _ordered_symbol_components(value: Grid, *, background: int):
    value = grid(value)
    h, w = _shape(value)
    if h != 2:
        raise Inapplicable("symbol path input must have exactly two rows")
    colours = _palette(value) - {background}
    if len(colours) != 1:
        raise Inapplicable("symbol path requires one foreground colour")
    foreground = next(iter(colours))
    components = _components_same_colour(value, background=background, connectivity=4)
    symbols = []
    for component in components:
        r0, c0, r1, c1 = component["bbox"]
        if r0 != 0 or r1 != 1:
            raise Inapplicable("every path symbol must span both rows")
        mask = component["mask"]
        if mask == ((1,), (1,)):
            symbol = "straight"
        elif mask == ((1, 0), (1, 1)):
            symbol = "right"
        elif mask == ((0, 1), (1, 1)):
            symbol = "left"
        else:
            raise Inapplicable("unknown path instruction symbol")
        symbols.append((c0, symbol))
    symbols.sort()
    if len(symbols) < 3 or len({col for col, _ in symbols}) != len(symbols):
        raise Inapplicable("insufficient ordered symbols")
    return foreground, tuple(symbol for _, symbol in symbols)


@dataclass(frozen=True)
class SymbolicTurnPathProgram:
    background: int
    marker_colour: int

    kind = "symbolic_turn_path"
    description_length = 8

    @property
    def schema_key(self):
        return self.kind, self.background, self.marker_colour

    def analyse(self, value: Grid):
        foreground, symbols = _ordered_symbol_components(value, background=self.background)
        if self.marker_colour in (self.background, foreground):
            raise Inapplicable("marker colour conflicts with path colours")
        width = 2 * len(symbols) - 3
        current = len(symbols) - 2
        rows = [[self.background for _ in range(width)]]
        rows[0][current] = self.marker_colour
        for symbol in symbols:
            if symbol == "straight":
                for _ in range(2):
                    row = [self.background for _ in range(width)]
                    row[current] = foreground
                    rows.append(row)
                continue
            next_col = current + (1 if symbol == "right" else -1)
            if not (0 <= next_col < width):
                raise Inapplicable("turn exits the output canvas")
            row = [self.background for _ in range(width)]
            for col in range(min(current, next_col), max(current, next_col) + 1):
                row[col] = foreground
            rows.append(row)
            current = next_col
        return {"symbols": symbols, "foreground": foreground, "prediction": tuple(tuple(row) for row in rows)}

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "marker_colour": self.marker_colour},
            definitions={
                "left_symbol": "a 2x2 triomino missing its upper-left cell",
                "right_symbol": "a 2x2 triomino missing its upper-right cell",
                "straight_symbol": "a vertical domino",
            },
            propositions=[
                "Symbols are read from left to right.",
                "Left and right symbols emit one horizontal transition row; straight symbols emit two vertical rows.",
                "The green-style marker occupies the initial column above the path.",
            ],
            corollary="Execute the ordered symbol programme as a connected path.",
            common_notions=["instruction sequence", "turn", "straight", "path execution"],
        )


def _fit_symbolic_turn_path(pairs):
    marker_candidates = None
    for source, target in pairs:
        try:
            background = _unique_mode(source) if 0 not in _palette(source) else 0
            foreground, _ = _ordered_symbol_components(source, background=background)
        except Inapplicable:
            return []
        values = _palette(target) - {background, foreground}
        marker_candidates = values if marker_candidates is None else marker_candidates & values
    programs = []
    for background in _candidate_backgrounds(pairs):
        for marker in sorted(marker_candidates or ()):
            program = SymbolicTurnPathProgram(background, int(marker))
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# Four-way object composition.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FourWayObjectCrossProgram:
    background: int

    kind = "four_way_object_cross"
    description_length = 6

    @property
    def schema_key(self):
        return self.kind, self.background

    def analyse(self, value: Grid):
        value = grid(value)
        components = _components_same_colour(value, background=self.background, connectivity=8)
        if len(components) != 1:
            raise Inapplicable("requires exactly one connected foreground object")
        component = components[0]
        if any(cell != component["colour"] and cell != self.background for row in value for cell in row):
            raise Inapplicable("foreground palette is not monochrome")
        source = _crop(value, component["bbox"])
        h, w = _shape(source)
        size = h + 2 * w
        work = [[self.background for _ in range(size)] for _ in range(size)]
        top = _rotate_cw(source)
        right = _flip_horizontal(source)
        bottom = _rotate_ccw(source)
        placements = [
            (top, 0, w),
            (source, w, 0),
            (right, w, w + h),
            (bottom, w + h, w),
        ]
        for block, r0, c0 in placements:
            bh, bw = _shape(block)
            for r in range(bh):
                for c in range(bw):
                    if block[r][c] != self.background:
                        work[r0 + r][c0 + c] = block[r][c]
        return {"source_crop": source, "prediction": tuple(tuple(row) for row in work)}

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "layout": "top_rot90_cw_left_identity_right_reflection_bottom_rot90_ccw"},
            definitions={
                "source_object": "the unique connected monochrome foreground object",
                "central_gap": "an h by h background square separating four object roles",
            },
            propositions=[
                "The left role is the source object and the right role is its horizontal reflection.",
                "The top and bottom roles are clockwise and counter-clockwise quarter turns.",
                "Output dimensions are h + 2w in both axes.",
            ],
            corollary="Compose four transformed copies around a central background gap.",
            common_notions=["object crop", "rotation", "reflection", "cross composition"],
        )


def _fit_four_way_object_cross(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        program = FourWayObjectCrossProgram(background)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# Mask-kernel colour composition.
# ---------------------------------------------------------------------------


def _split_four_vertical_panels(value: Grid, *, background: int):
    value = grid(value)
    h, w = _shape(value)
    if h < 5 or w not in (4 * h + 3, 4 * h + 2):
        raise Inapplicable("four-panel scene has incompatible dimensions")
    separators = [h, 2 * h + 1, 3 * h + 2]
    if separators[-1] >= w:
        raise Inapplicable("separator geometry exceeds canvas")
    sep_values = []
    for c in separators:
        column = [value[r][c] for r in range(h)]
        if len(set(column)) != 1 or column[0] == background:
            raise Inapplicable("separator column is not a complete uniform line")
        sep_values.append(int(column[0]))
    if len(set(sep_values)) != 1:
        raise Inapplicable("separator colour is inconsistent")
    boundaries = [(0, h - 1), (h + 1, 2 * h), (2 * h + 2, 3 * h + 1), (3 * h + 3, w - 1)]
    n = h - 2
    panels = []
    for a, b in boundaries:
        segment_width = b - a + 1
        if segment_width not in (n + 1, n + 2):
            raise Inapplicable("panel segment width mismatch")
        if any(value[0][c] != background or value[-1][c] != background for c in range(a, b + 1)):
            raise Inapplicable("panel top/bottom border is not background")
        # All known scenes place one background margin before the n-column panel;
        # a final right margin may be omitted at the canvas boundary.
        panel_start = a + 1
        panel_end = panel_start + n - 1
        if panel_end > b:
            raise Inapplicable("panel does not fit its segment")
        if any(value[r][a] != background for r in range(h)):
            raise Inapplicable("panel left border is not background")
        if panel_end < b and any(value[r][b] != background for r in range(h)):
            raise Inapplicable("panel right border is not background")
        panel = tuple(tuple(value[r][c] for c in range(panel_start, panel_end + 1)) for r in range(1, h - 1))
        if _shape(panel) != (n, n):
            raise Inapplicable("panel crop shape mismatch")
        panels.append(panel)
    return tuple(panels), sep_values[0]


@dataclass(frozen=True)
class MaskKernelColourCompositionProgram:
    background: int
    kernel_index: int
    placement_index: int
    foreground_panel_index: int
    background_panel_index: int

    kind = "mask_kernel_colour_composition"
    description_length = 10

    @property
    def schema_key(self):
        return (self.kind, self.background, self.kernel_index, self.placement_index, self.foreground_panel_index, self.background_panel_index)

    def analyse(self, value: Grid):
        panels, separator_colour = _split_four_vertical_panels(value, background=self.background)
        kernel = panels[self.kernel_index]
        placement = panels[self.placement_index]
        fg_panel = panels[self.foreground_panel_index]
        bg_panel = panels[self.background_panel_index]
        n = len(kernel)
        kernel_colours = _palette(kernel) - {self.background}
        placement_colours = _palette(placement) - {self.background}
        if len(kernel_colours) != 1 or len(placement_colours) != 1:
            raise Inapplicable("kernel and placement panels must be binary masks")
        if len(_palette(kernel)) != 2 or len(_palette(placement)) != 2:
            raise Inapplicable("mask panels must contain active and inactive cells")
        if len(_palette(fg_panel)) != 1 or len(_palette(bg_panel)) != 1:
            raise Inapplicable("colour panels must be solid")
        fg_colour = next(iter(_palette(fg_panel)))
        bg_colour = next(iter(_palette(bg_panel)))
        if fg_colour in (self.background, bg_colour) or bg_colour == self.background:
            raise Inapplicable("output colour roles are invalid")
        kernel_active = next(iter(kernel_colours))
        placement_active = next(iter(placement_colours))
        work = [[bg_colour for _ in range(n * n)] for _ in range(n * n)]
        for br in range(n):
            for bc in range(n):
                if placement[br][bc] != placement_active:
                    continue
                for r in range(n):
                    for c in range(n):
                        work[br * n + r][bc * n + c] = fg_colour if kernel[r][c] == kernel_active else bg_colour
        return {
            "separator_colour": separator_colour,
            "kernel": kernel,
            "placement": placement,
            "foreground_colour": fg_colour,
            "background_colour": bg_colour,
            "prediction": tuple(tuple(row) for row in work),
        }

    def predict(self, value: Grid):
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "kernel_index": self.kernel_index,
                "placement_index": self.placement_index,
                "foreground_panel_index": self.foreground_panel_index,
                "background_panel_index": self.background_panel_index,
            },
            definitions={
                "kernel_mask": "one sparse binary panel defining the within-block support",
                "placement_mask": "one sparse binary panel defining active macro positions",
                "colour_roles": "two solid panels defining foreground and background output colours",
            },
            propositions=[
                "Each active placement cell emits the colourised kernel mask.",
                "Each inactive placement cell emits a solid background-colour block.",
                "Panel roles are fitted from demonstrations rather than assumed from colour identity.",
            ],
            corollary="Compose a macro grid of colourised kernel blocks.",
            common_notions=["binary mask", "kernel", "macro placement", "colour roles", "Kronecker composition"],
        )


def _fit_mask_kernel_composition(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        try:
            parsed = [_split_four_vertical_panels(source, background=background)[0] for source, _ in pairs]
        except Inapplicable:
            continue
        for kernel_index, placement_index in permutations(range(4), 2):
            remaining = [i for i in range(4) if i not in (kernel_index, placement_index)]
            for foreground_index, background_index in permutations(remaining, 2):
                program = MaskKernelColourCompositionProgram(background, kernel_index, placement_index, foreground_index, background_index)
                try:
                    if all(program.predict(source) == target for source, target in pairs):
                        programs.append(program)
                except Inapplicable:
                    continue
    return programs


# ---------------------------------------------------------------------------
# Fitting, inference, counterfactuals, and validation.
# ---------------------------------------------------------------------------


FITTERS = {
    "frame_size_fill_codebook": _fit_frame_size_codebook,
    "framed_payload_diagonal_duplication": _fit_framed_payload_duplication,
    "symbolic_turn_path": _fit_symbolic_turn_path,
    "four_way_object_cross": _fit_four_way_object_cross,
    "mask_kernel_colour_composition": _fit_mask_kernel_composition,
}


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, FrameSizeFillCodebookProgram):
        return tuple((frame["size"], frame["bbox"]) for frame in analysis["frames"])
    if isinstance(program, FramedPayloadDiagonalDuplicationProgram):
        return analysis["frame_colour"], analysis["payload"]
    if isinstance(program, SymbolicTurnPathProgram):
        return analysis["symbols"]
    if isinstance(program, FourWayObjectCrossProgram):
        return analysis["source_crop"]
    if isinstance(program, MaskKernelColourCompositionProgram):
        return analysis["kernel"], analysis["placement"], analysis["foreground_colour"], analysis["background_colour"]
    return program.schema_key


def fit_instruction_relation_stage_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds or FITTERS)
    programs = []
    for kind, fitter in FITTERS.items():
        if kind not in allowed:
            continue
        try:
            candidates = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            candidates = []
        for program in candidates:
            try:
                if not all(program.predict(source) == target for source, target in pairs):
                    continue
                if require_role_variation and len({_serial(_role_signature(program, source)) for source, _ in pairs}) < 2:
                    continue
                programs.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
    unique = {program.schema_key: program for program in programs}
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.schema_key)))


def _counterfactual_result(kind, rows):
    return {"kind": kind, "rows": rows, "passed": bool(rows) and all(row.get("passed") for row in rows)}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}
        if isinstance(program, FrameSizeFillCodebookProgram):
            analysis = program.analyse(source)
            broken = _array(source)
            frame = analysis["frames"][0]
            r0, c0, _, c1 = frame["bbox"]
            broken[r0][(c0 + c1) // 2] = program.background
            try:
                changed = program.predict(tuple(tuple(row) for row in broken))
                causal = changed != original
            except Inapplicable:
                causal = True
            passed = causal
            details = {"frame_break_changes_or_rejects": causal}
        elif isinstance(program, FramedPayloadDiagonalDuplicationProgram):
            analysis = program.analyse(source)
            broken = _array(source)
            # Break one frame edge.
            broken[0][1] = program.background
            try:
                changed = program.predict(tuple(tuple(row) for row in broken))
                frame_causal = changed != original
            except Inapplicable:
                frame_causal = True
            passed = frame_causal
            details = {"frame_break_changes_or_rejects": frame_causal}
        elif isinstance(program, SymbolicTurnPathProgram):
            foreground, symbols = _ordered_symbol_components(source, background=program.background)
            altered = _array(source)
            # Remove one instruction cell from the left-most component.
            cell = next(( (r,c) for r,row in enumerate(source) for c,value in enumerate(row) if value == foreground), None)
            if cell is None:
                causal = False
            else:
                altered[cell[0]][cell[1]] = program.background
                try:
                    changed = program.predict(tuple(tuple(row) for row in altered))
                    causal = changed != original
                except Inapplicable:
                    causal = True
            passed = causal
            details = {"instruction_change_changes_or_rejects": causal}
        elif isinstance(program, FourWayObjectCrossProgram):
            components = _components_same_colour(source, background=program.background, connectivity=4)
            colour = components[0]["colour"]
            fresh = _fresh_colour(source, forbidden=(program.background, colour))
            recoloured = tuple(tuple(fresh if cell == colour else cell for cell in row) for row in source)
            expected = tuple(tuple(fresh if cell == colour else cell for cell in row) for row in original)
            try:
                equivariant = program.predict(recoloured) == expected
            except Inapplicable:
                equivariant = False
            passed = equivariant
            details = {"recolour_equivariance": equivariant}
        elif isinstance(program, MaskKernelColourCompositionProgram):
            analysis = program.analyse(source)
            panels, _ = _split_four_vertical_panels(source, background=program.background)
            # Recolour the solid foreground panel in the original scene.
            fresh = _fresh_colour(source, forbidden=(analysis["background_colour"],))
            work = _array(source)
            h, w = _shape(source)
            # Locate panel segment through the known separator structure.
            sep_cols = [h, 2 * h + 1, 3 * h + 2]
            bounds=[]; start=0
            for sep in sep_cols:
                bounds.append((start, sep-1)); start=sep+1
            bounds.append((start,w-1))
            a,b=bounds[program.foreground_panel_index]
            for r in range(1,h-1):
                for c in range(a+1,b):
                    work[r][c]=fresh
            altered=tuple(tuple(row) for row in work)
            try:
                changed=program.predict(altered)
                equivariant=changed != original and fresh in _palette(changed)
            except Inapplicable:
                equivariant=False
            passed=equivariant
            details={"foreground_role_recolour_changes_prediction":equivariant}
        rows.append({"demonstration": index, "passed": passed, **details})
    return _counterfactual_result(program.kind, rows)


def infer_instruction_relation_stage_algebra(task, *, minimum_pairs=2, allowed_kinds=None, require_role_variation=True):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_instruction_relation_stage_programs(
        pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds, require_role_variation=require_role_variation
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "instruction_relation_stage_algebra": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema")
    if kind == "frame_size_fill_codebook":
        mapping = tuple((int(entry["frame_size"]), int(entry["fill_colour"])) for entry in parameters["mapping"])
        return FrameSizeFillCodebookProgram(int(parameters["background"]), tuple(sorted(mapping)))
    if kind == "framed_payload_diagonal_duplication":
        return FramedPayloadDiagonalDuplicationProgram(int(parameters["background"]))
    if kind == "symbolic_turn_path":
        return SymbolicTurnPathProgram(int(parameters["background"]), int(parameters["marker_colour"]))
    if kind == "four_way_object_cross":
        return FourWayObjectCrossProgram(int(parameters["background"]))
    if kind == "mask_kernel_colour_composition":
        return MaskKernelColourCompositionProgram(
            int(parameters["background"]), int(parameters["kernel_index"]), int(parameters["placement_index"]),
            int(parameters["foreground_panel_index"]), int(parameters["background_panel_index"]),
        )
    raise Inapplicable("unknown V132 schema")


def _validate_frame_codebook(clean, program, expected, full_pairs):
    signatures = []
    total_counts = Counter()
    per_demo_counts = []
    for demo in clean["train"]:
        sizes = program.frame_signatures(demo["input"])
        signatures.append(sizes)
        count = Counter(sizes)
        per_demo_counts.append(count)
        total_counts.update(count)
    folds = []
    redundant_folds = 0
    for held_index, held_demo in enumerate(clean["train"]):
        held_sizes = per_demo_counts[held_index]
        fully_redundant = all(total_counts[size] > count for size, count in held_sizes.items())
        if not fully_redundant:
            exact = program.predict(held_demo["input"]) == grid(held_demo["output"])
            folds.append({
                "held_index": held_index,
                "status": "unique" if exact else "no_fit",
                "validation_mode": "singleton_direct_code_witness",
                "held_example_exact": exact,
                "test_prediction_stable": True,
                "signature_redundant": False,
            })
            continue
        redundant_folds += 1
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_instruction_relation_stage_programs(
            remaining, minimum_pairs=1, allowed_kinds=(program.kind,), require_role_variation=False
        )
        held_exact = []
        for candidate in refitted:
            try:
                if candidate.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                predictions = tuple(candidate.predict(case["input"]) for case in clean["test"])
                held_exact.append(predictions)
            except Inapplicable:
                continue
        groups = set(held_exact)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "validation_mode": "redundant_witness_lodo",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "signature_redundant": True,
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    test_witnessed = all(size in program.mapping_dict() for case in clean["test"] for size in program.frame_signatures(case["input"]))
    counterfactual = _counterfactual_validation(program, full_pairs)
    passed = (
        redundant_folds >= 1
        and test_witnessed
        and all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
        and counterfactual.get("passed")
    )
    return {
        "passed": passed,
        "reason": "passed" if passed else "frame_codebook_validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "witnessed_codebook_plus_redundant_lodo",
        "redundant_lodo_folds": redundant_folds,
        "singleton_direct_witnesses": len(folds) - redundant_folds,
        "test_signatures_witnessed": test_witnessed,
    }


def validate_instruction_relation_stage_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])

    codebooks = [program for program in programs if isinstance(program, FrameSizeFillCodebookProgram)]
    if codebooks:
        checks = [_validate_frame_codebook(clean, program, expected, full_pairs) for program in codebooks]
        passed_checks = [check for check in checks if check.get("passed")]
        return passed_checks[0] if passed_checks else checks[0]

    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_instruction_relation_stage_programs(
            remaining, minimum_pairs=1, allowed_kinds=allowed_kinds, require_role_variation=False
        )
        groups = defaultdict(list)
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                cf = _counterfactual_validation(program, full_pairs)
                if not cf.get("passed"):
                    continue
                predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                groups[predictions].append(program.schema_key)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                continue
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if groups and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
            "held_example_exact": bool(groups),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        })
    counterfactuals = []
    seen = set()
    for program in programs:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, full_pairs))
        except Exception as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    cf_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and cf_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def instruction_relation_stage_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_instruction_relation_stage_programs(pairs)}))


infer = infer_instruction_relation_stage_algebra
validate = validate_instruction_relation_stage_algebra
