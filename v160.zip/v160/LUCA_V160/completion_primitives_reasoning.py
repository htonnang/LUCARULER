"""LUCA V135: anti-unified completion primitives.

Typed language:
scene -> candidate/relation -> completion/transfer primitive -> emission.

The family excludes task identifiers, official test targets, and stored
absolute demonstration coordinates.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache

from runtime import public_task

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anti_unified_completion_primitives"
LANGUAGE = "spinoza_completion_primitives_v135"
SCHEMA_VERSION = 1


class Inapplicable(ValueError):
    pass


def grid(value) -> Grid:
    return tuple(tuple(int(cell) for cell in row) for row in value)


def _array(value: Grid):
    return [list(row) for row in grid(value)]


def _shape(value: Grid):
    value = grid(value)
    return len(value), len(value[0])


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("mode not unique")
    return int(winners[0])


def _dirs(connectivity=4):
    if connectivity == 4:
        return ((-1, 0), (1, 0), (0, -1), (0, 1))
    return tuple(
        (dr, dc)
        for dr in (-1, 0, 1)
        for dc in (-1, 0, 1)
        if (dr, dc) != (0, 0)
    )


def _bbox(cells):
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _normalise(cells):
    r0, c0, _, _ = _bbox(cells)
    return frozenset((r - r0, c - c0) for r, c in cells)


def _components_of_colour(value: Grid, colour: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if value[r][c] != colour or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and value[nr][nc] == colour
                        and (nr, nc) not in seen
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            components.append(tuple(sorted(cells)))
    components.sort(key=_bbox)
    return tuple(components)


def _foreground_components(value: Grid, background: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if value[r][c] == background or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and value[nr][nc] != background
                        and (nr, nc) not in seen
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            components.append(tuple(sorted(cells)))
    components.sort(key=_bbox)
    return tuple(components)


def _fresh_colour(value, forbidden=()):
    used = _palette(value) | set(forbidden)
    for colour in range(1, 10):
        if colour not in used:
            return colour
    raise Inapplicable("no fresh ARC colour")


def _d4_variants(cells):
    points = tuple(cells)
    variants = set()
    for index in range(8):
        transformed = []
        for r, c in points:
            if index == 0:
                rr, cc = r, c
            elif index == 1:
                rr, cc = r, -c
            elif index == 2:
                rr, cc = -r, c
            elif index == 3:
                rr, cc = -r, -c
            elif index == 4:
                rr, cc = c, r
            elif index == 5:
                rr, cc = c, -r
            elif index == 6:
                rr, cc = -c, r
            else:
                rr, cc = -c, -r
            transformed.append((rr, cc))
        r0 = min(r for r, _ in transformed)
        c0 = min(c for _, c in transformed)
        variants.add(frozenset((r - r0, c - c0) for r, c in transformed))
    return tuple(sorted(variants, key=lambda value: (len(value), sorted(value))))


def _canonical_d4(cells):
    return min(tuple(sorted(variant)) for variant in _d4_variants(cells))


def _transform_grid(value: Grid, transform: str) -> Grid:
    value = grid(value)
    h, w = _shape(value)
    if transform == "identity":
        return value
    if transform == "rot90":
        return tuple(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))
    if transform == "rot180":
        return tuple(tuple(reversed(row)) for row in reversed(value))
    if transform == "rot270":
        return tuple(tuple(value[r][w - 1 - c] for r in range(h)) for c in range(w - 1, -1, -1))
    if transform == "flip_lr":
        return tuple(tuple(reversed(row)) for row in value)
    if transform == "flip_ud":
        return tuple(reversed(value))
    if transform == "transpose":
        return tuple(tuple(value[r][c] for r in range(h)) for c in range(w))
    if transform == "anti_transpose":
        return tuple(tuple(value[h - 1 - r][w - 1 - c] for r in range(h)) for c in range(w - 1, -1, -1))
    raise Inapplicable("unknown grid transform")


GRID_TRANSFORMS = (
    "identity", "rot90", "rot180", "rot270",
    "flip_lr", "flip_ud", "transpose", "anti_transpose",
)


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


# ---------------------------------------------------------------------------
# 1. Frequency-tail recolouring.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FrequencyTailRecolourProgram:
    preserve_count: int
    replacement_colour: int

    kind = "frequency_tail_recolour"

    @property
    def schema_key(self):
        return self.kind, self.preserve_count, self.replacement_colour

    def analyse(self, value):
        value = grid(value)
        counts = Counter(cell for row in value for cell in row)
        if self.replacement_colour in counts:
            raise Inapplicable("replacement colour already present")
        if len(counts) < self.preserve_count + 2:
            raise Inapplicable("insufficient palette classes")
        ranked = sorted(counts, key=lambda colour: (-counts[colour], colour))
        if counts[ranked[self.preserve_count - 1]] <= counts[ranked[self.preserve_count]]:
            raise Inapplicable("frequency boundary tied")
        preserved = frozenset(ranked[: self.preserve_count])
        changed = frozenset(ranked[self.preserve_count :])
        if len(changed) < 2:
            raise Inapplicable("requires multiple tail colours")
        return preserved, changed, counts

    def predict(self, value):
        value = grid(value)
        preserved, _, _ = self.analyse(value)
        return tuple(
            tuple(cell if cell in preserved else self.replacement_colour for cell in row)
            for row in value
        )

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "preserve_count": self.preserve_count,
                "replacement_colour": self.replacement_colour,
            },
            definitions={
                "frequency_class": "one input colour ranked by total material",
                "tail": "all colours below the strict preserved-frequency boundary",
            },
            propositions=[
                "The most frequent colour classes remain unchanged.",
                "Every lower-frequency colour class is replaced by one semantic colour.",
            ],
            corollary="Preserve the top frequency classes and recolour the frequency tail.",
            common_notions=["frequency", "strict rank", "palette class", "global recolouring"],
        )


def _fit_frequency_tail(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    input_palettes = [_palette(grid(source)) for source, _ in pairs]
    output_palettes = [_palette(grid(target)) for _, target in pairs]
    candidates = set.intersection(
        *(out - inp for inp, out in zip(input_palettes, output_palettes))
    ) if pairs else set()
    programs = []
    for replacement in sorted(candidates):
        for preserve_count in range(1, 5):
            program = FrequencyTailRecolourProgram(preserve_count, replacement)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 2. Exact-cover piece decomposition.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExactCoverPieceDecompositionProgram:
    background: int
    source_colour: int
    templates: tuple  # ((canonical_shape, output_colour), ...)

    kind = "exact_cover_piece_decomposition"

    @property
    def schema_key(self):
        return self.kind, self.background, self.source_colour, self.templates

    def _placements(self, value):
        value = grid(value)
        h, w = _shape(value)
        support = frozenset(
            (r, c)
            for r, row in enumerate(value)
            for c, cell in enumerate(row)
            if cell == self.source_colour
        )
        if not support or any(
            cell not in (self.background, self.source_colour)
            for row in value for cell in row
        ):
            raise Inapplicable("source must be binary")
        placements = []
        for canonical, colour in self.templates:
            for variant in _d4_variants(canonical):
                vh = max(r for r, _ in variant) + 1
                vw = max(c for _, c in variant) + 1
                for r0 in range(h - vh + 1):
                    for c0 in range(w - vw + 1):
                        cells = frozenset((r0 + r, c0 + c) for r, c in variant)
                        if cells <= support:
                            placements.append((cells, colour))
        unique = {}
        for cells, colour in placements:
            unique[(cells, colour)] = (cells, colour)
        placements = tuple(unique.values())
        by_cell = defaultdict(list)
        for index, (cells, _) in enumerate(placements):
            for cell in cells:
                by_cell[cell].append(index)
        if any(not by_cell[cell] for cell in support):
            raise Inapplicable("some source cells have no learned piece placement")
        return support, placements, by_cell

    def predict(self, value):
        value = grid(value)
        support, placements, by_cell = self._placements(value)
        colourings = set()
        limit = 20000
        visits = 0

        def search(remaining, chosen):
            nonlocal visits
            if len(colourings) > 1 or visits > limit:
                return
            visits += 1
            if not remaining:
                assignment = {}
                for index in chosen:
                    cells, colour = placements[index]
                    for cell in cells:
                        assignment[cell] = colour
                colourings.add(tuple(sorted(assignment.items())))
                return
            cell = min(
                remaining,
                key=lambda item: sum(placements[index][0] <= remaining for index in by_cell[item]),
            )
            for index in by_cell[cell]:
                cells, _ = placements[index]
                if cells <= remaining:
                    search(remaining - cells, chosen + (index,))

        search(support, ())
        if visits > limit or len(colourings) != 1:
            raise Inapplicable("piece cover is absent or non-consensual")
        assignment = dict(next(iter(colourings)))
        out = _array(value)
        for (r, c), colour in assignment.items():
            out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "source_colour": self.source_colour,
                "templates": [
                    {"shape": list(shape), "output_colour": colour}
                    for shape, colour in self.templates
                ],
            },
            definitions={
                "piece": "one D4 variant of a learned output-coloured support",
                "cover": "a non-overlapping exact cover of all source-colour cells",
            },
            propositions=[
                "The source support is decomposed into learned shape classes.",
                "Every exact cover must imply the same cell colouring.",
            ],
            corollary="Colour the unique-consensus exact cover by learned piece class.",
            common_notions=["exact cover", "D4 shape class", "non-overlap", "consensus"],
        )


def _rectangle_shape(height, width):
    return tuple((r, c) for r in range(height) for c in range(width))


def _support_tileable_by_rectangle(support, height, width):
    support = frozenset(support)
    variants = {(height, width), (width, height)}
    placements = []
    if not support:
        return False
    rmax = max(r for r, _ in support)
    cmax = max(c for _, c in support)
    for hh, ww in variants:
        for r0 in range(rmax - hh + 2):
            for c0 in range(cmax - ww + 2):
                cells = frozenset((r0 + r, c0 + c) for r in range(hh) for c in range(ww))
                if cells <= support:
                    placements.append(cells)
    by_cell = defaultdict(list)
    for cells in placements:
        for cell in cells:
            by_cell[cell].append(cells)
    if any(not by_cell[cell] for cell in support):
        return False
    visits = 0
    limit = 10000
    def search(remaining):
        nonlocal visits
        visits += 1
        if visits > limit:
            return False
        if not remaining:
            return True
        cell = min(remaining, key=lambda item: len(by_cell[item]))
        return any(search(remaining - cells) for cells in by_cell[cell] if cells <= remaining)
    return search(support)


def _fit_exact_cover(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    first_source = grid(pairs[0][0])
    colours = Counter(cell for row in first_source for cell in row)
    if len(colours) != 2:
        return []
    backgrounds = [0] if 0 in colours else [colour for colour, _ in colours.most_common()]
    programs = []
    for background in backgrounds:
        source_colour = next((colour for colour in colours if colour != background), None)
        if source_colour is None:
            continue
        outputs_by_colour = defaultdict(list)
        valid = True
        for source, target in pairs:
            source, target = grid(source), grid(target)
            if _palette(source) != {background, source_colour}:
                valid = False
                break
            source_support = {(r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell != background}
            target_support = {(r, c) for r, row in enumerate(target) for c, cell in enumerate(row) if cell != background}
            if source_support != target_support or source_colour in _palette(target):
                valid = False
                break
            for colour in sorted(_palette(target) - {background}):
                outputs_by_colour[colour].append({
                    (r, c) for r, row in enumerate(target) for c, cell in enumerate(row) if cell == colour
                })
        if not valid or len(outputs_by_colour) < 2:
            continue
        learned = {}
        for colour, supports in outputs_by_colour.items():
            candidates = []
            for hh in range(1, 5):
                for ww in range(hh, 6):
                    area = hh * ww
                    if area < 2:
                        continue
                    if all(len(support) % area == 0 and _support_tileable_by_rectangle(support, hh, ww) for support in supports):
                        candidates.append((area, hh, ww))
            if not candidates:
                valid = False
                break
            best_area = max(area for area, _, _ in candidates)
            best = [(hh, ww) for area, hh, ww in candidates if area == best_area]
            if len(best) != 1:
                valid = False
                break
            hh, ww = best[0]
            learned[tuple(_rectangle_shape(hh, ww))] = colour
        if not valid or len(learned) < 2:
            continue
        templates = tuple(sorted(learned.items(), key=lambda item: (len(item[0]), item[0], item[1])))
        program = ExactCoverPieceDecompositionProgram(background, source_colour, templates)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 3. External-marker to rectangle-boundary projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BoundaryMarkerProjectionProgram:
    background: int
    rectangle_colour: int

    kind = "boundary_marker_projection"

    @property
    def schema_key(self):
        return self.kind, self.background, self.rectangle_colour

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        cells = [(r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == self.rectangle_colour]
        if not cells:
            raise Inapplicable("rectangle colour absent")
        r0, c0, r1, c1 = _bbox(cells)
        if r1 - r0 < 1 or c1 - c0 < 1:
            raise Inapplicable("rectangle too small")
        if any(value[r][c] != self.rectangle_colour for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)):
            raise Inapplicable("rectangle not solid")
        if len(cells) != (r1 - r0 + 1) * (c1 - c0 + 1):
            raise Inapplicable("rectangle colour occurs outside solid rectangle")
        markers = []
        for r in range(h):
            for c in range(w):
                colour = value[r][c]
                if colour in (self.background, self.rectangle_colour):
                    continue
                if r0 <= r <= r1 and c0 <= c <= c1:
                    raise Inapplicable("foreign cell inside rectangle")
                row_aligned = r0 <= r <= r1
                col_aligned = c0 <= c <= c1
                if row_aligned == col_aligned:
                    raise Inapplicable("marker not uniquely axis aligned")
                if row_aligned:
                    target = (r, c0 if c < c0 else c1)
                else:
                    target = (r0 if r < r0 else r1, c)
                markers.append((r, c, colour, target))
        if len(markers) < 2:
            raise Inapplicable("requires multiple external markers")
        targets = {}
        for _, _, colour, target in markers:
            previous = targets.get(target)
            if previous is not None and previous != colour:
                raise Inapplicable("marker target conflict")
            targets[target] = colour
        return (r0, c0, r1, c1), tuple(markers), targets

    def predict(self, value):
        value = grid(value)
        _, _, targets = self.analyse(value)
        out = _array(value)
        for (r, c), colour in targets.items():
            out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "rectangle_colour": self.rectangle_colour},
            definitions={
                "recipient": "the unique solid rectangle",
                "marker": "one external coloured singleton aligned with the rectangle",
            },
            propositions=[
                "A horizontal marker colours the nearest left or right boundary cell.",
                "A vertical marker colours the nearest top or bottom boundary cell.",
            ],
            corollary="Project every external marker onto the aligned rectangle boundary.",
            common_notions=["axis alignment", "nearest boundary", "marker", "solid rectangle"],
        )


def _fit_boundary_markers(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    common = set.intersection(*(_palette(grid(source)) for source, _ in pairs))
    programs = []
    for background in sorted(common):
        for rectangle_colour in sorted(common - {background}):
            program = BoundaryMarkerProjectionProgram(background, rectangle_colour)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 4. Spatial legend to object recolouring.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SpatialLegendObjectRecolourProgram:
    background: int
    panel_colour: int

    kind = "spatial_legend_object_recolour"

    @property
    def schema_key(self):
        return self.kind, self.background, self.panel_colour

    def _panel(self, value):
        value = grid(value)
        panel_cells = [(r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == self.panel_colour]
        if not panel_cells:
            raise Inapplicable("legend panel absent")
        r0, c0, r1, c1 = _bbox(panel_cells)
        area = (r1 - r0 + 1) * (c1 - c0 + 1)
        if area < 12 or any(value[r][c] == self.background for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)):
            raise Inapplicable("legend panel is not a filled rectangle")
        if any(value[r][c] == self.panel_colour and not (r0 <= r <= r1 and c0 <= c <= c1) for r, row in enumerate(value) for c, _ in enumerate(row)):
            raise Inapplicable("panel colour occurs outside legend")
        markers = [
            (r, c, value[r][c])
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if value[r][c] != self.panel_colour
        ]
        if len(markers) < 3 or len({colour for _, _, colour in markers}) != len(markers):
            raise Inapplicable("legend markers must be distinct")
        return (r0, c0, r1, c1), tuple(markers)

    @staticmethod
    def _object_row_groups(objects):
        ordered = sorted(objects, key=lambda item: (_bbox(item)[0], _bbox(item)[1]))
        groups = []
        for cells in ordered:
            r0, _, r1, _ = _bbox(cells)
            placed = False
            for group in groups:
                g0 = min(_bbox(item)[0] for item in group)
                g1 = max(_bbox(item)[2] for item in group)
                if not (r1 < g0 or r0 > g1):
                    group.append(cells)
                    placed = True
                    break
            if not placed:
                groups.append([cells])
        groups.sort(key=lambda group: min(_bbox(item)[0] for item in group))
        return groups

    def analyse(self, value):
        value = grid(value)
        panel_box, markers = self._panel(value)
        r0, c0, r1, c1 = panel_box
        outside = [
            value[r][c]
            for r, row in enumerate(value)
            for c, cell in enumerate(row)
            if not (r0 <= r <= r1 and c0 <= c <= c1) and cell != self.background
        ]
        colours = set(outside)
        if len(colours) != 1:
            raise Inapplicable("external objects must share one source colour")
        source_colour = next(iter(colours))
        objects = [
            component
            for component in _components_of_colour(value, source_colour, 8)
            if not all(r0 <= r <= r1 and c0 <= c <= c1 for r, c in component)
        ]
        if len(objects) != len(markers):
            raise Inapplicable("legend/object cardinalities differ")
        marker_groups = defaultdict(list)
        for marker in markers:
            marker_groups[marker[0]].append(marker)
        marker_rows = [sorted(marker_groups[row], key=lambda item: item[1]) for row in sorted(marker_groups)]
        object_rows = self._object_row_groups(objects)
        if len(marker_rows) != len(object_rows):
            raise Inapplicable("legend and object row groups differ")
        mapping = []
        for marker_group, object_group in zip(marker_rows, object_rows):
            object_group = sorted(object_group, key=lambda item: (_bbox(item)[1], _bbox(item)[0]))
            if len(marker_group) != len(object_group):
                raise Inapplicable("row-group cardinalities differ")
            mapping.extend((cells, marker[2]) for cells, marker in zip(object_group, marker_group))
        return panel_box, tuple(mapping)

    def predict(self, value):
        value = grid(value)
        _, mapping = self.analyse(value)
        out = _array(value)
        for cells, colour in mapping:
            for r, c in cells:
                out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "panel_colour": self.panel_colour},
            definitions={
                "legend_marker": "one coloured singleton inside a filled panel",
                "recipient": "one external monochrome object",
                "rank_correspondence": "row-group rank, then within-row column rank",
            },
            propositions=[
                "Legend markers and recipient objects have equal cardinality.",
                "Corresponding spatial ranks transfer marker colour to the whole object.",
            ],
            corollary="Recolour external objects from the spatially corresponding legend markers.",
            common_notions=["spatial rank", "legend", "homologous role", "whole-object recolouring"],
        )


def _fit_spatial_legend(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    common = set.intersection(*(_palette(grid(source)) for source, _ in pairs))
    programs = []
    for background in sorted(common):
        for panel_colour in sorted(common - {background}):
            program = SpatialLegendObjectRecolourProgram(background, panel_colour)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 5. Scaled pattern colour transfer.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ScaledPatternColourTransferProgram:
    background: int
    target_colour: int
    transform: str

    kind = "scaled_pattern_colour_transfer"

    @property
    def schema_key(self):
        return self.kind, self.background, self.target_colour, self.transform

    def analyse(self, value):
        value = grid(value)
        components = _foreground_components(value, self.background, 8)
        if len(components) != 2:
            raise Inapplicable("requires one instruction and one scaled target")
        records = []
        for cells in components:
            colours = {value[r][c] for r, c in cells}
            records.append((cells, colours))
        multi = [record for record in records if len(record[1]) >= 2]
        mono = [record for record in records if record[1] == {self.target_colour}]
        if len(multi) != 1 or len(mono) != 1:
            raise Inapplicable("instruction/target roles not unique")
        instruction_cells, _ = multi[0]
        target_cells, _ = mono[0]
        ir0, ic0, ir1, ic1 = _bbox(instruction_cells)
        tr0, tc0, tr1, tc1 = _bbox(target_cells)
        instruction = tuple(
            tuple(value[r][c] for c in range(ic0, ic1 + 1))
            for r in range(ir0, ir1 + 1)
        )
        transformed = _transform_grid(instruction, self.transform)
        ih, iw = _shape(transformed)
        th, tw = tr1 - tr0 + 1, tc1 - tc0 + 1
        if th % ih or tw % iw or th // ih != tw // iw or th // ih < 2:
            raise Inapplicable("target is not an integer isotropic scale")
        scale = th // ih
        mapping = []
        for rr in range(ih):
            for cc in range(iw):
                colour = transformed[rr][cc]
                block = {
                    value[tr0 + rr * scale + dr][tc0 + cc * scale + dc]
                    for dr in range(scale)
                    for dc in range(scale)
                }
                expected = {self.background} if colour == self.background else {self.target_colour}
                if block != expected:
                    raise Inapplicable("scaled support disagrees with transformed instruction")
                if colour != self.background:
                    mapping.append((rr, cc, colour))
        if len(mapping) < 3:
            raise Inapplicable("instruction too small")
        return (ir0, ic0, ir1 - ir0 + 1, ic1 - ic0 + 1), (tr0, tc0, scale), tuple(mapping)

    def predict(self, value):
        value = grid(value)
        _, (tr0, tc0, scale), mapping = self.analyse(value)
        out = _array(value)
        for rr, cc, colour in mapping:
            for dr in range(scale):
                for dc in range(scale):
                    out[tr0 + rr * scale + dr][tc0 + cc * scale + dc] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "target_colour": self.target_colour, "transform": self.transform},
            definitions={
                "instruction": "the compact multicolour pattern",
                "recipient": "a monochrome integer-scaled copy of the instruction support",
            },
            propositions=[
                "Every instruction cell corresponds to one uniform recipient block.",
                "Instruction colours are transferred blockwise while support is preserved.",
            ],
            corollary="Colour the scaled recipient blocks using the compact instruction pattern.",
            common_notions=["integer scale", "support homology", "block transfer", "pattern lifting"],
        )


def _fit_scaled_pattern(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    common = set.intersection(*(_palette(grid(source)) for source, _ in pairs))
    programs = []
    for background in sorted(common):
        for target_colour in sorted(common - {background}):
            for transform in GRID_TRANSFORMS:
                program = ScaledPatternColourTransferProgram(background, target_colour, transform)
                try:
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programs.append(program)
                except Inapplicable:
                    pass
    return programs


# ---------------------------------------------------------------------------
# 6. Panel-template occurrence recolouring.
# ---------------------------------------------------------------------------


def _regions_not_colour(value, separator):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    regions = []
    for r in range(h):
        for c in range(w):
            if value[r][c] == separator or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(4):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and value[nr][nc] != separator
                        and (nr, nc) not in seen
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            cells = tuple(sorted(cells))
            r0, c0, r1, c1 = _bbox(cells)
            if len(cells) != (r1 - r0 + 1) * (c1 - c0 + 1):
                raise Inapplicable("separator regions must be rectangular")
            regions.append(cells)
    regions.sort(key=_bbox)
    return tuple(regions)


@dataclass(frozen=True)
class PanelTemplateOccurrenceProgram:
    separator: int
    background: int
    source_colour: int

    kind = "panel_template_occurrence_recolour"

    @property
    def schema_key(self):
        return self.kind, self.separator, self.background, self.source_colour

    def analyse(self, value):
        value = grid(value)
        regions = _regions_not_colour(value, self.separator)
        dimensions = Counter()
        records = []
        for cells in regions:
            r0, c0, r1, c1 = _bbox(cells)
            dims = (r1 - r0 + 1, c1 - c0 + 1)
            dimensions[dims] += 1
            records.append((cells, (r0, c0, r1, c1), dims))
        if not dimensions:
            raise Inapplicable("no panel regions")
        standard, count = dimensions.most_common(1)[0]
        if count < 6 or standard[0] < 2 or standard[1] < 2:
            raise Inapplicable("insufficient standard panels")
        standard_records = [record for record in records if record[2] == standard]
        large_records = [record for record in records if record[2] != standard]
        candidates = []
        for cells, box, dims in large_records:
            if dims[0] % standard[0] or dims[1] % standard[1]:
                continue
            sr, sc = dims[0] // standard[0], dims[1] // standard[1]
            if sr != sc or sr < 2:
                continue
            r0, c0, _, _ = box
            colours = _palette(tuple(tuple(value[r][c] for c in range(c0, c0 + dims[1])) for r in range(r0, r0 + dims[0])))
            motif_colours = colours - {self.background}
            if len(motif_colours) != 1:
                continue
            template_colour = next(iter(motif_colours))
            if template_colour in (self.separator, self.source_colour):
                continue
            mask = []
            valid = True
            for rr in range(standard[0]):
                for cc in range(standard[1]):
                    block = {
                        value[r0 + rr * sr + dr][c0 + cc * sc + dc]
                        for dr in range(sr)
                        for dc in range(sc)
                    }
                    if block == {template_colour}:
                        mask.append((rr, cc))
                    elif block != {self.background}:
                        valid = False
            if valid and len(mask) >= 2:
                candidates.append((cells, template_colour, tuple(mask), box))
        if len(candidates) != 1:
            raise Inapplicable("template panel not unique")
        template_cells, template_colour, mask, template_box = candidates[0]
        matches = []
        for cells, box, _ in standard_records:
            r0, c0, _, _ = box
            if all(value[r0 + rr][c0 + cc] == self.source_colour for rr, cc in mask):
                matches.append((cells, box))
        if len(matches) < 2 or len(matches) == len(standard_records):
            raise Inapplicable("template support must select a proper panel subset")
        return template_cells, template_colour, mask, tuple(matches)

    def predict(self, value):
        value = grid(value)
        _, template_colour, mask, matches = self.analyse(value)
        out = _array(value)
        for _, box in matches:
            r0, c0, _, _ = box
            for rr, cc in mask:
                out[r0 + rr][c0 + cc] = template_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "separator": self.separator,
                "background": self.background,
                "source_colour": self.source_colour,
            },
            definitions={
                "template": "one larger panel containing an integer-scaled binary motif",
                "recipient_panel": "one standard panel containing the motif support in the source colour",
            },
            propositions=[
                "The template motif is downsampled by exact block uniformity.",
                "Every matching recipient panel recolours only the motif support.",
            ],
            corollary="Find every standard panel containing the template motif and transfer its colour.",
            common_notions=["separator lattice", "scaled template", "subpattern occurrence", "selective recolouring"],
        )


def _fit_panel_template(pairs):
    if not pairs or any(_shape(source) != _shape(target) for source, target in pairs):
        return []
    common = set.intersection(*(_palette(grid(source)) for source, _ in pairs))
    programs = []
    for separator in sorted(common):
        for background in sorted(common - {separator}):
            for source_colour in sorted(common - {separator, background}):
                program = PanelTemplateOccurrenceProgram(separator, background, source_colour)
                try:
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programs.append(program)
                except Inapplicable:
                    pass
    return programs


_FITTERS = {
    "frequency_tail_recolour": _fit_frequency_tail,
    "exact_cover_piece_decomposition": _fit_exact_cover,
    "boundary_marker_projection": _fit_boundary_markers,
    "spatial_legend_object_recolour": _fit_spatial_legend,
    "scaled_pattern_colour_transfer": _fit_scaled_pattern,
    "panel_template_occurrence_recolour": _fit_panel_template,
}


def fit_completion_primitive_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    programs = []
    seen = set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        for program in fitter(pairs):
            if program.schema_key not in seen:
                seen.add(program.schema_key)
                programs.append(program)
    return programs


def _counterfactual(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}
        try:
            if isinstance(program, FrequencyTailRecolourProgram):
                preserved, tail, counts = program.analyse(source)
                p = min(preserved, key=lambda colour: counts[colour])
                t = max(tail, key=lambda colour: counts[colour])
                work = _array(source)
                need = max(1, (counts[p] - counts[t]) // 2 + 1)
                changed = 0
                for r, row in enumerate(source):
                    for c, cell in enumerate(row):
                        if cell == p and changed < need:
                            work[r][c] = t
                            changed += 1
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"frequency_boundary_change_changes_or_rejects": passed}

            elif isinstance(program, ExactCoverPieceDecompositionProgram):
                work = _array(source)
                cell = next((
                    (r, c)
                    for r, row in enumerate(source)
                    for c, value in enumerate(row)
                    if value == program.source_colour
                ))
                work[cell[0]][cell[1]] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"piece_support_break_changes_or_rejects": passed}

            elif isinstance(program, BoundaryMarkerProjectionProgram):
                _, markers, _ = program.analyse(source)
                r, c, _, _ = markers[0]
                work = _array(source)
                work[r][c] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"marker_removal_changes_or_rejects": passed}

            elif isinstance(program, SpatialLegendObjectRecolourProgram):
                panel_box, _ = program.analyse(source)
                r0, c0, r1, c1 = panel_box
                marker = next(
                    (r, c)
                    for r in range(r0, r1 + 1)
                    for c in range(c0, c1 + 1)
                    if source[r][c] != program.panel_colour
                )
                fresh = _fresh_colour(source)
                work = _array(source)
                work[marker[0]][marker[1]] = fresh
                changed = program.predict(tuple(tuple(row) for row in work))
                passed = changed != original
                details = {"legend_recolour_changes_recipient": passed}

            elif isinstance(program, ScaledPatternColourTransferProgram):
                (ir0, ic0, ih0, iw0), _, _ = program.analyse(source)
                instruction_cells = [
                    (r, c)
                    for r in range(ir0, ir0 + ih0)
                    for c in range(ic0, ic0 + iw0)
                    if source[r][c] != program.background
                ]
                if not instruction_cells:
                    raise Inapplicable("instruction has no coloured cell")
                r, c = instruction_cells[0]
                fresh = _fresh_colour(source, (program.target_colour,))
                work = _array(source)
                work[r][c] = fresh
                changed = program.predict(tuple(tuple(row) for row in work))
                passed = changed != original
                details = {"instruction_recolour_propagates": passed}

            elif isinstance(program, PanelTemplateOccurrenceProgram):
                template_cells, _, _, _ = program.analyse(source)
                r, c = next(iter(template_cells))
                # Remove one template-colour cell, not a background cell.
                colour_cells = [(rr, cc) for rr, cc in template_cells if source[rr][cc] not in (program.background, program.separator)]
                r, c = colour_cells[0]
                work = _array(source)
                work[r][c] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"template_change_changes_or_rejects": passed}

        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **details})
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_completion_primitives(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_completion_primitive_programs(
        pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_completion_primitives": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programs_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = []
    for program in fit_completion_primitive_programs(
        pairs, minimum_pairs=2, allowed_kinds=allowed
    ):
        try:
            if (
                tuple(program.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(program, pairs).get("passed")
            ):
                programs.append(program)
        except Inapplicable:
            pass
    return expected, programs


def _validate_program(clean, program, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_completion_primitive_programs(
            remaining, minimum_pairs=1, allowed_kinds=(program.kind,)
        )
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(program, full_pairs)
    passed = all(
        fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds
    ) and counterfactual.get("passed")
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_completion_primitives(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programs = _programs_for_expected(clean, full)
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_program(clean, program, expected) for program in programs]
    passed = any(check.get("passed") for check in checks)
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": next((check["folds"] for check in checks if check.get("passed")), checks[0]["folds"]),
        "counterfactuals": [item for check in checks for item in check.get("counterfactuals", [])],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
