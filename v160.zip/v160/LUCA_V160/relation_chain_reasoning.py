"""LUCA V117: relation-chain graph programmes.

This proof-carrying research family extends V116 from one relation-bound
transformation to four instruction -> relation -> recipient chains:

* ``compressed_shape_class_recolour`` uses a run-compressed, dihedral-invariant
  topology signature to recolour all members of an instructed shape class;
* ``shape_legend_colour_transfer`` follows legend exemplar -> D4 shape class ->
  neutral recipient and transfers the exemplar colour;
* ``hierarchical_motif_object_projection`` projects a coloured instruction
  motif onto a self-similar graph of monochrome recipient objects;
* ``matrix_object_grid_projection`` projects a dense instructional colour
  matrix onto a complete grid of homologous recipient objects.

Programs use no task identifiers, stored demonstration coordinates, or test
outputs. Exact demonstration fit is necessary but not sufficient: accepted
predictions must survive leave-one-demonstration-out refitting, schema-specific
counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_relation_chain_graph_programmes"
LANGUAGE = "spinoza_relation_chain_graph_language_v1"
SCHEMA_VERSION = "relation_chain_graph_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _rot180(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(reversed(row)) for row in reversed(a))


@dataclass(frozen=True)
class _Component:
    colour: int
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    mask: tuple[tuple[int, int], ...]

    @property
    def height(self) -> int:
        return self.box[2] - self.box[0] + 1

    @property
    def width(self) -> int:
        return self.box[3] - self.box[1] + 1

    @property
    def area(self) -> int:
        return len(self.cells)


def _normalise(points: Iterable[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    points = tuple(points)
    if not points:
        return ()
    r0 = min(r for r, _ in points)
    c0 = min(c for _, c in points)
    return tuple(sorted((r - r0, c - c0) for r, c in points))


def _colour_components(value: Grid, colour: int, connectivity: int = 4) -> tuple[_Component, ...]:
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    a = grid(value)
    h, w = _shape(a)
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions.extend([(1, 1), (1, -1), (-1, 1), (-1, -1)])
    seen: set[tuple[int, int]] = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or a[r][c] != colour:
                continue
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w):
                        continue
                    if (nr, nc) in seen or a[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    queue.append((nr, nc))
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            result.append(_Component(
                colour,
                tuple(sorted(cells)),
                (r0, c0, r1, c1),
                _normalise(cells),
            ))
    return tuple(result)


def _all_monochrome_components(value: Grid, background: int, connectivity: int = 4) -> tuple[_Component, ...]:
    result = []
    for colour in sorted(_palette(value) - {background}):
        result.extend(_colour_components(value, colour, connectivity))
    return tuple(result)


def _mask_matrix(mask: tuple[tuple[int, int], ...]) -> tuple[tuple[int, ...], ...]:
    if not mask:
        raise Inapplicable("empty component mask")
    h = max(r for r, _ in mask) + 1
    w = max(c for _, c in mask) + 1
    points = set(mask)
    return tuple(tuple(1 if (r, c) in points else 0 for c in range(w)) for r in range(h))


def _rot90(matrix: tuple[tuple[int, ...], ...]) -> tuple[tuple[int, ...], ...]:
    h, w = len(matrix), len(matrix[0])
    return tuple(tuple(matrix[h - 1 - r][c] for r in range(h)) for c in range(w))


def _flip_lr(matrix: tuple[tuple[int, ...], ...]) -> tuple[tuple[int, ...], ...]:
    return tuple(tuple(reversed(row)) for row in matrix)


def _d4_matrices(matrix: tuple[tuple[int, ...], ...]) -> tuple[tuple[tuple[int, ...], ...], ...]:
    result = []
    seen = set()
    current = matrix
    for _ in range(4):
        for candidate in (current, _flip_lr(current)):
            key = (len(candidate), len(candidate[0]), candidate)
            if key not in seen:
                seen.add(key)
                result.append(candidate)
        current = _rot90(current)
    return tuple(result)


def _canonical_d4_mask(mask: tuple[tuple[int, int], ...]):
    candidates = []
    for matrix in _d4_matrices(_mask_matrix(mask)):
        candidates.append((len(matrix), len(matrix[0]), matrix))
    return min(candidates, key=repr)


def _compress_runs(matrix: tuple[tuple[int, ...], ...]) -> tuple[tuple[int, ...], ...]:
    rows = [tuple(row) for row in matrix]
    changed = True
    while changed:
        changed = False
        reduced_rows = [rows[0]]
        for row in rows[1:]:
            if row != reduced_rows[-1]:
                reduced_rows.append(row)
        if len(reduced_rows) != len(rows):
            rows = reduced_rows
            changed = True
        columns = [tuple(row[c] for row in rows) for c in range(len(rows[0]))]
        reduced_columns = [columns[0]]
        for column in columns[1:]:
            if column != reduced_columns[-1]:
                reduced_columns.append(column)
        if len(reduced_columns) != len(columns):
            rows = [tuple(column[r] for column in reduced_columns) for r in range(len(rows))]
            changed = True
    return tuple(rows)


def _compressed_d4_signature(mask: tuple[tuple[int, int], ...]):
    candidates = []
    for matrix in _d4_matrices(_mask_matrix(mask)):
        compressed = _compress_runs(matrix)
        candidates.append((len(compressed), len(compressed[0]), compressed))
    return min(candidates, key=repr)


def _rank_coordinates(points: Iterable[tuple[int, int]]) -> dict[tuple[int, int], tuple[int, int]]:
    points = tuple(points)
    if not points:
        raise Inapplicable("empty coordinate set")
    rows = {value: index for index, value in enumerate(sorted({r for r, _ in points}))}
    cols = {value: index for index, value in enumerate(sorted({c for _, c in points}))}
    return {(r, c): (rows[r], cols[c]) for r, c in points}


# ---------------------------------------------------------------------------
# Schema I: compressed topology class selects scale-varying homologs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CompressedShapeClassRecolourProgram:
    exemplar_colour: int
    recipient_colour: int
    connectivity: int = 4
    kind: str = "compressed_shape_class_recolour"

    @property
    def schema_key(self):
        return (self.kind, self.exemplar_colour, self.recipient_colour, self.connectivity)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        if _palette(a) - {background} != {self.exemplar_colour, self.recipient_colour}:
            raise Inapplicable("requires exactly exemplar and recipient colours")
        exemplars = _colour_components(a, self.exemplar_colour, self.connectivity)
        recipients = _colour_components(a, self.recipient_colour, self.connectivity)
        if len(exemplars) != 1 or len(recipients) < 2:
            raise Inapplicable("requires one exemplar and multiple recipients")
        signature = _compressed_d4_signature(exemplars[0].mask)
        matches = tuple(component for component in recipients if _compressed_d4_signature(component.mask) == signature)
        nonmatches = tuple(component for component in recipients if _compressed_d4_signature(component.mask) != signature)
        if not matches or not nonmatches:
            raise Inapplicable("requires both matching and nonmatching recipient classes")
        output = _array(a)
        for component in matches:
            for r, c in component.cells:
                output[r][c] = self.exemplar_colour
        return background, exemplars[0], recipients, matches, nonmatches, tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, exemplar, recipients, matches, nonmatches, _ = self._analyse(source)
            evidence.append({
                "exemplar_box": list(exemplar.box),
                "recipient_count": len(recipients),
                "matching_count": len(matches),
                "nonmatching_count": len(nonmatches),
                "compressed_signature": repr(_compressed_d4_signature(exemplar.mask)),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "exemplar_colour": self.exemplar_colour,
                "recipient_colour": self.recipient_colour,
                "connectivity": self.connectivity,
                "shape_abstraction": "run_compressed_d4",
            },
            "definitions": [
                {"name": "InstructionalShape", "type": "Component -> CompressedD4Signature"},
                {"name": "ScaleVaryingHomolog", "type": "Component -> Boolean"},
                {"name": "ClassRecolour", "type": "HomologSet -> GridEdit"},
            ],
            "propositions": [
                {"index": 1, "definition": "CompressRuns", "effect": "remove repeated rows and columns while preserving topology"},
                {"index": 2, "definition": "BindShapeClass", "effect": "select recipient components with the exemplar signature"},
                {"index": 3, "definition": "TransferExemplarColour", "effect": "recolour the selected class only"},
            ],
            "corollary": "a coloured exemplar defines a scale- and dihedral-invariant recipient class",
            "common_notions": [{"name": "compressed_shape_class_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema II: multiple shape exemplars form a colour legend
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ShapeLegendColourTransferProgram:
    recipient_colour: int
    connectivity: int = 4
    kind: str = "shape_legend_colour_transfer"

    @property
    def schema_key(self):
        return (self.kind, self.recipient_colour, self.connectivity)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        recipients = _colour_components(a, self.recipient_colour, self.connectivity)
        if len(recipients) < 2:
            raise Inapplicable("requires multiple neutral recipients")
        recipient_signatures = {_canonical_d4_mask(component.mask) for component in recipients}
        if len(recipient_signatures) < 2:
            raise Inapplicable("requires at least two recipient shape classes")
        mapping = {}
        witnesses = []
        for component in _all_monochrome_components(a, background, self.connectivity):
            if component.colour == self.recipient_colour:
                continue
            signature = _canonical_d4_mask(component.mask)
            if signature not in recipient_signatures:
                continue
            if signature in mapping and mapping[signature] != component.colour:
                raise Inapplicable("legend assigns two colours to one shape")
            mapping[signature] = component.colour
            witnesses.append(component)
        if set(mapping) != recipient_signatures or len(set(mapping.values())) < 2:
            raise Inapplicable("legend does not uniquely cover recipient shape classes")
        output = _array(a)
        for component in recipients:
            colour = mapping[_canonical_d4_mask(component.mask)]
            for r, c in component.cells:
                output[r][c] = colour
        return background, recipients, tuple(witnesses), mapping, tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, recipients, witnesses, mapping, _ = self._analyse(source)
            evidence.append({
                "recipient_count": len(recipients),
                "recipient_shape_classes": len(mapping),
                "legend_exemplars": len(witnesses),
                "legend_colours": sorted(set(mapping.values())),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "recipient_colour": self.recipient_colour,
                "connectivity": self.connectivity,
                "shape_group": "D4",
            },
            "definitions": [
                {"name": "ShapeLegend", "type": "ExemplarSet -> ShapeColourMap"},
                {"name": "D4ShapeClass", "type": "Component -> CanonicalShape"},
                {"name": "NeutralRecipient", "type": "Component -> Boolean"},
            ],
            "propositions": [
                {"index": 1, "definition": "BuildLegend", "effect": "map exemplar shape classes to colours"},
                {"index": 2, "definition": "BindRecipients", "effect": "classify neutral components by D4 shape"},
                {"index": 3, "definition": "TransferLegendColour", "effect": "recolour every matched recipient"},
            ],
            "corollary": "a multi-shape legend determines the colour of every dihedrally homologous recipient",
            "common_notions": [{"name": "shape_legend_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema III: coloured motif projects onto a self-similar object graph
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HierarchicalMotifObjectProjectionProgram:
    recipient_colour: int
    connectivity: int = 8
    kind: str = "hierarchical_motif_object_projection"

    @property
    def schema_key(self):
        return (self.kind, self.recipient_colour, self.connectivity)

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        recipients = _colour_components(a, self.recipient_colour, self.connectivity)
        if len(recipients) < 3:
            raise Inapplicable("requires at least three recipient objects")
        masks = {component.mask for component in recipients}
        if len(masks) != 1:
            raise Inapplicable("recipient objects are not homologous")
        instruction = tuple(
            (r, c, a[r][c])
            for r in range(len(a))
            for c in range(len(a[0]))
            if a[r][c] not in (background, self.recipient_colour)
        )
        if len(instruction) != len(recipients) or len({colour for _, _, colour in instruction}) < 2:
            raise Inapplicable("instruction and recipient cardinalities do not agree")
        instruction_points = tuple((r, c) for r, c, _ in instruction)
        instruction_rank = _rank_coordinates(instruction_points)
        instruction_by_rank = {instruction_rank[(r, c)]: colour for r, c, colour in instruction}
        origins = tuple((component.box[0], component.box[1]) for component in recipients)
        recipient_rank = _rank_coordinates(origins)
        recipient_by_rank = {
            recipient_rank[(component.box[0], component.box[1])]: component for component in recipients
        }
        if set(instruction_by_rank) != set(recipient_by_rank):
            raise Inapplicable("instruction layout and recipient graph are not homologous")
        common_mask = next(iter(masks))
        if tuple(sorted(instruction_by_rank)) != common_mask:
            raise Inapplicable("instruction support is not self-similar to recipient objects")
        output = _array(a)
        for role, colour in instruction_by_rank.items():
            for r, c in recipient_by_rank[role].cells:
                output[r][c] = colour
        return background, instruction, recipients, instruction_by_rank, recipient_by_rank, tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, instruction, recipients, instruction_by_rank, _, _ = self._analyse(source)
            evidence.append({
                "instruction_cells": len(instruction),
                "instruction_colours": sorted({colour for _, _, colour in instruction}),
                "recipient_objects": len(recipients),
                "logical_shape": [
                    max(r for r, _ in instruction_by_rank) + 1,
                    max(c for _, c in instruction_by_rank) + 1,
                ],
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "recipient_colour": self.recipient_colour,
                "connectivity": self.connectivity,
                "layout_relation": "rank_homology",
            },
            "definitions": [
                {"name": "ColouredInstructionMotif", "type": "Grid -> RankedColourPattern"},
                {"name": "HomologousObjectGraph", "type": "ComponentSet -> RankedObjectPattern"},
                {"name": "SelfSimilarSupport", "type": "InstructionPattern x ObjectMask -> Boolean"},
            ],
            "propositions": [
                {"index": 1, "definition": "RankInstructionCells", "effect": "express the coloured motif in logical coordinates"},
                {"index": 2, "definition": "RankRecipientObjects", "effect": "express object positions in the same coordinate system"},
                {"index": 3, "definition": "ProjectCellColours", "effect": "recolour each whole object from its homologous instruction role"},
            ],
            "corollary": "a coloured motif determines the colours of a self-similar graph of recipient objects",
            "common_notions": [{"name": "hierarchical_projection_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema IV: dense colour matrix projects onto a complete object grid
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MatrixObjectGridProjectionProgram:
    recipient_colour: int
    connectivity: int = 4
    kind: str = "matrix_object_grid_projection"

    @property
    def schema_key(self):
        return (self.kind, self.recipient_colour, self.connectivity)

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        recipients = _colour_components(a, self.recipient_colour, self.connectivity)
        if len(recipients) < 4:
            raise Inapplicable("requires a grid of recipient objects")
        masks = {component.mask for component in recipients}
        if len(masks) != 1:
            raise Inapplicable("recipient objects are not homologous")
        instruction = tuple(
            (r, c, a[r][c])
            for r in range(len(a))
            for c in range(len(a[0]))
            if a[r][c] not in (background, self.recipient_colour)
        )
        if not instruction:
            raise Inapplicable("missing instructional colour matrix")
        r0 = min(r for r, _, _ in instruction)
        r1 = max(r for r, _, _ in instruction)
        c0 = min(c for _, c, _ in instruction)
        c1 = max(c for _, c, _ in instruction)
        height, width = r1 - r0 + 1, c1 - c0 + 1
        if len(instruction) != height * width:
            raise Inapplicable("instruction is not a dense rectangle")
        if len({colour for _, _, colour in instruction}) < 2:
            raise Inapplicable("instruction matrix is not multicolour")
        origins = tuple((component.box[0], component.box[1]) for component in recipients)
        ranked = _rank_coordinates(origins)
        roles = set(ranked.values())
        expected = {(r, c) for r in range(height) for c in range(width)}
        if len(recipients) != height * width or roles != expected:
            raise Inapplicable("recipient object grid does not match instruction dimensions")
        recipient_by_role = {
            ranked[(component.box[0], component.box[1])]: component for component in recipients
        }
        instruction_by_role = {(r - r0, c - c0): colour for r, c, colour in instruction}
        output = _array(a)
        for role, component in recipient_by_role.items():
            colour = instruction_by_role[role]
            for r, c in component.cells:
                output[r][c] = colour
        return background, instruction, recipients, instruction_by_role, recipient_by_role, tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, instruction, recipients, instruction_by_role, _, _ = self._analyse(source)
            evidence.append({
                "instruction_shape": [
                    max(r for r, _ in instruction_by_role) + 1,
                    max(c for _, c in instruction_by_role) + 1,
                ],
                "instruction_colours": sorted({colour for _, _, colour in instruction}),
                "recipient_objects": len(recipients),
            })
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "recipient_colour": self.recipient_colour,
                "connectivity": self.connectivity,
                "grid_binding": "rank_complete",
            },
            "definitions": [
                {"name": "DenseColourMatrix", "type": "Grid -> LogicalColourGrid"},
                {"name": "HomologousObjectGrid", "type": "ComponentSet -> LogicalObjectGrid"},
                {"name": "RoleProjection", "type": "ColourGrid x ObjectGrid -> GridEdit"},
            ],
            "propositions": [
                {"index": 1, "definition": "ExtractInstructionMatrix", "effect": "recover the dense colour grid"},
                {"index": 2, "definition": "BindObjectGrid", "effect": "rank homologous recipient objects by row and column"},
                {"index": 3, "definition": "ProjectMatrixColours", "effect": "recolour each object from its corresponding instruction cell"},
            ],
            "corollary": "a dense colour matrix determines the colours of a complete homologous object grid",
            "common_notions": [{"name": "matrix_projection_evidence", "evidence": evidence}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Fitting and consensus inference
# ---------------------------------------------------------------------------


def _common_nonbackground_colours(pairs):
    common = None
    try:
        for source, _ in pairs:
            colours = _palette(source) - {_unique_modal(source)}
            common = colours if common is None else common & colours
    except (Inapplicable, ValueError, IndexError, TypeError):
        return set()
    return set(common or ())


def _fit_compressed_shape_class(pairs):
    colours = sorted(_common_nonbackground_colours(pairs))
    result = []
    for exemplar_colour in colours:
        for recipient_colour in colours:
            if exemplar_colour == recipient_colour:
                continue
            for connectivity in (4, 8):
                program = CompressedShapeClassRecolourProgram(exemplar_colour, recipient_colour, connectivity)
                try:
                    if all(program.predict(source) == target for source, target in pairs):
                        result.append(program)
                except (Inapplicable, ValueError, IndexError, TypeError):
                    continue
    return result


def _fit_shape_legend(pairs):
    result = []
    for recipient_colour in sorted(_common_nonbackground_colours(pairs)):
        for connectivity in (4, 8):
            program = ShapeLegendColourTransferProgram(recipient_colour, connectivity)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    result.append(program)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
    return result


def _fit_hierarchical_projection(pairs):
    result = []
    for recipient_colour in sorted(_common_nonbackground_colours(pairs)):
        for connectivity in (4, 8):
            program = HierarchicalMotifObjectProjectionProgram(recipient_colour, connectivity)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    result.append(program)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
    return result


def _fit_matrix_projection(pairs):
    result = []
    for recipient_colour in sorted(_common_nonbackground_colours(pairs)):
        for connectivity in (4, 8):
            program = MatrixObjectGridProjectionProgram(recipient_colour, connectivity)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    result.append(program)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
    return result


def _role_varies(program, pairs):
    evidence = []
    try:
        for source, _ in pairs:
            if isinstance(program, CompressedShapeClassRecolourProgram):
                _, exemplar, recipients, matches, nonmatches, _ = program._analyse(source)
                evidence.append((exemplar.box, tuple(component.box for component in matches), tuple(component.box for component in nonmatches)))
            elif isinstance(program, ShapeLegendColourTransferProgram):
                _, recipients, witnesses, mapping, _ = program._analyse(source)
                evidence.append((tuple(component.box for component in recipients), tuple(component.box for component in witnesses), tuple(sorted((repr(key), value) for key, value in mapping.items()))))
            elif isinstance(program, HierarchicalMotifObjectProjectionProgram):
                _, instruction, recipients, instruction_by_rank, _, _ = program._analyse(source)
                evidence.append((instruction, tuple(component.box for component in recipients), tuple(sorted(instruction_by_rank.items()))))
            elif isinstance(program, MatrixObjectGridProjectionProgram):
                _, instruction, recipients, instruction_by_role, _, _ = program._analyse(source)
                evidence.append((instruction, tuple(component.box for component in recipients), tuple(sorted(instruction_by_role.items()))))
            else:
                return False
    except (Inapplicable, ValueError, IndexError, TypeError):
        return False
    return len({_serial(item) for item in evidence}) >= 2


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "compressed_shape_class_recolour" in allowed:
        programs.extend(_fit_compressed_shape_class(pairs))
    if allowed is None or "shape_legend_colour_transfer" in allowed:
        programs.extend(_fit_shape_legend(pairs))
    if allowed is None or "hierarchical_motif_object_projection" in allowed:
        programs.extend(_fit_hierarchical_projection(pairs))
    if allowed is None or "matrix_object_grid_projection" in allowed:
        programs.extend(_fit_matrix_projection(pairs))
    return programs


def fit_relation_chain_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)),
    )


def infer_relation_chain(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_relation_chain_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "relation_chain_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "relation_chain_graph_programmes": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery and validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "compressed_shape_class_recolour":
        return CompressedShapeClassRecolourProgram(
            int(parameters["exemplar_colour"]),
            int(parameters["recipient_colour"]),
            int(parameters["connectivity"]),
        )
    if kind == "shape_legend_colour_transfer":
        return ShapeLegendColourTransferProgram(
            int(parameters["recipient_colour"]), int(parameters["connectivity"])
        )
    if kind == "hierarchical_motif_object_projection":
        return HierarchicalMotifObjectProjectionProgram(
            int(parameters["recipient_colour"]), int(parameters["connectivity"])
        )
    if kind == "matrix_object_grid_projection":
        return MatrixObjectGridProjectionProgram(
            int(parameters["recipient_colour"]), int(parameters["connectivity"])
        )
    raise Inapplicable("unknown relation-chain schema")


def _fresh_colour(value: Grid, forbidden=()):
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused counterfactual colour")


def _compressed_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, exemplar, _, _, _, _ = program._analyse(a)
        removed = _array(a)
        r, c = exemplar.cells[0]
        removed[r][c] = background
        try:
            exemplar_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            exemplar_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "exemplar_necessary": exemplar_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(row["exemplar_necessary"] and row["rotation_equivariant"] for row in rows),
    }


def _legend_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, _, witnesses, mapping, _ = program._analyse(a)
        witness = witnesses[0]
        removed = _array(a)
        for r, c in witness.cells:
            removed[r][c] = background
        try:
            legend_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            legend_necessary = True
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        for r, c in witness.cells:
            recoloured[r][c] = replacement
        try:
            changed = program.predict(tuple(tuple(row) for row in recoloured))
            recolour_propagates = changed != original and any(
                changed[r][c] == replacement
                for component in _colour_components(a, program.recipient_colour, program.connectivity)
                if _canonical_d4_mask(component.mask) == _canonical_d4_mask(witness.mask)
                for r, c in component.cells
            )
        except Inapplicable:
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "legend_necessary": legend_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
            "legend_shape_classes": len(mapping),
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["legend_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _hierarchical_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, instruction, _, instruction_by_rank, recipient_by_rank, _ = program._analyse(a)
        r, c, old_colour = instruction[0]
        removed = _array(a)
        removed[r][c] = background
        try:
            instruction_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            instruction_necessary = True
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        recoloured[r][c] = replacement
        try:
            changed = program.predict(tuple(tuple(row) for row in recoloured))
            role = _rank_coordinates((rr, cc) for rr, cc, _ in instruction)[(r, c)]
            recolour_propagates = changed != original and all(
                changed[rr][cc] == replacement for rr, cc in recipient_by_rank[role].cells
            )
        except (Inapplicable, KeyError):
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "instruction_necessary": instruction_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
            "instruction_roles": len(instruction_by_rank),
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["instruction_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _matrix_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background, instruction, _, instruction_by_role, recipient_by_role, _ = program._analyse(a)
        r, c, _ = instruction[0]
        removed = _array(a)
        removed[r][c] = background
        try:
            matrix_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            matrix_necessary = True
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        recoloured[r][c] = replacement
        try:
            changed = program.predict(tuple(tuple(row) for row in recoloured))
            r0 = min(rr for rr, _, _ in instruction)
            c0 = min(cc for _, cc, _ in instruction)
            role = (r - r0, c - c0)
            recolour_propagates = changed != original and all(
                changed[rr][cc] == replacement for rr, cc in recipient_by_role[role].cells
            )
        except (Inapplicable, KeyError):
            recolour_propagates = False
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "matrix_necessary": matrix_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
            "matrix_roles": len(instruction_by_role),
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["matrix_necessary"] and row["recolour_propagates"] and row["rotation_equivariant"]
            for row in rows
        ),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, CompressedShapeClassRecolourProgram):
        return _compressed_counterfactuals(program, pairs)
    if isinstance(program, ShapeLegendColourTransferProgram):
        return _legend_counterfactuals(program, pairs)
    if isinstance(program, HierarchicalMotifObjectProjectionProgram):
        return _hierarchical_counterfactuals(program, pairs)
    if isinstance(program, MatrixObjectGridProjectionProgram):
        return _matrix_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_relation_chain(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_relation_chain(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def relation_chain_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_relation_chain_programs(pairs)}))


infer = infer_relation_chain
validate = validate_relation_chain
