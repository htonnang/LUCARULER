"""V59 — derive dimension-dependent operators from demonstrations, not an integer menu.

Safely abstains if otherwise valid hypotheses conflict on held-out inputs.
"""
from dataclasses import dataclass
from geometry import grid, rotate, reflect, crop, infer_mapping, map_colors

@dataclass(frozen=True)
class InducedLaw:
    operation: str
    parameter: int
    rotation: int = 0
    flip: str = 'none'
    background: int | None = None
    palette: tuple = ()

    def predict(self, value):
        a=grid(value)
        if self.background is not None:a=crop(a,self.background)
        a=reflect(a,self.flip)
        a=rotate(a,self.rotation)
        n=self.parameter
        if self.operation=='scale':
            a=tuple(tuple(v for v in row for _ in range(n)) for row in a for _ in range(n))
        elif self.operation=='tile':
            a=tuple(tuple(v for _ in range(n) for v in row) for _ in range(n) for row in a)
        else:raise ValueError('unsupported operation')
        if len(a)>30 or len(a[0])>30:return None
        return map_colors(a,dict(self.palette))

def _shape(a):return len(a),len(a[0])

def infer(pairs, *, allow_palette=True, max_grid=30):
    """Infer scale / repeated tiling factors from actual output:input ratios.

    Require 2+ demonstrations to reduce accidental fits. All test results are
    validated without seeing test targets. Return distinct-fitting laws.
    """
    if len(pairs)<2:return []
    pairs=[(grid(a),grid(b)) for a,b in pairs]
    laws=[];seen=set()
    backgrounds=[None]+[c for c in range(10) if all(any(c in row for row in x) for x,_ in pairs)]
    for background in backgrounds:
        for flip in ('none','horizontal'):
            for rotation in range(4):
                transformed=[rotate(reflect(crop(x,background) if background is not None else x,flip),rotation) for x,_ in pairs]
                factors=[]
                for a,(_,y) in zip(transformed,pairs):
                    h,w=_shape(a);oh,ow=_shape(y)
                    if oh%h or ow%w or oh//h!=ow//w:break
                    factors.append(oh//h)
                else:
                    if len(set(factors))!=1:continue
                    factor=factors[0]
                    if factor<2 or factor>max_grid:continue
                    for operation in ('scale','tile'):
                        base=InducedLaw(operation,factor,rotation,flip,background)
                        preds=[base.predict(x) for x,_ in pairs]
                        if any(p is None for p in preds):continue
                        mapping=infer_mapping(preds,[y for _,y in pairs]) if allow_palette else ()
                        if mapping is None:continue
                        if not allow_palette and any(p!=y for p,(_,y) in zip(preds,pairs)):continue
                        mapping=tuple((a,b) for a,b in mapping if a!=b)
                        candidate=InducedLaw(operation,factor,rotation,flip,background,mapping)
                        if all(candidate.predict(x)==y for x,y in pairs) and candidate not in seen:
                            seen.add(candidate);laws.append(candidate)
    return laws


