"""LUCA V155: guide-extent coordinate projection.

This family anti-unifies three transformations in which a secondary guide
encodes a count or spatial extent that determines a structural projection:

    sparse markers around a solid bar -> compact boundary extensions
    a corner-attached run -> translate a full-canvas cross inward
    triangular guides beside a diagonal -> emit parallel diagonals

The implementation is task-ID blind and target blind. Colours, orientations,
counts, offsets, signal directions and guide sizes are inferred from the
training demonstrations or current input. No absolute demonstration
coordinates are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import permutations

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_guide_extent_coordinate_projection"
LANGUAGE = "spinoza_guide_extent_coordinate_projection_v155"
SCHEMA_VERSION = 1
OPERATOR = "guide_extent_coordinate_materialisation"
NODE_VOCABULARY = "reference_support_and_guide_extent_nodes"
EDGE_VOCABULARY = "count_offset_and_parallel_projection_edges"


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "guide_extent_coordinate_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "guide_extent_coordinates": True,
            "shared_guide_extent_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _common_input_colours(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes:
        return ()
    return tuple(sorted(set.intersection(*palettes)))


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int, connectivity: int = 4):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            neighbours = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
            if connectivity == 8:
                neighbours += [
                    (r - 1, c - 1), (r - 1, c + 1),
                    (r + 1, c - 1), (r + 1, c + 1),
                ]
            for point in neighbours:
                if point in remaining:
                    remaining.remove(point)
                    component.add(point)
                    stack.append(point)
        output.append(frozenset(component))
    output.sort(key=lambda component: (_bbox(component), len(component)))
    return tuple(output)


def _solid_rectangle(cells):
    box = _bbox(cells)
    r0, c0, r1, c1 = box
    expected = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
    if set(cells) != expected:
        raise Inapplicable("support is not a solid rectangle")
    return box


def _full_diagonal_cells(h, w, orientation, invariant):
    if orientation == "down_right":
        return {(r, c) for r in range(h) for c in range(w) if c - r == invariant}
    if orientation == "down_left":
        return {(r, c) for r in range(h) for c in range(w) if c + r == invariant}
    raise Inapplicable("unknown diagonal orientation")


def _diagonal_coordinate(point, orientation):
    r, c = point
    return c - r if orientation == "down_right" else c + r


def _parallel_coordinate(point, orientation):
    r, c = point
    return r + c if orientation == "down_right" else r - c


@dataclass(frozen=True)
class MarkerMultiplicityBoundaryProgram:
    background: int
    reference_colour: int

    kind = "marker_multiplicity_boundary_projection"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.reference_colour

    def _scene(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        palette = _palette(value)
        if self.background not in palette or self.reference_colour not in palette:
            raise Inapplicable("required background/reference roles are absent")
        other_colours = palette - {self.background, self.reference_colour}
        if len(other_colours) != 1:
            raise Inapplicable("exactly one input-derived marker role is required")
        marker_colour = next(iter(other_colours))
        reference_cells = {
            (r, c) for r in range(h) for c in range(w)
            if value[r][c] == self.reference_colour
        }
        box = _solid_rectangle(reference_cells)
        r0, c0, r1, c1 = box
        vertical = r0 == 0 and r1 == h - 1 and 1 < (c1 - c0 + 1) < w
        horizontal = c0 == 0 and c1 == w - 1 and 1 < (r1 - r0 + 1) < h
        if vertical == horizontal:
            raise Inapplicable("the reference must span exactly one canvas axis")
        orientation = "vertical" if vertical else "horizontal"
        markers = {
            (r, c) for r in range(h) for c in range(w)
            if value[r][c] == marker_colour
        }
        if not markers:
            raise Inapplicable("at least one marker is required")
        groups = Counter()
        for r, c in markers:
            if orientation == "vertical":
                if c < c0:
                    groups[("low", r)] += 1
                elif c > c1:
                    groups[("high", r)] += 1
                else:
                    raise Inapplicable("marker intersects the vertical reference")
            else:
                if r < r0:
                    groups[("low", c)] += 1
                elif r > r1:
                    groups[("high", c)] += 1
                else:
                    raise Inapplicable("marker intersects the horizontal reference")
        # The compacted extension must fit and initially contain only background.
        for (side, coordinate), count in groups.items():
            for offset in range(1, count + 1):
                if orientation == "vertical":
                    point = (coordinate, c0 - offset if side == "low" else c1 + offset)
                else:
                    point = (r0 - offset if side == "low" else r1 + offset, coordinate)
                rr, cc = point
                if not (0 <= rr < h and 0 <= cc < w):
                    raise Inapplicable("compacted boundary extension leaves the canvas")
                if value[rr][cc] not in {self.background, marker_colour}:
                    raise Inapplicable("boundary extension collides with material")
        return box, orientation, marker_colour, frozenset(markers), dict(groups)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        box, orientation, _, markers, groups = self._scene(value)
        r0, c0, r1, c1 = box
        output = _array(value)
        for r, c in markers:
            output[r][c] = self.background
        for (side, coordinate), count in groups.items():
            for offset in range(1, count + 1):
                if orientation == "vertical":
                    r = coordinate
                    c = c0 - offset if side == "low" else c1 + offset
                else:
                    r = r0 - offset if side == "low" else r1 + offset
                    c = coordinate
                output[r][c] = self.reference_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one full-axis solid reference bar and sparse markers outside it",
            relation_chain=(
                "extract the solid bar and its orientation",
                "group external markers by aligned row or column and side",
                "convert marker multiplicity into a compact boundary extension",
                "remove guide markers and materialise the reference-colour extension",
            ),
            parameters={
                "background": self.background,
                "reference_colour": self.reference_colour,
                "marker_colour": "input-derived non-reference role",
            },
            corollary="Project guide counts onto the nearest side of a full-axis reference bar.",
            notions=["full-axis reference", "marker multiplicity", "side role", "compact projection"],
        )


@dataclass(frozen=True)
class CornerRunCrossShiftProgram:
    background: int
    guide_colour: int

    kind = "corner_run_cross_translation"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.guide_colour

    def _scene(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        palette = _palette(value)
        if self.background not in palette or self.guide_colour not in palette:
            raise Inapplicable("required background/guide roles are absent")
        signal_colours = palette - {self.background, self.guide_colour}
        if len(signal_colours) != 1:
            raise Inapplicable("exactly one input-derived cross colour is required")
        signal_colour = next(iter(signal_colours))
        guide = {(r, c) for r in range(h) for c in range(w) if value[r][c] == self.guide_colour}
        if len(guide) < 1:
            raise Inapplicable("a nonempty guide run is required")

        corners = [
            (0, 0, "top_left"),
            (0, w - 1, "top_right"),
            (h - 1, 0, "bottom_left"),
            (h - 1, w - 1, "bottom_right"),
        ]
        candidates = []
        for cr, cc, name in corners:
            if (cr, cc) not in guide:
                continue
            vertical = {(r, cc) for r in range(h)}
            horizontal = {(cr, c) for c in range(w)}
            if guide <= vertical:
                rows = sorted(r for r, _ in guide)
                expected = list(range(0, len(rows))) if cr == 0 else list(range(h - len(rows), h))
                if rows == expected:
                    candidates.append((name, "vertical", len(rows)))
            if guide <= horizontal:
                cols = sorted(c for _, c in guide)
                expected = list(range(0, len(cols))) if cc == 0 else list(range(w - len(cols), w))
                if cols == expected:
                    candidates.append((name, "horizontal", len(cols)))
        # A one-cell guide is simultaneously horizontal and vertical; its
        # corner and extent are nevertheless unique for the displacement law.
        collapsed = {}
        for name, orientation, extent in candidates:
            collapsed.setdefault((name, extent), set()).add(orientation)
        if len(collapsed) != 1:
            raise Inapplicable("the guide must identify one unique corner and extent")
        (corner, extent), orientations = next(iter(collapsed.items()))
        guide_orientation = next(iter(orientations)) if len(orientations) == 1 else "point"

        signal = {(r, c) for r in range(h) for c in range(w) if value[r][c] == signal_colour}
        rows = {r for r, _ in signal}
        cols = {c for _, c in signal}
        cross_candidates = []
        for row in rows:
            if all((row, c) in signal for c in range(w)):
                for col in cols:
                    expected = {(row, c) for c in range(w)} | {(r, col) for r in range(h)}
                    if signal == expected:
                        cross_candidates.append((row, col))
        if len(cross_candidates) != 1:
            raise Inapplicable("the signal must be one complete full-canvas cross")
        row, col = cross_candidates[0]

        dr = extent if corner.startswith("top") else -extent
        dc = extent if corner.endswith("left") else -extent
        new_row, new_col = row + dr, col + dc
        if not (0 <= new_row < h and 0 <= new_col < w):
            raise Inapplicable("guide-induced cross translation leaves the canvas")
        return signal_colour, frozenset(signal), frozenset(guide), corner, guide_orientation, extent, (row, col), (new_row, new_col)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        signal_colour, signal, guide, _, _, _, _, (new_row, new_col) = self._scene(value)
        output = _array(value)
        for r, c in signal | guide:
            output[r][c] = self.background
        for c in range(w):
            output[new_row][c] = signal_colour
        for r in range(h):
            output[r][new_col] = signal_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one full-canvas cross and one corner-attached straight guide run",
            relation_chain=(
                "extract the cross intersection and the guide-bearing corner",
                "measure the guide run extent",
                "translate both cross axes inward from the guide corner by that extent",
                "remove the guide and materialise the translated full-canvas cross",
            ),
            parameters={
                "background": self.background,
                "guide_colour": self.guide_colour,
                "cross_colour": "input-derived signal role",
            },
            corollary="Use a corner-run extent as a two-axis displacement for a complete cross.",
            notions=["corner guide", "run extent", "axis translation", "D4 corner role"],
        )


@dataclass(frozen=True)
class TriangularGuideParallelDiagonalProgram:
    background: int
    guide_colour: int

    kind = "triangular_guide_parallel_diagonal_projection"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.guide_colour

    def _triangle_record(self, component, orientation, invariant):
        offsets = [_diagonal_coordinate(point, orientation) - invariant for point in component]
        if not offsets or 0 in offsets or any((value > 0) != (offsets[0] > 0) for value in offsets):
            raise Inapplicable("guide triangle must occupy one side of the signal diagonal")
        sign = 1 if offsets[0] > 0 else -1
        distances = [abs(value) for value in offsets]
        side = max(distances)
        if side < 2 or len(component) != side * (side + 1) // 2:
            raise Inapplicable("guide component is not a right staircase triangle")
        counts = Counter(distances)
        if any(counts.get(distance, 0) != side - distance + 1 for distance in range(1, side + 1)):
            raise Inapplicable("guide distance levels do not form a staircase triangle")
        for distance in range(1, side + 1):
            points = [point for point in component if abs(_diagonal_coordinate(point, orientation) - invariant) == distance]
            parallel = sorted(_parallel_coordinate(point, orientation) for point in points)
            if len(parallel) > 1 and any(b - a != 2 for a, b in zip(parallel, parallel[1:])):
                raise Inapplicable("guide distance level is not contiguous along the diagonal")
        return sign, side

    def _scene(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        palette = _palette(value)
        if self.background not in palette or self.guide_colour not in palette:
            raise Inapplicable("required background/guide roles are absent")
        signal_colours = palette - {self.background, self.guide_colour}
        if len(signal_colours) != 1:
            raise Inapplicable("exactly one input-derived diagonal colour is required")
        signal_colour = next(iter(signal_colours))
        signal = {(r, c) for r in range(h) for c in range(w) if value[r][c] == signal_colour}
        diagonal_candidates = []
        for orientation in ("down_right", "down_left"):
            invariants = {_diagonal_coordinate(point, orientation) for point in signal}
            if len(invariants) != 1:
                continue
            invariant = next(iter(invariants))
            if signal == _full_diagonal_cells(h, w, orientation, invariant):
                diagonal_candidates.append((orientation, invariant))
        if len(diagonal_candidates) != 1:
            raise Inapplicable("the signal must be one complete clipped 45-degree diagonal")
        orientation, invariant = diagonal_candidates[0]

        guide_components = _components_of_colour(value, self.guide_colour, 4)
        if not guide_components:
            raise Inapplicable("one or more guide triangles are required")
        records = []
        new_invariants = set()
        for component in guide_components:
            sign, side = self._triangle_record(component, orientation, invariant)
            new_invariant = invariant + sign * (side + 2)
            line = _full_diagonal_cells(h, w, orientation, new_invariant)
            if not line:
                raise Inapplicable("guide-induced diagonal does not intersect the canvas")
            if new_invariant in new_invariants:
                raise Inapplicable("two guide triangles induce the same diagonal")
            new_invariants.add(new_invariant)
            records.append((component, sign, side, new_invariant, line))
        return signal_colour, frozenset(signal), orientation, invariant, tuple(records)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        signal_colour, _, _, _, records = self._scene(value)
        output = _array(value)
        for component, _, _, _, _ in records:
            for r, c in component:
                output[r][c] = self.background
        for _, _, _, _, line in records:
            for r, c in line:
                output[r][c] = signal_colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one complete 45-degree signal diagonal and one or more adjacent staircase triangles",
            relation_chain=(
                "extract the clipped signal diagonal and its orientation",
                "measure each guide triangle by signed diagonal side and staircase extent",
                "convert triangle side length n into a parallel offset of n plus two",
                "remove the guides and materialise the complete parallel diagonals",
            ),
            parameters={
                "background": self.background,
                "guide_colour": self.guide_colour,
                "signal_colour": "input-derived diagonal role",
            },
            corollary="Use each staircase-triangle extent to place a full parallel signal diagonal.",
            notions=["complete diagonal", "staircase triangle", "signed side", "extent-derived offset", "D4 diagonal orientation"],
        )


def _fit_marker_multiplicity(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background, reference_colour in permutations(common, 2):
        programme = MarkerMultiplicityBoundaryProgram(background, reference_colour)
        orientations = set()
        marker_colours = set()
        valid = True
        for source, target in pairs:
            try:
                _, orientation, marker_colour, _, groups = programme._scene(source)
                orientations.add(orientation)
                marker_colours.add(marker_colour)
                if not groups or programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and len(marker_colours) >= min(2, len(pairs)):
            output.append(programme)
    return output


def _fit_corner_cross(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background, guide_colour in permutations(common, 2):
        programme = CornerRunCrossShiftProgram(background, guide_colour)
        signal_colours = set()
        extents = set()
        valid = True
        for source, target in pairs:
            try:
                signal_colour, _, _, _, _, extent, _, _ = programme._scene(source)
                signal_colours.add(signal_colour)
                extents.add(extent)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and len(signal_colours) >= min(2, len(pairs)) and len(extents) >= 1:
            output.append(programme)
    return output


def _fit_triangular_diagonal(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background, guide_colour in permutations(common, 2):
        programme = TriangularGuideParallelDiagonalProgram(background, guide_colour)
        signal_colours = set()
        side_lengths = set()
        valid = True
        for source, target in pairs:
            try:
                signal_colour, _, _, _, records = programme._scene(source)
                signal_colours.add(signal_colour)
                side_lengths.update(record[2] for record in records)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and len(signal_colours) >= min(2, len(pairs)) and len(side_lengths) >= 2:
            output.append(programme)
    return output


_FITTERS = {
    "marker_multiplicity_boundary_projection": _fit_marker_multiplicity,
    "corner_run_cross_translation": _fit_corner_cross,
    "triangular_guide_parallel_diagonal_projection": _fit_triangular_diagonal,
}


def fit_guide_extent_coordinate_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, MarkerMultiplicityBoundaryProgram):
                box, _, marker_colour, markers, _ = programme._scene(source)
                r, c = sorted(markers)[0]
                candidates.append((r, c, programme.background, "guide_marker"))
                candidates.append((box[0], box[1], programme.background, "reference_corner"))
            elif isinstance(programme, CornerRunCrossShiftProgram):
                _, signal, guide, _, _, _, _, _ = programme._scene(source)
                r, c = sorted(guide)[-1]
                candidates.append((r, c, programme.background, "corner_guide_extent"))
                r, c = sorted(signal)[len(signal) // 2]
                candidates.append((r, c, programme.background, "cross_support"))
            elif isinstance(programme, TriangularGuideParallelDiagonalProgram):
                _, signal, _, _, records = programme._scene(source)
                r, c = sorted(records[0][0])[-1]
                candidates.append((r, c, programme.background, "triangle_extent"))
                r, c = sorted(signal)[len(signal) // 2]
                candidates.append((r, c, programme.background, "signal_diagonal"))
        except Inapplicable:
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {
                    "cell": [r, c],
                    "from": int(previous),
                    "to": int(replacement),
                    "role": role,
                }
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_guide_extent_coordinate_projection(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_guide_extent_coordinate_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "guide_extent_coordinates": True,
            "shared_guide_extent_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_guide_extent_coordinate_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_guide_extent_coordinate_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_guide_extent_coordinate_projection(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
