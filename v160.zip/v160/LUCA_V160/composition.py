"""V64 finite, typed family composition. No task IDs, target grids, or learned lookup.

Grammar: input view (identity / D4 / foreground crop / unique size-selected
component) -> dihedral geometry + dimension-induced scale/tile + global bijective
colour map, OR V63 guarded completion. Pattern repair is terminal: its complete-
erasure contract is induced from its actual intermediate-to-final demonstrations.

All admissible prefixes are preserved. Identical demonstration states SHARE
suffix-fitting work, never replace each other's programs. No beam, first winner,
or max-program cutoff. V64 revision 2 adds a shared panel-partition,
Boolean-mask, and symbolic-paint program grammar guided by V38. A timeout invalidates acceptance of the entire search.
This is exhaustive only within this declared finite grammar, not all ARC programs.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from typing import Any

from correspondence import grid
from runtime import describe, joint_result, public_task
from geometry import rotate, reflect, infer_mapping
from pattern_completion import CompletionLaw, GENERATORS, erased_colour
from panel_layout import fit as fit_panels

Grid = tuple[tuple[int, ...], ...]


@lru_cache(maxsize=2048)
def components(a: Grid, background: int, connectivity: int) -> tuple:
    if connectivity not in (4, 8): raise ValueError('connectivity must be 4 or 8')
    h, w = len(a), len(a[0]); seen = set(); found = []
    dirs = ((-1,0),(1,0),(0,-1),(0,1))
    if connectivity == 8: dirs += ((-1,-1),(-1,1),(1,-1),(1,1))
    for r in range(h):
        for c in range(w):
            if a[r][c] == background or (r,c) in seen: continue
            queue = deque([(r,c)]); seen.add((r,c)); points = []
            while queue:
                rr,cc = queue.popleft(); points.append((rr,cc))
                for dr,dc in dirs:
                    nr,nc = rr+dr,cc+dc
                    if 0 <= nr < h and 0 <= nc < w and (nr,nc) not in seen and a[nr][nc] != background:
                        seen.add((nr,nc)); queue.append((nr,nc))
            found.append(tuple(sorted(points)))
    return tuple(found)


def d4(a: Grid, turns: int, flip: bool) -> Grid:
    return rotate(reflect(a, 'horizontal') if flip else a, turns)


@dataclass(frozen=True)
class View:
    kind: str = 'identity'
    background: int = 0
    connectivity: int = 4
    selection: str = 'largest'
    mode: str = 'crop'
    turns: int = 0
    flip: bool = False

    def predict(self, raw) -> Grid | None:
        a = grid(raw)
        if self.kind == 'identity': return a
        if self.kind == 'd4': return d4(a, self.turns, self.flip)
        if self.kind == 'foreground':
            pts = tuple((r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v != self.background)
            if not pts: return None
        elif self.kind == 'object':
            objects = components(a, self.background, self.connectivity)
            if not objects: return None
            wanted = (max if self.selection == 'largest' else min)(len(o) for o in objects)
            selected = [o for o in objects if len(o) == wanted]
            if len(selected) != 1: return None  # never silently return the input on a tie
            pts = selected[0]
        else: raise ValueError('unknown view')
        r0,r1 = min(r for r,c in pts),max(r for r,c in pts)
        c0,c1 = min(c for r,c in pts),max(c for r,c in pts)
        if self.kind == 'foreground': return tuple(row[c0:c1+1] for row in a[r0:r1+1])
        chosen = set(pts)
        if self.mode == 'mask': r0,c0,r1,c1 = 0,0,len(a)-1,len(a[0])-1
        return tuple(tuple(a[r][c] if (r,c) in chosen else self.background
                           for c in range(c0,c1+1)) for r in range(r0,r1+1))

    def name(self) -> str:
        if self.kind == 'identity': return 'input'
        if self.kind == 'd4': return f'view:D4(turns={self.turns},flip={self.flip})'
        if self.kind == 'foreground': return f'view:foreground_crop(background={self.background})'
        return f'view:object({self.selection},{self.connectivity}-connected,bg={self.background},mode={self.mode})'


@dataclass(frozen=True)
class SpatialLaw:
    turns: int = 0
    flip: bool = False
    operation: str = 'none'
    factor: int = 1
    palette: tuple = ()  # complete observed mapping, including identities when nontrivial

    def predict(self, raw) -> Grid | None:
        a = d4(grid(raw), self.turns, self.flip)
        n = self.factor
        if n < 1 or len(a)*n > 30 or len(a[0])*n > 30: return None
        if self.operation == 'scale':
            a = tuple(tuple(v for v in row for _ in range(n)) for row in a for _ in range(n))
        elif self.operation == 'tile':
            a = tuple(row*n for _ in range(n) for row in a)
        elif self.operation != 'none': raise ValueError('unknown spatial operation')
        if self.palette:
            mapping = dict(self.palette)
            if any(v not in mapping for row in a for v in row): return None
            a = tuple(tuple(mapping[v] for v in row) for row in a)
        return grid(a)

    def name(self) -> str:
        return f'geometry:D4({self.turns},{self.flip})/{self.operation}({self.factor})/colors={self.palette}'


@dataclass(frozen=True)
class FamilyProgram:
    view: View
    suffix: Any

    def predict(self, raw) -> Grid | None:
        a = self.view.predict(raw)
        if a is None: return None
        result = self.suffix.predict(a)
        return None if result is None else grid(result)

    def name(self) -> str:
        return self.view.name() + ' -> ' + describe(self.suffix)

    def template(self) -> str:
        start = {'identity':'input', 'd4':'geometry', 'foreground':'foreground_crop', 'object':'object_selection'}[self.view.kind]
        end = 'guarded_pattern' if isinstance(self.suffix, CompletionLaw) else 'geometry'
        if isinstance(self.suffix, SpatialLaw):
            if self.suffix.operation != 'none': end += '+' + self.suffix.operation
            if self.suffix.palette: end += '+symbolic_recolor'
        return start + ' -> ' + end


def candidate_views(inputs: tuple[Grid, ...]) -> list[View]:
    common = set(range(10))
    for a in inputs: common &= {v for row in a for v in row}
    result = [View()]
    result += [View(kind='d4', turns=k, flip=f) for f,k in product((False,True),range(4)) if f or k]
    for bg in sorted(common):
        result.append(View(kind='foreground', background=bg))
        for sel,conn,mode in product(('largest','smallest'),(4,8),('crop','mask')):
            result.append(View(kind='object', background=bg, selection=sel, connectivity=conn, mode=mode))
    return result


def fit_spatial(inputs: tuple[Grid, ...], targets: tuple[Grid, ...]) -> list[SpatialLaw]:
    laws = []
    for flip,turns in product((False,True),range(4)):
        transformed = tuple(d4(a,turns,flip) for a in inputs)
        factors = []
        for a,y in zip(transformed, targets):
            h,w,oh,ow = len(a),len(a[0]),len(y),len(y[0])
            if oh%h or ow%w or oh//h != ow//w: break
            factors.append(oh//h)
        else:
            if not factors or len(set(factors)) != 1: continue
            n = factors[0]
            if n < 1: continue
            for mode in ('none',) if n == 1 else ('scale','tile'):
                law = SpatialLaw(turns,flip,mode,n)
                outputs = tuple(law.predict(a) for a in inputs)
                if any(a is None for a in outputs): continue
                mapping = infer_mapping(outputs,targets)
                if mapping is None: continue
                # Pure identity is a structural law; nontrivial maps must cover every test colour.
                if all(a == b for a,b in mapping): mapping = ()
                candidate = SpatialLaw(turns,flip,mode,n,mapping)
                if all(candidate.predict(a) == y for a,y in zip(inputs,targets)):
                    laws.append(candidate)
    return laws


def fit_completion(inputs: tuple[Grid, ...], targets: tuple[Grid, ...]) -> list[CompletionLaw]:
    """V63 completion vocabulary, with the same mask contract and consistency kernel.

    Fast rejection uses the necessary condition that every edit originates in
    one mask colour. This does not guess an intermediate target or a donor.
    """
    changed = set()
    for a,y in zip(inputs,targets):
        if len(a)!=len(y) or len(a[0])!=len(y[0]): return []
        changed.update(a[r][c] for r in range(len(a)) for c in range(len(a[0])) if a[r][c]!=y[r][c])
    if len(changed)!=1: return []
    mask = next(iter(changed))
    complete = all(mask not in row for y in targets for row in y)
    choices = [('flip_rows',0),('flip_cols',0)]
    choices += [(relation,p) for relation in ('period_rows','period_cols') for p in range(2,7)]
    pairs = list(zip(inputs,targets))
    if erased_colour(pairs) is not None:
        choices += [(relation,0) for relation in GENERATORS if (relation,0) not in choices]
    result = []
    for relation,p in choices:
        law = CompletionLaw(relation,mask,complete,p)
        if all(law.predict(a)==y for a,y in pairs): result.append(law)
    return result


def synthesize(raw_pairs) -> tuple[list[Any], dict]:
    pairs = [(grid(a),grid(y)) for a,y in raw_pairs]
    if not pairs: raise ValueError('missing demonstrations')
    inputs,targets = tuple(a for a,y in pairs),tuple(y for a,y in pairs)
    views = candidate_views(inputs); suffix_cache = {}; programs = []
    admissible = 0; invalid = 0; unobserved_effect = 0
    for view in views:
        states = tuple(view.predict(a) for a in inputs)
        if any(s is None for s in states): invalid += 1; continue
        # An explicit relevance grammar: nonidentity views need an observed effect.
        # The identity view remains a member; nonidentity no-ops are not asserted equivalent.
        if view.kind != 'identity' and states == inputs:
            unobserved_effect += 1; continue
        admissible += 1
        if states not in suffix_cache:
            suffix_cache[states] = fit_spatial(states,targets) + fit_completion(states,targets)
        for law in suffix_cache[states]:
            program = FamilyProgram(view,law)
            if not all(program.predict(a)==y for a,y in pairs):
                raise AssertionError('a fitted program failed exact demonstration replay')
            programs.append(program)
    view_program_count = len(programs)
    panel_programs = fit_panels(pairs)
    programs.extend(panel_programs)
    return programs, {'panel_programs':len(panel_programs),'view_programs':view_program_count,'candidate_views':len(views),'admissible_views':admissible,
            'invalid_views':invalid,'views_without_observed_effect':unobserved_effect,
            'distinct_demonstration_states':len(suffix_cache),'fitted_programs':len(programs),
            'beam_pruning':False,'fitted_alternatives_discarded':False,
            'search_complete_within_declared_grammar':True,'terminal_patterns_are_v63_guarded':True}


def evaluate(programs: list, inputs: list) -> dict:
    groups = {}; rejected = 0; templates = {}
    for program in programs:
        predictions = tuple(program.predict(a) for a in inputs)
        if any(p is None for p in predictions): rejected += 1; continue
        key = tuple(grid(p) for p in predictions)
        support = {'family':'safe_composition_v64','law':program.name(),'template':program.template()}
        groups.setdefault(key,[]).append(support)
        templates[program.template()] = templates.get(program.template(),0)+1
    result = joint_result(groups,len(inputs))
    # Store every distinct JOINT prediction; support display may be limited, hypotheses are not.
    result['candidates'] = [
        {'predictions':[[list(row) for row in a] for a in key],
         'program_count':len(support), 'templates':sorted({s['template'] for s in support}),
         'laws':[s['law'] for s in support]}
        for key,support in groups.items()]
    result['inapplicable_programs'] = rejected
    result['template_counts'] = templates
    return result


def infer(task: dict) -> dict:
    clean = public_task(task)
    programs,stats = synthesize([(e['input'],e['output']) for e in clean['train']])
    result = evaluate(programs,[e['input'] for e in clean['test']])
    result['stats'] = stats
    return result


def validate_leave_one_out(task: dict, fitted: dict) -> dict:
    """Refit without each demonstration and require unique, stable joint predictions.

    Each fold sees retained demonstrations and the held input plus ordinary test
    inputs. The held demonstration TARGET is read only by the fold validator,
    after synthesis/prediction. This is within-task validation, not unseen-task CV.
    """
    clean = public_task(task)
    n = len(clean['train'])
    if fitted['status'] != 'unique':
        return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if n < 2:
        return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected_tests = [t['prediction'] for t in fitted['tests']]
    folds = []
    for held in range(n):
        demos = [d for i,d in enumerate(clean['train']) if i != held]
        fold_task = {'train':demos, 'test':[{'input':clean['train'][held]['input']}] + clean['test']}
        result = infer(fold_task)
        predictions = [t['prediction'] for t in result['tests']]
        held_exact = result['status']=='unique' and predictions[0] == clean['train'][held]['output']
        stable = result['status']=='unique' and predictions[1:] == expected_tests
        folds.append({'held_index':held,'status':result['status'],'held_example_exact':held_exact,
                      'test_prediction_stable':stable, 'joint_hypotheses':result['joint_hypotheses'],
                      'fitted_programs':result['stats']['fitted_programs']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':passed, 'reason':'passed' if passed else 'held_example_or_stability_failure','folds':folds}
