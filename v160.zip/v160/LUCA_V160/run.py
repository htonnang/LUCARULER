"""Run LUCA V156 anchor-relative stencil materialisation: python run.py task.json --output prediction.json"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from engine import infer_bundle


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', type=Path, help='ARC task JSON, with demonstrations and test inputs')
    parser.add_argument('--output', type=Path, help='write JSON here; otherwise print to stdout')
    parser.add_argument('--compare', action='store_true', help='include family evidence and decision stages')
    parser.add_argument('--encoded-only', action='store_true', help='EXPERIMENTAL: validate encode/shared-reason/decode only; inactive in default')
    parser.add_argument('--reconstruct-only', action='store_true', help='encoded-only ablation: identity logical reasoning')
    parser.add_argument('--kernel-only', action='store_true', help='use the new shared language only, retaining validation')
    parser.add_argument('--context-only', action='store_true', help='validate the shared scene-context program alone')
    parser.add_argument('--wallpaper-only', action='store_true', help='validate D4 + mirrored wallpaper reconstruction alone')
    parser.add_argument('--relational-transport-only', action='store_true', help='validate shared relational component transport alone')
    parser.add_argument('--spinoza-only', action='store_true', help='validate proof-carrying two-step causal composition alone')
    parser.add_argument('--common-notion-only', action='store_true', help='validate common-notion component extraction alone')
    parser.add_argument('--causal-trigger-only', action='store_true', help='validate causal marker/repetition trigger induction alone')
    parser.add_argument('--trigger-action-only', action='store_true', help='validate V111 trigger-bound axis actions alone')
    parser.add_argument('--analogy-only', action='store_true', help='validate V112 relational panel analogy alone')
    parser.add_argument('--operator-induction-only', action='store_true', help='validate V113 relational operator induction alone')
    parser.add_argument('--instructional-transfer-only', action='store_true', help='validate V114 instructional operator transfer alone')
    parser.add_argument('--graph-bound-transfer-only', action='store_true', help='validate V115 graph-bound instructional transfer alone')
    parser.add_argument('--transformational-graph-only', action='store_true', help='validate V116 transformational graph propagation alone')
    parser.add_argument('--relation-chain-only', action='store_true', help='validate V117 relation-chain graph programmes alone')
    parser.add_argument('--relational-projection-only', action='store_true', help='validate V118 relational projection algebra alone')
    parser.add_argument('--counterfactual-query-only', action='store_true', help='validate V119 counterfactual relational query composition alone')
    parser.add_argument('--quantified-relation-only', action='store_true', help='validate V120 unified quantified relation algebra alone')
    parser.add_argument('--selector-algebra-only', action='store_true', help='validate V121 general counterfactual selector algebra alone')
    parser.add_argument('--learned-feature-only', action='store_true', help='validate V122 learned counterfactual feature induction alone')
    parser.add_argument('--relation-vocabulary-only', action='store_true', help='validate V123 learned relation vocabulary alone')
    parser.add_argument('--expansion-grammar-only', action='store_true', help='validate V124 self-similar expansion grammar alone')
    parser.add_argument('--generative-expansion-only', action='store_true', help='validate V125 unified generative expansion algebra alone')
    parser.add_argument('--recursive-expansion-only', action='store_true', help='validate V126 recursive unified generative algebra alone')
    parser.add_argument('--composable-recursive-only', action='store_true', help='validate V127 composable recursive generative primitives alone')
    parser.add_argument('--compositional-primitives-only', action='store_true', help='validate V128 compositional primitive algebra alone')
    parser.add_argument('--anti-unified-composition-only', action='store_true', help='validate V129 anti-unified compositional search alone')
    parser.add_argument('--multi-stage-composition-only', action='store_true', help='validate V130 anti-unified multi-stage composition alone')
    parser.add_argument('--learned-stage-algebra-only', action='store_true', help='validate V131 learned stage algebra alone')
    parser.add_argument('--instruction-relation-stage-only', action='store_true', help='validate V132 instruction-relation stage algebra alone')
    parser.add_argument('--relational-completion-projection-only', action='store_true', help='validate V133 relational completion/projection algebra alone')
    parser.add_argument('--relational-completion-algebra-only', action='store_true', help='validate V134 anti-unified relational completion algebra alone')
    parser.add_argument('--completion-primitives-only', action='store_true', help='validate V135 anti-unified completion primitives alone')
    parser.add_argument('--transfer-cover-algebra-only', action='store_true', help='validate V136 anti-unified transfer and cover algebra alone')
    parser.add_argument('--boundary-graph-composition-only', action='store_true', help='validate V137 boundary-graph relation and cross-operator composition alone')
    parser.add_argument('--dynamic-graph-constructor-only', action='store_true', help='validate V138 dynamic graph-constructor composition alone')
    parser.add_argument('--graph-constructor-grammar-only', action='store_true', help='validate V139 graph-constructor grammar and bounded relation chains alone')
    parser.add_argument('--learned-constructor-proof-search-only', action='store_true', help='validate V140 learned constructor grammar and bounded proof search alone')
    parser.add_argument('--reusable-node-edge-proof-search-only', action='store_true', help='validate V141 reusable node/edge grammar and bounded two-step proof search alone')
    parser.add_argument('--anti-unified-node-edge-composition-only', action='store_true', help='validate V142 anti-unified node/edge composition alone')
    parser.add_argument('--parameterised-node-edge-relation-chains-only', action='store_true', help='validate V143 parameterised node/edge relation chains alone')
    parser.add_argument('--primitive-anti-unification-relation-search-only', action='store_true', help='validate V144 primitive anti-unification and bounded relation search alone')
    parser.add_argument('--learned-primitive-graph-grammar-only', action='store_true', help='validate V145 learned primitive graph grammar and bounded three-stage relation chains alone')
    parser.add_argument('--anti-unified-extractor-transfer-composition-only', action='store_true', help='validate V146 anti-unified extractors and bounded transfer composition alone')
    parser.add_argument('--reference-frame-extraction-transfer-only', action='store_true', help='validate V147 reference-frame extraction and transfer alone')
    parser.add_argument('--ordered-reference-graph-extraction-only', action='store_true', help='validate V148 ordered reference-graph extraction alone')
    parser.add_argument('--learned-order-graph-sequence-composition-only', action='store_true', help='validate V149 learned order-graph sequence composition alone')
    parser.add_argument('--ordered-phase-recolour-only', action='store_true', help='validate V150 ordered phase recolouring alone')
    parser.add_argument('--rectangle-coordinate-field-only', action='store_true', help='validate V151 rectangle coordinate-field materialisation alone')
    parser.add_argument('--rectangle-coordinate-algebra-only', action='store_true', help='validate V152 rectangle coordinate algebra and ownership materialisation alone')
    parser.add_argument('--normalised-region-coordinate-only', action='store_true', help='validate V153 normalised region-coordinate grammar alone')
    parser.add_argument('--d4-frame-coordinate-only', action='store_true', help='validate V154 D4-aware frame-coordinate grammar alone')
    parser.add_argument('--guide-extent-coordinate-only', action='store_true', help='validate V155 guide-extent coordinate projection alone')
    parser.add_argument('--anchor-relative-stencil-only', action='store_true', help='validate V156 anchor-relative stencil materialisation alone')
    parser.add_argument('--anchor-relative-transport-only', action='store_true', help='validate V157 anchor-relative transport composition alone')
    parser.add_argument('--self-measured-extent-transport-only', action='store_true', help='validate V158 self-measured extent transport alone')
    parser.add_argument('--anchor-destination-ownership-only', action='store_true', help='validate V159 anchor-destination ownership alone')
    parser.add_argument('--equivariant-anchor-transport-only', action='store_true', help='validate the V160 anchor-transport rewrite alone')
    parser.add_argument('--equivariant-transport-only', action='store_true', help='validate the V160 transport rewrite alone')
    parser.add_argument('--equivariant-ordered-phase-only', action='store_true', help='validate the V160 ordered-phase rewrite alone')
    parser.add_argument('--equivariant-reference-transfer-only', action='store_true', help='validate the V160 reference-transfer rewrite alone')
    parser.add_argument('--structural-components-only', action='store_true', help='validate shared structural-component reasoning alone')
    parser.add_argument('--identity-base', action='store_true', help='wallpaper-only control: identity base orientation only')
    parser.add_argument('--plain-tile', action='store_true', help='wallpaper-only control: no parity reflections')
    parser.add_argument('--joint-only', action='store_true', help='validate the new conditional joint-edit grammar alone')
    parser.add_argument('--single-edit', action='store_true', help='joint-only ablation: at most one edit per category')
    parser.add_argument('--relational-only', action='store_true', help='validate shared relational edits without the legacy portfolio')
    parser.add_argument('--placement-only', action='store_true', help='validate shared relation-bound placement only')
    parser.add_argument('--unrestricted-references', action='store_true', help='placement control: all stationary references')
    parser.add_argument('--unrestricted-offsets', action='store_true', help='placement control: disable the exact-anchor prior')
    parser.add_argument('--material-only', action='store_true', help='validate shared material-cover language alone')
    parser.add_argument('--one-piece', action='store_true', help='material-only ablation: at most one piece per target')
    parser.add_argument('--legacy-material', action='store_true', help='material-only control: original implicit source roles and individual reference targets')
    parser.add_argument('--inventory-only', action='store_true', help='validate ordered-inventory reconstruction alone')
    parser.add_argument('--grouped-inventory-only', action='store_true', help='infer rows and columns from object relationships')
    parser.add_argument('--complete-lattice-only', action='store_true', help='grouped control: require every relational slot to be occupied')
    parser.add_argument('--grid-inventory-only', action='store_true', help='validate the shared two-dimensional inventory layout alone')
    parser.add_argument('--spatial-order-only', action='store_true', help='inventory control: exclude quantity-based ordering')
    parser.add_argument('--coordinate-inventory-only', action='store_true', help='validate provenance-aware coordinates and witnessed-pitch layouts')
    parser.add_argument('--rank-only', action='store_true', help='coordinate control: remove empty-band pitch inference')
    parser.add_argument('--untyped-coordinates', action='store_true', help='coordinate ablation: allow disconnected colour aggregation')
    args = parser.parse_args()
    if (args.rank_only or args.untyped_coordinates) and not args.coordinate_inventory_only: parser.error('coordinate controls require --coordinate-inventory-only')
    if args.complete_lattice_only and not args.grouped_inventory_only: parser.error('--complete-lattice-only requires --grouped-inventory-only')
    if args.spatial_order_only and not (args.inventory_only or args.grid_inventory_only): parser.error('--spatial-order-only requires --inventory-only or --grid-inventory-only')
    if args.legacy_material and not args.material_only: parser.error('--legacy-material requires --material-only')
    if args.one_piece and not args.material_only: parser.error('--one-piece requires --material-only')
    if (args.unrestricted_references or args.unrestricted_offsets) and not args.placement_only:
        parser.error('placement controls require --placement-only')
    if args.single_edit and not (args.joint_only or args.relational_only): parser.error('--single-edit requires --joint-only or --relational-only')
    if args.reconstruct_only and not args.encoded_only: parser.error('--reconstruct-only requires --encoded-only')
    if (args.identity_base or args.plain_tile) and not args.wallpaper_only: parser.error('wallpaper controls require --wallpaper-only')
    if sum((args.encoded_only,args.kernel_only,args.joint_only,args.relational_only,args.placement_only,args.material_only,args.inventory_only,args.grid_inventory_only,args.grouped_inventory_only,args.coordinate_inventory_only,args.context_only,args.wallpaper_only,args.structural_components_only,args.relational_transport_only,args.spinoza_only,args.common_notion_only,args.causal_trigger_only,args.trigger_action_only,args.analogy_only,args.operator_induction_only,args.instructional_transfer_only,args.graph_bound_transfer_only,args.transformational_graph_only,args.relation_chain_only,args.relational_projection_only,args.counterfactual_query_only,args.quantified_relation_only,args.selector_algebra_only,args.learned_feature_only,args.relation_vocabulary_only,args.expansion_grammar_only,args.generative_expansion_only,args.recursive_expansion_only,args.composable_recursive_only,args.compositional_primitives_only,args.anti_unified_composition_only,args.multi_stage_composition_only,args.learned_stage_algebra_only,args.instruction_relation_stage_only,args.relational_completion_projection_only,args.relational_completion_algebra_only,args.completion_primitives_only,args.transfer_cover_algebra_only,args.boundary_graph_composition_only,args.dynamic_graph_constructor_only,args.graph_constructor_grammar_only,args.learned_constructor_proof_search_only,args.reusable_node_edge_proof_search_only,args.anti_unified_node_edge_composition_only,args.parameterised_node_edge_relation_chains_only,args.primitive_anti_unification_relation_search_only,args.learned_primitive_graph_grammar_only,args.anti_unified_extractor_transfer_composition_only,args.reference_frame_extraction_transfer_only,args.ordered_reference_graph_extraction_only,args.learned_order_graph_sequence_composition_only,args.ordered_phase_recolour_only,args.rectangle_coordinate_field_only,args.rectangle_coordinate_algebra_only,args.normalised_region_coordinate_only,args.d4_frame_coordinate_only,args.guide_extent_coordinate_only,args.anchor_relative_stencil_only,args.anchor_relative_transport_only,args.self_measured_extent_transport_only,args.anchor_destination_ownership_only,args.equivariant_anchor_transport_only,args.equivariant_transport_only,args.equivariant_ordered_phase_only,args.equivariant_reference_transfer_only))>1:parser.error('select one isolated language mode')
    try:
        task = json.loads(args.task.read_text(encoding='utf-8'))
        if args.encoded_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            pair=run_checked(task,partial(scene_programs.infer_encoded_scene,reasoning=not args.reconstruct_only),partial(scene_programs.validate_encoded_scene,reasoning=not args.reconstruct_only))
            bundle={'result':pair['validated'],'registry':{'shared_scene_encoded_reasoning':pair}}
        elif args.coordinate_inventory_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            settings=dict(allow_pitch=not args.rank_only,local_items=not args.untyped_coordinates)
            pair=run_checked(task,partial(scene_programs.infer_coordinate_inventory,**settings),partial(scene_programs.validate_coordinate_inventory,**settings))
            bundle={'result':pair['validated'],'registry':{'shared_scene_coordinate_inventory':pair}}
        elif args.grouped_inventory_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            pair=run_checked(task,partial(scene_programs.infer_grouped_inventory,complete_only=args.complete_lattice_only),partial(scene_programs.validate_grouped_inventory,complete_only=args.complete_lattice_only))
            bundle={'result':pair['validated'],'registry':{'shared_scene_grouped_inventory':pair}}
        elif args.grid_inventory_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            pair=run_checked(task,partial(scene_programs.infer_grid_inventory,spatial_only=args.spatial_order_only),partial(scene_programs.validate_grid_inventory,spatial_only=args.spatial_order_only))
            bundle={'result':pair['validated'],'registry':{'shared_scene_grid_inventory':pair}}
        elif args.inventory_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            pair = run_checked(task, partial(scene_programs.infer_inventory, spatial_only=args.spatial_order_only), partial(scene_programs.validate_inventory, spatial_only=args.spatial_order_only))
            bundle = {'result':pair['validated'], 'registry':{'shared_scene_inventory':pair}}
        elif args.material_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            pair = run_checked(task, partial(scene_programs.infer_material, one_piece=args.one_piece, role_targets=not args.legacy_material), partial(scene_programs.validate_material, one_piece=args.one_piece, role_targets=not args.legacy_material))
            bundle = {'result': pair['validated'], 'registry': {'shared_scene_material': pair}}
        elif args.placement_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            settings=dict(relations=not args.unrestricted_references,prefer_zero=not args.unrestricted_offsets,consume=False)
            pair=run_checked(task,partial(scene_programs.infer_placements,**settings),partial(scene_programs.validate_placements,**settings))
            bundle={'result':pair['validated'],'registry':{'shared_scene_placement':pair}}
        elif args.joint_only or args.relational_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            edits=1 if args.single_edit else 2
            pair=run_checked(task,partial(scene_programs.infer_joint,max_edits=edits,relations=args.relational_only),partial(scene_programs.validate_joint,max_edits=edits,relations=args.relational_only))
            bundle={'result':pair['validated'],'registry':{'shared_scene_relational_edits' if args.relational_only else 'shared_scene_joint_edits':pair}}
        elif args.kernel_only:
            import scene_programs
            from runtime import run_checked
            pair = run_checked(task, scene_programs.infer, scene_programs.validate)
            bundle = {'result': pair['validated'], 'registry': {'shared_scene_programs': pair}}
        elif args.context_only:
            import scene_programs
            from runtime import run_checked
            pair = run_checked(task, scene_programs.infer_context, scene_programs.validate_context)
            bundle = {'result': pair['validated'], 'registry': {'shared_scene_context': pair}}
        elif args.structural_components_only:
            import scene_programs
            from runtime import run_checked
            pair=run_checked(task,scene_programs.infer_structural_components,scene_programs.validate_structural_components)
            bundle={'result':pair['validated'],'registry':{'shared_structural_components':pair}}
        elif args.relational_transport_only:
            import scene_programs
            from runtime import run_checked
            pair=run_checked(task,scene_programs.infer_relational_transport,scene_programs.validate_relational_transport)
            bundle={'result':pair['validated'],'registry':{'shared_relational_transport':pair}}
        elif args.spinoza_only:
            import spinoza_reasoning
            from runtime import run_checked
            pair=run_checked(task,spinoza_reasoning.infer_spinoza,spinoza_reasoning.validate_spinoza)
            bundle={'result':pair['validated'],'registry':{'spinoza_causal_composition':pair}}
        elif args.common_notion_only:
            import common_notion_reasoning
            from runtime import run_checked
            pair=run_checked(task,common_notion_reasoning.infer_common_notion_extraction,common_notion_reasoning.validate_common_notion_extraction)
            bundle={'result':pair['validated'],'registry':{'spinoza_common_notion_extraction':pair}}
        elif args.causal_trigger_only:
            import causal_trigger_reasoning
            from runtime import run_checked
            pair=run_checked(task,causal_trigger_reasoning.infer_causal_trigger,causal_trigger_reasoning.validate_causal_trigger)
            bundle={'result':pair['validated'],'registry':{'spinoza_causal_trigger_induction':pair}}
        elif args.trigger_action_only:
            import trigger_action_reasoning
            from runtime import run_checked
            pair=run_checked(task,trigger_action_reasoning.infer_trigger_action,trigger_action_reasoning.validate_trigger_action)
            bundle={'result':pair['validated'],'registry':{'spinoza_trigger_action_composition':pair}}
        elif args.analogy_only:
            import analogy_reasoning
            from runtime import run_checked
            pair=run_checked(task,analogy_reasoning.infer_analogy,analogy_reasoning.validate_analogy)
            bundle={'result':pair['validated'],'registry':{'spinoza_analogy_proposition_composition':pair}}
        elif args.operator_induction_only:
            import operator_induction_reasoning
            from runtime import run_checked
            pair=run_checked(task,operator_induction_reasoning.infer_operator,operator_induction_reasoning.validate_operator)
            bundle={'result':pair['validated'],'registry':{'spinoza_relational_operator_induction':pair}}
        elif args.instructional_transfer_only:
            import instructional_transfer_reasoning
            from runtime import run_checked
            pair=run_checked(task,instructional_transfer_reasoning.infer_instructional_transfer,instructional_transfer_reasoning.validate_instructional_transfer)
            bundle={'result':pair['validated'],'registry':{'spinoza_instructional_operator_transfer':pair}}
        elif args.graph_bound_transfer_only:
            import graph_bound_transfer_reasoning
            from runtime import run_checked
            pair=run_checked(task,graph_bound_transfer_reasoning.infer_graph_bound_transfer,graph_bound_transfer_reasoning.validate_graph_bound_transfer)
            bundle={'result':pair['validated'],'registry':{'spinoza_graph_bound_instructional_transfer':pair}}
        elif args.transformational_graph_only:
            import transformational_graph_reasoning
            from runtime import run_checked
            pair=run_checked(task,transformational_graph_reasoning.infer_transformational_graph,transformational_graph_reasoning.validate_transformational_graph)
            bundle={'result':pair['validated'],'registry':{'spinoza_transformational_graph_propagation':pair}}
        elif args.relation_chain_only:
            import relation_chain_reasoning
            from runtime import run_checked
            pair=run_checked(task,relation_chain_reasoning.infer_relation_chain,relation_chain_reasoning.validate_relation_chain)
            bundle={'result':pair['validated'],'registry':{'spinoza_relation_chain_graph_programmes':pair}}
        elif args.relational_projection_only:
            import relational_projection_reasoning
            from runtime import run_checked
            pair=run_checked(task,relational_projection_reasoning.infer_relational_projection,relational_projection_reasoning.validate_relational_projection)
            bundle={'result':pair['validated'],'registry':{'spinoza_relational_projection_algebra':pair}}
        elif args.counterfactual_query_only:
            import counterfactual_query_reasoning
            from runtime import run_checked
            pair=run_checked(task,counterfactual_query_reasoning.infer_counterfactual_queries,counterfactual_query_reasoning.validate_counterfactual_queries)
            bundle={'result':pair['validated'],'registry':{'spinoza_counterfactual_relational_query_composition':pair}}
        elif args.quantified_relation_only:
            import quantified_relation_reasoning
            from runtime import run_checked
            pair=run_checked(task,quantified_relation_reasoning.infer_quantified_relations,quantified_relation_reasoning.validate_quantified_relations)
            bundle={'result':pair['validated'],'registry':{'spinoza_unified_quantified_relation_algebra':pair}}
        elif args.selector_algebra_only:
            import selector_algebra_reasoning
            from runtime import run_checked
            pair=run_checked(task,selector_algebra_reasoning.infer_selector_algebra,selector_algebra_reasoning.validate_selector_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_general_counterfactual_selector_algebra':pair}}
        elif args.learned_feature_only:
            import learned_feature_reasoning
            from runtime import run_checked
            pair=run_checked(task,learned_feature_reasoning.infer_learned_features,learned_feature_reasoning.validate_learned_features)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_counterfactual_feature_induction':pair}}
        elif args.relation_vocabulary_only:
            import relation_vocabulary_reasoning
            from runtime import run_checked
            pair=run_checked(task,relation_vocabulary_reasoning.infer_relation_vocabulary,relation_vocabulary_reasoning.validate_relation_vocabulary)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_relation_vocabulary':pair}}
        elif args.expansion_grammar_only:
            import expansion_grammar_reasoning
            from runtime import run_checked
            pair=run_checked(task,expansion_grammar_reasoning.infer_expansion_grammar,expansion_grammar_reasoning.validate_expansion_grammar)
            bundle={'result':pair['validated'],'registry':{'spinoza_self_similar_expansion_grammar':pair}}
        elif args.generative_expansion_only:
            import generative_expansion_reasoning
            from runtime import run_checked
            pair=run_checked(task,generative_expansion_reasoning.infer_generative_expansion,generative_expansion_reasoning.validate_generative_expansion)
            bundle={'result':pair['validated'],'registry':{'spinoza_unified_generative_expansion_algebra':pair}}
        elif args.recursive_expansion_only:
            import recursive_expansion_reasoning
            from runtime import run_checked
            pair=run_checked(task,recursive_expansion_reasoning.infer_recursive_expansion,recursive_expansion_reasoning.validate_recursive_expansion)
            bundle={'result':pair['validated'],'registry':{'spinoza_recursive_unified_generative_algebra':pair}}
        elif args.composable_recursive_only:
            import composable_recursive_reasoning
            from runtime import run_checked
            pair=run_checked(task,composable_recursive_reasoning.infer_composable_recursive,composable_recursive_reasoning.validate_composable_recursive)
            bundle={'result':pair['validated'],'registry':{'spinoza_composable_recursive_generative_primitives':pair}}
        elif args.compositional_primitives_only:
            import compositional_primitive_algebra
            from runtime import run_checked
            pair=run_checked(task,compositional_primitive_algebra.infer_compositional_primitives,compositional_primitive_algebra.validate_compositional_primitives)
            bundle={'result':pair['validated'],'registry':{'spinoza_compositional_primitive_algebra':pair}}
        elif args.anti_unified_composition_only:
            import anti_unified_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,anti_unified_composition_reasoning.infer_anti_unified_composition,anti_unified_composition_reasoning.validate_anti_unified_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_compositional_search':pair}}
        elif args.multi_stage_composition_only:
            import multi_stage_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,multi_stage_composition_reasoning.infer_multi_stage_composition,multi_stage_composition_reasoning.validate_multi_stage_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_multi_stage_composition':pair}}
        elif args.learned_stage_algebra_only:
            import learned_stage_algebra
            from runtime import run_checked
            pair=run_checked(task,learned_stage_algebra.infer_learned_stage_algebra,learned_stage_algebra.validate_learned_stage_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_stage_algebra':pair}}
        elif args.instruction_relation_stage_only:
            import instruction_relation_stage_algebra
            from runtime import run_checked
            pair=run_checked(task,instruction_relation_stage_algebra.infer_instruction_relation_stage_algebra,instruction_relation_stage_algebra.validate_instruction_relation_stage_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_instruction_relation_stage_algebra':pair}}
        elif args.relational_completion_projection_only:
            import relational_completion_projection_reasoning
            from runtime import run_checked
            pair=run_checked(task,relational_completion_projection_reasoning.infer_relational_completion_projection,relational_completion_projection_reasoning.validate_relational_completion_projection)
            bundle={'result':pair['validated'],'registry':{'spinoza_relational_completion_projection_algebra':pair}}
        elif args.relational_completion_algebra_only:
            import relational_completion_algebra
            from runtime import run_checked
            pair=run_checked(task,relational_completion_algebra.infer_relational_completion_algebra,relational_completion_algebra.validate_relational_completion_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_relational_completion_algebra':pair}}
        elif args.completion_primitives_only:
            import completion_primitives_reasoning
            from runtime import run_checked
            pair=run_checked(task,completion_primitives_reasoning.infer_completion_primitives,completion_primitives_reasoning.validate_completion_primitives)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_completion_primitives':pair}}
        elif args.transfer_cover_algebra_only:
            import transfer_cover_algebra_reasoning
            from runtime import run_checked
            pair=run_checked(task,transfer_cover_algebra_reasoning.infer_transfer_cover_algebra,transfer_cover_algebra_reasoning.validate_transfer_cover_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_transfer_cover_algebra':pair}}
        elif args.boundary_graph_composition_only:
            import boundary_graph_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,boundary_graph_composition_reasoning.infer_boundary_graph_composition,boundary_graph_composition_reasoning.validate_boundary_graph_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_boundary_graph_composition':pair}}
        elif args.dynamic_graph_constructor_only:
            import dynamic_graph_constructor_reasoning
            from runtime import run_checked
            pair=run_checked(task,dynamic_graph_constructor_reasoning.infer_dynamic_graph_constructor,dynamic_graph_constructor_reasoning.validate_dynamic_graph_constructor)
            bundle={'result':pair['validated'],'registry':{'spinoza_dynamic_graph_constructor_composition':pair}}
        elif args.graph_constructor_grammar_only:
            import graph_constructor_grammar_reasoning
            from runtime import run_checked
            pair=run_checked(task,graph_constructor_grammar_reasoning.infer_graph_constructor_grammar,graph_constructor_grammar_reasoning.validate_graph_constructor_grammar)
            bundle={'result':pair['validated'],'registry':{'spinoza_graph_constructor_grammar':pair}}
        elif args.learned_constructor_proof_search_only:
            import learned_constructor_proof_search_reasoning
            from runtime import run_checked
            pair=run_checked(task,learned_constructor_proof_search_reasoning.infer_learned_constructor_proof_search,learned_constructor_proof_search_reasoning.validate_learned_constructor_proof_search)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_constructor_proof_search':pair}}
        elif args.reusable_node_edge_proof_search_only:
            import reusable_node_edge_proof_search_reasoning
            from runtime import run_checked
            pair=run_checked(task,reusable_node_edge_proof_search_reasoning.infer_reusable_node_edge_proof_search,reusable_node_edge_proof_search_reasoning.validate_reusable_node_edge_proof_search)
            bundle={'result':pair['validated'],'registry':{'spinoza_reusable_node_edge_proof_search':pair}}
        elif args.anti_unified_node_edge_composition_only:
            import anti_unified_node_edge_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,anti_unified_node_edge_composition_reasoning.infer_anti_unified_node_edge_composition,anti_unified_node_edge_composition_reasoning.validate_anti_unified_node_edge_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_node_edge_composition':pair}}
        elif args.parameterised_node_edge_relation_chains_only:
            import parameterised_node_edge_relation_chain_reasoning
            from runtime import run_checked
            pair=run_checked(task,parameterised_node_edge_relation_chain_reasoning.infer_parameterised_node_edge_relation_chains,parameterised_node_edge_relation_chain_reasoning.validate_parameterised_node_edge_relation_chains)
            bundle={'result':pair['validated'],'registry':{'spinoza_parameterised_node_edge_relation_chains':pair}}
        elif args.primitive_anti_unification_relation_search_only:
            import primitive_anti_unification_relation_search_reasoning
            from runtime import run_checked
            pair=run_checked(task,primitive_anti_unification_relation_search_reasoning.infer_primitive_anti_unification_relation_search,primitive_anti_unification_relation_search_reasoning.validate_primitive_anti_unification_relation_search)
            bundle={'result':pair['validated'],'registry':{'spinoza_primitive_anti_unification_relation_search':pair}}
        elif args.learned_primitive_graph_grammar_only:
            import learned_primitive_graph_grammar_reasoning
            from runtime import run_checked
            pair=run_checked(task,learned_primitive_graph_grammar_reasoning.infer_learned_primitive_graph_grammar,learned_primitive_graph_grammar_reasoning.validate_learned_primitive_graph_grammar)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_primitive_graph_grammar':pair}}
        elif args.anti_unified_extractor_transfer_composition_only:
            import anti_unified_extractor_transfer_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,anti_unified_extractor_transfer_composition_reasoning.infer_anti_unified_extractor_transfer_composition,anti_unified_extractor_transfer_composition_reasoning.validate_anti_unified_extractor_transfer_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_anti_unified_extractor_transfer_composition':pair}}
        elif args.reference_frame_extraction_transfer_only:
            import reference_frame_extraction_transfer_reasoning
            from runtime import run_checked
            pair=run_checked(task,reference_frame_extraction_transfer_reasoning.infer_reference_frame_extraction_transfer,reference_frame_extraction_transfer_reasoning.validate_reference_frame_extraction_transfer)
            bundle={'result':pair['validated'],'registry':{'spinoza_reference_frame_extraction_transfer':pair}}
        elif args.ordered_reference_graph_extraction_only:
            import ordered_reference_graph_extraction_reasoning
            from runtime import run_checked
            pair=run_checked(task,ordered_reference_graph_extraction_reasoning.infer_ordered_reference_graph_extraction,ordered_reference_graph_extraction_reasoning.validate_ordered_reference_graph_extraction)
            bundle={'result':pair['validated'],'registry':{'spinoza_ordered_reference_graph_extraction':pair}}
        elif args.learned_order_graph_sequence_composition_only:
            import learned_order_graph_sequence_composition_reasoning
            from runtime import run_checked
            pair=run_checked(task,learned_order_graph_sequence_composition_reasoning.infer_learned_order_graph_sequence_composition,learned_order_graph_sequence_composition_reasoning.validate_learned_order_graph_sequence_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_learned_order_graph_sequence_composition':pair}}
        elif args.ordered_phase_recolour_only:
            import ordered_phase_recolour_reasoning
            from runtime import run_checked
            pair=run_checked(task,ordered_phase_recolour_reasoning.infer_ordered_phase_recolour,ordered_phase_recolour_reasoning.validate_ordered_phase_recolour)
            bundle={'result':pair['validated'],'registry':{'spinoza_ordered_phase_recolour':pair}}
        elif args.rectangle_coordinate_field_only:
            import rectangle_coordinate_field_reasoning
            from runtime import run_checked
            pair=run_checked(task,rectangle_coordinate_field_reasoning.infer_rectangle_coordinate_field,rectangle_coordinate_field_reasoning.validate_rectangle_coordinate_field)
            bundle={'result':pair['validated'],'registry':{'spinoza_rectangle_coordinate_field':pair}}
        elif args.rectangle_coordinate_algebra_only:
            import rectangle_coordinate_algebra_reasoning
            from runtime import run_checked
            pair=run_checked(task,rectangle_coordinate_algebra_reasoning.infer_rectangle_coordinate_algebra,rectangle_coordinate_algebra_reasoning.validate_rectangle_coordinate_algebra)
            bundle={'result':pair['validated'],'registry':{'spinoza_rectangle_coordinate_algebra':pair}}
        elif args.normalised_region_coordinate_only:
            import normalised_region_coordinate_reasoning
            from runtime import run_checked
            pair=run_checked(task,normalised_region_coordinate_reasoning.infer_normalised_region_coordinate_grammar,normalised_region_coordinate_reasoning.validate_normalised_region_coordinate_grammar)
            bundle={'result':pair['validated'],'registry':{'spinoza_normalised_region_coordinate_grammar':pair}}
        elif args.d4_frame_coordinate_only:
            import d4_frame_coordinate_reasoning
            from runtime import run_checked
            pair=run_checked(task,d4_frame_coordinate_reasoning.infer_d4_frame_coordinate_grammar,d4_frame_coordinate_reasoning.validate_d4_frame_coordinate_grammar)
            bundle={'result':pair['validated'],'registry':{'spinoza_d4_frame_coordinate_grammar':pair}}
        elif args.guide_extent_coordinate_only:
            import guide_extent_coordinate_reasoning
            from runtime import run_checked
            pair=run_checked(task,guide_extent_coordinate_reasoning.infer_guide_extent_coordinate_projection,guide_extent_coordinate_reasoning.validate_guide_extent_coordinate_projection)
            bundle={'result':pair['validated'],'registry':{'spinoza_guide_extent_coordinate_projection':pair}}
        elif args.anchor_relative_stencil_only:
            import anchor_relative_stencil_reasoning
            from runtime import run_checked
            pair=run_checked(task,anchor_relative_stencil_reasoning.infer_anchor_relative_stencil_materialisation,anchor_relative_stencil_reasoning.validate_anchor_relative_stencil_materialisation)
            bundle={'result':pair['validated'],'registry':{'spinoza_anchor_relative_stencil_materialisation':pair}}
        elif args.anchor_relative_transport_only:
            import anchor_relative_transport_reasoning
            from runtime import run_checked
            pair=run_checked(task,anchor_relative_transport_reasoning.infer_anchor_relative_transport_composition,anchor_relative_transport_reasoning.validate_anchor_relative_transport_composition)
            bundle={'result':pair['validated'],'registry':{'spinoza_anchor_relative_transport_composition':pair}}
        elif args.self_measured_extent_transport_only:
            import self_measured_extent_transport_reasoning
            from runtime import run_checked
            pair=run_checked(task,self_measured_extent_transport_reasoning.infer_self_measured_extent_transport,self_measured_extent_transport_reasoning.validate_self_measured_extent_transport)
            bundle={'result':pair['validated'],'registry':{'spinoza_self_measured_extent_transport':pair}}
        elif args.anchor_destination_ownership_only:
            import anchor_destination_ownership_reasoning
            from runtime import run_checked
            pair=run_checked(task,anchor_destination_ownership_reasoning.infer_anchor_destination_ownership,anchor_destination_ownership_reasoning.validate_anchor_destination_ownership)
            bundle={'result':pair['validated'],'registry':{'spinoza_anchor_destination_ownership':pair}}
        elif args.equivariant_anchor_transport_only:
            import equivariant_family_rewrite_reasoning
            from runtime import run_checked
            pair=run_checked(task,equivariant_family_rewrite_reasoning.infer_equivariant_anchor_transport_rewrite,equivariant_family_rewrite_reasoning.validate_equivariant_anchor_transport_rewrite)
            bundle={'result':pair['validated'],'registry':{'spinoza_equivariant_anchor_transport_rewrite':pair}}
        elif args.equivariant_transport_only:
            import equivariant_family_rewrite_reasoning
            from runtime import run_checked
            pair=run_checked(task,equivariant_family_rewrite_reasoning.infer_equivariant_transport_rewrite,equivariant_family_rewrite_reasoning.validate_equivariant_transport_rewrite)
            bundle={'result':pair['validated'],'registry':{'spinoza_equivariant_transport_rewrite':pair}}
        elif args.equivariant_ordered_phase_only:
            import equivariant_family_rewrite_reasoning
            from runtime import run_checked
            pair=run_checked(task,equivariant_family_rewrite_reasoning.infer_equivariant_ordered_phase_rewrite,equivariant_family_rewrite_reasoning.validate_equivariant_ordered_phase_rewrite)
            bundle={'result':pair['validated'],'registry':{'spinoza_equivariant_ordered_phase_rewrite':pair}}
        elif args.equivariant_reference_transfer_only:
            import equivariant_family_rewrite_reasoning
            from runtime import run_checked
            pair=run_checked(task,equivariant_family_rewrite_reasoning.infer_equivariant_reference_transfer_rewrite,equivariant_family_rewrite_reasoning.validate_equivariant_reference_transfer_rewrite)
            bundle={'result':pair['validated'],'registry':{'spinoza_equivariant_reference_transfer_rewrite':pair}}
        elif args.wallpaper_only:
            import scene_programs
            from functools import partial
            from runtime import run_checked
            grammar='plain' if args.plain_tile else 'identity' if args.identity_base else 'd4'
            pair=run_checked(task,partial(scene_programs.infer_wallpaper,grammar=grammar),partial(scene_programs.validate_wallpaper,grammar=grammar))
            bundle={'result':pair['validated'],'registry':{f'shared_scene_wallpaper_{grammar}':pair}}
        else:
            bundle = infer_bundle(task)
        text = json.dumps(bundle if args.compare else bundle['result'], indent=2) + '\n'
        if args.output:
            args.output.write_text(text, encoding='utf-8')
        else:
            print(text, end='')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    main()
