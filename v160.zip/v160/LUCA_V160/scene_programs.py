"""One finite goal-constrained search over the shared scene-program interpreter.

No native complete-task fitter, predictor or validator is invoked. Candidates are
compiled from reusable predicates, masks, colour expressions and endpoint edits.
Output examples constrain programs; official test targets never enter inference.
"""
from __future__ import annotations
from constraints import Choice, ConstraintSearch
from collections import Counter, defaultdict
from itertools import product
from correspondence import grid
from runtime import public_task
from scene_kernel import (Program, Instruction, Predicate, Inapplicable, perceive,
                          masks, Entities, paint, emit)
from attributes import FEATURES
from region_geometry import REGIONS

FAMILY = 'shared_scene_programs'
SCALARS = ('area','area_rank','area_rank_desc','height','width','bbox_area','holes','shape_frequency')
MASKS = ('support',)+REGIONS


def predicate_candidates(scenes, selection=True):
    yield Predicate()
    if not selection: return
    for feature in FEATURES+('palette',):
        if feature in SCALARS:
            yield Predicate('min',feature); yield Predicate('max',feature)
        common=set.intersection(*(set(e.value(feature) for e in s.entities) for s in scenes))
        for value in sorted(common,key=repr):
            yield Predicate('eq',feature,value); yield Predicate('ne',feature,value)


def make_program(bg,conn,mono,predicate,kind='support',expr='original',value=None,scope='any',mode='preserve'):
    return Program(bg,conn,mono,predicate,(Instruction('select'),Instruction('mask',(kind,)),
        Instruction('paint',(expr,value,scope)),Instruction('emit',(mode,))))


def fit(pairs, *, selection=True):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs): return []
    # This language does not expand a canvas; arbitrary expansion is a different type.
    if any(len(y)>len(a) or len(y[0])>len(a[0]) for a,y in pairs): return []
    same=all(len(a)==len(y) and len(a[0])==len(y[0]) for a,y in pairs)
    conserve=same and all(Counter(v for r in a for v in r)==Counter(v for r in y for v in r) for a,y in pairs)
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    changed=[{(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=y[r][c]}
             for a,y in pairs] if same else []
    out_colours=set.intersection(*({v for row in y for v in row} for a,y in pairs))
    models=[]
    for bg,conn,mono in product(('modal',*sorted(common)),(4,8),(True,False)):
        try: scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
        except Inapplicable: continue
        # Cache suffix work by demonstrated entity sets, NOT by one winning predicate.
        groups=defaultdict(list)
        for predicate in predicate_candidates(scenes,selection):
            ids=tuple(predicate.select(s) for s in scenes)
            if any(not x for x in ids): continue
            if predicate.operator!='all' and not any(len(x)<len(s.entities) for x,s in zip(ids,scenes)):
                continue  # explicit observed-selection restriction, repeated in folds
            groups[ids].append(predicate)
        for indices,predicates in groups.items():
            selections=tuple(Entities(s,ids) for s,ids in zip(scenes,indices))
            # The same mask/write/emit interpreter implements crops and cleanup.
            regions=tuple(masks(v,'support') for v in selections)
            for mode in ('crop','context','isolate'):
                if mode=='isolate' and not same: continue
                predictions=[]
                try:
                    for r in regions: predictions.append(emit(paint(r,'original'),mode))
                except Inapplicable: continue
                if all(p==y for p,(_,y) in zip(predictions,pairs)):
                    models.extend(make_program(bg,conn,mono,p,mode=mode) for p in predicates)
            if not same: continue
            # A target-difference constraint rejects masks that cannot affect every
            # required cell. It is exact pruning, not scoring by test correctness.
            for kind in MASKS:
                regions=tuple(masks(v,kind) for v in selections)
                scope='any' if kind=='support' else 'background'
                covered=[set.union(set(),*(set(mask) for owner,mask in rs.masks)) for rs in regions]
                if any(not delta.issubset(cells) for delta,cells in zip(changed,covered)): continue
                if scope=='background' and any(any(a[r][c]!=s.background for r,c in delta)
                                                for (a,y),s,delta in zip(pairs,scenes,changed)): continue
                # Constants come from demonstration colours, not held/test targets.
                colours=[('background',None),('source',None),('original',None)]
                colours.extend(('constant',v) for v in sorted(out_colours))
                for expr,value in colours:
                    predicted=[]
                    try:
                        for rs in regions: predicted.append(emit(paint(rs,expr,value,scope),'preserve'))
                    except Inapplicable: continue
                    if all(p==y for p,(_,y) in zip(predicted,pairs)):
                        models.extend(make_program(bg,conn,mono,p,kind,expr,value,scope) for p in predicates)
            # Independent displacement from a reference relation uses the same atomic
            # edit protocol, not the old object_alignment fitter or renderer.
            if conserve and selection and all(len(ids)<len(s.entities) for ids,s in zip(indices,scenes)):
                for axis,sa,ra in product((0,1),('low','center','high'),('low','center','high')):
                    ops=(Instruction('select'),Instruction('bind_complement'),
                         Instruction('align',(axis,sa,ra)),Instruction('emit',('preserve',)))
                    p=Program(bg,conn,mono,predicates[0],ops)
                    try: predictions=[p.execute_scene(s) for s in scenes]
                    except Inapplicable: continue
                    if all(p==y for p,(_,y) in zip(predictions,pairs)):
                        models.extend(Program(bg,conn,mono,pred,ops) for pred in predicates)
    # Exact duplicates only. Different predicates survive even if demos look equal.
    return list(dict.fromkeys(models))


def predict_models(models, inputs):
    groups={}; invalid=0; structure_counts=Counter()
    for model in models:
        key=tuple(model.predict(a) for a in inputs)
        if any(x is None for x in key): invalid+=1; continue
        groups.setdefault(key,[]).append(model)
        structure_counts[model.signature()]+=1
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    applicable=groups[chosen] if chosen else []
    # Preserve each semantic stage variant in reporting before filling the cap.
    representatives=[];seen=set()
    for p in applicable:
        d=p.describe(); category=(p.signature(),tuple((i.op,i.args[0] if i.args else '') for i in p.instructions))
        if category not in seen: representatives.append(d);seen.add(category)
    reports=representatives+[p.describe() for p in applicable if p.describe() not in representatives]
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
        'tests':[{'status':status,'prediction':[list(row) for row in chosen[i]] if chosen else None}
                 for i in range(len(inputs))],
        'supporting_families':[FAMILY] if chosen else [],'supporting_laws':reports[:20],
        'witness_predictions':[[[list(r) for r in a] for a in key] for key in list(groups)[:2]],
        'program_structures':dict(structure_counts),
        'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
                 'complete_predictions_retained':True,'description_limit_not_search_limit':20}}


def infer(task, *, selection=True):
    clean=public_task(task)
    models=fit(((d['input'],d['output']) for d in clean['train']),selection=selection)
    return predict_models(models,tuple(grid(d['input']) for d in clean['test']))


def validate(task, full, *, selection=True):
    clean=public_task(task)
    if full['status']!='unique': return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2: return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[d['prediction'] for d in full['tests']]; folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer(fold,selection=selection); ps=[d['prediction'] for d in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
                      'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
                      'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}

# Joint effect synthesis is part of the SAME compiler and executes through the
# SAME scene interpreter. No native whole-task fit function is used here.
from dataclasses import dataclass
from scene_kernel import (EditAction, JointProgram, case_key, merge_edits,
                          category_values, RelationalFeature, RELATIONAL_FEATURES)

JOINT_FAMILY = 'shared_scene_joint_edits'

@dataclass(frozen=True)
class EffectOption:
    actions: tuple[EditAction,...]
    covered: int  # compile-time constraint bits, not stored in a witnessed program

@dataclass(frozen=True)
class JointSpace:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    feature: str
    keys: tuple
    domains: tuple[tuple[EffectOption,...],...]
    required: int

    def predictions(self, inputs):
        """Find up to two different COMPLETE outputs; exhaust search to claim unique.

        Alias domains share work only when both demonstration coverage and all test
        writes agree. No first-winner answer or per-input mixture is accepted.
        """
        try:
            scenes=tuple(perceive(a,self.background_rule,self.connectivity,self.monochrome) for a in inputs)
            keys=set(self.keys)
            if any(any(k not in keys for k in category_values(s,self.feature)) for s in scenes): return [],True,0
        except Inapplicable: return [],True,0
        offsets=[];offset=0
        for s in scenes:
            offsets.append(offset);offset+=len(s.source)*len(s.source[0])
        prepared=[]
        for key,domain in zip(self.keys,self.domains):
            aliases={}
            selections=[Entities(s,tuple(i for i,k in enumerate(category_values(s,self.feature)) if k==key)) for s in scenes]
            for option in domain:
                writes={};valid=True
                try:
                    for selection,offset in zip(selections,offsets):
                        if not selection.indices: continue
                        for action in option.actions:
                            edit=action.execute(selection);w=len(selection.scene.source[0])
                            for r,c,v in edit.writes:
                                pos=offset+r*w+c
                                if pos in writes and writes[pos]!=v: raise Inapplicable('intra-branch conflict')
                                writes[pos]=v
                except Inapplicable: valid=False
                if valid:
                    token=(option.covered,tuple(sorted(writes.items())))
                    aliases.setdefault(token,option)
            if not aliases:return [],True,0
            prepared.append((key,[(option,cov,items) for (cov,items),option in aliases.items()]))
        # The same engine serves compatible edit tables and object placements.
        # Emission includes every test write; coverage includes all demonstrations.
        choices=tuple(tuple(Choice(frozenset(items),covers=cov,writes=items)
                            for option,cov,items in options)
                      for key,options in prepared)
        search=ConstraintSearch(choices,required=self.required,label='joint_edits')
        found={}
        generator=search.solutions()
        try:
            for indices in generator:
                table={key:options[j][0].actions for (key,options),j in zip(prepared,indices)}
                program=JointProgram(self.background_rule,self.connectivity,self.monochrome,self.feature,
                                     tuple((k,table[k]) for k in self.keys))
                try:outputs=tuple(program.execute_scene(s) for s in scenes)
                except Inapplicable:continue
                found.setdefault(outputs,program)
                if len(found)>=2:break
        finally:
            generator.close()
        return list(found.items()),len(found)<2,search.stats['nodes']



def _valid_effect(action,selections,targets,changed_bits):
    """Necessary exact target constraints for one primitive effect on all demos."""
    covered=0;observed=False
    try:
        for selection,y,bit_map in zip(selections,targets,changed_bits):
            if not selection.indices:continue
            edit=action.execute(selection);a=selection.scene.source
            for r,c,v in edit.writes:
                if v != y[r][c]:return None
                if a[r][c]!=v:
                    observed=True;covered |= bit_map[r,c]
    except Inapplicable:return None
    # Explicit grammar prior: no unseen nonidentity action is installed speculatively.
    return EffectOption((action,),covered) if observed else None


def fit_joint(pairs, *, max_edits=2, relations=False):
    """Infer all admitted feature-conditioned edit tables from demonstrations.

    One instruction schema has one or two edit slots per category. Grouping uses an
    existing structural feature or a common all-entities case. Every constant comes
    from demonstration outputs, every category from demonstration input objects.
    """
    if max_edits not in (1,2):raise ValueError('max_edits must be one or two')
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any(len(a)!=len(y) or len(a[0])!=len(y[0]) for a,y in pairs):return []
    changed_bits=[];bit=0
    for a,y in pairs:
        mapping={}
        for r,row in enumerate(a):
            for c,v in enumerate(row):
                if v!=y[r][c]:mapping[r,c]=1<<bit;bit+=1
        changed_bits.append(mapping)
    required=(1<<bit)-1;targets=tuple(y for a,y in pairs)
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    colours=sorted({v for a,y in pairs for row in y for v in row})
    models=[]
    for bg,conn,mono in product(('modal',*sorted(common)),(4,8),(True,False)):
        try:scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
        except Inapplicable:continue
        # Cache effect fits for identical demonstrated selections across descriptors.
        cache={}; borrowed_cache={}; supports=(EditAction('support','background'),)+tuple(EditAction('support','constant',c) for c in colours)
        region_actions=tuple(EditAction(k,expr,val,'background') for k in REGIONS
                             for expr,val in [('source',None)]+[('constant',c) for c in colours])
        features=('__all__',)+FEATURES+('palette',)+(RELATIONAL_FEATURES if relations else ())
        for feature in features:
            vectors=tuple(category_values(s,feature) for s in scenes)
            keys=tuple(sorted({k for row in vectors for k in row},key=repr))
            if not keys:continue
            if not isinstance(feature,RelationalFeature) and feature!='__all__' and len(keys)<2:continue
            if isinstance(feature,RelationalFeature):
                from scene_kernel import relate
                if not any(any(relate(s,feature.relation).references) for s in scenes):continue
            domains=[];bad=False
            for key in keys:
                ids=tuple(tuple(i for i,k in enumerate(row) if k==key) for row in vectors)
                if ids not in cache:
                    selections=tuple(Entities(s,indices) for s,indices in zip(scenes,ids))
                    sp=[x for action in supports if (x:=_valid_effect(action,selections,targets,changed_bits)) is not None]
                    rp=[x for action in region_actions if (x:=_valid_effect(action,selections,targets,changed_bits)) is not None]
                    cache[ids]=(sp,rp)
                sp,rp=cache[ids]
                if isinstance(feature,RelationalFeature):
                    # The same Mask/Paint operation may borrow the unanimous colour
                    # of the bound reference set, recomputed on every input.
                    token=(ids,feature.relation)
                    if token not in borrowed_cache:
                        selections=tuple(Entities(s,indices) for s,indices in zip(scenes,ids))
                        borrowed=[EditAction('support','reference',feature.relation)]
                        borrowed += [EditAction(k,'reference',feature.relation,'background') for k in REGIONS]
                        borrowed_cache[token]=[x for action in borrowed if (x:=_valid_effect(action,selections,targets,changed_bits)) is not None]
                    fitted=borrowed_cache[token]
                    sp=sp+[x for x in fitted if x.actions[0].kind=='support']
                    rp=rp+[x for x in fitted if x.actions[0].kind!='support']
                options=[EffectOption((),0)]+sp+rp
                if max_edits==2:
                    options.extend(EffectOption(s.actions+r.actions,s.covered|r.covered) for s in sp for r in rp)
                # Structural aliases are retained; only exact duplicate instructions merge.
                domains.append(tuple(dict.fromkeys(options)))
            # Required-cell coverage propagation, valid for this original-scene
            # compatible-write grammar. It never scores official test targets.
            while True:
                coverage=[]
                for d in domains:
                    u=0
                    for o in d:u|=o.covered
                    coverage.append(u)
                total=0
                for u in coverage:total|=u
                if required & ~total:bad=True;break
                changed=False
                for i,d in enumerate(domains):
                    other=0
                    for j,u in enumerate(coverage):
                        if i!=j:other|=u
                    essential=required & ~other
                    keep=tuple(o for o in d if o.covered & essential==essential)
                    if not keep:bad=True;break
                    if len(keep)!=len(d):domains[i]=keep;changed=True
                if bad or not changed:break
            if not bad:models.append(JointSpace(bg,conn,mono,feature,keys,tuple(domains),required))
    return models


def infer_joint(task, *, max_edits=2, relations=False):
    clean=public_task(task);inputs=tuple(grid(t['input']) for t in clean['test'])
    models=fit_joint(((d['input'],d['output']) for d in clean['train']),max_edits=max_edits,relations=relations)
    groups={};nodes=0;exhausted=True;examined=0
    for model in models:
        predictions,complete,n=model.predictions(inputs);nodes+=n;examined+=1
        for key,p in predictions:groups.setdefault(key,[]).append(p)
        exhausted &= complete
        if len(groups)>=2:
            exhausted=False;break # logically sufficient witnesses, not a first-fit cutoff
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    applicable=groups[chosen] if chosen else []
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':exhausted,
        'tests':[{'status':status,'prediction':[list(row) for row in chosen[i]] if chosen else None} for i in range(len(inputs))],
        'supporting_families':['shared_scene_relational_edits' if relations else JOINT_FAMILY] if chosen else [],
        'supporting_laws':[p.describe() for p in applicable[:20]],
        'witness_predictions':[[[list(r) for r in a] for a in key] for key in list(groups)[:2]],
        'stats':{'fitted_spaces':len(models),'examined_spaces':examined,'assignment_nodes':nodes,
                 'search_exhausted':exhausted,'decision_complete':True,'max_edits_per_case':max_edits,
                 'ambiguity_uses_complete_witnesses':True,'description_limit_not_search_limit':20}}


def validate_joint(task, full, *, max_edits=2, relations=False):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer_joint(fold,max_edits=max_edits,relations=relations);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
            'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
            'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
            'joint_hypotheses':r['joint_hypotheses']})
    passed=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':passed,'reason':'passed' if passed else 'held_example_or_stability_failure','folds':folds}

# The same compiler now binds relations to rigid endpoint transformations.
from scene_kernel import (PlacementProgram,PlacementSpec,RelationSpec,RELATION_SPECS,BoundAssignment,
                          bind_references,anchor_twice)
PLACEMENT_FAMILY='shared_scene_placement'
PLACEMENT_RELATIONS=(RelationSpec('all','other'),)+RELATION_SPECS


def _compatible_translations(scene,target,owner,cleared):
    e=scene.entities[owner];a=scene.source;h,w=len(a),len(a[0]);r0,c0=e.cells[0];v=a[r0][c0];out=[]
    for r,row in enumerate(target):
        for c,value in enumerate(row):
            if value!=v:continue
            dr,dc=r-r0,c-c0
            if all(0<=rr+dr<h and 0<=cc+dc<w and target[rr+dr][cc+dc]==a[rr][cc] and
                   ((rr+dr,cc+dc) in cleared or a[rr+dr][cc+dc]==scene.background) for rr,cc in e.cells):out.append((dr,dc))
    return tuple(out)


def fit_placements(pairs,*,relations=True,prefer_zero=True,consume=False):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs) or any(len(a)!=len(y) or len(a[0])!=len(y[0]) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    ic=[Counter(v for row in a for v in row) for a,y in pairs];oc=[Counter(v for row in y for v in row) for a,y in pairs]
    if any(set(o)-set(i) for i,o in zip(ic,oc)):return []  # never invent material colours
    conserve=all(i==o for i,o in zip(ic,oc))
    changes=[frozenset((r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=y[r][c]) for a,y in pairs]
    models=[];specs=PLACEMENT_RELATIONS if relations else PLACEMENT_RELATIONS[:1]
    for bg,conn,mono in product(('modal',*sorted(common)),(4,8),(True,False)):
        try:scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
        except Inapplicable:continue
        ec=[tuple(Counter(s.source[r][c] for r,c in e.cells) for e in s.entities) for s in scenes]
        copy_ok=all(all(a[r][c]==s.background and y[r][c]!=s.background for r,c in changed)
                    for (a,y),s,changed in zip(pairs,scenes,changes))
        if not consume and not conserve and not copy_ok:continue
        groups=defaultdict(list)
        for pred in predicate_candidates(scenes):
            ids=tuple(pred.select(s) for s in scenes)
            if any(not i or len(i)==len(s.entities) for i,s in zip(ids,scenes)):continue
            groups[ids].append(pred)
        for indices,predicates in groups.items():
            # This compiler needs witnessed multi-cell source structure; the low-level
            # assignment primitive can still manipulate singleton bodies.
            if any(len(s.entities[i].cells)<2 for s,ids in zip(scenes,indices) for i in ids):continue
            selections=tuple(Entities(s,ids) for s,ids in zip(scenes,indices))
            source_cells=[frozenset(p for i in ids for p in s.entities[i].cells) for s,ids in zip(scenes,indices)]
            source_counts=[sum((e[i] for i in ids),Counter()) for e,ids in zip(ec,indices)]
            for operation,lifecycle in product(('move','copy'),('preserve','consume') if consume else ('preserve',)):
                if lifecycle=='preserve' and ((operation=='move' and not conserve) or (operation=='copy' and not copy_ok)):continue
                eligible=[];cleared=[];valid=True
                for q,(s,ids,src,counts,i_count,o_count,compcounts,delta) in enumerate(zip(scenes,indices,source_cells,source_counts,ic,oc,ec,changes)):
                    remaining=tuple(j for j in range(len(s.entities)) if j not in ids)
                    origins=src if operation=='move' else frozenset()
                    if lifecycle=='consume':
                        # Necessary exact colour balance. Never prune using test targets.
                        wanted={c:i_count[c]+(counts[c] if operation=='copy' else 0)-o_count[c] for c in range(10) if c!=s.background}
                        if any(v<0 for v in wanted.values()) or sum(wanted.values())<=0:valid=False;break
                        er=tuple(j for j in remaining if all(n<=wanted.get(c,0) for c,n in compcounts[j].items()))
                        total=sum((compcounts[j] for j in er),Counter())
                        if not er or any(total[c]<n for c,n in wanted.items()) or sum(wanted.values())>len(ids)*max(len(s.entities[j].cells) for j in er):valid=False;break
                        allowed=origins|frozenset(p for j in er for p in s.entities[j].cells)
                    else:
                        er=remaining;allowed=origins
                        if operation=='copy' and counts!=Counter(pairs[q][1][r][c] for r,c in delta):valid=False;break
                    if any(s.source[r][c]!=s.background and (r,c) not in allowed for r,c in delta):valid=False;break
                    eligible.append(frozenset(er));cleared.append(allowed)
                if not valid:continue
                positions=tuple(tuple(_compatible_translations(s,y,i,cl) for i in ids) for (a,y),s,ids,cl in zip(pairs,scenes,indices,cleared))
                if any(any(not opts for opts in row) for row in positions):continue
                for relation in specs:
                    try:bindings=tuple(bind_references(sel,relation) for sel in selections)
                    except Inapplicable:continue
                    # Filtering is compile-time pruning AFTER relational ties are
                    # computed. The interpreter still replays the complete domains.
                    domains=tuple(tuple(tuple(j for j in row if j in ok) for row in b.domains) for b,ok in zip(bindings,eligible))
                    if any(any(not row for row in d) for d in domains):continue
                    for axes,sa,ra in product(((0,),(1,),(0,1)),('low','center','high'),('low','center','high')):
                        offsets=None
                        for s,ids,domain,row in zip(scenes,indices,domains,positions):
                            for i,refs,translations in zip(ids,domain,row):
                                options=set()
                                for dr,dc in translations:
                                    if any((dr,dc)[axis]!=0 for axis in (0,1) if axis not in axes):continue
                                    for j in refs:
                                        v=[0,0];ok=True
                                        for axis in axes:
                                            d=anchor_twice(s.entities[i].box,axis,sa)+2*(dr,dc)[axis]-anchor_twice(s.entities[j].box,axis,ra)
                                            if d%2:ok=False;break
                                            v[axis]=d//2
                                        if ok:options.add(tuple(v))
                                offsets=options if offsets is None else offsets&options
                                if not offsets:break
                            if not offsets:break
                        for offset in sorted(offsets or ()):
                            for injective in (False,True):
                                spec=PlacementSpec(axes,sa,ra,offset,operation,lifecycle)
                                model=PlacementProgram(bg,conn,mono,predicates[0],relation,spec,injective)
                                try:
                                    if any(model.execute_options(s)[0]!=(y,) for s,(a,y) in zip(scenes,pairs)):continue
                                except Inapplicable:continue
                                models.extend(PlacementProgram(bg,conn,mono,p,relation,spec,injective) for p in predicates)
    models=list(dict.fromkeys(models));zero=[m for m in models if m.placement.offset==(0,0)]
    return zero if prefer_zero and zero else models


def predict_placements(models,inputs):
    groups={};invalid=0;exhausted=True;leaves=0
    for model in models:
        domains=[]
        for a in inputs:
            out,complete,n=model.predict_options(a);leaves+=n
            if not out:break
            domains.append(out)
        if len(domains)!=len(inputs):invalid+=1;continue
        for key in product(*domains):
            groups.setdefault(tuple(key),[]).append(model)
            if len(groups)>1:exhausted=False;break
        if not exhausted:break
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit';chosen=next(iter(groups)) if status=='unique' else None
    applicable=groups[chosen] if chosen else [];reps=[];seen=set()
    for m in applicable:
        label=(m.placement.operation,m.placement.reference_policy,m.placement.axes,m.relation.edge,m.relation.targets,m.injective)
        if label not in seen:reps.append(m.describe());seen.add(label)
    reports=reps+[m.describe() for m in applicable if m.describe() not in reps]
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':exhausted,
            'tests':[{'status':status,'prediction':[list(row) for row in chosen[i]] if chosen else None} for i in range(len(inputs))],
            'supporting_families':[PLACEMENT_FAMILY] if chosen else [],'supporting_laws':reports[:20],
            'witness_predictions':[[[list(row) for row in a] for a in key] for key in list(groups)[:2]],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'assignment_leaves_visited':leaves,
                     'search_exhausted':exhausted,'ambiguous_outputs_not_discarded':True}}


def infer_placements(task,*,relations=True,prefer_zero=True,consume=False):
    clean=public_task(task);models=fit_placements(((d['input'],d['output']) for d in clean['train']),relations=relations,prefer_zero=prefer_zero,consume=consume)
    return predict_placements(models,tuple(grid(d['input']) for d in clean['test']))


def validate_placements(task,full,*,relations=True,prefer_zero=True,consume=False):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[d['prediction'] for d in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        t={'train':[d for i,d in enumerate(clean['train']) if i!=held],'test':[{'input':demo['input']}]+clean['test']}
        r=infer_placements(t,relations=relations,prefer_zero=prefer_zero,consume=consume);ps=[d['prediction'] for d in r['tests']]
        folds.append({'held_index':held,'status':r['status'],'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}

# Shared material assignment: the one-piece control differs only in capacity.
from scene_kernel import MaterialProgram, CoverSpec, bind_cover, cover_edits, reference_groups

MATERIAL_FAMILY = 'shared_scene_material'
MATERIAL_RELATIONS = tuple(RelationSpec(edge) for edge in ('all', 'same_palette', 'nearest_center', 'same_row', 'same_column'))


@dataclass(frozen=True)
class MaterialAliases:
    """A factored Cartesian set of symbolic predicates, not a chosen answer.

    All members agree on the fitting selections. At prediction, refactor using
    their joint selections on EVERY supplied input; retain every distinct result.
    """
    exemplar: MaterialProgram
    references: tuple
    sources: tuple

    @property
    def count(self):
        return len(self.references)*len(self.sources)

    def instantiate(self, inputs):
        from dataclasses import replace
        m=self.exemplar
        try:
            scenes=tuple(perceive(a,m.background_rule,m.connectivity,m.monochrome) for a in inputs)
        except Inapplicable:
            return
        def quotient(predicates):
            groups={}
            for p in predicates:
                try: key=tuple(p.select(s) for s in scenes) if p is not None else None
                except Inapplicable: continue
                groups.setdefault(key,p)
            return tuple(groups.values())
        for rp,sp in product(quotient(self.references),quotient(self.sources)):
            yield replace(m,reference_predicate=rp,source_predicate=sp)


def fit_material(pairs, *, one_piece=False, role_targets=False, factor_aliases=False):
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    if any((len(a), len(a[0])) != (len(y), len(y[0])) or Counter(v for row in a for v in row) != Counter(v for row in y for v in row) for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, y in pairs))
    models = []
    fit_cache = {}  # Exact binding signatures share search, not hypothesis selection.
    for bg, conn, mono in product(('modal', *sorted(common)), (4, 8), (True, False)):
        try:
            scenes = tuple(perceive(a, bg, conn, mono) for a, y in pairs)
        except Inapplicable:
            continue
        added, removed = [], []
        admissible = True
        for scene, (a, y) in zip(scenes, pairs):
            aa, rr = set(), set()
            for row in range(len(a)):
                for col in range(len(a[0])):
                    if a[row][col] == y[row][col]:
                        continue
                    if a[row][col] == scene.background:
                        aa.add((row, col))
                    elif y[row][col] == scene.background:
                        rr.add((row, col))
                    else:
                        admissible = False
            added.append(frozenset(aa)); removed.append(frozenset(rr))
        if not admissible or any(not x for x in added):
            continue
        groups = defaultdict(list)
        for predicate in predicate_candidates(scenes):
            ids = tuple(predicate.select(s) for s in scenes)
            if any(not row or len(row) == len(s.entities) for s, row in zip(scenes, ids)):
                continue
            if any(any(a[r][c] != y[r][c] for i in row for r, c in s.entities[i].cells) for s, row, (a, y) in zip(scenes, ids, pairs)):
                continue  # stationary references: necessary demonstration pruning
            groups[ids].append(predicate)
        # Source-role induction is pruned by whole-source removal in demonstrations.
        # The emitted model retains only the predicate, never these changed cells.
        source_groups = {None: None}
        if role_targets:
            source_groups = defaultdict(list)
            source_groups[None] = None  # Retain the complete original role grammar.
            for predicate in predicate_candidates(scenes):
                selections = tuple(tuple(i for i in predicate.select(s) if len(s.entities[i].cells)>=2)
                                   for s in scenes)
                if any(not row for row in selections): continue
                # Only removed bodies can participate; stationary selected references
                # are ignored later by the input-local role binding.
                if any(not rr <= frozenset(p for i in row for p in s.entities[i].cells)
                       for s,row,rr in zip(scenes,selections,removed)): continue
                source_groups[selections].append(predicate)
        for selections, predicates in groups.items():
            groupings = ('individual','palette','selected') if role_targets else ('individual',)
            kinds = ('box','holes','row_spans','column_spans','axial_spans',
                     'extend_left','extend_right','extend_up','extend_down') if role_targets else ('box','holes','extend_left','extend_right','extend_up','extend_down')
            for grouping in groupings:
                if grouping!='individual' and not any(any(len(g)>1 for g in reference_groups(Entities(s,ids),grouping))
                                                      for s,ids in zip(scenes,selections)): continue
                for selected_sources, source_predicates in source_groups.items():
                    if selected_sources is not None:
                        # Exact source role membership after references are excluded.
                        if any(frozenset(p for i in row if i not in refs for p in s.entities[i].cells)!=rr
                               for s,row,refs,rr in zip(scenes,selected_sources,selections,removed)): continue
                        source_rep=source_predicates[0]
                    else: source_rep=None
                    for kind in kinds:
                        bindings=[]
                        for s,ids,aa,rr in zip(scenes,selections,added,removed):
                            try:
                                binding=bind_cover(Entities(s,ids),CoverSpec(kind,reference_grouping=grouping),MATERIAL_RELATIONS[0],source_rep)
                            except Inapplicable: break
                            if frozenset(p for _,mask in binding.targets for p in mask)!=aa: break
                            partial=any(bool(set(s.entities[i].cells)&rr) and not set(s.entities[i].cells)<=rr for i in binding.sources)
                            origins=frozenset(p for i in binding.sources if set(s.entities[i].cells)<=rr for p in s.entities[i].cells)
                            if partial or origins!=rr: break
                            if source_rep is not None and sum(len(s.entities[i].cells) for i in binding.sources)!=len(rr): break
                            bindings.append(binding)
                        if len(bindings)!=len(scenes): continue
                        participations=('all',) if source_rep is not None or grouping!='individual' else ('all','palette_groups')
                        for orient,participation,relation in product(('identity','rotations','dihedral'),participations,MATERIAL_RELATIONS):
                            if kind.startswith('extend_') and participation!='all': continue
                            spec=CoverSpec(kind,orient,participation,one_piece,grouping)
                            try:
                                bound=tuple(bind_cover(Entities(s,ids),spec,relation,source_rep)
                                            for s,ids in zip(scenes,selections))
                            except Inapplicable: continue
                            # Cover geometry and grouping are already represented by
                            # the exact target/domain values. Only three remaining
                            # parameters affect the covering interpreter.
                            execution=CoverSpec('box',orient,participation,one_piece)
                            key=(bound,execution)
                            if key not in fit_cache:
                                fit_cache[key]=all(tuple(emit(edit,'preserve') for edit,trace in cover_edits(binding,execution)[0])==(y,)
                                                   for binding,(a,y) in zip(bound,pairs))
                            if not fit_cache[key]: continue
                            sps=tuple(source_predicates) if source_predicates is not None else (None,)
                            if factor_aliases:
                                models.append(MaterialAliases(MaterialProgram(bg,conn,mono,predicates[0],relation,spec,sps[0]),tuple(predicates),sps))
                            else:
                                for p in predicates:
                                    for sp in sps:
                                        models.append(MaterialProgram(bg,conn,mono,p,relation,spec,sp))
    return list(dict.fromkeys(models))


def predict_material(models, inputs):
    groups = {}; invalid = 0; exhausted = True; nodes = 0
    prediction_cache = {}
    scene_cache = {}; selection_cache = {}; binding_cache = {}
    programs=(p for m in models for p in (m.instantiate(inputs) if isinstance(m,MaterialAliases) else (m,)))
    for model in programs:
        domains = []
        for input_index, a in enumerate(inputs):
            try:
                scene_key=(input_index,model.background_rule,model.connectivity,model.monochrome)
                if scene_key not in scene_cache:
                    scene_cache[scene_key]=perceive(a,model.background_rule,model.connectivity,model.monochrome)
                scene=scene_cache[scene_key]
                def selected(predicate):
                    k=(scene_key,predicate)
                    if k not in selection_cache: selection_cache[k]=predicate.select(scene)
                    return selection_cache[k]
                refs=Entities(scene,selected(model.reference_predicate))
                sources=selected(model.source_predicate) if model.source_predicate is not None else None
                binding_key=(scene_key,refs.indices,sources,model.cover,model.relation)
                if binding_key not in binding_cache:
                    try: binding_cache[binding_key]=bind_cover(refs,model.cover,model.relation,model.source_predicate)
                    except Inapplicable: binding_cache[binding_key]=None
                bound=binding_cache[binding_key]
                if bound is None: raise Inapplicable('inapplicable bound roles')
                execution=CoverSpec('box',model.cover.orientation_group,model.cover.participation,model.cover.one_piece)
                key=(bound,execution)
                if key not in prediction_cache:
                    edits,complete,stats=cover_edits(bound,execution)
                    nodes += stats.get('nodes',0)
                    prediction_cache[key]=tuple(emit(edit,'preserve') for edit,trace in edits)
                out=prediction_cache[key]
            except Inapplicable:
                out=()
            if not out:
                break
            domains.append(out)
        if len(domains) != len(inputs):
            invalid += 1
            continue
        for key in product(*domains):
            groups.setdefault(tuple(key), []).append(model)
            if len(groups) > 1:
                exhausted = False
                break
        if not exhausted:
            break
    status = 'unique' if len(groups) == 1 else 'ambiguous' if groups else 'no_fit'
    chosen = next(iter(groups)) if status == 'unique' else None
    laws = [m.describe() for m in groups[chosen]] if chosen else []
    return {'status': status, 'joint_hypotheses': len(groups), 'joint_hypotheses_is_exact': exhausted,
            'tests': [{'status': status, 'prediction': [list(row) for row in chosen[i]] if chosen else None} for i in range(len(inputs))],
            'supporting_families': [MATERIAL_FAMILY] if chosen else [], 'supporting_laws': laws[:20],
            'witness_predictions': [[[list(row) for row in a] for a in key] for key in list(groups)[:2]],
            'stats': {'fitted_programs': sum(m.count if isinstance(m,MaterialAliases) else 1 for m in models),
                      'fitted_spaces':len(models), 'inapplicable_representatives': invalid,
                      'constraint_nodes': nodes, 'search_exhausted': exhausted}}


def infer_material(task, *, one_piece=False, role_targets=False):
    clean = public_task(task)
    models = fit_material(((d['input'], d['output']) for d in clean['train']), one_piece=one_piece, role_targets=role_targets, factor_aliases=role_targets)
    return predict_material(models, tuple(grid(t['input']) for t in clean['test']))


def validate_material(task, full, *, one_piece=False, role_targets=False):
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [t['prediction'] for t in full['tests']]; folds = []
    for held, demo in enumerate(clean['train']):
        task_fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                     'test': [{'input': demo['input']}] + clean['test']}
        r = infer_material(task_fold, one_piece=one_piece, role_targets=role_targets)
        ps = [t['prediction'] for t in r['tests']]
        folds.append({'held_index': held, 'status': r['status'],
                      'held_example_exact': r['status'] == 'unique' and ps[0] == demo['output'],
                      'test_prediction_stable': r['status'] == 'unique' and ps[1:] == expected,
                      'joint_hypotheses': r['joint_hypotheses']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure', 'folds': folds}

# V92: ordered inventory is another schema over the SAME Scene and interpreter.
from scene_kernel import (InventoryProgram, MeasureSpec, collect_inventory, measure_inventory,
                          layout_inventory, INVENTORY_QUANTITIES, INVENTORY_ORDERS,
                          INVENTORY_SPATIAL_ORDERS)
INVENTORY_FAMILY = 'shared_scene_inventory'


def fit_inventory(pairs, *, spatial_only=False):
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, y in pairs))
    inks = set.intersection(*({v for row in y for v in row} for a, y in pairs))
    target_shapes = tuple((len(y), len(y[0])) for a, y in pairs)
    target_counts = tuple(Counter(v for row in y for v in row) for a, y in pairs)
    orders = INVENTORY_SPATIAL_ORDERS if spatial_only else INVENTORY_ORDERS
    specs = [MeasureSpec('pattern'), MeasureSpec('symbol')]
    specs += [MeasureSpec('symbol', ink='constant', value=v) for v in sorted(inks)]
    for encoding, quantity in product(('bar_rows', 'bar_columns', 'square'), INVENTORY_QUANTITIES):
        specs.append(MeasureSpec(encoding, quantity))
        specs.extend(MeasureSpec(encoding, quantity, 'constant', v) for v in sorted(inks))
    found = []
    for bg, conn, mono in product(('modal', *sorted(common)), (4, 8), (True, False)):
        try:
            scenes = tuple(perceive(a, bg, conn, mono) for a, y in pairs)
        except Inapplicable:
            continue
        for collection in ('objects', 'colours', 'foreground'):
            try:
                inventories = tuple(collect_inventory(s, collection, conn) for s in scenes)
            except Inapplicable:
                continue
            # Alias by demonstrated tiles to share layout fitting, NOT to remove
            # alternative representations/quantities that may diverge at inference.
            aliases = defaultdict(list)
            for spec in specs:
                try:
                    values = tuple(measure_inventory(i, spec) for i in inventories)
                except Inapplicable:
                    continue
                aliases[tuple(v.tiles for v in values)].append(spec)
            for tiles_key, measure_specs in aliases.items():
                values = tuple(measure_inventory(i, measure_specs[0]) for i in inventories)
                for axis, gap in product((0, 1), (0, 1, 2)):
                    shape_ok = True
                    for vs, target_shape, tc in zip(values, target_shapes, target_counts):
                        cross = max(len(t[0]) if axis == 0 else len(t) for t in vs.tiles)
                        length = sum(len(t) if axis == 0 else len(t[0]) for t in vs.tiles) + gap*(len(vs.tiles)-1)
                        shape = (length, cross) if axis == 0 else (cross, length)
                        if shape != target_shape:
                            shape_ok = False; break
                        cc = Counter(v for tile in vs.tiles for row in tile for v in row)
                        cc[vs.inventory.scene.background] += length*cross - sum(len(t)*len(t[0]) for t in vs.tiles)
                        if +cc != +tc:
                            shape_ok = False; break
                    if not shape_ok:
                        continue
                    for order, descending, alignment in product(orders, (False, True), ('low', 'center', 'high')):
                        # Fitting requires an unambiguous output for each demo.
                        # Test-time equal-ranked alternatives are still retained.
                        try:
                            outputs = tuple(layout_inventory(vs, order, descending, axis, gap, alignment) for vs in values)
                        except Inapplicable:
                            continue
                        if not all(len(p) == 1 and p[0] == y for p, (_, y) in zip(outputs, pairs)):
                            continue
                        found.extend(InventoryProgram(bg, conn, mono, collection, spec, order,
                                                     descending, axis, gap, alignment) for spec in measure_specs)
    return list(dict.fromkeys(found))


def predict_inventory(models, inputs):
    inputs = tuple(grid(a) for a in inputs)
    groups = {}; invalid = 0; fully_enumerated = True
    # Cache exact interpretation/encoding/layout queries across program aliases.
    for model in models:
        options = tuple(model.predict_options(a) for a in inputs)
        if any(not ps for ps in options):
            invalid += 1; continue
        first = tuple(ps[0] for ps in options)
        groups.setdefault(first, []).append(model.describe())
        for i, ps in enumerate(options):
            if len(ps) > 1:
                second = list(first); second[i] = ps[1]
                groups.setdefault(tuple(second), []).append(model.describe())
                break
        if len(groups) > 1:
            fully_enumerated = False; break  # two COMPLETE witnesses prove ambiguity
    from runtime import joint_result
    records = {k:[{'family':INVENTORY_FAMILY, 'program':p} for p in ps] for k, ps in groups.items()}
    result = joint_result(records, len(inputs))
    result['joint_hypotheses_is_exact'] = fully_enumerated
    result['supporting_laws'] = next(iter(groups.values()))[:20] if result['status'] == 'unique' else []
    result['witness_predictions'] = [[[list(row) for row in g] for g in k] for k in list(groups)[:2]]
    result['stats'] = {'fitted_programs':len(models), 'inapplicable_programs_visited':invalid,
                       'tie_policy':'output_equivalence_or_two_full_witnesses',
                       'description_cap_not_search_cap':20}
    return result


def infer_inventory(task, *, spatial_only=False):
    clean = public_task(task)
    models = fit_inventory(((d['input'], d['output']) for d in clean['train']), spatial_only=spatial_only)
    return predict_inventory(models, tuple(grid(d['input']) for d in clean['test']))


def validate_inventory(task, full, *, spatial_only=False):
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed':False, 'reason':'full_fit_not_unique', 'folds':[]}
    if len(clean['train']) < 2:
        return {'passed':False, 'reason':'requires_two_demonstrations', 'folds':[]}
    expected = [d['prediction'] for d in full['tests']]; folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train':[d for i,d in enumerate(clean['train']) if i != held],
                'test':[{'input':demo['input']}] + clean['test']}
        result = infer_inventory(fold, spatial_only=spatial_only)
        predictions = [d['prediction'] for d in result['tests']]
        folds.append({'held_index':held, 'status':result['status'],
                      'held_example_exact':result['status']=='unique' and predictions[0]==demo['output'],
                      'test_prediction_stable':result['status']=='unique' and predictions[1:]==expected,
                      'joint_hypotheses':result['joint_hypotheses']})
    ok = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok, 'reason':'passed' if ok else 'held_example_or_stability_failure', 'folds':folds}

# The shared inventory compiler now admits a second typed output geometry.
from scene_kernel import GridInventoryProgram, GridLayoutSpec, layout_inventory_grid
GRID_INVENTORY_FAMILY = 'shared_scene_grid_inventory'


def fit_grid_inventory(pairs, *, spatial_only=False):
    """Infer complete 2D arrangements using the native collection/measurement API.

    Dimensions and colour counts prune layouts before any order is tested. Fixed
    row/column counts are induced from all demonstrations. Square count is computed
    anew from the current inventory. All aliases survive prediction; none stores
    an example tile, source coordinate, target grid, or task identifier.
    """
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    if any(min(len(y), len(y[0])) < 2 for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, y in pairs))
    inks = set.intersection(*({v for row in y for v in row} for a, y in pairs))
    target_shapes = tuple((len(y), len(y[0])) for a, y in pairs)
    target_counts = tuple(Counter(v for row in y for v in row) for a, y in pairs)
    orders = INVENTORY_SPATIAL_ORDERS if spatial_only else INVENTORY_ORDERS
    specs = [MeasureSpec('pattern'), MeasureSpec('symbol')]
    specs += [MeasureSpec('symbol', ink='constant', value=v) for v in sorted(inks)]
    for encoding, quantity in product(('bar_rows', 'bar_columns', 'square'), INVENTORY_QUANTITIES):
        specs.append(MeasureSpec(encoding, quantity))
        specs.extend(MeasureSpec(encoding, quantity, 'constant', v) for v in sorted(inks))
    found = []
    # Share successful suffix calculations across identical scene perceptions.
    prefix_cache = {}
    for bg, conn, mono in product(('modal', *sorted(common)), (4, 8), (True, False)):
        try:
            scenes = tuple(perceive(a, bg, conn, mono) for a, y in pairs)
        except Inapplicable:
            continue
        for collection in ('objects', 'colours', 'foreground'):
            try:
                inventories = tuple(collect_inventory(s, collection, conn) for s in scenes)
            except Inapplicable:
                continue
            if any(len(i.items) < 4 for i in inventories):
                continue
            signature = inventories  # includes source, items, measured values, and background
            if signature in prefix_cache:
                found.extend(GridInventoryProgram(bg, conn, mono, collection, *suffix)
                             for suffix in prefix_cache[signature])
                continue
            suffixes = []
            aliases = defaultdict(list)
            for spec in specs:
                try:
                    values = tuple(measure_inventory(i, spec) for i in inventories)
                except Inapplicable:
                    continue
                aliases[tuple(v.tiles for v in values)].append(spec)
            for tile_key, measure_specs in aliases.items():
                values = tuple(measure_inventory(i, measure_specs[0]) for i in inventories)
                # With fixed slot geometry, sorting cannot alter counts or shape.
                if any(+Counter(v for t in val.tiles for row in t for v in row if v != val.inventory.scene.background)
                       != +Counter(v for row in y for v in row if v != val.inventory.scene.background)
                       for val, (_, y) in zip(values, pairs)):
                    continue
                for rg, cg in product((0, 1, 2), repeat=2):
                    shapes = []
                    for val, (h, w) in zip(values, target_shapes):
                        th = max(len(t) for t in val.tiles); tw = max(len(t[0]) for t in val.tiles)
                        if (h + rg) % (th + rg) or (w + cg) % (tw + cg):
                            break
                        rows, cols = (h + rg) // (th + rg), (w + cg) // (tw + cg)
                        if min(rows, cols) < 2 or rows * cols != len(val.tiles):
                            break
                        shapes.append((rows, cols))
                    if len(shapes) != len(pairs):
                        continue
                    shape_rules = []
                    if len({r for r, c in shapes}) == 1: shape_rules.append(('rows', shapes[0][0]))
                    if len({c for r, c in shapes}) == 1: shape_rules.append(('columns', shapes[0][1]))
                    if all(r == c for r, c in shapes): shape_rules.append(('square', 2))
                    if not shape_rules:
                        continue
                    for order, descending, flow, ar, ac in product(orders, (False, True),
                            ('rows', 'columns', 'snake_rows', 'snake_columns'),
                            ('low', 'center', 'high'), ('low', 'center', 'high')):
                        rule, count = shape_rules[0]
                        layout = GridLayoutSpec(rule, count, flow, rg, cg, ar, ac)
                        try:
                            outputs = tuple(layout_inventory_grid(v, order, descending, layout) for v in values)
                        except Inapplicable:
                            continue
                        if not all(len(p) == 1 and p[0] == y for p, (_, y) in zip(outputs, pairs)):
                            continue
                        # Other dimensional descriptions agree only on supplied
                        # demonstrations, and are retained for every future input.
                        for spec in measure_specs:
                            for rule, count in shape_rules:
                                suffixes.append((spec, order, descending,
                                    GridLayoutSpec(rule, count, flow, rg, cg, ar, ac)))
            prefix_cache[signature] = suffixes
            found.extend(GridInventoryProgram(bg, conn, mono, collection, *suffix) for suffix in suffixes)
    return list(dict.fromkeys(found))


def predict_grid_inventory(models, inputs):
    # The generic complete-program predictor works for both InventoryProgram and
    # GridInventoryProgram. Only diagnostic family labels differ.
    result = predict_inventory(models, inputs)
    result['supporting_families'] = [GRID_INVENTORY_FAMILY] if result['status'] == 'unique' else []
    return result


def infer_grid_inventory(task, *, spatial_only=False):
    clean = public_task(task)
    models = fit_grid_inventory(((d['input'], d['output']) for d in clean['train']), spatial_only=spatial_only)
    return predict_grid_inventory(models, tuple(grid(d['input']) for d in clean['test']))


def validate_grid_inventory(task, full, *, spatial_only=False):
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [d['prediction'] for d in full['tests']]; folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': demo['input']}] + clean['test']}
        result = infer_grid_inventory(fold, spatial_only=spatial_only)
        predictions = [d['prediction'] for d in result['tests']]
        folds.append({'held_index': held, 'status': result['status'],
                      'held_example_exact': result['status'] == 'unique' and predictions[0] == demo['output'],
                      'test_prediction_stable': result['status'] == 'unique' and predictions[1:] == expected,
                      'joint_hypotheses': result['joint_hypotheses']})
    ok = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': ok, 'reason': 'passed' if ok else 'held_example_or_stability_failure', 'folds': folds}


# Input-relative grouping composes with the SAME inventory collection/measurement API.
from scene_kernel import (GroupedInventoryProgram, GroupedLayoutSpec,
                          layout_inventory_grouped, AXIS_GROUP_RELATIONS)
GROUPED_INVENTORY_FAMILY = 'shared_scene_grouped_inventory'


def _fit_spatial_inventory(pairs, *, complete_only=False, coordinates=False,
                           allow_pitch=True, local_items=True):
    """One compiler for ordinal and provenance-certified coordinate layouts."""
    from dataclasses import replace
    from scene_kernel import CoordinateLayoutSpec, CoordinateInventoryProgram
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if not coordinates and any(min(len(y),len(y[0]))<2 for a,y in pairs):return []
    ProgramClass=CoordinateInventoryProgram if coordinates else GroupedInventoryProgram
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    inks=set.intersection(*({v for row in y for v in row} for a,y in pairs))
    specs=[MeasureSpec('pattern'),MeasureSpec('symbol')]
    specs.extend(MeasureSpec('symbol',ink='constant',value=v) for v in sorted(inks))
    for encoding,quantity in product(('bar_rows','bar_columns','square'),INVENTORY_QUANTITIES):
        specs.append(MeasureSpec(encoding,quantity))
        specs.extend(MeasureSpec(encoding,quantity,'constant',v) for v in sorted(inks))
    found=[];prefix_cache={}
    for bg,conn,mono in product(('modal',*sorted(common)),(4,8),(True,False)):
        try:scenes=tuple(perceive(a,bg,conn,mono) for a,y in pairs)
        except Inapplicable:continue
        for collection in ('objects','colours'):
            try:inventories=tuple(collect_inventory(s,collection,conn) for s in scenes)
            except Inapplicable:continue
            if any(len(i.items)<2 for i in inventories):continue
            if inventories in prefix_cache:
                found.extend(ProgramClass(bg,conn,mono,collection,*x) for x in prefix_cache[inventories]);continue
            groups={}
            for rr,cr in product(AXIS_GROUP_RELATIONS,repeat=2):
                metrics=product(('rank','pitch') if allow_pitch and rr!='overlap' else ('rank',),
                                ('rank','pitch') if allow_pitch and cr!='overlap' else ('rank',)) if coordinates else [('rank','rank')]
                for rm,cm in metrics:
                    layout=CoordinateLayoutSpec(rr,cr,rm,cm,local_items=local_items) if coordinates else GroupedLayoutSpec(rr,cr,require_complete=complete_only)
                    try:slotmaps=tuple(layout.slots(inv) for inv in inventories)
                    except Inapplicable:continue
                    if coordinates:
                        # A pitch expansion must have an observable missing-band
                        # effect in the fitting examples. This is an explicit prior,
                        # not logical equivalence of pitch and rank on unseen inputs.
                        if rm=='pitch' and not any(R>len({r for r,c in slots}) for R,C,slots in slotmaps):continue
                        if cm=='pitch' and not any(C>len({c for r,c in slots}) for R,C,slots in slotmaps):continue
                    groups.setdefault(slotmaps,[]).append(layout)
            if not groups:
                prefix_cache[inventories]=[];continue
            measured={}
            for spec in specs:
                try:values=tuple(measure_inventory(i,spec) for i in inventories)
                except Inapplicable:continue
                if any(Counter(v for t in val.tiles for row in t for v in row if v!=val.inventory.scene.background)
                       != Counter(v for row in y for v in row if v!=val.inventory.scene.background)
                       for val,(_,y) in zip(values,pairs)):continue
                measured.setdefault(tuple(v.tiles for v in values),[]).append(spec)
            suffixes=[]
            for tile_key,measure_aliases in measured.items():
                values=tuple(measure_inventory(inv,measure_aliases[0]) for inv in inventories)
                for slotmaps,layout_aliases in groups.items():
                    gaps=set(product((0,1,2),repeat=2))
                    for val,(rows,cols,_),(_,y) in zip(values,slotmaps,pairs):
                        h=max(len(t) for t in val.tiles);w=max(len(t[0]) for t in val.tiles)
                        gaps={g for g in gaps if rows*h+(rows-1)*g[0]==len(y) and cols*w+(cols-1)*g[1]==len(y[0])}
                        if not gaps:break
                    for rg,cg in sorted(gaps):
                        for ar,ac in product(('low','center','high'),repeat=2):
                            layout=replace(layout_aliases[0],row_gap=rg,column_gap=cg,row_alignment=ar,column_alignment=ac)
                            try:outputs=tuple(layout_inventory_grouped(val,layout) for val in values)
                            except Inapplicable:continue
                            if not all(len(out)==1 and out[0]==y for out,(_,y) in zip(outputs,pairs)):continue
                            for spec in measure_aliases:
                                for alias in layout_aliases:
                                    suffixes.append((spec,replace(alias,row_gap=rg,column_gap=cg,row_alignment=ar,column_alignment=ac)))
            prefix_cache[inventories]=suffixes
            found.extend(ProgramClass(bg,conn,mono,collection,*s) for s in suffixes)
    return list(dict.fromkeys(found))


def fit_grouped_inventory(pairs, *, complete_only=False):
    return _fit_spatial_inventory(pairs,complete_only=complete_only)


def fit_coordinate_inventory(pairs, *, allow_pitch=True, local_items=True):
    return _fit_spatial_inventory(pairs,coordinates=True,allow_pitch=allow_pitch,local_items=local_items)


def infer_grouped_inventory(task, *, complete_only=False):
    clean=public_task(task)
    models=fit_grouped_inventory(((d['input'],d['output']) for d in clean['train']),complete_only=complete_only)
    result=predict_inventory(models,tuple(grid(d['input']) for d in clean['test']))
    result['supporting_families']=[GROUPED_INVENTORY_FAMILY] if result['status']=='unique' else []
    return result


def _validate_spatial_inventory(task,full,infer_function):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[d['prediction'] for d in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        result=infer_function(fold)
        preds=[d['prediction'] for d in result['tests']]
        folds.append({'held_index':held,'status':result['status'],
                      'held_example_exact':result['status']=='unique' and preds[0]==demo['output'],
                      'test_prediction_stable':result['status']=='unique' and preds[1:]==expected,
                      'joint_hypotheses':result['joint_hypotheses']})
    passed=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':passed,'reason':'passed' if passed else 'held_example_or_stability_failure','folds':folds}


COORDINATE_INVENTORY_FAMILY='shared_scene_coordinate_inventory'


def infer_coordinate_inventory(task, *, allow_pitch=True, local_items=True):
    clean=public_task(task)
    models=fit_coordinate_inventory(((d['input'],d['output']) for d in clean['train']),allow_pitch=allow_pitch,local_items=local_items)
    result=predict_inventory(models,tuple(grid(d['input']) for d in clean['test']))
    result['supporting_families']=[COORDINATE_INVENTORY_FAMILY] if result['status']=='unique' else []
    return result


def validate_grouped_inventory(task,full,*,complete_only=False):
    from functools import partial
    return _validate_spatial_inventory(task,full,partial(infer_grouped_inventory,complete_only=complete_only))


def validate_coordinate_inventory(task,full,*,allow_pitch=True,local_items=True):
    from functools import partial
    return _validate_spatial_inventory(task,full,partial(infer_coordinate_inventory,allow_pitch=allow_pitch,local_items=local_items))

# Shared encode -> reason -> decode, not a call to the old cell-reasoning fitter.
from functools import lru_cache
from scene_kernel import (AbstractionSpec, AbstractView, EncodedSceneProgram,
                          CoordinateLayoutSpec, abstraction_reason_compatible)
from scene_kernel import _encoded_view_cached
ENCODED_SCENE_FAMILY='shared_scene_encoded_reasoning'


def abstraction_candidates(pairs):
    from cell_abstraction import Partition
    pairs=tuple(pairs);a=pairs[0][0];h,w=len(a),len(a[0])
    common=set.intersection(*({v for row in x for v in row} for x,y in pairs))
    parts=[Partition('separators',separator=s) for s in ('modal',*sorted(common))]
    parts.append(Partition('identical_runs'))
    for rh in range(1,h+1):
        if h%rh:continue
        for cw in range(1,w+1):
            if w%cw or rh*cw==1 or (h//rh)*(w//cw)>64:continue
            parts.extend((Partition('factor',rh,cw),Partition('count',h//rh,w//cw)))
    for part in dict.fromkeys(parts):
        for reducer in ('uniform','majority','mode','foreground'):
            for bg in ('modal',*sorted(common)) if reducer=='foreground' else (None,):
                yield AbstractionSpec('cells',part,reducer,bg)
    for bg,conn,rr,cr in product(('modal',*sorted(common)),(4,8),('low','center','high','overlap'),('low','center','high','overlap')):
        for rm,cm in product(('rank','pitch') if rr!='overlap' else ('rank',),('rank','pitch') if cr!='overlap' else ('rank',)):
            yield AbstractionSpec('coordinates',background_rule=bg,connectivity=conn,
                                  coordinates=CoordinateLayoutSpec(rr,cr,rm,cm))


@lru_cache(maxsize=256)
def _shared_logical_fit(pairs):
    # Exactly the native shared predicate/mask/paint/alignment compiler; no
    # whole-task attribute, completion, line or other legacy family fitter.
    return tuple(fit(pairs,selection=True))


def fit_encoded_scene(pairs,*,reasoning=True):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    same=all((len(a),len(a[0]))==(len(y),len(y[0])) for a,y in pairs)
    shrink=all(len(y)<=len(a) and len(y[0])<=len(a[0]) and len(y)*len(y[0])<len(a)*len(a[0]) for a,y in pairs)
    if not (same or shrink):return []
    mode='lift' if same else 'abstract';groups={}
    for encoder in abstraction_candidates(pairs):
        try:
            views=tuple(_encoded_view_cached(encoder,a) for a,y in pairs)
            if encoder.kind=='coordinates':
                # Keep the V95 witnessed-gap prior in every refit.
                if encoder.coordinates.row_metric=='pitch' and not any(sum(any(d for d in v.domains[r*len(v.symbols[0]):(r+1)*len(v.symbols[0])]) for r in range(len(v.symbols)))<len(v.symbols) for v in views):continue
                if encoder.coordinates.column_metric=='pitch' and not any(sum(any(v.domains[r*len(v.symbols[0])+c] for r in range(len(v.symbols))) for c in range(len(v.symbols[0])))<len(v.symbols[0]) for v in views):continue
            ys=tuple(v.target(y,mode) for v,(_,y) in zip(views,pairs))
            if any(len(y)>len(v.symbols) or len(y[0])>len(v.symbols[0]) for v,y in zip(views,ys)):continue
        except Inapplicable:continue
        logical=tuple((v.symbols,y) for v,y in zip(views,ys))
        key=(logical,tuple(v.metric_safe for v in views))
        groups.setdefault(key,[]).append((encoder,views))
    result=[]
    for (logical,_),aliases in groups.items():
        reasons=[None] if all(a==y for a,y in logical) else []
        if reasoning:reasons.extend(_shared_logical_fit(logical))
        for reason in reasons:
            # A representation-changing prefix must be needed in a supplied
            # example. Otherwise the same downstream program explains the task
            # directly, and contraction would be an unobserved extra operation.
            if reason is not None and not encoding_needed_in_fit(reason,pairs):continue
            if not all(abstraction_reason_compatible(v,reason) for v in aliases[0][1]):continue
            # The lossless input-domain pullback is checked for every alias above.
            # One shared logical replay suffices for aliases with identical symbols
            # and targets; this avoids rediscovering and repainting the same effects.
            representative=EncodedSceneProgram(aliases[0][0],mode,reason)
            if not all(representative.reason_view(v)==y for v,(_,y) in zip(aliases[0][1],logical)):continue
            result.extend(EncodedSceneProgram(encoder,mode,reason) for encoder,views in aliases)
    return list(dict.fromkeys(result))


def predict_encoded_scene(models,inputs):
    from runtime import joint_result
    groups={};invalid=0
    for p in models:
        key=tuple(p.predict(a) for a in inputs)
        if any(x is None for x in key):invalid+=1;continue
        support=groups.setdefault(key,[])
        if len(support)<20:support.append({'family':ENCODED_SCENE_FAMILY,'law':p.describe()})
    result=joint_result(groups,len(inputs))
    result.update({'joint_hypotheses_is_exact':True,
        'witness_predictions':[[[list(r) for r in a] for a in key] for key in list(groups)[:2]],
        'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
                 'description_limit_not_search_limit':20,'max_logical_sites':64}})
    return result


def infer_encoded_scene(task,*,reasoning=True):
    clean=public_task(task)
    models=fit_encoded_scene(((d['input'],d['output']) for d in clean['train']),reasoning=reasoning)
    return predict_encoded_scene(models,tuple(grid(d['input']) for d in clean['test']))


def validate_encoded_scene(task,full,*,reasoning=True):
    from functools import partial
    return _validate_spatial_inventory(task,full,partial(infer_encoded_scene,reasoning=reasoning))


@lru_cache(maxsize=1024)
def encoding_needed_in_fit(reason, pairs):
    """Declared simplicity prior, evaluated using fitting examples only.

    Not a proof of intent: this may withhold a valid encoded rule when the
    demonstrations do not distinguish it from the unencoded rule.
    """
    return any(reason.predict(a)!=y for a,y in pairs)


# V98 shared context compiler. This is the V97 broad context vocabulary expressed
# as a compiler for the shared scene representation/execution protocol.
from scene_kernel import ContextRewriteProgram, context_features, context_scene, _CONTEXT_KEEP

CONTEXT_FAMILY='shared_scene_context'
_CONTEXT_MAX_DEPTH=8


def _context_split_score(left: Counter,right: Counter):
    nl,nr=sum(left.values()),sum(right.values())
    if not nl or not nr:return 10**18
    return (nl-sum(v*v for v in left.values())/nl)+(nr-sum(v*v for v in right.values())/nr)


def _context_best(rows):
    total=Counter()
    for f,l,n in rows: total[l]+=n
    best=None; nfeat=len(rows[0][0])
    for j in range(nfeat):
        by=defaultdict(Counter)
        for f,l,n in rows: by[f[j]][l]+=n
        if len(by)<2: continue
        vals=sorted(by)
        if len(vals)<=12:
            for v in vals:
                score=_context_split_score(by[v],total-by[v]); cand=(score,0,j,v)
                if best is None or cand<best: best=cand
        left=Counter()
        for v in vals[:-1]:
            left+=by[v]; score=_context_split_score(left,total-left); cand=(score,1,j,v)
            if best is None or cand<best: best=cand
    return best


def _context_build(rows,depth):
    labels={l for f,l,n in rows}
    if len(labels)==1:return ('leaf',next(iter(labels)))
    if depth<=0:return None
    b=_context_best(rows)
    if b is None:return None
    _,kind,j,v=b
    if kind==0:
        left=[x for x in rows if x[0][j]==v]; right=[x for x in rows if x[0][j]!=v]
    else:
        left=[x for x in rows if x[0][j]<=v]; right=[x for x in rows if x[0][j]>v]
    if not left or not right:return None
    a=_context_build(left,depth-1); c=_context_build(right,depth-1)
    return ('node','eq' if kind==0 else 'le',j,v,a,c) if a is not None and c is not None else None


def _context_walk(tree,f):
    while tree[0]=='node':
        _,kind,j,v,a,b=tree; tree=a if ((f[j]==v) if kind=='eq' else (f[j]<=v)) else b
    return tree[1]


def _fit_context_variant(pairs,tier,mode):
    table=defaultdict(Counter); changed=False
    for a,y in pairs:
        try: scene=context_scene(a,'modal'); fs=context_features(scene,tier)
        except Inapplicable:return None
        for f,src,dst in zip(fs,(v for row in a for v in row),(v for row in y for v in row)):
            label=_CONTEXT_KEEP if mode=='keep' and src==dst else ('L',dst)
            table[f][label]+=1; changed |= src!=dst
    if not changed:return None
    rows=[]
    for f,cnt in table.items():
        if len(cnt)>1:return None
        (label,n),=cnt.items(); rows.append((f,label,n))
    tree=_context_build(rows,_CONTEXT_MAX_DEPTH)
    if tree is None:return None
    p=ContextRewriteProgram('modal',tier,mode,tree)
    if any(p.predict(a,_context_walk)!=y for a,y in pairs):return None
    return p


def fit_context(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if len(pairs)<2 or any(len(a)!=len(y) or len(a[0])!=len(y[0]) for a,y in pairs):return []
    novel=set()
    for a,y in pairs:
        source={v for row in a for v in row}
        novel.update(v for row in y for v in row if v not in source)
    if len(novel)>3:return []
    models=[]
    for tier,mode in ((1,'keep'),(1,'literal'),(2,'keep'),(2,'literal')):
        p=_fit_context_variant(pairs,tier,mode)
        if p is not None:models.append(p)
    return models


def infer_context(task):
    clean=public_task(task); models=fit_context((d['input'],d['output']) for d in clean['train'])
    inputs=tuple(grid(t['input']) for t in clean['test']); groups={}; invalid=0
    for model in models:
        ps=tuple(model.predict(a,_context_walk) for a in inputs)
        if any(p is None for p in ps): invalid+=1; continue
        groups.setdefault(ps,[]).append(model.describe())
        if len(groups)>=2: break
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'; chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':len(groups)<2,
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None} for i in range(len(inputs))],
            'supporting_families':[CONTEXT_FAMILY] if chosen else [],
            'supporting_laws':groups[chosen][:20] if chosen else [],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'shared_scene_interpreter':True}}


def validate_context(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']]; folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held], 'test':[{'input':demo['input']}]+clean['test']}
        r=infer_context(fold); ps=[d['prediction'] for d in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
                      'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
                      'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


# V99 shared wallpaper compiler: D4 transform -> 2D repetition -> optional
# alternating row/column reflection. Two grammar strata use the same program
# representation so a narrow, independently validated identity-base rule is not
# invalidated merely because the broader D4 grammar is ambiguous in a held fold.
from scene_kernel import WallpaperProgram

WALLPAPER_FAMILY='shared_scene_wallpaper'

def fit_wallpaper(pairs, grammar='d4'):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs): return []
    if grammar not in ('plain','identity','d4'): raise ValueError('unknown wallpaper grammar')
    from oriented_panels import orient
    codes=(0,) if grammar in ('plain','identity') else tuple(range(8))
    flips=((False,False),) if grammar=='plain' else tuple(product((False,True),repeat=2))
    models=[]
    for code in codes:
        ratios=[]; valid=True
        for a,y in pairs:
            b=orient(a,code); h,w=len(b),len(b[0]); oh,ow=len(y),len(y[0])
            if oh%h or ow%w:
                valid=False; break
            ratios.append((oh//h,ow//w))
        if not valid or len(set(ratios))!=1: continue
        kh,kw=ratios[0]
        if kh<1 or kw<1 or (kh,kw)==(1,1): continue
        for rf,cf in flips:
            p=WallpaperProgram(code,kh,kw,rf,cf)
            try:
                if all(p.predict(a)==y for a,y in pairs): models.append(p)
            except Inapplicable:
                continue
    return models


def infer_wallpaper(task, grammar='d4'):
    clean=public_task(task); models=fit_wallpaper(((d['input'],d['output']) for d in clean['train']),grammar)
    groups={}; invalid=0
    for model in models:
        try: predictions=tuple(model.predict(t['input']) for t in clean['test'])
        except Inapplicable:
            invalid+=1; continue
        groups.setdefault(predictions,[]).append(model.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':True,
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
                     for i in range(len(clean['test']))],
            'supporting_families':[f'{WALLPAPER_FAMILY}:{grammar}'] if chosen else [],
            'supporting_laws':groups[chosen][:20] if chosen else [],
            'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,
                     'grammar':grammar,'shared_scene_interpreter':True}}


def validate_wallpaper(task, full, grammar='d4'):
    clean=public_task(task)
    if full['status']!='unique': return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2: return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']]; folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer_wallpaper(fold,grammar); ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
                      'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
                      'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


# V100 shared structural-component compiler.  All variants use the same program
# representation and are evaluated together under output-consensus semantics.
from scene_kernel import (StructuralComponentProgram, structural_components,
    structural_component_features, structural_predicate_holds,
    structural_patch_pair_candidates)

STRUCTURAL_COMPONENT_FAMILY='shared_structural_components'
_STRUCT_NUM=('size','height','width','bbox_area','holes','endpoints','branch_nodes','maxdeg','mindeg')
_STRUCT_BOOL=('isolated','line','rectangle','touch_border')


def _fit_component_recolour(pairs):
    source=target=None; dataset=[]
    for a,y in pairs:
        if len(a)!=len(y) or len(a[0])!=len(y[0]): return []
        diffs=[(r,c,a[r][c],y[r][c]) for r in range(len(a)) for c in range(len(a[0])) if a[r][c]!=y[r][c]]
        if not diffs: return []
        changes={(u,v) for r,c,u,v in diffs}
        if len(changes)!=1: return []
        s,t=next(iter(changes))
        if source is None: source,target=s,t
        elif (source,target)!=(s,t): return []
        changed={(r,c) for r,c,u,v in diffs}; rows=[]
        for cells in structural_components(a,source):
            inter=set(cells)&changed
            if inter and inter!=set(cells): return []
            rows.append((structural_component_features(a,cells),bool(inter)))
        if not rows or not any(flag for f,flag in rows): return []
        dataset.extend(rows)
    if len({flag for f,flag in dataset})<2: return []
    predicates=[]
    for key in _STRUCT_BOOL:
        for value in (True,False):
            pred=(key,'eq',value)
            if all(structural_predicate_holds(f,pred)==flag for f,flag in dataset): predicates.append(pred)
    for key in _STRUCT_NUM:
        for value in sorted({f[key] for f,flag in dataset}):
            for op in ('eq','ge','le'):
                pred=(key,op,value)
                if all(structural_predicate_holds(f,pred)==flag for f,flag in dataset): predicates.append(pred)
    return [StructuralComponentProgram('component_recolour',(source,target,p)) for p in predicates]


def _fit_patch_transfer(pairs):
    per=[]
    for a,y in pairs:
        cs=structural_patch_pair_candidates(a,y)
        if len(cs)!=1: return []
        per.append(cs[0])
    sockets={c['socket_colour'] for c in per}
    if len(sockets)!=1: return []
    common=set(per[0]['valid_transforms'])
    for c in per[1:]: common &= set(c['valid_transforms'])
    if not common:return []
    return [StructuralComponentProgram('context_patch_transfer',(next(iter(sockets)),tuple(sorted(common))))]


def _fit_compact_symbols(pairs):
    models=[]; out_colours=set.union(*({v for row in y for v in row} for a,y in pairs))
    for bg in sorted(out_colours):
        for mark in sorted(out_colours-{bg}):
            p=StructuralComponentProgram('colour_count_orientation',(bg,mark))
            if all(p.predict(a)==y for a,y in pairs): models.append(p)
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    for bg in sorted(common):
        for source in sorted(common-{bg}):
            for arrow in sorted(common-{bg,source}):
                p=StructuralComponentProgram('arrow_adjacent_mirror',(bg,source,arrow))
                if all(p.predict(a)==y for a,y in pairs): models.append(p)
    return models


def fit_structural_components(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if len(pairs)<2 or not any(a!=y for a,y in pairs): return []
    models=[]
    models.extend(_fit_component_recolour(pairs))
    models.extend(_fit_patch_transfer(pairs))
    models.extend(_fit_compact_symbols(pairs))
    exact=[]
    for p in models:
        try:
            if all(p.predict(a)==y for a,y in pairs): exact.append(p)
        except (Inapplicable,ValueError): pass
    return list(dict.fromkeys(exact))


def infer_structural_components(task):
    clean=public_task(task); models=fit_structural_components((d['input'],d['output']) for d in clean['train'])
    groups={}; invalid=0
    for model in models:
        try: ps=tuple(model.predict(t['input']) for t in clean['test'])
        except (Inapplicable,ValueError): invalid+=1; continue
        if any(p is None for p in ps): invalid+=1; continue
        groups.setdefault(ps,[]).append(model.describe())
        if len(groups)>=2: break
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit'; chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':len(groups)<2,
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None}
                     for i in range(len(clean['test']))],
            'supporting_families':[STRUCTURAL_COMPONENT_FAMILY] if chosen else [],
            'supporting_laws':groups[chosen][:20] if chosen else [],
            'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'shared_scene_interpreter':True}}


def validate_structural_components(task,full):
    clean=public_task(task)
    if full['status']!='unique': return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2: return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']]; folds=[]
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
              'test':[{'input':demo['input']}]+clean['test']}
        r=infer_structural_components(fold); ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
                      'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
                      'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


# V101 shared relational-transport compiler. Four schemas share one program
# representation and output-consensus / held-demonstration validation policy.
from scene_kernel import (RelationalTransportProgram, relational_guide_candidates,
    relational_support_candidates, _rt_components, _rt_bbox,
    _DIHEDRAL_CLOSURE_GROUPS)
from itertools import permutations as _rt_permutations

RELATIONAL_TRANSPORT_FAMILY='shared_relational_transport'

def _fit_rt_dual_anchor(pairs):
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    models=[]
    for anchor in sorted(common):
        
        for policy in ('move','copy'):
            p=RelationalTransportProgram('dual_anchor',(anchor,),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models

def _rt_guide_params_from_input(a):
    a=grid(a); bg=Counter(v for row in a for v in row).most_common(1)[0][0]
    colours=sorted({v for row in a for v in row if v!=bg}); out=set()
    if len(colours)!=2:return out
    for guide in colours:
        payload=next(v for v in colours if v!=guide)
        gps=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==guide]
        if len(gps)<4:continue
        same_col=len({c for r,c in gps})==1; same_row=len({r for r,c in gps})==1
        if same_col==same_row:continue
        axis='v' if same_col else 'h'; coords=sorted(r if axis=='v' else c for r,c in gps)
        diffs=[coords[i+1]-coords[i] for i in range(len(coords)-1)]
        if not diffs or min(diffs)<=0 or len(set(diffs))!=1:continue
        step=diffs[0]; pcs=_rt_components(a,payload)
        if len(pcs)!=1:continue
        P=pcs[0]; r0,c0,r1,c1=_rt_bbox(P)
        if (r1-r0)%2 or (c1-c0)%2:continue
        cr,cc=(r0+r1)//2,(c0+c1)//2
        expected={(r,c) for r in range(r0,r1+1) for c in range(c0,c1+1) if (r,c)!=(cr,cc)}
        if set(P)!=expected or (cr,cc) not in gps:continue
        for sign in (-1,1):
            dr,dc=(sign*step,0) if axis=='v' else (0,sign*step)
            if (cr+dr,cc+dc) in gps:out.add((guide,payload,step,sign,(r1-r0+1,c1-c0+1)))
    return out

def _fit_rt_guide(pairs):
    candidates=None
    for a,y in pairs:
        here=_rt_guide_params_from_input(a)
        if not here:return []
        candidates=here if candidates is None else candidates&here
    models=[]
    for x in sorted(candidates or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('periodic_guide',tuple(x),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models

def _fit_rt_pivot(pairs):
    colour_sets=[]
    for a,y in pairs:
        try:bg=Counter(v for row in a for v in row).most_common(1)[0][0]
        except Exception:return []
        cols={v for row in a for v in row if v!=bg}
        if len(cols)!=3 or {v for row in y for v in row if v!=bg}!=cols:return []
        colour_sets.append(tuple(sorted(cols)))
    if len(set(colour_sets))!=1:return []
    models=[]
    for roles in _rt_permutations(colour_sets[0],3):
        
        for policy in ('move','copy'):
            p=RelationalTransportProgram('pivot_hinge',tuple(roles),'quarter_turn_tail',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models

def _rt_support_params_from_input(a):
    a=grid(a); H,W=len(a),len(a[0]); bg=Counter(v for row in a for v in row).most_common(1)[0][0]
    colours=sorted({v for row in a for v in row if v!=bg}); out=set()
    for payload in colours:
        src=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==payload]
        if not src:continue
        r0,c0=src[0]
        for support in colours:
            if support==payload:continue
            support_cells=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==support]
            for tr,tc in support_cells:
                dr,dc=tr-r0,tc-c0
                if (dr==0)==(dc==0):continue
                sr=0 if dr==0 else (1 if dr>0 else -1); sc=0 if dc==0 else (1 if dc>0 else -1)
                ok=True
                for r,c in src:
                    rr,cc=r+dr,c+dc
                    if not(0<=rr<H and 0<=cc<W) or a[rr][cc]!=support:ok=False;break
                    x,y=r+sr,c+sc
                    while (x,y)!=(rr,cc):
                        if a[x][y]!=support:ok=False;break
                        x+=sr;y+=sc
                    if not ok:break
                if ok:out.add((bg,payload,support,dr,dc))
    return out

def _fit_rt_support(pairs):
    common=None
    for a,y in pairs:
        here=_rt_support_params_from_input(a)
        if not here:return []
        common=here if common is None else common&here
    models=[]
    for x in sorted(common or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('support_path',tuple(x),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models


def _rt_homologous_params_from_input(a):
    """Enumerate graph/topology role bindings without looking at the output."""
    a=grid(a);bg=Counter(v for row in a for v in row).most_common(1)[0][0]
    colours=sorted({v for row in a for v in row if v!=bg});out=set()
    for reference in colours:
        refs=_rt_components(a,reference)
        if len(refs)!=2:continue
        # shape equivalence is translation invariant
        def norm(cells):
            r0=min(r for r,c in cells);c0=min(c for r,c in cells)
            return tuple(sorted((r-r0,c-c0) for r,c in cells))
        if norm(refs[0])!=norm(refs[1]):continue
        for payload in colours:
            if payload==reference:continue
            pcs=_rt_components(a,payload)
            if len(pcs)!=1:continue
            P=pcs[0]
            for connectivity in (4,8):
                steps=((1,0),(-1,0),(0,1),(0,-1)) if connectivity==4 else tuple(
                    (dr,dc) for dr in (-1,0,1) for dc in (-1,0,1) if (dr,dc)!=(0,0))
                touched=[]
                PS=set(P)
                for i,R in enumerate(refs):
                    RS=set(R)
                    if any((r+dr,c+dc) in RS for r,c in PS for dr,dc in steps):touched.append(i)
                if len(touched)==1:out.add((reference,payload,connectivity))
    return out


def _fit_rt_homologous_reference(pairs):
    common=None
    for a,y in pairs:
        here=_rt_homologous_params_from_input(a)
        if not here:return []
        common=here if common is None else common&here
    models=[]
    for x in sorted(common or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('homologous_reference',tuple(x),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models



def _rt_homologous_set_params_from_input(a):
    """Enumerate multi-node homologous-reference bindings using only input structure."""
    a=grid(a);bg=Counter(v for row in a for v in row).most_common(1)[0][0]
    colours=sorted({v for row in a for v in row if v!=bg});out=set()
    for reference in colours:
        refs=_rt_components(a,reference)
        if len(refs)<3:continue
        def norm(cells):
            r0=min(r for r,c in cells);c0=min(c for r,c in cells)
            return tuple(sorted((r-r0,c-c0) for r,c in cells))
        if len({norm(R) for R in refs})!=1:continue
        for payload in colours:
            if payload==reference:continue
            pcs=_rt_components(a,payload)
            if len(pcs)!=1:continue
            P=pcs[0]
            for connectivity in (4,8):
                steps=((1,0),(-1,0),(0,1),(0,-1)) if connectivity==4 else tuple(
                    (dr,dc) for dr in (-1,0,1) for dc in (-1,0,1) if (dr,dc)!=(0,0))
                touched=[];PS=set(P)
                for i,R in enumerate(refs):
                    RS=set(R)
                    if any((r+dr,c+dc) in RS for r,c in PS for dr,dc in steps):touched.append(i)
                if len(touched)==1:out.add((reference,payload,connectivity,3))
    return out


def _fit_rt_homologous_reference_set(pairs):
    common=None
    for a,y in pairs:
        here=_rt_homologous_set_params_from_input(a)
        if not here:return []
        common=here if common is None else common&here
    models=[]
    for x in sorted(common or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('homologous_reference_set',tuple(x),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models


def _rt_graph_role_params_from_input(a, bind_relation, minimum_references=2):
    """Enumerate role bindings for a typed component-graph relation using input only."""
    from scene_kernel import component_relation_graph
    a=grid(a);graph=component_relation_graph(a,4);bg=graph.background;out=set()
    colours=sorted({n.colour for n in graph.nodes if n.colour!=bg})
    for reference in colours:
        refs=[n for n in graph.nodes if n.colour==reference]
        if len(refs)<minimum_references or len({n.shape for n in refs})!=1:continue
        for payload in colours:
            if payload==reference:continue
            pays=[n for n in graph.nodes if n.colour==payload]
            if len(pays)!=1:continue
            P=pays[0]
            bound=[n for n in refs if bind_relation in graph.relations(n.index,P.index)]
            if len(bound)==1:out.add((reference,payload,minimum_references))
    return out


def _fit_rt_contained_reference_set(pairs):
    common=None
    for a,y in pairs:
        here=_rt_graph_role_params_from_input(a,'contains',2)
        if not here:return []
        common=here if common is None else common&here
    models=[]
    for x in sorted(common or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('contained_reference_set',tuple(x),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models


def _fit_rt_aligned_reference_set(pairs):
    candidates=None
    for a,y in pairs:
        here=set()
        for axis,relation in (('row','aligned_row_center'),('col','aligned_col_center')):
            for reference,payload,minimum in _rt_graph_role_params_from_input(a,relation,2):
                here.add((reference,payload,axis,minimum))
        if not here:return []
        candidates=here if candidates is None else candidates&here
    models=[]
    for reference,payload,axis,minimum in sorted(candidates or set(),key=repr):
        for policy in ('move','copy'):
            p=RelationalTransportProgram('aligned_reference_set',(reference,payload,axis,minimum),'translate',policy)
            try:
                if all(p.predict(a)==y for a,y in pairs):models.append(p)
            except (Inapplicable,ValueError):pass
    return models

def _rt_dihedral_completion_params_from_input(a):
    """Enumerate valid symmetry closures from the input only."""
    out=set()
    for closure in sorted(_DIHEDRAL_CLOSURE_GROUPS):
        p=RelationalTransportProgram('dihedral_completion',(closure,),
                                     'dihedral_closure','copy')
        try:
            if p.predict(a) is not None:out.add((closure,))
        except (Inapplicable,ValueError,IndexError):
            continue
    return out


def _fit_rt_dihedral_completion(pairs):
    common=None
    for a,y in pairs:
        here=_rt_dihedral_completion_params_from_input(a)
        if not here:return []
        common=here if common is None else common&here
    models=[]
    for parameters in sorted(common or set(),key=repr):
        p=RelationalTransportProgram('dihedral_completion',tuple(parameters),
                                     'dihedral_closure','copy')
        try:
            if all(p.predict(a)==y for a,y in pairs):models.append(p)
        except (Inapplicable,ValueError,IndexError):
            pass
    # Maximum-invariance prior: when several subgroup closures explain every
    # demonstration, retain the largest consistent symmetry group.  This is a
    # training-only structural preference and removes under-completed solutions.
    if models:
        order=max(len(_DIHEDRAL_CLOSURE_GROUPS[m.parameters[0]]) for m in models)
        models=[m for m in models if len(_DIHEDRAL_CLOSURE_GROUPS[m.parameters[0]])==order]
    return models


RELATIONAL_TRANSPORT_FITTERS = {}


def register_relational_transport_fitter(relation, fitter):
    if not relation or not callable(fitter):
        raise ValueError('relational transport fitter requires relation and callable')
    RELATIONAL_TRANSPORT_FITTERS[str(relation)] = fitter
    return fitter


register_relational_transport_fitter('dual_anchor', _fit_rt_dual_anchor)
register_relational_transport_fitter('periodic_guide', _fit_rt_guide)
register_relational_transport_fitter('pivot_hinge', _fit_rt_pivot)
register_relational_transport_fitter('support_path', _fit_rt_support)
register_relational_transport_fitter('homologous_reference', _fit_rt_homologous_reference)
register_relational_transport_fitter('homologous_reference_set', _fit_rt_homologous_reference_set)
register_relational_transport_fitter('contained_reference_set', _fit_rt_contained_reference_set)
register_relational_transport_fitter('aligned_reference_set', _fit_rt_aligned_reference_set)
register_relational_transport_fitter('dihedral_completion', _fit_rt_dihedral_completion)


def fit_relational_transport(pairs, *, minimum_pairs=2, allowed_relations=None):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if len(pairs)<minimum_pairs or any(len(a)!=len(y) or len(a[0])!=len(y[0]) for a,y in pairs) or not any(a!=y for a,y in pairs):return []
    selected=set(allowed_relations) if allowed_relations is not None else set(RELATIONAL_TRANSPORT_FITTERS)
    models=[]
    for relation in sorted(selected & set(RELATIONAL_TRANSPORT_FITTERS)):
        try:
            models.extend(RELATIONAL_TRANSPORT_FITTERS[relation](pairs))
        except (Inapplicable, ValueError, IndexError):
            # A relation family that cannot establish a stable input abstraction
            # is simply inapplicable to this task; it must not abort the full corpus.
            continue
    exact=[]
    for p in models:
        try:
            if all(p.predict(a)==y for a,y in pairs):exact.append(p)
        except (Inapplicable,ValueError):pass
    return list(dict.fromkeys(exact))

def infer_relational_transport(task, *, minimum_pairs=2, allowed_relations=None):
    clean=public_task(task);models=fit_relational_transport(
        ((d['input'],d['output']) for d in clean['train']),
        minimum_pairs=minimum_pairs,allowed_relations=allowed_relations)
    groups={};invalid=0
    for model in models:
        try:ps=tuple(model.predict(t['input']) for t in clean['test'])
        except (Inapplicable,ValueError):invalid+=1;continue
        if any(p is None for p in ps):invalid+=1;continue
        groups.setdefault(ps,[]).append(model.describe())
        if len(groups)>=2:break
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit';chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':len(groups)<2,
            'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None} for i in range(len(clean['test']))],
            'supporting_families':[RELATIONAL_TRANSPORT_FAMILY] if chosen else [],
            'supporting_laws':groups[chosen][:20] if chosen else [],
            'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
            'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'shared_scene_interpreter':True}}

def validate_relational_transport(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    selected_relations=tuple(sorted({law.get('relation') for law in full.get('supporting_laws',()) if law.get('relation')}))
    for held,demo in enumerate(clean['train']):
        fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],'test':[{'input':demo['input']}]+clean['test']}
        # A two-demonstration task leaves one example in a fold.  Restrict that
        # fold to the family selected by the full training set, but refit every
        # parameter from the remaining example.  Normal public inference still
        # requires two demonstrations.
        r=infer_relational_transport(fold,minimum_pairs=1,allowed_relations=selected_relations)
        ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
                      'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}
