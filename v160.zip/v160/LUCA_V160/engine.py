"""LUCA V160: four equivariant family rewrites over the validated registry.

The direct consensus, ordered no-fit fallbacks, and staged qualified evidence
are intentionally preserved. There is no recursive chain of old engine versions.
`infer_bundle` exposes current evidence rather than nested historical bundles.
"""
from __future__ import annotations
from dataclasses import dataclass
from functools import partial
from typing import Callable
import copy
import math
import time

import geometry
import placement
import dimension_induction
import single_relation
import group_relation
import correspondence
import pattern_completion
import composition
import colour_panels
import oriented_panels
import spatial
import attributes
import attribute_selection
import relational_selection
import frame_content
import cell_abstraction
import cell_reasoning
import pattern_lifting
import reference_patterns
import region_geometry
import stable_transport
import rigid_transport
import object_alignment
import scene_programs
import spinoza_reasoning
import common_notion_reasoning
import causal_trigger_reasoning
import trigger_action_reasoning
import analogy_reasoning
import operator_induction_reasoning
import instructional_transfer_reasoning
import graph_bound_transfer_reasoning
import transformational_graph_reasoning
import relation_chain_reasoning
import relational_projection_reasoning
import counterfactual_query_reasoning
import quantified_relation_reasoning
import selector_algebra_reasoning
import learned_feature_reasoning
import relation_vocabulary_reasoning
import expansion_grammar_reasoning
import generative_expansion_reasoning
import recursive_expansion_reasoning
import composable_recursive_reasoning
import compositional_primitive_algebra
import anti_unified_composition_reasoning
import multi_stage_composition_reasoning
import learned_stage_algebra
import instruction_relation_stage_algebra
import relational_completion_projection_reasoning
import relational_completion_algebra
import completion_primitives_reasoning
import transfer_cover_algebra_reasoning
import boundary_graph_composition_reasoning
import dynamic_graph_constructor_reasoning
import graph_constructor_grammar_reasoning
import learned_constructor_proof_search_reasoning
import reusable_node_edge_proof_search_reasoning
import anti_unified_node_edge_composition_reasoning
import parameterised_node_edge_relation_chain_reasoning
import primitive_anti_unification_relation_search_reasoning
import learned_primitive_graph_grammar_reasoning
import anti_unified_extractor_transfer_composition_reasoning
import reference_frame_extraction_transfer_reasoning
import ordered_reference_graph_extraction_reasoning
import learned_order_graph_sequence_composition_reasoning
import ordered_phase_recolour_reasoning
import rectangle_coordinate_field_reasoning
import rectangle_coordinate_algebra_reasoning
import normalised_region_coordinate_reasoning
import d4_frame_coordinate_reasoning
import guide_extent_coordinate_reasoning
import anchor_relative_stencil_reasoning
import anchor_relative_transport_reasoning
import self_measured_extent_transport_reasoning
import anchor_destination_ownership_reasoning
import equivariant_family_rewrite_reasoning
from runtime import public_task, time_limit, FamilyTimeout, describe, joint_result, run_checked
from evidence import Evidence, reconcile


@dataclass(frozen=True)
class Family:
    name: str
    infer: Callable
    validate: Callable
    timeout_key: str


# Ordered exactly as the prior current-runtime dependency chain, not score sorted.
DIRECT = (
    ('geometry_v42', geometry.fit),
    ('pattern_orbit_v63', pattern_completion.fit),
    ('placement_v44', placement.fit),
    ('dimension_induction_v59', dimension_induction.infer),
    ('single_relation_v60', single_relation.fit),
    ('group_relation_v61', group_relation.fit),
    ('correspondence_v62', correspondence.fit),
)
CORE = (
    Family('composition', composition.infer, composition.validate_leave_one_out, 'composition_timeout'),
    Family('colour_panels', colour_panels.infer, colour_panels.validate_leave_one_out, 'panel_timeout'),
    Family('oriented_panels', oriented_panels.infer, oriented_panels.validate_leave_one_out, 'orientation_timeout'),
    Family('aligned_spatial', partial(spatial.infer_stratum, grammar='aligned'),
           partial(spatial.validate, grammar='aligned'), 'line_timeout'),
    Family('directed_spatial', partial(spatial.infer_stratum, grammar='directed'),
           partial(spatial.validate, grammar='directed'), 'stroke_timeout'),
    Family('object_attributes', attributes.infer, attributes.validate, 'attribute_timeout'),
    Family('attribute_selection', attribute_selection.infer, attribute_selection.validate, 'selection_timeout'),
    Family('relational_selection', relational_selection.infer, relational_selection.validate, 'relational_timeout'),
    Family('frame_content', frame_content.infer, frame_content.validate, 'frame_timeout'),
)
EXTENSIONS = (
    Family('cell_abstraction', cell_abstraction.infer, cell_abstraction.validate, 'cell_timeout'),
    Family('cell_reasoning', cell_reasoning.infer, cell_reasoning.validate, 'cell_reasoning_timeout'),
    Family('pattern_lifting', pattern_lifting.infer, pattern_lifting.validate, 'pattern_timeout'),
    Family('reference_patterns', reference_patterns.infer, reference_patterns.validate, 'reference_timeout'),
    Family('region_geometry', region_geometry.infer, region_geometry.validate, 'region_timeout'),
    Family('stable_transport', stable_transport.infer, stable_transport.validate, 'transport_timeout'),
    Family('rigid_transport', rigid_transport.infer, rigid_transport.validate, 'rigid_timeout'),
    Family('object_alignment', object_alignment.infer, object_alignment.validate, 'alignment_timeout'),
    # Stable evidence slot; implementation migrated to shared material language.
    Family('object_assembly', partial(scene_programs.infer_material, role_targets=True),
           partial(scene_programs.validate_material, role_targets=True), 'assembly_timeout'),
    Family('shared_scene_programs', scene_programs.infer, scene_programs.validate, 'scene_timeout'),
    Family('shared_scene_joint_edits', scene_programs.infer_joint, scene_programs.validate_joint, 'joint_timeout'),
    Family('shared_scene_relational_edits', partial(scene_programs.infer_joint, relations=True),
           partial(scene_programs.validate_joint, relations=True), 'relation_edit_timeout'),
    Family('shared_scene_placement', scene_programs.infer_placements, scene_programs.validate_placements, 'assignment_timeout'),
    Family('shared_scene_inventory', scene_programs.infer_inventory, scene_programs.validate_inventory, 'inventory_timeout'),
    Family('shared_scene_grid_inventory', scene_programs.infer_grid_inventory, scene_programs.validate_grid_inventory, 'grid_inventory_timeout'),
    Family('shared_scene_grouped_inventory', scene_programs.infer_grouped_inventory, scene_programs.validate_grouped_inventory, 'grouped_inventory_timeout'),
    Family('shared_scene_coordinate_inventory', scene_programs.infer_coordinate_inventory, scene_programs.validate_coordinate_inventory, 'coordinate_inventory_timeout'),
    Family('shared_scene_context', scene_programs.infer_context, scene_programs.validate_context, 'context_timeout'),
    Family('shared_scene_wallpaper_identity', partial(scene_programs.infer_wallpaper, grammar='identity'),
           partial(scene_programs.validate_wallpaper, grammar='identity'), 'wallpaper_identity_timeout'),
    Family('shared_scene_wallpaper_d4', partial(scene_programs.infer_wallpaper, grammar='d4'),
           partial(scene_programs.validate_wallpaper, grammar='d4'), 'wallpaper_d4_timeout'),
    Family('shared_structural_components', scene_programs.infer_structural_components,
           scene_programs.validate_structural_components, 'structural_component_timeout'),
    Family('shared_relational_transport', scene_programs.infer_relational_transport,
           scene_programs.validate_relational_transport, 'relational_transport_timeout'),
)
# The production registry remains byte-for-byte compatible with V102's 31-family
# contract.  Meta-reasoning families are active in V138 inference but live in a
# separate registry so historical code that depends on stable family positions
# continues to work.
RESEARCH_FAMILIES = (
    Family('spinoza_causal_composition', spinoza_reasoning.infer_spinoza,
           spinoza_reasoning.validate_spinoza, 'spinoza_timeout'),
    Family('spinoza_common_notion_extraction', common_notion_reasoning.infer_common_notion_extraction,
           common_notion_reasoning.validate_common_notion_extraction, 'common_notion_timeout'),
    Family('spinoza_causal_trigger_induction', causal_trigger_reasoning.infer_causal_trigger,
           causal_trigger_reasoning.validate_causal_trigger, 'causal_trigger_timeout'),
    Family('spinoza_trigger_action_composition', trigger_action_reasoning.infer_trigger_action,
           trigger_action_reasoning.validate_trigger_action, 'trigger_action_timeout'),
    Family('spinoza_analogy_proposition_composition', analogy_reasoning.infer_analogy,
           analogy_reasoning.validate_analogy, 'analogy_timeout'),
    Family('spinoza_relational_operator_induction', operator_induction_reasoning.infer_operator,
           operator_induction_reasoning.validate_operator, 'operator_induction_timeout'),
    Family('spinoza_instructional_operator_transfer', instructional_transfer_reasoning.infer_instructional_transfer,
           instructional_transfer_reasoning.validate_instructional_transfer, 'instructional_transfer_timeout'),
    Family('spinoza_graph_bound_instructional_transfer', graph_bound_transfer_reasoning.infer_graph_bound_transfer,
           graph_bound_transfer_reasoning.validate_graph_bound_transfer, 'graph_bound_transfer_timeout'),
    Family('spinoza_transformational_graph_propagation', transformational_graph_reasoning.infer_transformational_graph,
           transformational_graph_reasoning.validate_transformational_graph, 'transformational_graph_timeout'),
    Family('spinoza_relation_chain_graph_programmes', relation_chain_reasoning.infer_relation_chain,
           relation_chain_reasoning.validate_relation_chain, 'relation_chain_timeout'),
    Family('spinoza_relational_projection_algebra', relational_projection_reasoning.infer_relational_projection,
           relational_projection_reasoning.validate_relational_projection, 'relational_projection_timeout'),
    Family('spinoza_counterfactual_relational_query_composition', counterfactual_query_reasoning.infer_counterfactual_queries,
           counterfactual_query_reasoning.validate_counterfactual_queries, 'counterfactual_query_timeout'),
    Family('spinoza_unified_quantified_relation_algebra', quantified_relation_reasoning.infer_quantified_relations,
           quantified_relation_reasoning.validate_quantified_relations, 'quantified_relation_timeout'),
    Family('spinoza_general_counterfactual_selector_algebra', selector_algebra_reasoning.infer_selector_algebra,
           selector_algebra_reasoning.validate_selector_algebra, 'selector_algebra_timeout'),
    Family('spinoza_learned_counterfactual_feature_induction', learned_feature_reasoning.infer_learned_features,
           learned_feature_reasoning.validate_learned_features, 'learned_feature_timeout'),
    Family('spinoza_learned_relation_vocabulary', relation_vocabulary_reasoning.infer_relation_vocabulary,
           relation_vocabulary_reasoning.validate_relation_vocabulary, 'relation_vocabulary_timeout'),
    Family('spinoza_self_similar_expansion_grammar', expansion_grammar_reasoning.infer_expansion_grammar,
           expansion_grammar_reasoning.validate_expansion_grammar, 'expansion_grammar_timeout'),
    Family('spinoza_unified_generative_expansion_algebra', generative_expansion_reasoning.infer_generative_expansion,
           generative_expansion_reasoning.validate_generative_expansion, 'generative_expansion_timeout'),
    Family('spinoza_recursive_unified_generative_algebra', recursive_expansion_reasoning.infer_recursive_expansion,
           recursive_expansion_reasoning.validate_recursive_expansion, 'recursive_expansion_timeout'),
    Family('spinoza_composable_recursive_generative_primitives', composable_recursive_reasoning.infer_composable_recursive,
           composable_recursive_reasoning.validate_composable_recursive, 'composable_recursive_timeout'),
    Family('spinoza_compositional_primitive_algebra', compositional_primitive_algebra.infer_compositional_primitives,
           compositional_primitive_algebra.validate_compositional_primitives, 'compositional_primitive_timeout'),
    Family('spinoza_anti_unified_compositional_search', anti_unified_composition_reasoning.infer_anti_unified_composition,
           anti_unified_composition_reasoning.validate_anti_unified_composition, 'anti_unified_composition_timeout'),
    Family('spinoza_anti_unified_multi_stage_composition', multi_stage_composition_reasoning.infer_multi_stage_composition,
           multi_stage_composition_reasoning.validate_multi_stage_composition, 'multi_stage_composition_timeout'),
    Family('spinoza_learned_stage_algebra', learned_stage_algebra.infer_learned_stage_algebra,
           learned_stage_algebra.validate_learned_stage_algebra, 'learned_stage_algebra_timeout'),
    Family('spinoza_instruction_relation_stage_algebra', instruction_relation_stage_algebra.infer_instruction_relation_stage_algebra,
           instruction_relation_stage_algebra.validate_instruction_relation_stage_algebra, 'instruction_relation_stage_timeout'),
    Family('spinoza_relational_completion_projection_algebra', relational_completion_projection_reasoning.infer_relational_completion_projection,
           relational_completion_projection_reasoning.validate_relational_completion_projection, 'relational_completion_projection_timeout'),
    Family('spinoza_anti_unified_relational_completion_algebra', relational_completion_algebra.infer_relational_completion_algebra,
           relational_completion_algebra.validate_relational_completion_algebra, 'relational_completion_algebra_timeout'),
    Family('spinoza_anti_unified_completion_primitives', completion_primitives_reasoning.infer_completion_primitives,
           completion_primitives_reasoning.validate_completion_primitives, 'completion_primitives_timeout'),
    Family('spinoza_anti_unified_transfer_cover_algebra', transfer_cover_algebra_reasoning.infer_transfer_cover_algebra,
           transfer_cover_algebra_reasoning.validate_transfer_cover_algebra, 'transfer_cover_algebra_timeout'),
    Family('spinoza_boundary_graph_composition', boundary_graph_composition_reasoning.infer_boundary_graph_composition,
           boundary_graph_composition_reasoning.validate_boundary_graph_composition, 'boundary_graph_composition_timeout'),
    Family('spinoza_dynamic_graph_constructor_composition', dynamic_graph_constructor_reasoning.infer_dynamic_graph_constructor,
           dynamic_graph_constructor_reasoning.validate_dynamic_graph_constructor, 'dynamic_graph_constructor_timeout'),
    Family('spinoza_graph_constructor_grammar', graph_constructor_grammar_reasoning.infer_graph_constructor_grammar,
           graph_constructor_grammar_reasoning.validate_graph_constructor_grammar, 'graph_constructor_grammar_timeout'),
    Family('spinoza_learned_constructor_proof_search', learned_constructor_proof_search_reasoning.infer_learned_constructor_proof_search,
           learned_constructor_proof_search_reasoning.validate_learned_constructor_proof_search, 'learned_constructor_timeout'),
    Family('spinoza_reusable_node_edge_proof_search', reusable_node_edge_proof_search_reasoning.infer_reusable_node_edge_proof_search,
           reusable_node_edge_proof_search_reasoning.validate_reusable_node_edge_proof_search, 'reusable_node_edge_timeout'),
    Family('spinoza_anti_unified_node_edge_composition', anti_unified_node_edge_composition_reasoning.infer_anti_unified_node_edge_composition,
           anti_unified_node_edge_composition_reasoning.validate_anti_unified_node_edge_composition, 'anti_unified_node_edge_timeout'),
    Family('spinoza_parameterised_node_edge_relation_chains', parameterised_node_edge_relation_chain_reasoning.infer_parameterised_node_edge_relation_chains,
           parameterised_node_edge_relation_chain_reasoning.validate_parameterised_node_edge_relation_chains, 'parameterised_node_edge_timeout'),
    Family('spinoza_primitive_anti_unification_relation_search', primitive_anti_unification_relation_search_reasoning.infer_primitive_anti_unification_relation_search,
           primitive_anti_unification_relation_search_reasoning.validate_primitive_anti_unification_relation_search, 'primitive_anti_unification_timeout'),
    Family('spinoza_learned_primitive_graph_grammar', learned_primitive_graph_grammar_reasoning.infer_learned_primitive_graph_grammar,
           learned_primitive_graph_grammar_reasoning.validate_learned_primitive_graph_grammar, 'learned_primitive_graph_grammar_timeout'),
    Family('spinoza_anti_unified_extractor_transfer_composition', anti_unified_extractor_transfer_composition_reasoning.infer_anti_unified_extractor_transfer_composition,
           anti_unified_extractor_transfer_composition_reasoning.validate_anti_unified_extractor_transfer_composition, 'anti_unified_extractor_transfer_timeout'),
    Family('spinoza_reference_frame_extraction_transfer', reference_frame_extraction_transfer_reasoning.infer_reference_frame_extraction_transfer,
           reference_frame_extraction_transfer_reasoning.validate_reference_frame_extraction_transfer, 'reference_frame_extraction_transfer_timeout'),
    Family('spinoza_ordered_reference_graph_extraction', ordered_reference_graph_extraction_reasoning.infer_ordered_reference_graph_extraction,
           ordered_reference_graph_extraction_reasoning.validate_ordered_reference_graph_extraction, 'ordered_reference_graph_extraction_timeout'),
    Family('spinoza_learned_order_graph_sequence_composition', learned_order_graph_sequence_composition_reasoning.infer_learned_order_graph_sequence_composition,
           learned_order_graph_sequence_composition_reasoning.validate_learned_order_graph_sequence_composition, 'learned_order_graph_sequence_timeout'),
    Family('spinoza_ordered_phase_recolour', ordered_phase_recolour_reasoning.infer_ordered_phase_recolour,
           ordered_phase_recolour_reasoning.validate_ordered_phase_recolour, 'ordered_phase_recolour_timeout'),
    Family('spinoza_rectangle_coordinate_field', rectangle_coordinate_field_reasoning.infer_rectangle_coordinate_field,
           rectangle_coordinate_field_reasoning.validate_rectangle_coordinate_field, 'rectangle_coordinate_field_timeout'),
    Family('spinoza_rectangle_coordinate_algebra', rectangle_coordinate_algebra_reasoning.infer_rectangle_coordinate_algebra,
           rectangle_coordinate_algebra_reasoning.validate_rectangle_coordinate_algebra, 'rectangle_coordinate_algebra_timeout'),
    Family('spinoza_normalised_region_coordinate_grammar', normalised_region_coordinate_reasoning.infer_normalised_region_coordinate_grammar,
           normalised_region_coordinate_reasoning.validate_normalised_region_coordinate_grammar, 'normalised_region_coordinate_timeout'),
    Family('spinoza_d4_frame_coordinate_grammar', d4_frame_coordinate_reasoning.infer_d4_frame_coordinate_grammar,
           d4_frame_coordinate_reasoning.validate_d4_frame_coordinate_grammar, 'd4_frame_coordinate_timeout'),
    Family('spinoza_guide_extent_coordinate_projection', guide_extent_coordinate_reasoning.infer_guide_extent_coordinate_projection,
           guide_extent_coordinate_reasoning.validate_guide_extent_coordinate_projection, 'guide_extent_coordinate_timeout'),
    Family('spinoza_anchor_relative_stencil_materialisation', anchor_relative_stencil_reasoning.infer_anchor_relative_stencil_materialisation,
           anchor_relative_stencil_reasoning.validate_anchor_relative_stencil_materialisation, 'anchor_relative_stencil_timeout'),
    Family('spinoza_anchor_relative_transport_composition', anchor_relative_transport_reasoning.infer_anchor_relative_transport_composition,
           anchor_relative_transport_reasoning.validate_anchor_relative_transport_composition, 'anchor_relative_transport_timeout'),
    Family('spinoza_self_measured_extent_transport', self_measured_extent_transport_reasoning.infer_self_measured_extent_transport,
           self_measured_extent_transport_reasoning.validate_self_measured_extent_transport, 'self_measured_extent_transport_timeout'),
    Family('spinoza_anchor_destination_ownership', anchor_destination_ownership_reasoning.infer_anchor_destination_ownership,
           anchor_destination_ownership_reasoning.validate_anchor_destination_ownership, 'anchor_destination_ownership_timeout'),
    Family('spinoza_equivariant_anchor_transport_rewrite', equivariant_family_rewrite_reasoning.infer_equivariant_anchor_transport_rewrite,
           equivariant_family_rewrite_reasoning.validate_equivariant_anchor_transport_rewrite, 'equivariant_anchor_transport_timeout'),
    Family('spinoza_equivariant_transport_rewrite', equivariant_family_rewrite_reasoning.infer_equivariant_transport_rewrite,
           equivariant_family_rewrite_reasoning.validate_equivariant_transport_rewrite, 'equivariant_transport_timeout'),
    Family('spinoza_equivariant_ordered_phase_rewrite', equivariant_family_rewrite_reasoning.infer_equivariant_ordered_phase_rewrite,
           equivariant_family_rewrite_reasoning.validate_equivariant_ordered_phase_rewrite, 'equivariant_ordered_phase_timeout'),
    Family('spinoza_equivariant_reference_transfer_rewrite', equivariant_family_rewrite_reasoning.infer_equivariant_reference_transfer_rewrite,
           equivariant_family_rewrite_reasoning.validate_equivariant_reference_transfer_rewrite, 'equivariant_reference_transfer_timeout'),
)
FAMILIES = CORE + EXTENSIONS
ACTIVE_FAMILIES = FAMILIES + RESEARCH_FAMILIES
TIMEOUT_KEYS = ('family_timeout', 'validation_timeout') + tuple(
    dict.fromkeys(f.timeout_key for f in ACTIVE_FAMILIES)
)


def _limits(values: dict) -> dict:
    unknown = set(values) - set(TIMEOUT_KEYS)
    if unknown:
        raise TypeError('unknown timeout options: ' + ', '.join(sorted(unknown)))
    result = dict.fromkeys(TIMEOUT_KEYS, 0.0)
    for key, value in values.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError(key + ' must be a finite nonnegative number')
        result[key] = float(value)
    return result


def direct_infer(task: dict, family_timeout: float = 0) -> dict:
    """Seven native direct searches; one complete program per joint prediction."""
    demos = [(correspondence.grid(d['input']), correspondence.grid(d['output'])) for d in task['train']]
    inputs = [correspondence.grid(t['input']) for t in task['test']]
    outputs, union = {}, {}
    incomplete = False
    for name, fit in DIRECT:
        start = time.perf_counter()
        groups, laws, invalid, failure, error = {}, [], 0, None, None
        try:
            with time_limit(family_timeout):
                laws = fit(demos)
                for law in laws:
                    predictions = []
                    for value in inputs:
                        predicted = law.predict(value)
                        if predicted is None:
                            break
                        try:
                            predictions.append(correspondence.grid(predicted))
                        except ValueError:
                            break
                    if len(predictions) != len(inputs):
                        invalid += 1
                        continue
                    groups.setdefault(tuple(predictions), []).append({'family': name, 'law': describe(law)})
        except FamilyTimeout:
            failure, error = 'timeout', 'per-family safety timeout'
        except Exception as exc:
            failure, error = 'error', f'{type(exc).__name__}: {exc}'
        result = joint_result(groups, len(inputs), incomplete=failure is not None)
        result.update({'family': name, 'laws': len(laws), 'inapplicable_laws': invalid,
                       'runtime_seconds': time.perf_counter() - start, 'search_completed': failure is None})
        if failure:
            result.update({'status': failure, 'error': error})
            incomplete = True
        else:
            for key, support in groups.items():
                union.setdefault(key, []).extend(support)
        outputs[name] = result
    result = joint_result(union, len(inputs), incomplete)
    result['runtime_seconds'] = sum(r['runtime_seconds'] for r in outputs.values())
    return {'result': result, 'families': outputs}


def fallback(baseline: dict, candidate: dict, name: str) -> dict:
    """No-fit-only fallback used in the original core; other outcomes are binding."""
    use = baseline['status'] == 'no_fit'
    result = copy.deepcopy(candidate if use else baseline)
    if use:
        result['route'] = name
    result['runtime_seconds'] = baseline.get('runtime_seconds', 0) + (candidate.get('runtime_seconds', 0) if use else 0)
    return result


def assemble(direct: dict, registry: dict, *, demonstrations: int, test_count: int,
             families: tuple[Family, ...] = FAMILIES) -> dict:
    """Pure decision replay over a complete selected registry, with no hidden grading.

    The default is the stable 31-family production contract.  V136's full engine
    passes ACTIVE_FAMILIES explicitly, preserving backward compatibility while
    allowing the proof-carrying research layer to participate in inference.
    """
    expected_all = tuple(f.name for f in families)
    if set(registry) != set(expected_all):
        raise ValueError('complete current family registry required')
    current = copy.deepcopy(direct)
    stages = []
    for name in ('composition', 'colour_panels', 'oriented_panels'):
        current = fallback(current, registry[name]['validated'], name)
    # Both strata are searched, but directed reasoning is a core fallback only
    # after aligned no-fit. Later qualification can reconsider a complete abstention.
    aligned = registry['aligned_spatial']['validated']
    directed = registry['directed_spatial']['validated']
    chosen = aligned if aligned['status'] != 'no_fit' else directed
    current = fallback(current, chosen, 'spatial')
    for name in ('object_attributes', 'attribute_selection', 'relational_selection', 'frame_content'):
        current = fallback(current, registry[name]['validated'], name)
    names = tuple(f.name for f in CORE)
    entries = [Evidence(n, registry[n]['raw'], registry[n]['validated']) for n in names]
    current = reconcile(current, entries, expected=names,
                        demonstrations=demonstrations, test_count=test_count)
    stages.append({'stage': 'core_evidence', **copy.deepcopy(current.get('evidence', {}))})
    for family in families[len(CORE):]:
        names += (family.name,)
        pair = registry[family.name]
        entries.append(Evidence(family.name, pair['raw'], pair['validated']))
        current = reconcile(current, entries, expected=names, demonstrations=demonstrations,
                            test_count=test_count, candidate=pair['validated'])
        stages.append({'stage': family.name, **copy.deepcopy(current.get('evidence', {}))})
    current['route'] = 'staged_qualified_families'
    return {'result': current, 'decision_stages': stages}


def infer_bundle(task: dict, *, include_research: bool = True, **timeouts) -> dict:
    """Evaluate every current family once; return the result and auditable evidence.

    Input schema: nonempty train input/output pairs and test inputs. Additional
    fields, including IDs and test outputs, are discarded before any family call.
    External safety timers default to zero. Native finite grammars are unchanged.
    """
    clean = public_task(task)
    limits = _limits(timeouts)
    start = time.perf_counter()
    direct = direct_infer(clean, limits['family_timeout'])
    selected_families = ACTIVE_FAMILIES if include_research else FAMILIES
    registry = {}
    for family in selected_families:
        registry[family.name] = run_checked(clean, family.infer, family.validate,
            search_timeout=limits[family.timeout_key], validation_timeout=limits['validation_timeout'])
    result = assemble(direct['result'], registry, demonstrations=len(clean['train']),
                      test_count=len(clean['test']), families=selected_families)
    result['result']['runtime_seconds'] = time.perf_counter() - start
    return {**result, 'direct_result': direct['result'], 'direct_families': direct['families'], 'registry': registry,
            'metadata': {'version': 'V160 EQUIVARIANT FAMILY REWRITE', 'test_targets_used': False, 'task_ids_used': False,
                         'transformation_language_changed': True, 'native_assembly_fitter_replaced': True, 'validators_changed': True,
                         'proof_carrying_composition': True, 'causal_minimality_required': True,
                         'cross_task_common_notion_mining': True, 'program_anti_unification': True,
                         'component_attribute_extraction': True,
                         'causal_trigger_induction': True, 'counterfactual_trigger_validation': True,
                         'trigger_action_composition': True, 'shared_axis_segment_grammar': True,
                         'counterfactual_action_validation': True,
                         'analogy_proposition_composition': True, 'shared_panel_relation_grammar': True,
                         'boolean_relation_induction': True, 'structural_panel_selection': True,
                         'ordered_panel_overlay': True, 'counterfactual_analogy_validation': True,
                         'relational_operator_induction': True, 'spatial_quantity_algebra': True,
                         'sparse_sequence_continuation': True, 'midpoint_glyph_construction': True,
                         'signed_unary_bar_arithmetic': True, 'counterfactual_operator_validation': True,
                         'instructional_operator_transfer': True, 'shared_instructional_transfer_language': True,
                         'hole_shape_fill_transfer': True, 'priority_mask_transfer': True,
                         'whole_object_mask_gating': True, 'block_mode_compression': True,
                         'panel_sequence_extrapolation': True, 'counterfactual_instruction_validation': True,
                         'graph_bound_instructional_transfer': True, 'homologous_pattern_propagation': True,
                         'boundary_marker_orientation': True, 'counterfactual_graph_transfer_validation': True,
                         'transformational_graph_propagation': True, 'lattice_axis_connection': True,
                         'anchor_stencil_propagation': True, 'anchor_relative_stencil_materialisation': True,
                         'anchor_relative_transport_composition': True, 'quarter_turn_guide_transport': True,
                         'anchor_adjacent_compaction': True, 'lattice_cell_centring': True,
                         'self_measured_extent_transport': True, 'axis_extent_component_transport': True,
                         'boundary_rail_area_transport': True, 'payload_self_measurement': True,
                         'anchor_destination_ownership': True, 'marker_shell_compaction': True,
                         'equivariant_family_rewrite_suite': True,
                         'equivariant_anchor_transport_rewrite': True,
                         'equivariant_transport_rewrite': True,
                         'equivariant_ordered_phase_rewrite': True,
                         'equivariant_reference_transfer_rewrite': True,
                         'unit_step_toward_anchor': True,
                         'adjacent_pair_perpendicular_separation': True,
                         'diagonal_square_palette_propagation': True,
                         'partition_marker_majority_transfer': True,
                         'd4_colour_scale_count_equivariance': True,
                         'opposite_corner_extrusion': True, 'successor_corner_transport': True,
                         'd4_relative_anchor_roles': True, 'contained_exemplar_shape_colour_transfer': True,
                         'instructional_motif_completion': True, 'counterfactual_transformational_graph_validation': True,
                         'relation_chain_graph_programmes': True, 'compressed_shape_class_recolour': True,
                         'shape_legend_colour_transfer': True, 'hierarchical_motif_object_projection': True,
                         'matrix_object_grid_projection': True, 'counterfactual_relation_chain_validation': True,
                         'relational_projection_algebra': True, 'dominant_signal_component_crop': True,
                         'repeated_class_outlier_crop': True, 'ring_center_colour_query': True,
                         'holed_frame_colour_query': True, 'marker_context_majority_query': True,
                         'local_dihedral_orbit_completion': True, 'counterfactual_relational_projection_validation': True,
                         'counterfactual_relational_query_composition': True,
                         'uninterrupted_stripe_colour_query': True, 'bridge_connectivity_query': True,
                         'canvas_symmetry_codebook_query': True, 'unary_square_count_projection': True,
                         'frequency_ranked_block_colour_projection': True, 'colour_area_rank_projection': True,
                         'largest_frame_interior_projection': True, 'separator_growth_comparison_projection': True,
                         'paired_half_reversal': True, 'embedded_object_grid_projection': True,
                         'counterfactual_query_validation': True,
                         'unified_quantified_relation_algebra': True,
                         'component_feature_outlier_crop': True,
                         'modal_component_class_crop': True,
                         'component_extremum_colour_projection': True,
                         'quantified_relation_validation': True,
                         'general_counterfactual_selector_algebra': True,
                         'structured_region_selector_crop': True,
                         'separator_grid_dimension_projection': True,
                         'unary_foreground_cell_count_projection': True,
                         'counterfactual_selector_validation': True,
                         'learned_counterfactual_feature_induction': True,
                         'learned_component_feature_selector': True,
                         'lattice_cell_feature_selector': True,
                         'homologous_anchor_pair_window': True,
                         'dihedral_tile_seed_extraction': True,
                         'periodic_hole_recovery': True,
                         'held_exact_consensus_validation': True,
                         'learned_relation_vocabulary': True,
                         'fundamental_quadrant_projection': True,
                         'largest_closed_frame_interior': True,
                         'framed_pattern_outlier': True,
                         'instruction_bbox_frame_selector': True,
                         'relation_vocabulary_counterfactual_validation': True,
                         'anti_unified_compositional_search': True,
                         'embedded_marker_object_repair': True,
                         'nested_palette_swap_crop': True,
                         'mask_role_inversion': True,
                         'semantic_colour_count_panel_selector': True,
                         'nearest_marker_colour_recolour': True,
                         'external_pair_codebook_recolour': True,
                         'anti_unified_counterfactual_validation': True,
                         'anti_unified_multi_stage_composition': True,
                         'concentric_palette_program': True,
                         'framed_reference_homology_recolour': True,
                         'cyclic_region_palette_rotation': True,
                         'cyclic_framed_motif_recolour': True,
                         'multi_stage_counterfactual_validation': True,
                         'learned_stage_algebra': True,
                         'witnessed_shape_codebook': True,
                         'self_colour_corner_group_selection': True,
                         'dotted_path_motif_selection': True,
                         'witnessed_codebook_validation': True,
                         'instruction_relation_stage_algebra': True,
                         'frame_size_fill_codebook': True,
                         'framed_payload_diagonal_duplication': True,
                         'symbolic_turn_path': True,
                         'four_way_object_cross': True,
                         'mask_kernel_colour_composition': True,
                         'instruction_relation_stage_counterfactual_validation': True,
                         'relational_completion_projection_algebra': True,
                         'component_feature_recolour': True,
                         'component_palette_swap': True,
                         'matching_border_pair_connection': True,
                         'lattice_cross_propagation': True,
                         'seed_region_flood_fill': True,
                         'separator_aligned_marker_recolour': True,
                         'object_frequency_staircase': True,
                         'object_quadrant_montage': True,
                         'frame_interior_extraction': True,
                         'largest_frame_marker_crop': True,
                         'frame_dimension_fill_codebook': True,
                         'bar_extrema_recolour': True,
                         'centre_payload_in_marker_box': True,
                         'component_bbox_completion': True,
                         'rigid_component_gravity_right': True,
                         'adjacent_marker_component_recolour': True,
                         'relational_completion_projection_counterfactual_validation': True,
                         'anti_unified_relational_completion_algebra': True,
                         'background_component_extrema_recolour': True,
                         'panel_priority_overlay': True,
                         'dominant_component_cleanup': True,
                         'exterior_boundary_projection': True,
                         'domino_halo_completion': True,
                         'colour_bbox_height_histogram': True,
                         'bbox_instruction_recolour': True,
                         'diagonal_orientation_frequency_recolour': True,
                         'relational_completion_algebra_counterfactual_validation': True,
                         'anti_unified_completion_primitives': True,
                         'frequency_tail_recolour': True,
                         'exact_cover_piece_decomposition': True,
                         'boundary_marker_projection': True,
                         'spatial_legend_object_recolour': True,
                         'scaled_pattern_colour_transfer': True,
                         'panel_template_occurrence_recolour': True,
                         'completion_primitives_counterfactual_validation': True,
                         'anti_unified_transfer_cover_algebra': True,
                         'scene_relation_operator_emitter_factorization': True,
                         'pairwise_legend_palette_involution': True,
                         'axis_legend_coordinate_projection': True,
                         'spatial_bin_legend_transfer': True,
                         'ordered_axis_class_recolour': True,
                         'full_separator_line_highlight': True,
                         'solid_rectangle_interior_fill': True,
                         'corner_seed_periodic_completion': True,
                         'shape_colour_dictionary_codec': True,
                         'transfer_cover_counterfactual_validation': True,
                         'boundary_graph_composition': True,
                         'role_ordered_manhattan_connector': True,
                         'paired_boundary_midpoint_connector': True,
                         'full_cross_marker_projection': True,
                         'colour_axis_projection': True,
                         'marker_voronoi_boundary_frames': True,
                         'marker_rectangle_grid_cover': True,
                         'nearest_corner_rectangle_cover': True,
                         'cross_operator_projection_cover_composition': True,
                         'boundary_graph_counterfactual_validation': True,
                         'dynamic_graph_constructor_composition': True,
                         'role_star_graph_connector': True,
                         'repeated_axis_spine': True,
                         'aligned_hollow_plus_graph': True,
                         'frame_centre_cross_projection': True,
                         'near_closed_frame_aperture_escape': True,
                         'diagonal_identical_object_connector': True,
                         'role_biased_chebyshev_connector': True,
                         'orthogonal_graph_path_emission': True,
                         'aperture_fill_escape_emission': True,
                         'diagonal_lattice_path_emission': True,
                         'dynamic_graph_counterfactual_validation': True,
                         'graph_constructor_grammar': True,
                         'separator_palette_broadcast': True,
                         'edge_motif_field_completion': True,
                         'diagonal_palette_nested_frame': True,
                         'corner_legend_quadrant_fill': True,
                         'frame_fill_preserve_marker_bbox': True,
                         'bulged_frame_symmetry_closure': True,
                         'strict_interior_rectangle_bridge': True,
                         'separator_overlap_complement_fill': True,
                         'periodic_field_emission': True,
                         'bounded_region_materialisation': True,
                         'interval_graph_cover_emission': True,
                         'graph_constructor_grammar_counterfactual_validation': True,
                         'learned_constructor_grammar': True,
                         'bounded_proof_search': True,
                         'component_region_materialisation': True,
                         'extremal_axis_emission': True,
                         'relational_structure_completion': True,
                         'learned_constructor_counterfactual_validation': True,
                         'reusable_node_edge_grammar': True,
                         'anti_unified_node_edge_composition': True,
                         'bounded_two_step_proof_search': True,
                         'shape_envelope_materialisation': True,
                         'node_edge_graph_emission': True,
                         'anchor_role_projection': True,
                         'reusable_node_edge_counterfactual_validation': True,
                         'parameterised_node_edge_relation_chains': True,
                         'dimension_parameterised_field_emission': True,
                         'periodic_phase_class_emission': True,
                         'rectilinear_marker_graph_materialisation': True,
                         'parameterised_node_edge_counterfactual_validation': True,
                         'primitive_anti_unification_relation_search': True,
                         'periodic_axis_continuation': True,
                         'rectilinear_relation_materialisation': True,
                         'bounded_two_step_relation_chain': True,
                         'anchored_periodic_evaluation_probe': True,
                         'primitive_anti_unification_counterfactual_validation': True,
                         'learned_primitive_graph_grammar': True,
                         'd4_diagonal_ray_emission': True,
                         'axis_role_projection': True,
                         'd4_orbit_materialisation': True,
                         'bounded_three_stage_relation_chain': True,
                         'learned_primitive_graph_counterfactual_validation': True,
                         'anti_unified_extractor_transfer_composition': True,
                         'boundary_conditioned_geometry_emission': True,
                         'instructional_structure_transfer': True,
                         'anti_unified_extractor_counterfactual_validation': True,
                         'reference_frame_extraction_transfer': True,
                         'reference_frame_alignment_orientation_selection': True,
                         'reference_frame_counterfactual_validation': True,
                         'ordered_reference_graph_extraction': True,
                         'ordered_reference_palette_emission': True,
                         'axis_precedence_and_occlusion_edges': True,
                         'ordered_reference_graph_counterfactual_validation': True,
                         'learned_order_graph_sequence_composition': True,
                         'ordered_sequence_frame_emission': True,
                         'ordered_structure_sequence_nodes': True,
                         'precedence_reference_and_selection_edges': True,
                         'learned_order_graph_sequence_counterfactual_validation': True,
                         'ordered_phase_recolour': True,
                         'ordered_congruent_units_and_directional_runs': True,
                         'successor_and_endpoint_phase_edges': True,
                         'ordered_phase_recolour_counterfactual_validation': True,
                         'rectangle_coordinate_field_materialisation': True,
                         'solid_monochrome_rectangle_nodes': True,
                         'normalised_rectangle_coordinate_and_area_rank_edges': True,
                         'rectangle_coordinate_field_counterfactual_validation': True,
                         'rectangle_coordinate_algebra_materialisation': True,
                         'solid_outline_and_enclosure_rectangle_nodes': True,
                         'border_distance_parity_and_enclosure_ownership_edges': True,
                         'rectangle_coordinate_algebra_counterfactual_validation': True,
                         'normalised_region_coordinate_grammar': True,
                         'normalised_region_coordinate_materialisation': True,
                         'connected_support_and_outline_region_nodes': True,
                         'normalised_axis_fraction_border_distance_and_colour_role_edges': True,
                         'normalised_region_coordinate_counterfactual_validation': True,
                         'd4_frame_coordinate_grammar': True,
                         'd4_frame_coordinate_materialisation': True,
                         'outline_square_rectangle_marker_and_rail_nodes': True,
                         'chebyshev_border_size_parity_enclosure_and_projection_edges': True,
                         'd4_frame_coordinate_counterfactual_validation': True,
                         'stable_registry_families': len(FAMILIES), 'active_registry_families': len(selected_families),
                         'research_families_enabled': include_research,
                         'priority_policy': 'direct consensus; ordered core; staged qualified reconciliation',
                         'within_task_validation_not_unseen_task_evaluation': True}}


def solve(task: dict, **timeouts) -> dict:
    """Return only the current solver result; use infer_bundle for full evidence."""
    return infer_bundle(task, **timeouts)['result']
