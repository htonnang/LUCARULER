"""V42 experimental reusable ARC grid transformations; independent of V38 and no task-ID routing.

A family law is accepted only when it exactly fits all supplied demonstrations and
its predicted test output is unambiguous.  These guards are necessary but not
sufficient evidence of generalization.
"""
from dataclasses import dataclass

from itertools import product

Grid = tuple[tuple[int, ...], ...]

def grid(x):
    a=tuple(tuple(int(v) for v in row) for row in x)
    if not a or not a[0] or any(len(row)!=len(a[0]) for row in a):
        raise ValueError('Non-rectangular/empty grid')
    return a

def rotate(a, n):
    for _ in range(n%4):
        a=tuple(tuple(a[len(a)-1-r][c] for r in range(len(a))) for c in range(len(a[0])))
    return a

def reflect(a, axis):
    if axis == 'horizontal':return tuple(row[::-1] for row in a)
    if axis == 'vertical':return a[::-1]
    return a

def crop(a, background):
    points=[(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v!=background]
    if not points:return a
    rs=[p[0] for p in points]; cs=[p[1] for p in points]
    return tuple(tuple(a[r][c] for c in range(min(cs),max(cs)+1)) for r in range(min(rs),max(rs)+1))

def scale(a, factor):
    if factor==1:return a
    return tuple(tuple(v for v in row for _ in range(factor)) for row in a for _ in range(factor))

def map_colors(a, mapping):
    return tuple(tuple(mapping.get(v,v) for v in row) for row in a)

@dataclass(frozen=True)
class Law:
    family: str
    rotations: int=0
    reflection: str='none'
    crop_background: int|None=None
    scale_factor: int=1
    color_mapping: tuple=()
    def predict(self, a):
        a=grid(a)
        if self.crop_background is not None: a=crop(a,self.crop_background)
        a=reflect(a,self.reflection)
        a=rotate(a,self.rotations)
        a=scale(a,self.scale_factor)
        return map_colors(a,dict(self.color_mapping))
    def name(self):
        p=[f'rotate={self.rotations}',f'reflect={self.reflection}',f'crop={self.crop_background}',f'scale={self.scale_factor}']
        if self.color_mapping:p.append(f'colors={self.color_mapping}')
        return self.family+'('+','.join(p)+')'

def infer_mapping(preds,truths):
    """Single global bijective mapping inferred from all demos (not per-example)."""
    mapping={};reverse={}
    for pred,true in zip(preds,truths):
        if len(pred)!=len(true) or len(pred[0])!=len(true[0]):return None
        for r in range(len(pred)):
            for c in range(len(pred[0])):
                p,t=pred[r][c],true[r][c]
                if p in mapping and mapping[p]!=t:return None
                if t in reverse and reverse[t]!=p:return None
                mapping[p]=t;reverse[t]=p
    return tuple(sorted(mapping.items()))

def fit(pairs, allow_colormap=True):
    """Discover reusable dihedral, crop, scaling and globally inferred color mapping laws."""
    pairs=[(grid(x),grid(y)) for x,y in pairs]
    if not pairs:return []
    backgrounds=[None]
    for color in range(10):
        if all(any(color in row for row in x) for x,_ in pairs):
            backgrounds.append(color)
    laws=[]; signatures=set()
    for bg,refl,rot,s in product(backgrounds,('none','horizontal'),range(4),(1,2,3,4)):
        if bg is not None and all(crop(x,bg)==x for x,_ in pairs):continue
        law=Law('relational_geometry',rot,refl,bg,s)
        shapes=[law.predict(x) for x,_ in pairs]
        if not all(len(a)==len(y) and len(a[0])==len(y[0]) for a,(_,y) in zip(shapes,pairs)):continue
        mapping=infer_mapping(shapes,[y for _,y in pairs]) if allow_colormap else ()
        if mapping is None:continue
        if not allow_colormap and any(a!=y for a,(_,y) in zip(shapes,pairs)):continue
        # Disallow gratuitous recoloring or identity mappings in the law name.
        mapping=tuple((a,b) for a,b in mapping if a!=b)
        candidate=Law('relational_geometry',rot,refl,bg,s,mapping)
        if any(candidate.predict(x)!=y for x,y in pairs):continue
        signature=(bg,refl,rot,s,mapping)
        if signature not in signatures:signatures.add(signature);laws.append(candidate)
    return laws


