"""V61 multi-object rigid group placement anchored to a singleton marker.
Infer a relation between the whole constellation and a marker from training examples.
All selected multi-cell components move together, preserving relative geometry.
Refuse out-of-bound moves, collisions, or uncertain predictions.
"""
from dataclasses import dataclass
from placement import components
from geometry import grid

@dataclass(frozen=True)
class MultiObjectLaw:
    bg: int
    marker: int
    connectivity: int
    offset_r: int
    offset_c: int
    erase: bool
    def predict(self, raw):
        a=grid(raw); h=len(a); w=len(a[0]); cc=components(a,self.bg,self.connectivity)
        markers=[o[0] for o in cc if len(o)==1 and a[o[0][0]][o[0][1]]==self.marker]
        objects=[o for o in cc if len(o)>1]
        if len(markers)!=1 or len(objects)<2:return None
        if any(any(a[r][c]==self.marker for r,c in o) for o in objects):return None
        cells={p for o in objects for p in o}; mr,mc=markers[0]
        origin_r=min(r for r,c in cells);origin_c=min(c for r,c in cells)
        dr=mr+self.offset_r-origin_r;dc=mc+self.offset_c-origin_c
        mapped={(r+dr,c+dc):(r,c) for r,c in cells}
        if len(mapped)!=len(cells):return None
        if any(not(0<=r<h and 0<=c<w) or (r,c) not in cells and a[r][c]!=self.bg for r,c in mapped):return None
        out=[list(row) for row in a]
        if self.erase:
            for r,c in cells:out[r][c]=self.bg
        for (r,c),(sr,sc) in mapped.items():out[r][c]=a[sr][sc]
        return grid(out)

def fit(pairs):
    pairs=[(grid(x),grid(y)) for x,y in pairs]
    if len(pairs)<2:return []
    possible=[]
    shared=set.intersection(*[{v for row in x for v in row} for x,y in pairs])
    for bg in sorted(shared):
        for marker in sorted(shared-{bg}):
            for conn in (4,8):
                offsets=[]
                for x,y in pairs:
                    if len(x)!=len(y) or len(x[0])!=len(y[0]):break
                    cc=components(x,bg,conn);objs=[o for o in cc if len(o)>1]
                    marks=[o[0] for o in cc if len(o)==1 and x[o[0][0]][o[0][1]]==marker]
                    if len(objs)<2 or len(marks)!=1:break
                    cells={p for o in objs for p in o}; mr,mc=marks[0]
                    if any(x[r][c]==marker for r,c in cells):break
                    r0=min(r for r,c in cells);c0=min(c for r,c in cells)
                    valid=set()
                    for tr in range(len(y)):
                        for tc in range(len(y[0])):
                            dr,dc=tr-r0,tc-c0
                            if all(0<=r+dr<len(y) and 0<=c+dc<len(y[0]) and y[r+dr][c+dc]==x[r][c] for r,c in cells):
                                valid.add((tr-mr,tc-mc))
                    if not valid:break
                    offsets.append(valid)
                else:
                    for drow,dcol in sorted(set.intersection(*offsets)):
                        for erase in (False,True):
                            law=MultiObjectLaw(bg,marker,conn,drow,dcol,erase)
                            if all(law.predict(x)==y for x,y in pairs):possible.append(law)
    return possible


