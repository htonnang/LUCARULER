"""LUCA V113: proof-carrying relational operator induction.

V113 learns reusable operators over spatial quantities rather than storing task
coordinates.  Three conservative schemas share one infer/validate boundary:

* ``sparse_sequence_continuation`` -- infer a collinear positional recurrence
  and a colour continuation law, then extend it to the canvas boundary;
* ``midpoint_glyph_construction`` -- bind two aligned endpoints and emit a
  canonical glyph at their midpoint;
* ``signed_unary_bar_arithmetic`` -- interpret aligned bar lengths as unary
  quantities, infer signed colour coefficients, and emit the result as a bar.

All inference receives demonstrations and test inputs only through
``runtime.public_task``.  Exact training fit is necessary but not sufficient:
programs must also survive leave-one-demonstration-out refitting, schema-specific
counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import reduce
from itertools import product
import json
import math
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_relational_operator_induction"
LANGUAGE = "spinoza_relational_operator_algebra_v1"
SCHEMA_VERSION = "operator_induction_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    ranked = counts.most_common()
    if not ranked:
        raise Inapplicable("empty grid")
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal colour")
    return ranked[0][0]


def _diff_cells(source: Grid, target: Grid):
    a, b = grid(source), grid(target)
    if _shape(a) != _shape(b):
        raise Inapplicable("operator requires shape preservation")
    return tuple(
        (r, c, a[r][c], b[r][c])
        for r in range(len(a))
        for c in range(len(a[0]))
        if a[r][c] != b[r][c]
    )


def _rotate90(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(row) for row in zip(*reversed(a)))


def _translate_grid(value: Grid, dr: int, dc: int, background: int) -> Grid:
    a = grid(value)
    h, w = _shape(a)
    out = [[background for _ in range(w)] for _ in range(h)]
    for r in range(h):
        for c in range(w):
            if a[r][c] == background:
                continue
            nr, nc = r + dr, c + dc
            if not (0 <= nr < h and 0 <= nc < w):
                raise Inapplicable("translation leaves canvas")
            if out[nr][nc] != background:
                raise Inapplicable("translation collision")
            out[nr][nc] = a[r][c]
    return tuple(tuple(row) for row in out)


# ---------------------------------------------------------------------------
# Schema I: sparse collinear examples -> positional recurrence -> continuation
# ---------------------------------------------------------------------------


def _line_analysis(value: Grid):
    a = grid(value)
    background = _unique_modal(a)
    points = [(r, c, a[r][c]) for r in range(len(a)) for c in range(len(a[0])) if a[r][c] != background]
    if len(points) < 2:
        raise Inapplicable("requires at least two sparse points")
    # Each occupied coordinate is treated as a point token.  Tokens may be
    # adjacent (for example, the first two terms of a sequence can have gap 1),
    # but the complete set must still lie on one ARC axis.
    positions = {(r, c) for r, c, _ in points}

    rows = {r for r, _, _ in points}
    cols = {c for _, c, _ in points}
    diag_main = {r - c for r, c, _ in points}
    diag_anti = {r + c for r, c, _ in points}
    if len(rows) == 1:
        axis = "horizontal"
        ordered = sorted(points, key=lambda item: item[1])
        scalar = lambda item: item[1]
        coord = lambda t, fixed=ordered[0][0]: (fixed, t)
        low, high = 0, len(a[0]) - 1
    elif len(cols) == 1:
        axis = "vertical"
        ordered = sorted(points, key=lambda item: item[0])
        scalar = lambda item: item[0]
        coord = lambda t, fixed=ordered[0][1]: (t, fixed)
        low, high = 0, len(a) - 1
    elif len(diag_main) == 1:
        axis = "diagonal_down_right"
        ordered = sorted(points, key=lambda item: item[0])
        offset = ordered[0][1] - ordered[0][0]
        scalar = lambda item: item[0]
        coord = lambda t, offset=offset: (t, t + offset)
        low = max(0, -offset)
        high = min(len(a) - 1, len(a[0]) - 1 - offset)
    elif len(diag_anti) == 1:
        axis = "diagonal_down_left"
        ordered = sorted(points, key=lambda item: item[0])
        total = ordered[0][0] + ordered[0][1]
        scalar = lambda item: item[0]
        coord = lambda t, total=total: (t, total - t)
        low = max(0, total - (len(a[0]) - 1))
        high = min(len(a) - 1, total)
    else:
        raise Inapplicable("points are not collinear on an ARC axis")
    values = tuple(scalar(item) for item in ordered)
    if len(set(values)) != len(values):
        raise Inapplicable("duplicate scalar positions")
    colours = tuple(item[2] for item in ordered)
    return {
        "background": background,
        "axis": axis,
        "ordered": tuple(ordered),
        "positions": values,
        "colours": colours,
        "coord": coord,
        "low": low,
        "high": high,
    }


@dataclass(frozen=True)
class SparseSequenceContinuationProgram:
    gap_delta: int
    extend_side: str
    colour_rule: str
    extension_colour: int | None = None
    kind: str = "sparse_sequence_continuation"

    @property
    def schema_key(self):
        return (self.kind, self.gap_delta, self.extend_side, self.colour_rule, self.extension_colour)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (abs(self.gap_delta), self.extend_side, self.colour_rule)

    def _ordered(self, analysis):
        positions = list(analysis["positions"])
        colours = list(analysis["colours"])
        if self.extend_side == "low":
            positions.reverse()
            colours.reverse()
        elif self.extend_side != "high":
            raise Inapplicable("unknown extension side")
        return positions, colours

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        analysis = _line_analysis(a)
        positions, colours = self._ordered(analysis)
        minimum_seed = 3 if self.colour_rule == "constant_extension" else 2
        if len(positions) < minimum_seed:
            raise Inapplicable("insufficient sequence seed")
        gaps = [abs(positions[index] - positions[index - 1]) for index in range(1, len(positions))]
        if not gaps or any(gap <= 0 for gap in gaps):
            raise Inapplicable("invalid seed gaps")
        # The observed seed itself must satisfy the same gap recurrence whenever
        # enough points are present to witness it.
        if len(gaps) >= 2 and any(gaps[index] - gaps[index - 1] != self.gap_delta for index in range(1, len(gaps))):
            raise Inapplicable("seed does not satisfy the inferred gap recurrence")
        out = _array(a)
        direction = 1 if self.extend_side == "high" else -1
        bound = analysis["high"] if direction > 0 else analysis["low"]
        current = positions[-1]
        current_gap = gaps[-1]
        additions = 0
        seed_colours = tuple(colours)
        while True:
            next_gap = current_gap + self.gap_delta
            if next_gap <= 0:
                raise Inapplicable("gap recurrence becomes nonpositive")
            candidate = current + direction * next_gap
            if (direction > 0 and candidate > bound) or (direction < 0 and candidate < bound):
                break
            r, c = analysis["coord"](candidate)
            if not (0 <= r < len(a) and 0 <= c < len(a[0])):
                break
            if out[r][c] != analysis["background"]:
                raise Inapplicable("sequence continuation collides")
            if self.colour_rule == "constant_extension":
                if self.extension_colour is None or self.extension_colour == analysis["background"]:
                    raise Inapplicable("invalid extension colour")
                colour = self.extension_colour
            elif self.colour_rule == "cycle_seed":
                colour = seed_colours[(len(seed_colours) + additions) % len(seed_colours)]
            else:
                raise Inapplicable("unknown colour recurrence")
            out[r][c] = colour
            additions += 1
            current = candidate
            current_gap = next_gap
        if additions == 0:
            raise Inapplicable("sequence has no continuation inside the canvas")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        analyses = [_line_analysis(source) for source, _ in pairs]
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "gap_delta": self.gap_delta,
                "extend_side": self.extend_side,
                "colour_rule": self.colour_rule,
                "extension_colour": self.extension_colour,
            },
            "definitions": [
                {"name": "SparseCollinearSeed", "type": "Grid -> OrderedPointSequence"},
                {"name": "GapRecurrence", "type": "IntegerSequence -> IntegerSequence"},
                {"name": "ColourContinuation", "type": "ColourSequence -> ColourSequence"},
            ],
            "axioms": [
                "foreground components are sparse singleton points on one ARC axis",
                "the same gap recurrence is used in every demonstration",
                "the continuation stops at the canvas boundary",
                "task IDs and test targets are excluded from inference",
            ],
            "propositions": [
                {"definition": "bind_sparse_collinear_seed", "parameters": {}},
                {"definition": "continue_gap_recurrence", "parameters": {"delta": self.gap_delta}},
                {"definition": "continue_colour_law", "parameters": {"rule": self.colour_rule}},
            ],
            "corollary": "ordered_seed -> inferred_recurrence -> boundary_completion",
            "adequacy": {
                "proof_carrying": True,
                "axes": [row["axis"] for row in analyses],
                "seed_steps": [
                    tuple(abs(row["positions"][i] - row["positions"][i - 1]) for i in range(1, len(row["positions"])))
                    for row in analyses
                ],
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Schema II: two aligned endpoints -> canonical midpoint glyph
# ---------------------------------------------------------------------------


def _midpoint_analysis(value: Grid):
    a = grid(value)
    background = _unique_modal(a)
    points = [(r, c, a[r][c]) for r in range(len(a)) for c in range(len(a[0])) if a[r][c] != background]
    if len(points) != 2 or points[0][2] != points[1][2]:
        raise Inapplicable("requires two same-colour singleton endpoints")
    (r1, c1, colour), (r2, c2, _) = points
    if r1 == r2:
        distance = abs(c2 - c1)
        orientation = "horizontal"
    elif c1 == c2:
        distance = abs(r2 - r1)
        orientation = "vertical"
    else:
        raise Inapplicable("endpoints are not axis-aligned")
    if distance < 4 or distance % 2:
        raise Inapplicable("midpoint must be integral and separated from endpoints")
    center = ((r1 + r2) // 2, (c1 + c2) // 2)
    return {
        "background": background,
        "endpoint_colour": colour,
        "points": tuple(points),
        "orientation": orientation,
        "distance": distance,
        "center": center,
    }


@dataclass(frozen=True)
class MidpointGlyphProgram:
    glyph_colour: int
    kind: str = "midpoint_glyph_construction"

    @property
    def schema_key(self):
        return (self.kind, self.glyph_colour, "plus_radius_1")

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.glyph_colour,)

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        analysis = _midpoint_analysis(a)
        if self.glyph_colour == analysis["background"]:
            raise Inapplicable("glyph colour equals background")
        cr, cc = analysis["center"]
        cells = ((cr, cc), (cr - 1, cc), (cr + 1, cc), (cr, cc - 1), (cr, cc + 1))
        out = _array(a)
        for r, c in cells:
            if not (0 <= r < len(a) and 0 <= c < len(a[0])):
                raise Inapplicable("midpoint glyph leaves canvas")
            if out[r][c] != analysis["background"]:
                raise Inapplicable("midpoint glyph collides with an endpoint")
            out[r][c] = self.glyph_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        analyses = [_midpoint_analysis(source) for source, _ in pairs]
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "glyph_colour": self.glyph_colour,
                "glyph": "plus_radius_1",
            },
            "definitions": [
                {"name": "AlignedEndpoints", "type": "Grid -> PointPair"},
                {"name": "Midpoint", "type": "PointPair -> Point"},
                {"name": "CanonicalPlus", "type": "Point x Colour -> GridEdit"},
            ],
            "axioms": [
                "two same-colour endpoints uniquely determine an axis and midpoint",
                "the midpoint glyph is independent of endpoint orientation",
                "the glyph does not overwrite existing foreground",
                "task IDs and test targets are excluded from inference",
            ],
            "propositions": [
                {"definition": "bind_aligned_endpoints", "parameters": {}},
                {"definition": "derive_midpoint", "parameters": {}},
                {"definition": "emit_plus_glyph", "parameters": {"colour": self.glyph_colour}},
            ],
            "corollary": "endpoint_relation -> midpoint_role -> canonical_glyph",
            "adequacy": {
                "proof_carrying": True,
                "orientations": [row["orientation"] for row in analyses],
                "distances": [row["distance"] for row in analyses],
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Schema III: aligned unary bars -> inferred signed arithmetic -> result bar
# ---------------------------------------------------------------------------


def _run(values: Sequence[int], background: int):
    indices = [index for index, value in enumerate(values) if value != background]
    if not indices:
        return None
    if indices != list(range(min(indices), max(indices) + 1)):
        raise Inapplicable("bar is not contiguous")
    colours = {values[index] for index in indices}
    if len(colours) != 1:
        raise Inapplicable("bar has multiple colours")
    return min(indices), max(indices), len(indices), next(iter(colours))


def _bar_scene(value: Grid, *, orientation: str | None = None, anchor: str | None = None, step: int | None = None):
    a = grid(value)
    h, w = _shape(a)
    background = _unique_modal(a)
    candidates = []
    if orientation in (None, "vertical"):
        bars = []
        for c in range(w):
            try:
                result = _run([a[r][c] for r in range(h)], background)
            except Inapplicable:
                bars = []
                break
            if result is not None:
                start, end, length, colour = result
                bars.append((c, start, end, length, colour))
        if bars:
            if sum(length for _, _, _, length, _ in bars) != sum(cell != background for row in a for cell in row):
                bars = []
        if len(bars) >= 2:
            for candidate_anchor in ("bottom", "top"):
                if anchor not in (None, candidate_anchor):
                    continue
                anchored = all((end == h - 1 if candidate_anchor == "bottom" else start == 0) for _, start, end, _, _ in bars)
                if not anchored:
                    continue
                coords = [row[0] for row in bars]
                gaps = [coords[i] - coords[i - 1] for i in range(1, len(coords))]
                if not gaps or len(set(gaps)) != 1 or gaps[0] <= 0:
                    continue
                if step is not None and gaps[0] != step:
                    continue
                candidates.append(("vertical", candidate_anchor, gaps[0], tuple(bars)))
    if orientation in (None, "horizontal"):
        bars = []
        for r in range(h):
            try:
                result = _run(list(a[r]), background)
            except Inapplicable:
                bars = []
                break
            if result is not None:
                start, end, length, colour = result
                bars.append((r, start, end, length, colour))
        if bars:
            if sum(length for _, _, _, length, _ in bars) != sum(cell != background for row in a for cell in row):
                bars = []
        if len(bars) >= 2:
            for candidate_anchor in ("right", "left"):
                if anchor not in (None, candidate_anchor):
                    continue
                anchored = all((end == w - 1 if candidate_anchor == "right" else start == 0) for _, start, end, _, _ in bars)
                if not anchored:
                    continue
                coords = [row[0] for row in bars]
                gaps = [coords[i] - coords[i - 1] for i in range(1, len(coords))]
                if not gaps or len(set(gaps)) != 1 or gaps[0] <= 0:
                    continue
                if step is not None and gaps[0] != step:
                    continue
                candidates.append(("horizontal", candidate_anchor, gaps[0], tuple(bars)))
    if len(candidates) != 1:
        raise Inapplicable("bar scene is absent or ambiguous")
    candidate_orientation, candidate_anchor, candidate_step, bars = candidates[0]
    return {
        "background": background,
        "orientation": candidate_orientation,
        "anchor": candidate_anchor,
        "step": candidate_step,
        "bars": bars,
        "height": h,
        "width": w,
    }


def _bar_sums(scene):
    sums = Counter()
    for _coord, _start, _end, length, colour in scene["bars"]:
        sums[colour] += length
    return sums


@dataclass(frozen=True)
class SignedUnaryBarArithmeticProgram:
    orientation: str
    anchor: str
    step: int
    extend_side: str
    output_colour: int
    coefficients: tuple[tuple[int, int], ...]
    kind: str = "signed_unary_bar_arithmetic"

    @property
    def coefficient_map(self):
        return dict(self.coefficients)

    @property
    def schema_key(self):
        return (
            self.kind,
            self.orientation,
            self.anchor,
            self.step,
            self.extend_side,
            self.output_colour,
            self.coefficients,
        )

    @property
    def description_length(self):
        return 6 + len(self.coefficients)

    @property
    def permissiveness_cost(self):
        return (sum(abs(value) for _, value in self.coefficients), len(self.coefficients))

    def _target_coord(self, scene):
        coordinates = [bar[0] for bar in scene["bars"]]
        if self.extend_side == "high":
            return max(coordinates) + self.step
        if self.extend_side == "low":
            return min(coordinates) - self.step
        raise Inapplicable("unknown bar extension side")

    def _result_length(self, scene):
        sums = _bar_sums(scene)
        coefficients = self.coefficient_map
        if not set(sums).issubset(coefficients):
            raise Inapplicable("bar colour vocabulary changed")
        result = sum(coefficients[colour] * sums.get(colour, 0) for colour in coefficients)
        if result <= 0:
            raise Inapplicable("signed unary result is nonpositive")
        limit = scene["height"] if self.orientation == "vertical" else scene["width"]
        if result > limit:
            raise Inapplicable("signed unary result exceeds canvas")
        return result

    def predict(self, value: Grid) -> Grid:
        a = grid(value)
        scene = _bar_scene(a, orientation=self.orientation, anchor=self.anchor, step=self.step)
        coordinate = self._target_coord(scene)
        limit = scene["width"] if self.orientation == "vertical" else scene["height"]
        if not 0 <= coordinate < limit:
            raise Inapplicable("result bar slot leaves canvas")
        length = self._result_length(scene)
        out = _array(a)
        if self.orientation == "vertical":
            rows = range(scene["height"] - length, scene["height"]) if self.anchor == "bottom" else range(length)
            for r in rows:
                if out[r][coordinate] != scene["background"]:
                    raise Inapplicable("result bar collides")
                out[r][coordinate] = self.output_colour
        else:
            cols = range(scene["width"] - length, scene["width"]) if self.anchor == "right" else range(length)
            for c in cols:
                if out[coordinate][c] != scene["background"]:
                    raise Inapplicable("result bar collides")
                out[coordinate][c] = self.output_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        scenes = [_bar_scene(source, orientation=self.orientation, anchor=self.anchor, step=self.step) for source, _ in pairs]
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "orientation": self.orientation,
                "anchor": self.anchor,
                "step": self.step,
                "extend_side": self.extend_side,
                "output_colour": self.output_colour,
                "coefficients": [[colour, coefficient] for colour, coefficient in self.coefficients],
            },
            "definitions": [
                {"name": "UnaryBar", "type": "LineSegment -> Integer"},
                {"name": "ColourCoefficient", "type": "Colour -> SignedInteger"},
                {"name": "SignedSum", "type": "Multiset[UnaryBar] -> Integer"},
            ],
            "axioms": [
                "bars are parallel, equally spaced, contiguous, and share one boundary anchor",
                "bar length is the represented quantity",
                "colour coefficients are constant across demonstrations",
                "task IDs and test targets are excluded from inference",
            ],
            "propositions": [
                {"definition": "measure_unary_bars", "parameters": {"orientation": self.orientation}},
                {"definition": "apply_signed_colour_coefficients", "parameters": {"coefficients": dict(self.coefficients)}},
                {"definition": "emit_result_bar", "parameters": {"colour": self.output_colour}},
            ],
            "corollary": "unary_quantities -> inferred_signed_operator -> geometric_result",
            "adequacy": {
                "proof_carrying": True,
                "bar_counts": [len(scene["bars"]) for scene in scenes],
                "quantity_vectors": [dict(_bar_sums(scene)) for scene in scenes],
                "description_length": self.description_length,
                "task_ids_used": False,
                "test_targets_used": False,
            },
        }


# ---------------------------------------------------------------------------
# Fitting and consensus
# ---------------------------------------------------------------------------


def _fit_sparse_sequence(pairs):
    constant_colours = None
    for source, target in pairs:
        try:
            analysis = _line_analysis(source)
            differences = _diff_cells(source, target)
        except Inapplicable:
            return []
        if not differences or any(before != analysis["background"] for _, _, before, _ in differences):
            return []
        colours = {after for _, _, _, after in differences}
        constant_colours = colours if constant_colours is None else constant_colours & colours
    candidates = []
    for delta in range(-2, 4):
        for side in ("high", "low"):
            for colour_rule in ("constant_extension", "cycle_seed"):
                extension_values = sorted(constant_colours or ()) if colour_rule == "constant_extension" else [None]
                for extension_colour in extension_values:
                    program = SparseSequenceContinuationProgram(delta, side, colour_rule, extension_colour)
                    try:
                        if all(program.predict(source) == grid(target) for source, target in pairs):
                            candidates.append(program)
                    except (Inapplicable, ValueError, IndexError, TypeError):
                        continue
    return candidates


def _fit_midpoint(pairs):
    colours = None
    for source, target in pairs:
        try:
            analysis = _midpoint_analysis(source)
            differences = _diff_cells(source, target)
        except Inapplicable:
            return []
        if len(differences) != 5 or any(before != analysis["background"] for _, _, before, _ in differences):
            return []
        current = {after for _, _, _, after in differences}
        if len(current) != 1:
            return []
        colours = current if colours is None else colours & current
    programs = []
    for colour in sorted(colours or ()):
        program = MidpointGlyphProgram(colour)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    return programs


def _added_bar(source, target, scene):
    differences = _diff_cells(source, target)
    if not differences or any(before != scene["background"] for _, _, before, _ in differences):
        raise Inapplicable("output does not add one clean bar")
    colours = {after for _, _, _, after in differences}
    if len(colours) != 1:
        raise Inapplicable("result bar has multiple colours")
    colour = next(iter(colours))
    if scene["orientation"] == "vertical":
        coordinates = {c for r, c, _, _ in differences}
        if len(coordinates) != 1:
            raise Inapplicable("result is not one vertical bar")
        coordinate = next(iter(coordinates))
        rows = sorted(r for r, _, _, _ in differences)
        if rows != list(range(min(rows), max(rows) + 1)):
            raise Inapplicable("result bar is not contiguous")
        if scene["anchor"] == "bottom" and max(rows) != scene["height"] - 1:
            raise Inapplicable("result bar anchor changed")
        if scene["anchor"] == "top" and min(rows) != 0:
            raise Inapplicable("result bar anchor changed")
        length = len(rows)
    else:
        coordinates = {r for r, c, _, _ in differences}
        if len(coordinates) != 1:
            raise Inapplicable("result is not one horizontal bar")
        coordinate = next(iter(coordinates))
        cols = sorted(c for _, c, _, _ in differences)
        if cols != list(range(min(cols), max(cols) + 1)):
            raise Inapplicable("result bar is not contiguous")
        if scene["anchor"] == "right" and max(cols) != scene["width"] - 1:
            raise Inapplicable("result bar anchor changed")
        if scene["anchor"] == "left" and min(cols) != 0:
            raise Inapplicable("result bar anchor changed")
        length = len(cols)
    existing = [bar[0] for bar in scene["bars"]]
    high = max(existing) + scene["step"]
    low = min(existing) - scene["step"]
    if coordinate == high:
        side = "high"
    elif coordinate == low:
        side = "low"
    else:
        raise Inapplicable("result bar is not in the next regular slot")
    return {"colour": colour, "length": length, "coordinate": coordinate, "side": side}


def _fit_bar_arithmetic(pairs):
    scenes = []
    additions = []
    for source, target in pairs:
        try:
            scene = _bar_scene(source)
            addition = _added_bar(source, target, scene)
        except Inapplicable:
            return []
        scenes.append(scene)
        additions.append(addition)
    orientation = {scene["orientation"] for scene in scenes}
    anchor = {scene["anchor"] for scene in scenes}
    step = {scene["step"] for scene in scenes}
    side = {row["side"] for row in additions}
    output_colour = {row["colour"] for row in additions}
    if any(len(values) != 1 for values in (orientation, anchor, step, side, output_colour)):
        return []
    colours = sorted(set().union(*(_bar_sums(scene).keys() for scene in scenes)))
    if not 1 <= len(colours) <= 4:
        return []
    programs = []
    for coefficients in product((-2, -1, 1, 2), repeat=len(colours)):
        if not any(value > 0 for value in coefficients):
            continue
        mapping = tuple(zip(colours, coefficients))
        program = SignedUnaryBarArithmeticProgram(
            next(iter(orientation)),
            next(iter(anchor)),
            next(iter(step)),
            next(iter(side)),
            next(iter(output_colour)),
            mapping,
        )
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    if not programs:
        return []
    minimum = min(program.permissiveness_cost for program in programs)
    return [program for program in programs if program.permissiveness_cost == minimum]


def _role_varies(program, pairs):
    if isinstance(program, SparseSequenceContinuationProgram):
        analyses = [_line_analysis(source) for source, _ in pairs]
        steps = [tuple(abs(row["positions"][i] - row["positions"][i - 1]) for i in range(1, len(row["positions"]))) for row in analyses]
        colours = [row["colours"] for row in analyses]
        return len({_serial(item) for item in steps}) >= 2 or len({_serial(item) for item in colours}) >= 2
    if isinstance(program, MidpointGlyphProgram):
        analyses = [_midpoint_analysis(source) for source, _ in pairs]
        return len({row["orientation"] for row in analyses}) >= 2 or len({row["distance"] for row in analyses}) >= 2
    if isinstance(program, SignedUnaryBarArithmeticProgram):
        scenes = [_bar_scene(source, orientation=program.orientation, anchor=program.anchor, step=program.step) for source, _ in pairs]
        vectors = [tuple(sorted(_bar_sums(scene).items())) for scene in scenes]
        return len(set(vectors)) >= 2 and len({len(scene["bars"]) for scene in scenes}) >= 2
    return False


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "sparse_sequence_continuation" in allowed:
        programs.extend(_fit_sparse_sequence(pairs))
    if allowed is None or "midpoint_glyph_construction" in allowed:
        programs.extend(_fit_midpoint(pairs))
    if allowed is None or "signed_unary_bar_arithmetic" in allowed:
        programs.extend(_fit_bar_arithmetic(pairs))
    return programs


def fit_operator_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(
        unique.values(),
        key=lambda program: (
            program.description_length,
            program.permissiveness_cost,
            repr(program.schema_key),
        ),
    )


def infer_operator(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_operator_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "operator_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "relational_operator_induction": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Program recovery, counterfactuals, and leave-one-demonstration-out validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    if kind == "sparse_sequence_continuation":
        return SparseSequenceContinuationProgram(
            int(parameters["gap_delta"]),
            str(parameters["extend_side"]),
            str(parameters["colour_rule"]),
            None if parameters.get("extension_colour") is None else int(parameters["extension_colour"]),
        )
    if kind == "midpoint_glyph_construction":
        return MidpointGlyphProgram(int(parameters["glyph_colour"]))
    if kind == "signed_unary_bar_arithmetic":
        return SignedUnaryBarArithmeticProgram(
            str(parameters["orientation"]),
            str(parameters["anchor"]),
            int(parameters["step"]),
            str(parameters["extend_side"]),
            int(parameters["output_colour"]),
            tuple((int(colour), int(coefficient)) for colour, coefficient in parameters["coefficients"]),
        )
    raise Inapplicable("unknown operator schema")


def _sequence_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        analysis = _line_analysis(source)
        original = program.predict(source)
        # Recolour seed tokens by a bijection.  Position recurrence must remain
        # unchanged; cycle-based continuations transform with the seed colours,
        # while a constant extension colour remains an independent instruction.
        palette = {cell for row in source for cell in row}
        seed_colours = sorted(set(analysis["colours"]))
        available = [colour for colour in range(10) if colour not in palette and colour != analysis["background"]]
        mapping = {}
        for offset, colour in enumerate(seed_colours):
            mapping[colour] = available[offset % len(available)] if available else (colour + 1) % 10
        recoloured_source = tuple(tuple(mapping.get(cell, cell) for cell in row) for row in grid(source))
        recoloured_expected = []
        input_positions = {(r, c) for r, c, _ in analysis["ordered"]}
        for r, row in enumerate(original):
            recoloured_expected.append(tuple(mapping.get(cell, cell) if (r, c) in input_positions or program.colour_rule == "cycle_seed" else cell for c, cell in enumerate(row)))
        try:
            recolour_equivariant = program.predict(recoloured_source) == tuple(recoloured_expected)
        except Inapplicable:
            recolour_equivariant = False
        # Removing one seed point must either invalidate the programme or alter
        # the predicted completion; the original effect cannot be decorative.
        ordered = list(analysis["ordered"])
        if len(ordered) <= 2:
            seed_necessary = True
        else:
            modified = _array(source)
            r, c, _ = ordered[len(ordered) // 2]
            modified[r][c] = analysis["background"]
            try:
                seed_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                seed_necessary = True
        rows.append({
            "demonstration": index,
            "seed_recolour_equivariant": recolour_equivariant,
            "seed_relation_necessary": seed_necessary,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(row["seed_recolour_equivariant"] and row["seed_relation_necessary"] for row in rows),
    }


def _midpoint_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        analysis = _midpoint_analysis(source)
        original = program.predict(source)
        # Endpoint order has no semantic effect.
        order_invariant = program.predict(source) == original
        # Translate the relation by one cell when the complete output remains in bounds.
        translated = False
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            try:
                moved_source = _translate_grid(source, dr, dc, analysis["background"])
                moved_expected = _translate_grid(original, dr, dc, analysis["background"])
                translated = program.predict(moved_source) == moved_expected
            except Inapplicable:
                continue
            if translated:
                break
        # Removing either endpoint must make the programme inapplicable.
        modified = _array(source)
        r, c, _ = analysis["points"][0]
        modified[r][c] = analysis["background"]
        try:
            program.predict(tuple(tuple(row) for row in modified))
            endpoint_necessary = False
        except Inapplicable:
            endpoint_necessary = True
        rows.append({
            "demonstration": index,
            "endpoint_order_invariant": order_invariant,
            "translation_equivariant": translated,
            "both_endpoints_necessary": endpoint_necessary,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(
            row["endpoint_order_invariant"]
            and row["translation_equivariant"]
            and row["both_endpoints_necessary"]
            for row in rows
        ),
    }


def _bar_counterfactuals(program, pairs):
    rows = []
    coefficients = program.coefficient_map
    for index, (source, _) in enumerate(pairs):
        scene = _bar_scene(source, orientation=program.orientation, anchor=program.anchor, step=program.step)
        original = program.predict(source)
        original_scene = _bar_scene(source, orientation=program.orientation, anchor=program.anchor, step=program.step)
        original_length = program._result_length(original_scene)
        # Reordering bar magnitudes across the regular slots must not change the
        # arithmetic result, only the instructional arrangement.
        bars = list(scene["bars"])
        reordered = _array(source)
        for r in range(scene["height"]):
            for c in range(scene["width"]):
                if reordered[r][c] != scene["background"]:
                    reordered[r][c] = scene["background"]
        reversed_payload = list(reversed([(bar[3], bar[4]) for bar in bars]))
        for coordinate, (length, colour) in zip([bar[0] for bar in bars], reversed_payload):
            if program.orientation == "vertical":
                rows_to_write = range(scene["height"] - length, scene["height"]) if program.anchor == "bottom" else range(length)
                for r in rows_to_write:
                    reordered[r][coordinate] = colour
            else:
                cols_to_write = range(scene["width"] - length, scene["width"]) if program.anchor == "right" else range(length)
                for c in cols_to_write:
                    reordered[coordinate][c] = colour
        try:
            reordered_scene = _bar_scene(tuple(tuple(row) for row in reordered), orientation=program.orientation, anchor=program.anchor, step=program.step)
            permutation_invariant = program._result_length(reordered_scene) == original_length
        except Inapplicable:
            permutation_invariant = False

        # Increase one bar by one cell where possible; the result must change by
        # exactly the signed coefficient of that bar colour.
        perturbation_respects_coefficient = False
        for coordinate, start, end, length, colour in bars:
            coefficient = coefficients[colour]
            changed = _array(source)
            if program.orientation == "vertical":
                candidate = start - 1 if program.anchor == "bottom" else end + 1
                if not 0 <= candidate < scene["height"] or changed[candidate][coordinate] != scene["background"]:
                    continue
                changed[candidate][coordinate] = colour
            else:
                candidate = start - 1 if program.anchor == "right" else end + 1
                if not 0 <= candidate < scene["width"] or changed[coordinate][candidate] != scene["background"]:
                    continue
                changed[coordinate][candidate] = colour
            try:
                changed_scene = _bar_scene(tuple(tuple(row) for row in changed), orientation=program.orientation, anchor=program.anchor, step=program.step)
                changed_length = program._result_length(changed_scene)
                perturbation_respects_coefficient = changed_length - original_length == coefficient
            except Inapplicable:
                perturbation_respects_coefficient = coefficient < 0 and original_length + coefficient <= 0
            if perturbation_respects_coefficient:
                break
        rows.append({
            "demonstration": index,
            "bar_order_invariant": permutation_invariant,
            "length_perturbation_matches_coefficient": perturbation_respects_coefficient,
        })
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": all(row["bar_order_invariant"] and row["length_perturbation_matches_coefficient"] for row in rows),
    }


def _counterfactual_validation(program, pairs):
    if isinstance(program, SparseSequenceContinuationProgram):
        return _sequence_counterfactuals(program, pairs)
    if isinstance(program, MidpointGlyphProgram):
        return _midpoint_counterfactuals(program, pairs)
    if isinstance(program, SignedUnaryBarArithmeticProgram):
        return _bar_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_operator(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    minimum_required = {
        "sparse_sequence_continuation": 2,
        "midpoint_glyph_construction": 2,
        "signed_unary_bar_arithmetic": 3,
    }
    if len(clean["train"]) < min(minimum_required[kind] for kind in allowed_kinds):
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_operator(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": (
            "passed"
            if passed
            else "leave_one_demonstration_out_failure"
            if not folds_passed
            else "causal_counterfactual_failure"
        ),
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def operator_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_operator_programs(pairs)}))


# Engine-compatible aliases.
infer = infer_operator
validate = validate_operator
