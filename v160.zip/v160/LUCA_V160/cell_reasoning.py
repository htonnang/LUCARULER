"""V76: ordered-cell abstraction -> existing reasoning law -> abstract/lifted output.

Finite program synthesis; training targets only constrain programs. The original
input supplies every cell boundary, including variable-width separators. Lift is
injective on the macro grid, so factorized ambiguity witnesses remain sound.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from functools import lru_cache
from itertools import product

from correspondence import grid
from runtime import public_task

from cell_abstraction import Partition, COLOUR_REDUCERS, features, infer_map
from geometry import rotate, reflect
from pattern_completion import CompletionLaw, GENERATORS
from attributes import fit as fit_attributes, AttributeProgram
from lines import fit as fit_lines
from strokes import fit_strokes

FAMILY='abstract_reason_reconstruct_v76'


def shape(a): return len(a),len(a[0])


def macro_target(a, y, partition):
    """Read a lossless target in the *input* cell geometry, never resegment y."""
    if shape(a)!=shape(y): return None
    axes=partition.axes(a)
    if axes is None: return None
    rr,cc=axes
    if len(rr)*len(cc)>=len(a)*len(a[0]): return None
    out=[]; active=set()
    for rs in rr:
        row=[]
        for cs in cc:
            pts={(r,c) for r in rs for c in cs}; active.update(pts)
            colours={y[r][c] for r,c in pts}
            if len(colours)!=1:return None
            row.append(next(iter(colours)))
        out.append(tuple(row))
    if any(a[r][c]!=y[r][c] for r in range(len(a)) for c in range(len(a[0])) if (r,c) not in active):return None
    return tuple(out)


def lift(a, macro, partition):
    """Paint each original cell; preserve all excluded separator pixels exactly."""
    a=grid(a);macro=grid(macro);axes=partition.axes(a)
    if axes is None:return None
    rr,cc=axes
    if shape(macro)!=(len(rr),len(cc)):return None
    out=[list(r) for r in a]
    for i,rs in enumerate(rr):
        for j,cs in enumerate(cc):
            for r in rs:
                for c in cs:out[r][c]=macro[i][j]
    return grid(out)


def partitions(pairs):
    a=pairs[0][0];h,w=shape(a)
    common=set.intersection(*({v for row in x for v in row} for x,y in pairs))
    result=[Partition('separators',separator=s) for s in ('modal',*sorted(common))]
    result.append(Partition('identical_runs'))
    # All divisors of the observed first input; these are dimensions, not task constants.
    for rh in range(1,h+1):
        if h%rh:continue
        for cw in range(1,w+1):
            if w%cw or rh*cw==1:continue
            result.extend((Partition('factor',rh,cw),Partition('count',h//rh,w//cw)))
    return tuple(dict.fromkeys(result))


@dataclass(frozen=True)
class GeometryReason:
    turns:int=0
    flip:bool=False
    projection:str='preserve'
    table:tuple=()
    def predict(self,a):
        x=rotate(reflect(a,'horizontal' if self.flip else 'none'),self.turns)
        if self.projection=='preserve':return x
        lookup=dict(self.table)
        if any(v not in lookup for row in x for v in row):return None
        return tuple(tuple(lookup[v] for v in row) for row in x)
    def describe(self):return {'kind':'macro_geometry_colour',**asdict(self)}


def reason_description(reason):
    if hasattr(reason,'describe'):return reason.describe()
    if isinstance(reason,CompletionLaw):return {'kind':'guarded_pattern',**asdict(reason)}
    return {'kind':type(reason).__name__,'law':reason.name()}


@lru_cache(maxsize=256)
def fit_reasons(pairs):
    """Reuse geometry, guarded reconstruction, attributes, and spatial renderers."""
    xs=tuple(a for a,y in pairs);ys=tuple(y for a,y in pairs);out=[]
    for flip,turns in product((False,True),range(4)):
        gs=tuple(rotate(reflect(x,'horizontal' if flip else 'none'),turns) for x in xs)
        if any(shape(x)!=shape(y) for x,y in zip(gs,ys)):continue
        # Explicit inherited observed-effect prior, not logical equivalence pruning.
        if (flip or turns) and gs==xs:continue
        if gs==ys:out.append(GeometryReason(turns,flip));continue
        table=infer_map(gs,ys)
        if table is not None and len(table)>=2:out.append(GeometryReason(turns,flip,'observed_table',table))
    if any(shape(x)!=shape(y) for x,y in pairs) or xs==ys:return tuple(out)
    changed_from={x[r][c] for x,y in pairs for r in range(len(x)) for c in range(len(x[0])) if x[r][c]!=y[r][c]}
    if len(changed_from)==1:
        mask=next(iter(changed_from));complete=all(mask not in row for y in ys for row in y)
        relations=[(r,0) for r in GENERATORS]
        relations += [('period_rows',p) for p in range(1,min(len(a) for a in xs))]
        relations += [('period_cols',p) for p in range(1,min(len(a[0]) for a in xs))]
        for rel,period in relations:
            law=CompletionLaw(rel,mask,complete,period)
            if all(law.predict(x)==y for x,y in pairs):out.append(law)
    # These return complete fitted programs, not the old families' accepted scores.
    out.extend(fit_attributes(pairs));out.extend(fit_lines(pairs));out.extend(fit_strokes(pairs))
    return tuple(out)


def representation_compatible(partition, axes, reason):
    """Conservative type gate for nonuniform run quotients, not a learned answer rule.

    Unequal row/column contraction changes area/shape measurements. Only the
    listed topological predicates may follow that quotient. Explicit regular or
    separator cells instead define a deliberate cell-coordinate representation.
    """
    if partition.kind!='identical_runs' or not isinstance(reason,AttributeProgram):return True
    uniform=all(len({len(g) for g in axis})==1 for axis in axes)
    return uniform or reason.feature in ('holes','border','solid')


@dataclass(frozen=True)
class LiftedProgram:
    partition:Partition
    reducer:str
    background_rule:int|str|None
    output_mode:str
    reason:object

    def abstract(self,a):
        return features(grid(a),'whole',self.background_rule,self.partition,self.reducer)

    def joint(self,raw_inputs):
        inputs=tuple(grid(a) for a in raw_inputs)
        for a in inputs:
            axes=self.partition.axes(a)
            if axes is None or not representation_compatible(self.partition,axes,self.reason):return None
        xs=tuple(self.abstract(a) for a in inputs)
        if any(x is None for x in xs):return None
        if hasattr(self.reason,'joint'):
            result=self.reason.joint(xs)
            if result is None:return None
            witnesses=result['witnesses'];n=result['prediction_count']
        else:
            ps=tuple(self.reason.predict(x) for x in xs)
            if any(y is None for y in ps):return None
            witnesses=[ps];n=1
        final=[]
        for key in witnesses:
            out=tuple(lift(a,y,self.partition) if self.output_mode=='lift' else y for a,y in zip(inputs,key))
            if any(y is None for y in out):return None
            final.append(out)
        return {'witnesses':final,'prediction_count':n}

    def describe(self):
        return {'family':FAMILY,'partition':asdict(self.partition),'reducer':self.reducer,
                'background_rule':self.background_rule,'output_mode':self.output_mode,
                'reason':reason_description(self.reason)}

    def trace(self,a):
        a=grid(a);x=self.abstract(a);j=self.joint((a,));ax=self.partition.axes(a)
        return {'program':self.describe(),'row_groups':ax[0] if ax else None,
            'column_groups':ax[1] if ax else None,'abstract_input':x,
            'abstract_predictions': (self.reason.joint((x,))['witnesses'] if x is not None and hasattr(self.reason,'joint') and self.reason.joint((x,)) is not None else
                                    [self.reason.predict(x)] if x is not None and not hasattr(self.reason,'joint') else []),
            'output':j['witnesses'][0][0] if j and j['prediction_count']==1 else None}


def fit(raw_pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    same=all(shape(a)==shape(y) for a,y in pairs)
    shrink=all(len(y)*len(y[0])<len(a)*len(a[0]) for a,y in pairs)
    if not same and not shrink:return []
    mode='lift' if same else 'abstract'
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    result=[]
    for part in partitions(pairs):
        axes=tuple(part.axes(a) for a,y in pairs)
        if any(ax is None or len(ax[0])*len(ax[1])>=len(a)*len(a[0]) for ax,(a,y) in zip(axes,pairs)):continue
        ys=tuple(macro_target(a,y,part) for a,y in pairs) if same else tuple(y for a,y in pairs)
        if any(y is None for y in ys):continue
        # Only D4 changes shape in this reasoning vocabulary.
        if any(shape(y) not in ((len(ax[0]),len(ax[1])),(len(ax[1]),len(ax[0]))) for ax,y in zip(axes,ys)):continue
        for reducer in COLOUR_REDUCERS:
            bgs=('modal',*sorted(common)) if reducer=='foreground' else (None,)
            for bg in bgs:
                xs=tuple(features(a,'whole',bg,part,reducer) for a,y in pairs)
                if any(x is None for x in xs):continue
                # Plain reduction alone is V75, not evidence of a new composition.
                if mode=='abstract' and xs==ys:continue
                for reason in fit_reasons(tuple(zip(xs,ys))):
                    if not all(representation_compatible(part,ax,reason) for ax in axes):continue
                    model=LiftedProgram(part,reducer,bg,mode,reason)
                    # Full-resolution replay is the acceptance constraint.
                    pred=model.joint(tuple(a for a,y in pairs))
                    if pred and pred['prediction_count']==1 and pred['witnesses'][0]==tuple(y for a,y in pairs):result.append(model)
    return result


def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    inputs=tuple(d['input'] for d in clean['test']);groups={};invalid=0;exact_count=True
    for model in models:
        j=model.joint(inputs)
        if j is None:invalid+=1;continue
        if j['prediction_count']>len(j['witnesses']):exact_count=False
        for key in j['witnesses']:groups.setdefault(key,[]).append(model.describe())
    status='unique' if len(groups)==1 else 'ambiguous' if groups else 'no_fit';key=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':len(groups),'joint_hypotheses_is_exact':exact_count,
       'tests':[{'status':status,'prediction':[list(r) for r in key[i]] if key else None} for i in range(len(inputs))],
       'supporting_families':[FAMILY] if key else [],'supporting_laws':groups[key][:20] if key else [],
       'witness_predictions':[[[list(row) for row in y] for y in k] for k in list(groups)[:2]],
       'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'all_applicable_alternatives_accounted_for':True}}


def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        f={'train':[d for i,d in enumerate(clean['train']) if i!=held],
           'test':[{'input':demo['input']}]+clean['test']}
        r=infer(f);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
          'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
          'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
          'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


