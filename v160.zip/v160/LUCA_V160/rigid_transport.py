"""Rigid component settling with simultaneous collision dependencies.

All bodies translate in one common cardinal direction. Components are extracted
once, so touching bodies never fuse or shed pixels during transport. No task IDs,
stored answers, scan-order tie breakers, output-derived coordinates or physics
claims are part of the language.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from itertools import product
from typing import Iterable

from attributes import background, components
from correspondence import Grid, grid
from runtime import public_task, joint_result
# The certificate-producing validator is identical for any infer(task) family.

FAMILY = 'rigid_transport'
DIRECTIONS = ((-1, 0), (1, 0), (0, -1), (0, 1))


def settle(a: Grid, bg: int, bodies: tuple[tuple[tuple[int, int], ...], ...],
           dr: int, dc: int, *, trace: bool = False, max_steps: int | None = None):
    """Translate a partition of movable foreground; preserve all remaining cells.

    Return (grid, displacements, ticks). Every proposal has the same displacement,
    so distinct moving bodies cannot collide with each other. Blocking propagates
    backwards along dependencies on stationary bodies until a fixed point. Cyclic
    dependencies can move together if no member is boundary/static-blocked.
    """
    if (dr, dc) not in DIRECTIONS:
        raise ValueError('direction must be a cardinal unit vector')
    if max_steps is not None and (type(max_steps) is not int or max_steps < 1):
        raise ValueError('step budget must be a positive integer')
    h, w = len(a), len(a[0])
    moving = set()
    for body in bodies:
        if not body or len(set(body)) != len(body):
            raise ValueError('bodies must be nonempty and contain distinct cells')
        for p in body:
            r, c = p
            if not (0 <= r < h and 0 <= c < w) or a[r][c] == bg or p in moving:
                raise ValueError('bodies must be disjoint foreground cells inside the grid')
            moving.add(p)
    static = {(r, c): a[r][c] for r in range(h) for c in range(w)
              if a[r][c] != bg and (r, c) not in moving}
    current = [set(body) for body in bodies]
    offsets = [[0, 0] for _ in bodies]
    ticks = []
    # No body can translate more than one axis length before crossing the grid.
    for tick in range(min(h if dr else w, max_steps) if max_steps is not None else (h if dr else w)):
        occupied = {p: i for i, body in enumerate(current) for p in body}
        dependencies = [set() for _ in bodies]
        feasible = set(range(len(bodies)))
        for i, body in enumerate(current):
            for r, c in body:
                p = (r + dr, c + dc)
                if not (0 <= p[0] < h and 0 <= p[1] < w) or p in static:
                    feasible.discard(i)
                other = occupied.get(p)
                if other is not None and other != i:
                    dependencies[i].add(other)
        while True:
            narrowed = {i for i in feasible if dependencies[i] <= feasible}
            if narrowed == feasible:
                break
            feasible = narrowed
        if not feasible:
            break
        for i in feasible:
            current[i] = {(r + dr, c + dc) for r, c in current[i]}
            offsets[i][0] += dr
            offsets[i][1] += dc
        if trace:
            ticks.append({'tick': tick + 1, 'moving_body_indices': sorted(feasible),
                          'dependencies': [sorted(ds) for ds in dependencies],
                          'displacements': [list(d) for d in offsets]})
    output = [[bg] * w for _ in range(h)]
    for (r, c), colour in static.items():
        output[r][c] = colour
    written = set(static)
    for body, (rr, cc) in zip(bodies, offsets):
        for r, c in body:
            p = (r + rr, c + cc)
            if p in written:
                raise RuntimeError('internal rigid transport collision')
            written.add(p)
            output[p[0]][p[1]] = a[r][c]
    return grid(output), tuple(tuple(d) for d in offsets), ticks


def approach_direction(source, target):
    """Unique cardinal approach between separated, axis-overlapping boxes.

    Bounding boxes choose an approach axis, not a collision surface. Subsequent
    collision tests still use the actual occupied cells. Diagonally separated or
    overlapping boxes do not determine an approach and reject this role.
    """
    if not source or not target:
        return None
    a,b = [(min(r for r,c in cells), max(r for r,c in cells),
            min(c for r,c in cells), max(c for r,c in cells)) for cells in (source,target)]
    dirs = []
    if max(a[0],b[0]) <= min(a[1],b[1]):
        if a[3] < b[2]: dirs.append((0,1))
        if b[3] < a[2]: dirs.append((0,-1))
    if max(a[2],b[2]) <= min(a[3],b[3]):
        if a[1] < b[0]: dirs.append((1,0))
        if b[1] < a[0]: dirs.append((-1,0))
    return dirs[0] if len(dirs)==1 else None


@dataclass(frozen=True)
class RigidProgram:
    background_rule: str | int
    connectivity: int
    monochrome: bool
    direction: tuple[int, int] | str
    barrier_colour: int | None = None
    steps: int | None = None

    def describe(self) -> dict:
        return {'family': FAMILY, 'background_rule': self.background_rule,
                'connectivity': self.connectivity, 'monochrome': self.monochrome,
                'direction': self.direction if isinstance(self.direction, str) else list(self.direction), 'barrier_colour': self.barrier_colour,
                'motion': 'synchronous greatest-feasible-set transport',
                'stopping': 'until_rest' if self.steps is None else 'learned_step_budget',
                'steps': self.steps,
                'body_identity': 'fixed from input; no resegmentation after contact',
                'conservation': 'colours, multiplicities and internal body offsets'}

    def execute(self, value: Grid, *, trace: bool = False):
        a = grid(value)
        bg = background(a, self.background_rule)
        if bg is None or bg == self.barrier_colour:
            return None
        if self.barrier_colour is not None:
            if type(self.barrier_colour) is not int or not 0 <= self.barrier_colour <= 9:
                raise ValueError('invalid barrier colour')
            if not any(self.barrier_colour in row for row in a):
                return None
        perception = tuple(tuple(bg if v == self.barrier_colour else v for v in row) for row in a)
        objs = components(perception, bg, self.connectivity, self.monochrome)
        if not objs:
            return None
        bodies = tuple(o.cells for o in objs)
        actual_direction = self.direction
        if isinstance(actual_direction, str):
            if actual_direction != 'toward_barrier':
                raise ValueError('unknown direction rule')
            if self.barrier_colour is None:
                return None
            target = {(rr,cc) for rr,row in enumerate(a) for cc,v in enumerate(row)
                      if v == self.barrier_colour}
            choices = {approach_direction(body, target) for body in bodies}
            if None in choices or len(choices) != 1:
                return None
            actual_direction = next(iter(choices))
        output, offsets, ticks = settle(a, bg, bodies, *actual_direction,
                                       trace=trace, max_steps=self.steps)
        moved_rigid = any(len(o) > 1 and d != (0, 0) for o, d in zip(bodies, offsets))
        details = {'background': bg, 'actual_direction': list(actual_direction), 'bodies': [
            {'source_cells': [[r, c, a[r][c]] for r, c in body],
             'displacement': list(delta),
             'destination_cells': [[r+delta[0], c+delta[1], a[r][c]] for r, c in body]}
            for body, delta in zip(bodies, offsets)], 'ticks': ticks} if trace else None
        return output, moved_rigid, details

    def predict(self, value: Grid) -> Grid | None:
        result = self.execute(value)
        return None if result is None else result[0]

    def trace(self, value: Grid) -> dict | None:
        result = self.execute(value, trace=True)
        return None if result is None else {'program': self.describe(), **result[2],
                                           'prediction': result[0]}


def fit(pairs: Iterable[tuple[Grid, Grid]]) -> list[RigidProgram]:
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if not pairs or not any(a != y for a, y in pairs):
        return []
    if any((len(a), len(a[0])) != (len(y), len(y[0])) or
           Counter(v for row in a for v in row) != Counter(v for row in y for v in row)
           for a, y in pairs):
        return []
    common = set.intersection(*({v for row in a for v in row} for a, _ in pairs))
    models = []
    # Every tick strictly increases this directed foreground moment. It is an
    # exact necessary condition used to locate a possible stopping tick, not a
    # score used to choose among demonstration-fitting answers.
    def moment(a, bg, direction):
        dr, dc = direction
        return sum(r*dr+c*dc for r, row in enumerate(a) for c, v in enumerate(row) if v != bg)

    for bg_rule, conn, mono, direction, barrier in product(
            ('modal', *sorted(common)), (4, 8), (True, False), (*DIRECTIONS, 'toward_barrier'), (None, *sorted(common))):
        model = RigidProgram(bg_rule, conn, mono, direction, barrier)
        inferred_steps = None
        moved = False
        possible = True
        trajectories = []
        for a, y in pairs:
            bg = background(a, bg_rule)
            if bg is None:
                possible = False; break
            result = model.execute(a, trace=True)
            if result is None:
                possible = False; break
            actual_direction = tuple(result[2]['actual_direction'])
            # Common-direction transport preserves perpendicular lane counts.
            lanes_a = a if actual_direction[1] else tuple(zip(*a))
            lanes_y = y if actual_direction[1] else tuple(zip(*y))
            if any(Counter(u) != Counter(v) for u,v in zip(lanes_a, lanes_y)):
                possible = False; break
            trajectories.append(result)
            moved |= result[1]
            if result[0] == y:
                continue
            # At least one demonstration must stop before the free-settling
            # endpoint to justify a learned finite budget. Otherwise use rest.
            target_moment = moment(y, bg, actual_direction)
            current_moment = moment(a, bg, actual_direction)
            sizes = [len(b['source_cells']) for b in result[2]['bodies']]
            candidate = None
            for tick in result[2]['ticks']:
                current_moment += sum(sizes[i] for i in tick['moving_body_indices'])
                if current_moment == target_moment:
                    candidate = tick['tick']; break
                if current_moment > target_moment:
                    break
            if candidate is None or (inferred_steps is not None and candidate != inferred_steps):
                possible = False; break
            inferred_steps = candidate
        if not possible:
            continue
        if inferred_steps is None:
            if moved:
                models.append(model)
        else:
            finite = RigidProgram(bg_rule, conn, mono, direction, barrier, inferred_steps)
            results = [finite.execute(a) for a, _ in pairs]
            if (all(r is not None and r[0] == y for r, (_, y) in zip(results, pairs))
                    and any(r[1] for r in results)):
                models.append(finite)
    return models


def infer(task: dict) -> dict:
    clean = public_task(task)
    models = fit((d['input'], d['output']) for d in clean['train'])
    groups, invalid = {}, 0
    for program in models:
        predictions = tuple(program.predict(t['input']) for t in clean['test'])
        if any(p is None for p in predictions):
            invalid += 1
            continue
        groups.setdefault(predictions, []).append(program.describe())
    result = joint_result(groups, len(clean['test']))
    result.update(joint_hypotheses_is_exact=True,
        witness_predictions=[[[list(row) for row in g] for g in key] for key in groups],
        stats={'fitted_programs': len(models), 'inapplicable_programs': invalid,
               'all_complete_joint_alternatives_retained': True})
    return result


def validate(task: dict, full: dict) -> dict:
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [t['prediction'] for t in full['tests']]
    folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': demo['input']}] + clean['test']}
        result = infer(fold)
        predictions = [t['prediction'] for t in result['tests']]
        folds.append({'held_index': held, 'status': result['status'],
                      'held_example_exact': result['status'] == 'unique' and predictions[0] == demo['output'],
                      'test_prediction_stable': result['status'] == 'unique' and predictions[1:] == expected,
                      'joint_hypotheses': result['joint_hypotheses']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure',
            'folds': folds}
