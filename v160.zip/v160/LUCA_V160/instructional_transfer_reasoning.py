"""LUCA V114: proof-carrying instructional operator transfer.

V114 separates an instructional relation from the consequence applied to a new
role.  Four conservative schemas share one infer/validate boundary:

* ``hole_shape_fill_transfer`` -- match coloured instruction motifs to enclosed
  holes by normalized shape and transfer motif colours into the canvas;
* ``priority_mask_transfer`` -- use one panel as a protected template and copy
  a second panel only into template-background cells;
* ``block_mode_compression`` -- infer a separator lattice, reduce every local
  block by its unique modal colour, and emit the reduced grid;
* ``panel_sequence_extrapolation`` -- treat a sequence of panels as an
  instruction, infer a local translation or monotone frontier law, and emit the
  next panel.

All inference receives demonstrations and test inputs only through
``runtime.public_task``.  Exact demonstration fit is necessary but not
sufficient: programs must also survive leave-one-demonstration-out refitting,
schema-specific counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from itertools import product
from typing import Iterable, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_instructional_operator_transfer"
LANGUAGE = "spinoza_instructional_operator_language_v1"
SCHEMA_VERSION = "instructional_operator_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    a = grid(value)
    return len(a), len(a[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    ranked = counts.most_common()
    if not ranked:
        raise Inapplicable("empty grid")
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal colour")
    return ranked[0][0]


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _components(value: Grid, predicate, *, same_colour: bool = False):
    a = grid(value)
    h, w = _shape(a)
    seen = set()
    result = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or not predicate(r, c, a[r][c]):
                continue
            colour = a[r][c]
            queue = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while queue:
                rr, cc = queue.popleft()
                cells.append((rr, cc))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nr, nc = rr + dr, cc + dc
                    if not (0 <= nr < h and 0 <= nc < w) or (nr, nc) in seen:
                        continue
                    if not predicate(nr, nc, a[nr][nc]):
                        continue
                    if same_colour and a[nr][nc] != colour:
                        continue
                    seen.add((nr, nc))
                    queue.append((nr, nc))
            result.append((colour, tuple(sorted(cells))))
    return tuple(result)


def _normalized_mask(cells: Sequence[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    if not cells:
        raise Inapplicable("empty component")
    r0 = min(r for r, _ in cells)
    c0 = min(c for _, c in cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _split_two(value: Grid, axis: str, gap: int) -> tuple[Grid, Grid, int | None]:
    a = grid(value)
    h, w = _shape(a)
    if gap < 0 or gap > 3:
        raise Inapplicable("unsupported panel gap")
    if axis == "horizontal":
        if (w - gap) <= 0 or (w - gap) % 2:
            raise Inapplicable("grid does not split into two horizontal panels")
        pw = (w - gap) // 2
        left = tuple(tuple(row[:pw]) for row in a)
        right = tuple(tuple(row[pw + gap :]) for row in a)
        sep = None
        if gap:
            values = {a[r][c] for r in range(h) for c in range(pw, pw + gap)}
            if len(values) != 1:
                raise Inapplicable("panel separator is not uniform")
            sep = next(iter(values))
        return left, right, sep
    if axis == "vertical":
        if (h - gap) <= 0 or (h - gap) % 2:
            raise Inapplicable("grid does not split into two vertical panels")
        ph = (h - gap) // 2
        top = tuple(tuple(row) for row in a[:ph])
        bottom = tuple(tuple(row) for row in a[ph + gap :])
        sep = None
        if gap:
            values = {cell for row in a[ph : ph + gap] for cell in row}
            if len(values) != 1:
                raise Inapplicable("panel separator is not uniform")
            sep = next(iter(values))
        return top, bottom, sep
    raise Inapplicable("unknown panel axis")


# ---------------------------------------------------------------------------
# Schema I: shape-matched instruction motifs fill enclosed holes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class HoleShapeFillTransferProgram:
    axis: str
    gap: int
    canvas_index: int
    kind: str = "hole_shape_fill_transfer"

    @property
    def schema_key(self):
        return (self.kind, self.axis, self.gap, self.canvas_index)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.gap, self.canvas_index)

    def _analyse(self, value: Grid):
        panels = _split_two(value, self.axis, self.gap)[:2]
        canvas = panels[self.canvas_index]
        instruction = panels[1 - self.canvas_index]
        background = _unique_modal(instruction)
        if background not in _palette(canvas):
            raise Inapplicable("instruction background is absent from canvas")
        h, w = _shape(canvas)
        holes = []
        for _, cells in _components(canvas, lambda r, c, colour: colour == background):
            if any(r in (0, h - 1) or c in (0, w - 1) for r, c in cells):
                continue
            holes.append(cells)
        motifs = []
        for colour, cells in _components(
            instruction,
            lambda r, c, value: value != background,
            same_colour=True,
        ):
            motifs.append((colour, cells))
        if len(holes) < 2 or len(holes) != len(motifs):
            raise Inapplicable("hole and instruction inventories disagree")
        by_shape = defaultdict(list)
        for colour, cells in motifs:
            by_shape[_normalized_mask(cells)].append(colour)
        assignments = []
        for cells in holes:
            colours = by_shape.get(_normalized_mask(cells), [])
            if len(set(colours)) != 1:
                raise Inapplicable("hole does not have one shape-matched instruction colour")
            colour = colours[0]
            assignments.append((cells, colour))
            colours.remove(colour)
        if any(colours for colours in by_shape.values()):
            raise Inapplicable("unused instruction motif")
        return canvas, instruction, background, tuple(assignments)

    def predict(self, value: Grid) -> Grid:
        canvas, _, _, assignments = self._analyse(value)
        output = _array(canvas)
        for cells, colour in assignments:
            for r, c in cells:
                output[r][c] = colour
        predicted = tuple(tuple(row) for row in output)
        if predicted == canvas:
            raise Inapplicable("instruction has no effect")
        return predicted

    def describe(self, pairs):
        inventories = []
        for source, _ in pairs:
            _, _, _, assignments = self._analyse(source)
            inventories.append(len(assignments))
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "axis": self.axis,
                "gap": self.gap,
                "canvas_index": self.canvas_index,
            },
            "definitions": [
                {"name": "EnclosedHole", "type": "Grid -> ShapeRole"},
                {"name": "InstructionMotif", "type": "Grid -> ColouredShape"},
                {"name": "ShapeCorrespondence", "type": "Shape x Shape -> Boolean"},
            ],
            "propositions": [
                {"index": 1, "definition": "PanelDecomposition", "effect": "bind canvas and instruction panels"},
                {"index": 2, "definition": "ShapeCorrespondence", "effect": "match each hole to one motif"},
                {"index": 3, "definition": "ColourTransfer", "effect": "paint the matched enclosed region"},
            ],
            "corollary": "shape-matched instruction motifs determine hole colours",
            "common_notions": [
                {"name": "inventory_sizes", "evidence": inventories},
                {"name": "position_independent_shape_matching", "evidence": True},
            ],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema II: protected template receives a secondary panel through its mask
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PriorityMaskTransferProgram:
    axis: str
    gap: int
    priority_index: int
    background_colour: int
    kind: str = "priority_mask_transfer"

    @property
    def schema_key(self):
        return (self.kind, self.axis, self.gap, self.priority_index, self.background_colour)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (self.gap, self.priority_index)

    def _analyse(self, value: Grid):
        panels = _split_two(value, self.axis, self.gap)[:2]
        primary = panels[self.priority_index]
        secondary = panels[1 - self.priority_index]
        if _shape(primary) != _shape(secondary):
            raise Inapplicable("panel shapes disagree")
        background = self.background_colour
        if background not in _palette(secondary):
            raise Inapplicable("declared background is absent from payload")
        if background not in _palette(primary):
            raise Inapplicable("secondary background is absent from template")
        return primary, secondary, background

    def predict(self, value: Grid) -> Grid:
        primary, secondary, background = self._analyse(value)
        output = _array(primary)
        # Transfer is component-gated rather than pixel-gated: a payload object
        # is copied only when its complete footprint lies inside the template
        # background.  Partial clipping would destroy object identity and is
        # therefore rejected as an instruction.
        for colour, cells in _components(
            secondary,
            lambda r, c, value: value != background,
            same_colour=True,
        ):
            if all(primary[r][c] == background for r, c in cells):
                for r, c in cells:
                    output[r][c] = colour
        return tuple(tuple(row) for row in output)

    def describe(self, pairs):
        transferred = []
        for source, _ in pairs:
            primary, secondary, background = self._analyse(source)
            transferred.append(sum(primary[r][c] == background and secondary[r][c] != background for r in range(len(primary)) for c in range(len(primary[0]))))
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "axis": self.axis,
                "gap": self.gap,
                "priority_index": self.priority_index,
                "background_colour": self.background_colour,
            },
            "definitions": [
                {"name": "ProtectedTemplate", "type": "Grid"},
                {"name": "SecondaryPayload", "type": "Grid"},
                {"name": "BackgroundMask", "type": "Grid -> BooleanMask"},
            ],
            "propositions": [
                {"index": 1, "definition": "PanelDecomposition", "effect": "bind primary and secondary roles"},
                {"index": 2, "definition": "BackgroundMask", "effect": "identify writable template cells"},
                {"index": 3, "definition": "WholeObjectGate", "effect": "copy a payload component only when its full footprint fits"},
            ],
            "corollary": "the template protects its material and admits only whole payload objects that fit inside its background",
            "common_notions": [{"name": "effective_transfer_counts", "evidence": transferred}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema III: separator lattice -> local unique mode -> compressed grid
# ---------------------------------------------------------------------------


def _intervals(indices: Sequence[int]) -> tuple[tuple[int, int], ...]:
    if not indices:
        return ()
    result = []
    start = previous = indices[0]
    for value in indices[1:]:
        if value != previous + 1:
            result.append((start, previous + 1))
            start = value
        previous = value
    result.append((start, previous + 1))
    return tuple(result)


def _block_partition(value: Grid, separator_colour: int):
    a = grid(value)
    h, w = _shape(a)
    separator_rows = {r for r in range(h) if all(a[r][c] == separator_colour for c in range(w))}
    separator_cols = {c for c in range(w) if all(a[r][c] == separator_colour for r in range(h))}
    row_groups = _intervals([r for r in range(h) if r not in separator_rows])
    col_groups = _intervals([c for c in range(w) if c not in separator_cols])
    if len(row_groups) < 2 or len(col_groups) < 2:
        raise Inapplicable("requires a two-dimensional separator lattice")
    heights = {end - start for start, end in row_groups}
    widths = {end - start for start, end in col_groups}
    if len(heights) != 1 or len(widths) != 1:
        raise Inapplicable("lattice blocks are not uniform")
    blocks = []
    for r0, r1 in row_groups:
        for c0, c1 in col_groups:
            blocks.append(tuple(tuple(a[r][c0:c1]) for r in range(r0, r1)))
    return row_groups, col_groups, tuple(blocks)


def _unique_nonseparator_mode(block: Grid, separator_colour: int) -> int:
    counts = Counter(cell for row in grid(block) for cell in row if cell != separator_colour)
    if not counts:
        raise Inapplicable("empty lattice block")
    ranked = counts.most_common()
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("block mode is ambiguous")
    return ranked[0][0]


@dataclass(frozen=True)
class BlockModeCompressionProgram:
    separator_colour: int
    output_border: int
    kind: str = "block_mode_compression"

    @property
    def schema_key(self):
        return (self.kind, self.separator_colour, self.output_border)

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return (self.output_border, self.separator_colour)

    def _analyse(self, value: Grid):
        row_groups, col_groups, blocks = _block_partition(value, self.separator_colour)
        modes = tuple(_unique_nonseparator_mode(block, self.separator_colour) for block in blocks)
        return row_groups, col_groups, blocks, modes

    def predict(self, value: Grid) -> Grid:
        row_groups, col_groups, _, modes = self._analyse(value)
        rows, cols = len(row_groups), len(col_groups)
        border = self.output_border
        output = [[self.separator_colour for _ in range(cols + 2 * border)] for _ in range(rows + 2 * border)]
        for index, colour in enumerate(modes):
            rr, cc = divmod(index, cols)
            output[rr + border][cc + border] = colour
        return tuple(tuple(row) for row in output)

    def describe(self, pairs):
        layouts = []
        for source, _ in pairs:
            row_groups, col_groups, _, modes = self._analyse(source)
            layouts.append({"rows": len(row_groups), "cols": len(col_groups), "mode_palette": sorted(set(modes))})
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "separator_colour": self.separator_colour,
                "output_border": self.output_border,
            },
            "definitions": [
                {"name": "SeparatorLattice", "type": "Grid -> BlockGrid"},
                {"name": "UniqueLocalMode", "type": "Block -> Colour"},
                {"name": "CompressedGrid", "type": "ColourGrid"},
            ],
            "propositions": [
                {"index": 1, "definition": "SeparatorLattice", "effect": "bind uniform local blocks"},
                {"index": 2, "definition": "UniqueLocalMode", "effect": "reduce each block to one colour"},
                {"index": 3, "definition": "BorderedAssembly", "effect": "emit the compressed lattice"},
            ],
            "corollary": "each local demonstration block transfers its dominant identity to one output cell",
            "common_notions": [{"name": "lattice_layouts", "evidence": layouts}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Schema IV: demonstration-internal panel sequence teaches the next state
# ---------------------------------------------------------------------------


def _split_sequence(value: Grid, axis: str, gap: int, panel_count: int) -> tuple[Grid, ...]:
    a = grid(value)
    h, w = _shape(a)
    if panel_count < 3 or gap < 0 or gap > 3:
        raise Inapplicable("unsupported panel sequence")
    if axis == "vertical":
        usable = h - (panel_count - 1) * gap
        if usable <= 0 or usable % panel_count:
            raise Inapplicable("vertical panel sequence does not divide")
        ph = usable // panel_count
        panels = []
        for index in range(panel_count):
            r0 = index * (ph + gap)
            panels.append(tuple(tuple(row) for row in a[r0 : r0 + ph]))
            if gap and index < panel_count - 1:
                band = a[r0 + ph : r0 + ph + gap]
                if len({cell for row in band for cell in row}) != 1:
                    raise Inapplicable("sequence separator is not uniform")
        return tuple(panels)
    if axis == "horizontal":
        usable = w - (panel_count - 1) * gap
        if usable <= 0 or usable % panel_count:
            raise Inapplicable("horizontal panel sequence does not divide")
        pw = usable // panel_count
        panels = []
        for index in range(panel_count):
            c0 = index * (pw + gap)
            panels.append(tuple(tuple(row[c0 : c0 + pw]) for row in a))
            if gap and index < panel_count - 1:
                values = {a[r][c] for r in range(h) for c in range(c0 + pw, c0 + pw + gap)}
                if len(values) != 1:
                    raise Inapplicable("sequence separator is not uniform")
        return tuple(panels)
    raise Inapplicable("unknown panel-sequence axis")


def _translate_exact(source: Grid, target: Grid):
    a, b = grid(source), grid(target)
    if _shape(a) != _shape(b):
        return ()
    background = _unique_modal(a)
    if _unique_modal(b) != background:
        return ()
    h, w = _shape(a)
    source_cells = [(r, c, a[r][c]) for r in range(h) for c in range(w) if a[r][c] != background]
    target_cells = [(r, c, b[r][c]) for r in range(h) for c in range(w) if b[r][c] != background]
    if not source_cells or len(source_cells) != len(target_cells):
        return ()
    candidates = set()
    first_r, first_c, first_colour = source_cells[0]
    for tr, tc, colour in target_cells:
        if colour != first_colour:
            continue
        dr, dc = tr - first_r, tc - first_c
        shifted = sorted((r + dr, c + dc, colour) for r, c, colour in source_cells)
        if shifted == sorted(target_cells):
            candidates.add((dr, dc, background))
    return tuple(sorted(candidates))


def _apply_translation(value: Grid, dr: int, dc: int, background: int) -> Grid:
    a = grid(value)
    h, w = _shape(a)
    output = [[background for _ in range(w)] for _ in range(h)]
    for r in range(h):
        for c in range(w):
            if a[r][c] == background:
                continue
            nr, nc = r + dr, c + dc
            if not (0 <= nr < h and 0 <= nc < w):
                raise Inapplicable("translated panel leaves the canvas")
            if output[nr][nc] != background:
                raise Inapplicable("translated panel collides")
            output[nr][nc] = a[r][c]
    return tuple(tuple(row) for row in output)


def _translation_continuation(panels: Sequence[Grid]):
    vectors = []
    for source, target in zip(panels, panels[1:]):
        candidates = _translate_exact(source, target)
        if len(candidates) != 1:
            raise Inapplicable("panel transition is not a unique translation")
        vectors.append(candidates[0])
    if len(set(vectors)) != 1:
        raise Inapplicable("translation vector changes across the sequence")
    dr, dc, background = vectors[0]
    if dr == 0 and dc == 0:
        raise Inapplicable("identity sequence")
    return _apply_translation(panels[-1], dr, dc, background), {
        "local_law": "constant_translation",
        "vector": [dr, dc],
        "background": background,
    }


def _frontier_recolour_continuation(panels: Sequence[Grid]):
    if any(_shape(panel) != _shape(panels[0]) for panel in panels):
        raise Inapplicable("panel shapes disagree")
    transitions = []
    colour_pair = None
    for source, target in zip(panels, panels[1:]):
        diffs = [(r, c, source[r][c], target[r][c]) for r in range(len(source)) for c in range(len(source[0])) if source[r][c] != target[r][c]]
        if not diffs:
            raise Inapplicable("sequence transition is empty")
        pairs = {(before, after) for _, _, before, after in diffs}
        if len(pairs) != 1:
            raise Inapplicable("transition changes more than one colour relation")
        pair = next(iter(pairs))
        if colour_pair is None:
            colour_pair = pair
        elif colour_pair != pair:
            raise Inapplicable("recolour relation changes across panels")
        transitions.append(diffs)
    source_colour, target_colour = colour_pair

    # First prefer the strongest geometric explanation: the complete changed
    # mask itself translates by one constant vector.  This prevents a moving
    # two-cell instruction from expanding into every source-colour cell in the
    # next columns merely because the source colour is also the background.
    masks = [tuple(sorted((r, c) for r, c, _, _ in diffs)) for diffs in transitions]
    normalized = [_normalized_mask(mask) for mask in masks]
    if len(set(normalized)) == 1:
        anchors = [(min(r for r, _ in mask), min(c for _, c in mask)) for mask in masks]
        vectors = [
            (anchors[index][0] - anchors[index - 1][0], anchors[index][1] - anchors[index - 1][1])
            for index in range(1, len(anchors))
        ]
        if vectors and len(set(vectors)) == 1 and vectors[0] != (0, 0):
            dr, dc = vectors[0]
            translated = tuple((r + dr, c + dc) for r, c in masks[-1])
            h, w = _shape(panels[-1])
            if translated and all(0 <= r < h and 0 <= c < w and panels[-1][r][c] == source_colour for r, c in translated):
                output = _array(panels[-1])
                for r, c in translated:
                    output[r][c] = target_colour
                return tuple(tuple(row) for row in output), {
                    "local_law": "translated_recolour_mask",
                    "vector": [dr, dc],
                    "source_colour": source_colour,
                    "target_colour": target_colour,
                }

    candidates = []
    for axis in ("row", "col"):
        intervals = []
        for diffs in transitions:
            coordinates = sorted({r if axis == "row" else c for r, c, _, _ in diffs})
            if not coordinates or coordinates != list(range(coordinates[0], coordinates[-1] + 1)):
                break
            intervals.append((coordinates[0], coordinates[-1], len(coordinates)))
        else:
            if len({width for _, _, width in intervals}) != 1:
                continue
            starts = [start for start, _, _ in intervals]
            if len(starts) < 2:
                continue
            steps = [starts[index] - starts[index - 1] for index in range(1, len(starts))]
            if len(set(steps)) != 1 or steps[0] == 0:
                continue
            step = steps[0]
            width = intervals[0][2]
            next_start = starts[-1] + step
            candidates.append((axis, step, width, next_start))
    predictions = []
    h, w = _shape(panels[-1])
    for axis, step, width, next_start in candidates:
        limit = h if axis == "row" else w
        if next_start < 0 or next_start + width > limit:
            continue
        output = _array(panels[-1])
        changed = 0
        for r in range(h):
            for c in range(w):
                coordinate = r if axis == "row" else c
                if next_start <= coordinate < next_start + width and output[r][c] == source_colour:
                    output[r][c] = target_colour
                    changed += 1
        if changed:
            predictions.append((tuple(tuple(row) for row in output), {
                "local_law": "monotone_frontier_recolour",
                "axis": axis,
                "step": step,
                "width": width,
                "source_colour": source_colour,
                "target_colour": target_colour,
            }))
    unique = {}
    for prediction, evidence in predictions:
        unique.setdefault(prediction, evidence)
    if len(unique) != 1:
        raise Inapplicable("frontier continuation is absent or ambiguous")
    prediction, evidence = next(iter(unique.items()))
    return prediction, evidence


def _local_sequence_next(panels: Sequence[Grid]):
    candidates = []
    for function in (_translation_continuation, _frontier_recolour_continuation):
        try:
            candidates.append(function(panels))
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    grouped = {}
    for prediction, evidence in candidates:
        grouped.setdefault(prediction, []).append(evidence)
    if len(grouped) != 1:
        raise Inapplicable("instructional sequence has no unique continuation")
    prediction, evidence_rows = next(iter(grouped.items()))
    return prediction, evidence_rows


@dataclass(frozen=True)
class PanelSequenceExtrapolationProgram:
    axis: str
    gap: int
    panel_count: int
    kind: str = "panel_sequence_extrapolation"

    @property
    def schema_key(self):
        return (self.kind, self.axis, self.gap, self.panel_count)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (self.panel_count, self.gap)

    def _analyse(self, value: Grid):
        panels = _split_sequence(value, self.axis, self.gap, self.panel_count)
        prediction, evidence = _local_sequence_next(panels)
        return panels, prediction, evidence

    def predict(self, value: Grid) -> Grid:
        _, prediction, _ = self._analyse(value)
        return prediction

    def describe(self, pairs):
        local_laws = []
        for source, _ in pairs:
            _, _, evidence = self._analyse(source)
            local_laws.append(evidence)
        return {
            "family": FAMILY,
            "language": LANGUAGE,
            "schema_version": SCHEMA_VERSION,
            "schema": self.kind,
            "parameters": {
                "kind": self.kind,
                "axis": self.axis,
                "gap": self.gap,
                "panel_count": self.panel_count,
            },
            "definitions": [
                {"name": "PanelSequence", "type": "Grid -> OrderedGridSequence"},
                {"name": "LocalTransitionLaw", "type": "GridSequence -> Operator"},
                {"name": "NextState", "type": "Operator x Grid -> Grid"},
            ],
            "propositions": [
                {"index": 1, "definition": "PanelSequence", "effect": "bind ordered instructional states"},
                {"index": 2, "definition": "LocalTransitionLaw", "effect": "infer translation or frontier recurrence"},
                {"index": 3, "definition": "NextState", "effect": "apply the inferred law to the final panel"},
            ],
            "corollary": "the sequence itself teaches the operator used to produce its next state",
            "common_notions": [{"name": "local_laws", "evidence": local_laws}],
            "adequacy": {"exact_training_fit": True, "task_ids_used": False, "test_targets_used": False},
        }


# ---------------------------------------------------------------------------
# Fitting and inference
# ---------------------------------------------------------------------------


def _fit_hole_transfer(pairs):
    programs = []
    for axis in ("horizontal", "vertical"):
        for gap in range(4):
            for canvas_index in (0, 1):
                program = HoleShapeFillTransferProgram(axis, gap, canvas_index)
                try:
                    if all(_shape(target) == _shape(_split_two(source, axis, gap)[canvas_index]) and program.predict(source) == target for source, target in pairs):
                        programs.append(program)
                except (Inapplicable, ValueError, IndexError, TypeError):
                    continue
    return programs


def _fit_priority_overlay(pairs):
    programs = []
    common_colours = set.intersection(*(_palette(source) | _palette(target) for source, target in pairs))
    for axis in ("horizontal", "vertical"):
        for gap in range(4):
            for priority_index in (0, 1):
                for background_colour in sorted(common_colours):
                    program = PriorityMaskTransferProgram(axis, gap, priority_index, background_colour)
                    try:
                        outputs = [program.predict(source) for source, _ in pairs]
                        if all(output == target for output, (_, target) in zip(outputs, pairs)) and any(output != _split_two(source, axis, gap)[priority_index] for output, (source, _) in zip(outputs, pairs)):
                            programs.append(program)
                    except (Inapplicable, ValueError, IndexError, TypeError):
                        continue
    return programs


def _fit_block_compression(pairs):
    programs = []
    common_colours = set.intersection(*(_palette(source) | _palette(target) for source, target in pairs))
    for separator_colour in sorted(common_colours):
        for border in range(3):
            program = BlockModeCompressionProgram(separator_colour, border)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programs.append(program)
            except (Inapplicable, ValueError, IndexError, TypeError):
                continue
    return programs


def _fit_panel_sequence(pairs):
    candidates = None
    for source, target in pairs:
        sh, sw = _shape(source)
        th, tw = _shape(target)
        current = set()
        for axis in ("vertical", "horizontal"):
            for gap in range(4):
                for count in range(3, 9):
                    if axis == "vertical" and sw == tw and count * th + (count - 1) * gap == sh:
                        current.add((axis, gap, count))
                    if axis == "horizontal" and sh == th and count * tw + (count - 1) * gap == sw:
                        current.add((axis, gap, count))
        candidates = current if candidates is None else candidates & current
    programs = []
    for axis, gap, count in sorted(candidates or ()):
        program = PanelSequenceExtrapolationProgram(axis, gap, count)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                programs.append(program)
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
    return programs


def _role_varies(program, pairs):
    if isinstance(program, HoleShapeFillTransferProgram):
        inventories = []
        colours = []
        for source, _ in pairs:
            _, _, _, assignments = program._analyse(source)
            inventories.append(tuple(sorted(len(cells) for cells, _ in assignments)))
            colours.append(tuple(sorted(colour for _, colour in assignments)))
        return len(set(inventories)) >= 2 or len(set(colours)) >= 2
    if isinstance(program, PriorityMaskTransferProgram):
        signatures = []
        for source, _ in pairs:
            primary, secondary, background = program._analyse(source)
            signatures.append((
                tuple(sorted(Counter(cell for row in primary for cell in row).items())),
                tuple(sorted(Counter(cell for row in secondary for cell in row).items())),
                background,
            ))
        return len({_serial(item) for item in signatures}) >= 2
    if isinstance(program, BlockModeCompressionProgram):
        signatures = []
        mixed = False
        for source, _ in pairs:
            _, _, blocks, modes = program._analyse(source)
            signatures.append(modes)
            mixed = mixed or any(len(set(cell for row in block for cell in row)) > 1 for block in blocks)
        return mixed and len({_serial(item) for item in signatures}) >= 2
    if isinstance(program, PanelSequenceExtrapolationProgram):
        evidence = []
        for source, _ in pairs:
            _, _, local = program._analyse(source)
            evidence.append(local)
        return len({_serial(item) for item in evidence}) >= 2
    return False


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programs = []
    if allowed is None or "hole_shape_fill_transfer" in allowed:
        programs.extend(_fit_hole_transfer(pairs))
    if allowed is None or "priority_mask_transfer" in allowed:
        programs.extend(_fit_priority_overlay(pairs))
    if allowed is None or "block_mode_compression" in allowed:
        programs.extend(_fit_block_compression(pairs))
    if allowed is None or "panel_sequence_extrapolation" in allowed:
        programs.extend(_fit_panel_sequence(pairs))
    return programs


def fit_instructional_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(unique.values(), key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)))


def infer_instructional_transfer(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    programs = fit_instructional_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programs:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "instructional_schemas": sorted({program.kind for program in programs}),
            "proof_carrying": True,
            "instructional_operator_transfer": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Recovery and validation
# ---------------------------------------------------------------------------


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = parameters.get("kind") or law.get("schema")
    if kind == "hole_shape_fill_transfer":
        return HoleShapeFillTransferProgram(str(parameters["axis"]), int(parameters["gap"]), int(parameters["canvas_index"]))
    if kind == "priority_mask_transfer":
        return PriorityMaskTransferProgram(str(parameters["axis"]), int(parameters["gap"]), int(parameters["priority_index"]), int(parameters["background_colour"]))
    if kind == "block_mode_compression":
        return BlockModeCompressionProgram(int(parameters["separator_colour"]), int(parameters["output_border"]))
    if kind == "panel_sequence_extrapolation":
        return PanelSequenceExtrapolationProgram(str(parameters["axis"]), int(parameters["gap"]), int(parameters["panel_count"]))
    raise Inapplicable("unknown instructional transfer schema")


def _hole_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        canvas, instruction, background, assignments = program._analyse(source)
        original = program.predict(source)
        panels = list(_split_two(source, program.axis, program.gap)[:2])
        instruction_index = 1 - program.canvas_index
        instruction_array = _array(instruction)
        foreground = [(r, c) for r in range(len(instruction)) for c in range(len(instruction[0])) if instruction[r][c] != background]
        r, c = foreground[0]
        instruction_array[r][c] = background
        panels[instruction_index] = tuple(tuple(row) for row in instruction_array)
        modified = _assemble_two(panels[0], panels[1], program.axis, program.gap, background)
        try:
            motif_necessary = program.predict(modified) != original
        except Inapplicable:
            motif_necessary = True
        # Recolour one complete instruction motif; geometry should remain and
        # the corresponding filled region should change colour.
        motif_components = _components(instruction, lambda rr, cc, value: value != background, same_colour=True)
        colour, cells = motif_components[0]
        replacement = next((value for value in range(10) if value not in _palette(source) and value != background), (colour + 1) % 10)
        recoloured = _array(instruction)
        for rr, cc in cells:
            recoloured[rr][cc] = replacement
        panels = list(_split_two(source, program.axis, program.gap)[:2])
        panels[instruction_index] = tuple(tuple(row) for row in recoloured)
        changed_source = _assemble_two(panels[0], panels[1], program.axis, program.gap, background)
        try:
            changed_prediction = program.predict(changed_source)
            recolour_transfers = changed_prediction != original and sum(cell == replacement for row in changed_prediction for cell in row) == len(cells)
        except Inapplicable:
            recolour_transfers = False
        rows.append({"demonstration": index, "motif_necessary": motif_necessary, "motif_recolour_transfers": recolour_transfers})
    return {"kind": program.kind, "rows": rows, "passed": all(row["motif_necessary"] and row["motif_recolour_transfers"] for row in rows)}


def _assemble_two(first: Grid, second: Grid, axis: str, gap: int, separator_colour: int) -> Grid:
    a, b = grid(first), grid(second)
    if axis == "horizontal":
        if len(a) != len(b):
            raise Inapplicable("panel heights disagree")
        return tuple(tuple(list(a[r]) + [separator_colour] * gap + list(b[r])) for r in range(len(a)))
    if axis == "vertical":
        if len(a[0]) != len(b[0]):
            raise Inapplicable("panel widths disagree")
        rows = [tuple(row) for row in a]
        rows.extend(tuple(separator_colour for _ in range(len(a[0]))) for _ in range(gap))
        rows.extend(tuple(row) for row in b)
        return tuple(rows)
    raise Inapplicable("unknown panel axis")


def _overlay_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        primary, secondary, background = program._analyse(source)
        original = program.predict(source)
        panels = list(_split_two(source, program.axis, program.gap)[:2])
        secondary_index = 1 - program.priority_index
        panels[secondary_index] = tuple(tuple(background for _ in row) for row in secondary)
        removed_source = _assemble_two(panels[0], panels[1], program.axis, program.gap, background)
        removed_prediction = program.predict(removed_source)
        removal_respects_mask = removed_prediction == primary
        # Recolour the secondary payload; only cells admitted by the primary
        # background mask may change.
        colours = sorted(_palette(secondary) - {background})
        if colours:
            mapping = {colours[0]: next((value for value in range(10) if value not in _palette(source)), (colours[0] + 1) % 10)}
            changed_secondary = tuple(tuple(mapping.get(cell, cell) for cell in row) for row in secondary)
            panels = list(_split_two(source, program.axis, program.gap)[:2])
            panels[secondary_index] = changed_secondary
            changed_source = _assemble_two(panels[0], panels[1], program.axis, program.gap, background)
            changed_prediction = program.predict(changed_source)
            protected = all(primary[r][c] == background or changed_prediction[r][c] == primary[r][c] for r in range(len(primary)) for c in range(len(primary[0])))
            admitted = changed_prediction != original or original == primary
        else:
            protected = admitted = True
        rows.append({"demonstration": index, "removal_respects_mask": removal_respects_mask, "primary_material_protected": protected, "secondary_change_admitted": admitted})
    return {"kind": program.kind, "rows": rows, "passed": all(row["removal_respects_mask"] and row["primary_material_protected"] and row["secondary_change_admitted"] for row in rows)}


def _block_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        original = program.predict(source)
        row_groups, col_groups, blocks, _ = program._analyse(source)
        # Reverse the cells inside every block.  Unique modes are invariant to
        # within-block permutations.
        changed = _array(source)
        for block_index, block in enumerate(blocks):
            rr, cc = divmod(block_index, len(col_groups))
            r0, r1 = row_groups[rr]
            c0, c1 = col_groups[cc]
            values = [cell for row in block for cell in row][::-1]
            cursor = 0
            for r in range(r0, r1):
                for c in range(c0, c1):
                    changed[r][c] = values[cursor]
                    cursor += 1
        permutation_invariant = program.predict(tuple(tuple(row) for row in changed)) == original
        # Break one full separator row; the lattice should become inapplicable
        # or produce a different answer.
        broken = _array(source)
        separator_rows = [r for r in range(len(broken)) if all(cell == program.separator_colour for cell in broken[r])]
        if separator_rows:
            r = separator_rows[len(separator_rows) // 2]
            broken[r][0] = next((value for value in range(10) if value != program.separator_colour), 1)
            try:
                separator_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
            except Inapplicable:
                separator_necessary = True
        else:
            separator_necessary = False
        rows.append({"demonstration": index, "within_block_permutation_invariant": permutation_invariant, "separator_lattice_necessary": separator_necessary})
    return {"kind": program.kind, "rows": rows, "passed": all(row["within_block_permutation_invariant"] and row["separator_lattice_necessary"] for row in rows)}


def _sequence_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        panels = list(_split_sequence(source, program.axis, program.gap, program.panel_count))
        original = program.predict(source)
        # Reverse instructional order.  A genuine next-state law should not
        # silently produce the same continuation.
        reversed_source = _assemble_sequence(tuple(reversed(panels)), program.axis, program.gap, _sequence_separator_colour(source, program))
        try:
            order_necessary = program.predict(reversed_source) != original
        except Inapplicable:
            order_necessary = True
        # Remove one changed cell from an interior state.  The inferred law must
        # change or become inapplicable.
        modified_panels = [list(map(list, panel)) for panel in panels]
        changed_cell = None
        for panel_index in range(1, len(panels) - 1):
            previous = panels[panel_index - 1]
            current = panels[panel_index]
            for r in range(len(current)):
                for c in range(len(current[0])):
                    if previous[r][c] != current[r][c]:
                        changed_cell = (panel_index, r, c, previous[r][c])
                        break
                if changed_cell:
                    break
            if changed_cell:
                break
        if changed_cell:
            panel_index, r, c, replacement = changed_cell
            modified_panels[panel_index][r][c] = replacement
            modified = tuple(tuple(tuple(row) for row in panel) for panel in modified_panels)
            modified_source = _assemble_sequence(modified, program.axis, program.gap, _sequence_separator_colour(source, program))
            try:
                relation_necessary = program.predict(modified_source) != original
            except Inapplicable:
                relation_necessary = True
        else:
            relation_necessary = False
        rows.append({"demonstration": index, "panel_order_necessary": order_necessary, "transition_evidence_necessary": relation_necessary})
    return {"kind": program.kind, "rows": rows, "passed": all(row["panel_order_necessary"] and row["transition_evidence_necessary"] for row in rows)}


def _sequence_separator_colour(source, program):
    a = grid(source)
    panels = _split_sequence(source, program.axis, program.gap, program.panel_count)
    if program.gap == 0:
        return _unique_modal(a)
    if program.axis == "vertical":
        ph = len(panels[0])
        return a[ph][0]
    pw = len(panels[0][0])
    return a[0][pw]


def _assemble_sequence(panels: Sequence[Grid], axis: str, gap: int, separator_colour: int) -> Grid:
    panels = tuple(grid(panel) for panel in panels)
    if axis == "vertical":
        width = len(panels[0][0])
        rows = []
        for index, panel in enumerate(panels):
            rows.extend(tuple(row) for row in panel)
            if index < len(panels) - 1:
                rows.extend(tuple(separator_colour for _ in range(width)) for _ in range(gap))
        return tuple(rows)
    if axis == "horizontal":
        height = len(panels[0])
        rows = []
        for r in range(height):
            row = []
            for index, panel in enumerate(panels):
                row.extend(panel[r])
                if index < len(panels) - 1:
                    row.extend([separator_colour] * gap)
            rows.append(tuple(row))
        return tuple(rows)
    raise Inapplicable("unknown sequence axis")


def _counterfactual_validation(program, pairs):
    if isinstance(program, HoleShapeFillTransferProgram):
        return _hole_counterfactuals(program, pairs)
    if isinstance(program, PriorityMaskTransferProgram):
        return _overlay_counterfactuals(program, pairs)
    if isinstance(program, BlockModeCompressionProgram):
        return _block_counterfactuals(program, pairs)
    if isinstance(program, PanelSequenceExtrapolationProgram):
        return _sequence_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_instructional_transfer(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programs = []
    for law in full.get("supporting_laws", ()):
        try:
            programs.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programs}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_instructional_transfer(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    counterfactuals = []
    for program in programs:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, TypeError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})
    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def instructional_affordances(task):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    return tuple(sorted({program.kind for program in fit_instructional_programs(pairs)}))


infer = infer_instructional_transfer
validate = validate_instructional_transfer
