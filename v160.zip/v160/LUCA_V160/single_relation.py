"""V60: derive object placement offset from demonstrations, not fixed anchor menu.
The reference marker is a unique singleton of an inferred color. Exactly one largest
connected component must be the source. Its output translation is inferred from
retained pixel colors; the destination is predicted relative to the marker in each
new input. Conservative collisions/ambiguity lead to abstention.
"""
from dataclasses import dataclass

from placement import components
from geometry import grid

@dataclass(frozen=True)
class Relation:
    background:int
    marker_color:int
    connectivity:int
    delta_row:int
    delta_col:int
    erase:bool

    def predict(self,raw):
        a=grid(raw); h=len(a);w=len(a[0]); cc=components(a,self.background,self.connectivity)
        candidates=[obj for obj in cc if len(obj)>1]
        if not candidates:return None
        size=max(map(len,candidates)); source=[obj for obj in candidates if len(obj)==size]
        if len(source)!=1:return None
        source=source[0]; singles=[ob[0] for ob in cc if len(ob)==1 and a[ob[0][0]][ob[0][1]]==self.marker_color]
        if len(singles)!=1:return None
        mr,mc=singles[0]; sr=min(r for r,c in source);sc=min(c for r,c in source)
        target_r,target_c=mr+self.delta_row,mc+self.delta_col
        dr,dc=target_r-sr,target_c-sc
        moved=[(r+dr,c+dc,r,c) for r,c in source]
        if any(not (0<=rr<h and 0<=cc<w) for rr,cc,r,c in moved):return None
        old=set(source)
        if any(a[rr][cc]!=self.background and (rr,cc) not in old for rr,cc,r,c in moved):return None
        out=[list(row) for row in a]
        if self.erase:
            for r,c in source:out[r][c]=self.background
        for rr,cc,r,c in moved:out[rr][cc]=a[r][c]
        return grid(out)

def fit(pairs):
    pairs=[(grid(x),grid(y)) for x,y in pairs]
    if len(pairs)<2:return []
    common=set.intersection(*[{v for row in x for v in row} for x,y in pairs]); candidates=[]
    for bg in common:
        for marker in common-{bg}:
            for conn in (4,8):
                anchors=[]
                for x,y in pairs:
                    cc=components(x,bg,conn)
                    objects=[obj for obj in cc if len(obj)>1]
                    if not objects:break
                    maximum=max(map(len,objects)); sources=[obj for obj in objects if len(obj)==maximum]
                    marks=[obj[0] for obj in cc if len(obj)==1 and x[obj[0][0]][obj[0][1]]==marker]
                    if len(sources)!=1 or len(marks)!=1:break
                    source=sources[0];mr,mc=marks[0]
                    # Find target origin by matching all source colored pixels to output,
                    # searching only translations that keep the entire component in bounds.
                    r0=min(r for r,c in source); c0=min(c for r,c in source)
                    options=[]
                    for tr in range(len(y)):
                        for tc in range(len(y[0])):
                            dr,dc=tr-r0,tc-c0
                            if all(0<=r+dr<len(y) and 0<=c+dc<len(y[0]) and y[r+dr][c+dc]==x[r][c] for r,c in source):
                                options.append((tr-mr,tc-mc))
                    if not options:break
                    anchors.append(set(options))
                else:
                    shared=set.intersection(*anchors)
                    for drow,dcol in sorted(shared):
                        for erase in (True,False):
                            law=Relation(bg,marker,conn,drow,dcol,erase)
                            if all(law.predict(x)==y for x,y in pairs):candidates.append(law)
    return candidates


