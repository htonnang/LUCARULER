"""V68: ray and clear-connector proposals reuse V67's transactional line renderer.

All candidate programs fit all demonstrations. No first-source or colour-order
conflict resolution. Paint roles are source colour, fixed colour, or an explicitly
learned source-colour map; unseen map entries reject, never silently copy.
"""
from __future__ import annotations
from collections import defaultdict
from dataclasses import dataclass
from itertools import combinations, product
from typing import Iterable
from correspondence import grid

from panel_layout import Background
from lines import PathProposal, render_paths, select_markers

DIRS={'U':(-1,0),'D':(1,0),'L':(0,-1),'R':(0,1),
      'UL':(-1,-1),'UR':(-1,1),'DL':(1,-1),'DR':(1,1)}
DIRECTIONS={k:(v,) for k,v in DIRS.items()}
DIRECTIONS.update(horizontal=((0,-1),(0,1)),vertical=((-1,0),(1,0)),
    orthogonal=((-1,0),(1,0),(0,-1),(0,1)),
    diagonals=((-1,-1),(-1,1),(1,-1),(1,1)),
    all_eight=tuple(DIRS.values()),positive_diagonal=((-1,-1),(1,1)),
    negative_diagonal=((-1,1),(1,-1)))
SELECTORS=('foreground_cells','isolated_cells','cross_centres')
CROSSINGS=('reject','vertical','horizontal')
TEMPLATE='select markers -> propose directed strokes -> resolve geometric priority -> paint background'
Grid=tuple[tuple[int,...],...]


def markers(a:Grid,bg:int,source:int|None,selector:str):
    if selector not in SELECTORS:raise ValueError('unknown selector')
    if selector!='isolated_cells':return select_markers(a,bg,selector,source)
    cells=select_markers(a,bg,'foreground_cells',source)
    h,w=len(a),len(a[0])
    return tuple((r,c,v) for r,c,v in cells if not any(
        0<=r+dr<h and 0<=c+dc<w and a[r+dr][c+dc]==v
        for dr,dc in DIRS.values()))


def propose(a:Grid,bg:int,source:int|None,selector:str,kind:str,directions:str,termination:str):
    """All paths use the unmodified scene; newly painted cells are not obstacles."""
    if kind not in ('ray','connector'):raise ValueError('unknown stroke kind')
    if directions not in DIRECTIONS:raise ValueError('unknown direction set')
    if termination not in ('obstacle','through'):raise ValueError('unknown termination')
    pts=markers(a,bg,source,selector)
    if not pts:return None
    h,w=len(a),len(a[0]);paths=[]
    if kind=='ray':
        for r,c,v in pts:
            for dr,dc in DIRECTIONS[directions]:
                rr,cc=r+dr,c+dc;cells=[]
                while 0<=rr<h and 0<=cc<w:
                    if a[rr][cc]==bg:cells.append((rr,cc))
                    elif termination=='obstacle':break
                    rr+=dr;cc+=dc
                if cells:paths.append(PathProposal(tuple(cells),v,dr,dc))
    else:
        # Undirected clear connectors: direction reversal is equivalent.
        allowed={d for dr,dc in DIRECTIONS[directions] for d in ((dr,dc),(-dr,-dc))}
        for (r,c,v),(rr,cc,vv) in combinations(pts,2):
            if v!=vv:continue
            dr,dc=rr-r,cc-c
            if not (dr==0 or dc==0 or abs(dr)==abs(dc)):continue
            n=max(abs(dr),abs(dc));step=((dr>0)-(dr<0),(dc>0)-(dc<0))
            if n<=1 or step not in allowed:continue
            cells=tuple((r+k*step[0],c+k*step[1]) for k in range(1,n))
            if termination=='obstacle' and any(a[x][y]!=bg for x,y in cells):continue
            cells=tuple((x,y) for x,y in cells if a[x][y]==bg)
            if cells:paths.append(PathProposal(cells,v,*step))
    return tuple(paths)


def winning_sources(paths,crossing):
    """Contributions of highest geometric priority; ties remain explicit sets."""
    if crossing not in CROSSINGS:raise ValueError('invalid crossing policy')
    requests=defaultdict(list)
    for path in paths:
        p=abs(path.dr) if crossing=='vertical' else abs(path.dc) if crossing=='horizontal' else 0
        for cell in path.cells:requests[cell].append((p,path.source_colour))
    return {cell:{v for p,v in entries if p==max(q for q,_ in entries)}
            for cell,entries in requests.items()}


@dataclass(frozen=True)
class Paint:
    mode:str='source'
    constant:int|None=None
    mapping:tuple[tuple[int,int],...]=()

    def value(self,source):
        if self.mode=='source':return source
        if self.mode=='constant':return self.constant
        if self.mode=='mapping':return dict(self.mapping).get(source)
        raise ValueError('unknown paint role')

    def name(self):
        return self.mode if self.mode=='source' else f'{self.mode}:{self.constant if self.mode=="constant" else self.mapping}'


def paint_paths(a,paths,paint,crossing):
    # A missing mapping for a completely hidden stroke is harmless. Only winning
    # contributions need evidence. Remove hidden cells before the shared renderer.
    winners=winning_sources(paths,crossing);converted=[]
    for path in paths:
        visible=tuple(cell for cell in path.cells if path.source_colour in winners[cell])
        if not visible:continue
        colour=paint.value(path.source_colour)
        if colour is None:return None
        converted.append(PathProposal(visible,colour,path.dr,path.dc))
    return render_paths(a,tuple(converted),None,crossing)


@dataclass(frozen=True)
class StrokeProgram:
    background:Background
    source:int|None
    selector:str
    kind:str
    directions:str
    termination:str
    paint:Paint
    crossing:str

    def predict(self,raw):
        a=grid(raw);bg=self.background.value(a,(a,))
        if bg is None:return None
        paths=propose(a,bg,self.source,self.selector,self.kind,self.directions,self.termination)
        return None if paths is None else paint_paths(a,paths,self.paint,self.crossing)

    def name(self):
        return (f'background({self.background.name()}) -> select({self.selector},source={self.source})'
                f' -> {self.kind}({self.directions},{self.termination})'
                f' -> paint({self.paint.name()},crossing={self.crossing})')

    def template(self):return TEMPLATE

    def trace(self,raw):
        a=grid(raw);bg=self.background.value(a,(a,))
        if bg is None:return None
        paths=propose(a,bg,self.source,self.selector,self.kind,self.directions,self.termination)
        if paths is None:return None
        pred=paint_paths(a,paths,self.paint,self.crossing)
        return {'law':self.name(),'kind':self.kind,'selector':self.selector,'directions':self.directions,
                'termination':self.termination,'paint':self.paint.name(),'crossing':self.crossing,
                'background_colour':bg,'markers':[list(p) for p in markers(a,bg,self.source,self.selector)],
                'paths':[{'cells':[list(c) for c in p.cells],'source_colour':p.source_colour,'direction':[p.dr,p.dc]} for p in paths],
                'prediction':[list(r) for r in pred] if pred is not None else None}


def fit_strokes(raw_pairs:Iterable)->list[StrokeProgram]:
    pairs=tuple((grid(a),grid(y)) for a,y in raw_pairs)
    if not pairs or any((len(a),len(a[0]))!=(len(y),len(y[0])) for a,y in pairs):return []
    changes=tuple({(r,c):y[r][c] for r in range(len(a)) for c in range(len(a[0])) if a[r][c]!=y[r][c]} for a,y in pairs)
    if not any(changes):return []
    changed_inputs={a[r][c] for (a,y),d in zip(pairs,changes) for r,c in d}
    outputs={v for d in changes for v in d.values()}
    backgrounds=[Background('unique_modal')]
    if len(changed_inputs)==1:backgrounds.append(Background('constant',next(iter(changed_inputs))))
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs));laws=[]
    geometries=[('ray',d,t) for d in DIRECTIONS for t in ('obstacle','through')]
    geometries += [('connector',d,t) for d in ('orthogonal','diagonals','all_eight') for t in ('obstacle','through')]
    for background in backgrounds:
        bgs=tuple(background.value(a,(a,)) for a,y in pairs)
        if any(bg is None for bg in bgs):continue
        if any(a[r][c]!=bg for (a,y),bg,d in zip(pairs,bgs,changes) for r,c in d):continue
        sources=[None]+[v for v in sorted(common) if any(v!=bg for bg in bgs)]
        for source,selector,(kind,directions,termination) in product(sources,SELECTORS,geometries):
            paths=tuple(propose(a,bg,source,selector,kind,directions,termination) for (a,y),bg in zip(pairs,bgs))
            if any(ps is None for ps in paths):continue
            if any({cell for p in ps for cell in p.cells}!=set(d) for ps,d in zip(paths,changes)):continue
            for crossing in CROSSINGS:
                paints=[Paint()]
                if len(outputs)==1:paints.append(Paint('constant',next(iter(outputs))))
                mapping={};consistent=True
                for ps,d in zip(paths,changes):
                    for cell,values in winning_sources(ps,crossing).items():
                        for value in values:
                            if value in mapping and mapping[value]!=d[cell]:consistent=False
                            mapping[value]=d[cell]
                if consistent and mapping:paints.append(Paint('mapping',mapping=tuple(sorted(mapping.items()))))
                for paint in paints:
                    if all(paint_paths(a,ps,paint,crossing)==y for (a,y),ps in zip(pairs,paths)):
                        laws.append(StrokeProgram(background,source,selector,kind,directions,termination,paint,crossing))
    return laws


