"""LUCA V139: graph-constructor grammar and bounded relation-chain search.

The family factors eight scene programmes through three reusable consequence
operators::

    scene -> typed nodes -> relation chain -> shared operator -> full grid

No task identifier, official test target, or absolute demonstration coordinate
is supplied to inference.  Programmes retain structural roles, directions, and
semantic colours only when demonstrations require them.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _mode, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_graph_constructor_grammar"
LANGUAGE = "spinoza_graph_constructor_grammar_v139"
SCHEMA_VERSION = 1


def _law(
    program,
    *,
    scene,
    relation,
    operator,
    parameters,
    definitions,
    propositions,
    corollary,
    common_notions,
):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "relation": relation,
            "operator": operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "graph_constructor_grammar": True,
            "bounded_relation_chain": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _background(value: Grid) -> int:
    return _mode(grid(value))


def _changed_output_colours(source: Grid, target: Grid):
    source = grid(source)
    target = grid(target)
    if _shape(source) != _shape(target):
        raise Inapplicable("shape changed")
    colours = set()
    changes = 0
    for r in range(len(source)):
        for c in range(len(source[0])):
            if source[r][c] != target[r][c]:
                colours.add(target[r][c])
                changes += 1
    if not changes:
        raise Inapplicable("identity transformation")
    return colours


def _single_paint_colour(pairs) -> int:
    paint = None
    for source, target in pairs:
        source = grid(source)
        target = grid(target)
        background = _background(source)
        colours = _changed_output_colours(source, target)
        if len(colours) != 1:
            raise Inapplicable("changes do not share one consequence colour")
        current = next(iter(colours))
        if current == background:
            raise Inapplicable("consequence colour equals background")
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] != target[r][c]:
                    if source[r][c] != background or target[r][c] != current:
                        raise Inapplicable("transformation is not background-only emission")
        if paint is None:
            paint = current
        elif paint != current:
            raise Inapplicable("consequence colour changes between demonstrations")
    if paint is None:
        raise Inapplicable("missing consequence colour")
    return int(paint)


def _transpose(value: Grid) -> Grid:
    value = grid(value)
    return tuple(tuple(value[r][c] for r in range(len(value))) for c in range(len(value[0])))


def _flip_rows(value: Grid) -> Grid:
    return tuple(reversed(grid(value)))


def _flip_cols(value: Grid) -> Grid:
    return tuple(tuple(reversed(row)) for row in grid(value))


def _bbox(cells):
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _rect_border(r0, c0, r1, c1):
    return {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }


def _monochrome_components(value: Grid):
    value = grid(value)
    h, w = _shape(value)
    background = _background(value)
    seen = set()
    output = []
    for r in range(h):
        for c in range(w):
            if (r, c) in seen or value[r][c] == background:
                continue
            colour = value[r][c]
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and (nr, nc) not in seen
                        and value[nr][nc] == colour
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append(
                {
                    "colour": int(colour),
                    "cells": frozenset(cells),
                    "bbox": _bbox(cells),
                }
            )
    return output


def _hollow_rectangles(value: Grid):
    output = []
    for component in _monochrome_components(value):
        r0, c0, r1, c1 = component["bbox"]
        if r1 - r0 < 2 or c1 - c0 < 2:
            continue
        if component["cells"] == frozenset(_rect_border(r0, c0, r1, c1)):
            output.append(component)
    return output


def _solid_rectangle(component) -> bool:
    r0, c0, r1, c1 = component["bbox"]
    return len(component["cells"]) == (r1 - r0 + 1) * (c1 - c0 + 1)


def _runs(values, background):
    output = []
    start = None
    colour = None
    for index, value in enumerate(tuple(values) + (background,)):
        if value != background and start is None:
            start = index
            colour = value
        if start is not None and (value == background or value != colour):
            output.append((start, index - 1, int(colour)))
            start = None
            colour = None
            if value != background:
                start = index
                colour = value
    return output


# ---------------------------------------------------------------------------
# Shared operator I: periodic field emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SeparatorPaletteBroadcastProgram:
    direction: str

    kind = "separator_palette_broadcast"

    @property
    def schema_key(self):
        return self.kind, self.direction

    def _down(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        candidates = []
        for separator in range(1, h - 1):
            row = value[separator]
            if len(set(row)) != 1 or row[0] == background:
                continue
            seed = value[separator - 1]
            if any(cell == background for cell in seed) or len(set(seed)) < 2:
                continue
            if any(value[r][c] != background for r in range(separator + 1, h) for c in range(w)):
                continue
            candidates.append((separator, seed))
        if len(candidates) != 1:
            raise Inapplicable("requires one seed row, separator row, and empty field")
        separator, seed = candidates[0]
        out = _array(value)
        for r in range(separator + 1, h):
            colour = seed[(r - separator - 1) % w]
            for c in range(w):
                out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if self.direction == "down":
            return self._down(value)
        if self.direction == "up":
            return _flip_rows(self._down(_flip_rows(value)))
        if self.direction == "right":
            return _transpose(self._down(_transpose(value)))
        if self.direction == "left":
            return _flip_cols(_transpose(self._down(_transpose(_flip_cols(value)))))
        raise Inapplicable("unknown broadcast direction")

    def describe(self, pairs):
        return _law(
            self,
            scene="ordered_palette_seed_adjacent_to_uniform_separator_and_empty_field",
            relation="ordered_seed_cycle_projects_across_the_separator_into_field_lanes",
            operator="periodic_field_emission",
            parameters={"direction": self.direction},
            definitions={
                "seed": "the multicolour lane immediately beside the separator",
                "separator": "a complete uniform lane dividing instruction and field",
                "field": "the background-only region on the emitted side",
            },
            propositions=[
                "The seed order is read from the current input rather than stored coordinates.",
                "Each emitted lane receives the next seed role cyclically.",
                "The instruction and separator remain unchanged.",
            ],
            corollary="Broadcast the ordered seed cycle through every empty field lane.",
            common_notions=["ordered role", "separator", "periodic projection", "field"],
        )


@dataclass(frozen=True)
class EdgeMotifFieldProgram:
    direction: str

    kind = "edge_motif_field_completion"

    @property
    def schema_key(self):
        return self.kind, self.direction

    def _right(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        width = 0
        while width < w and all(value[r][width] != background for r in range(h)):
            width += 1
        if width < 2 or width >= w:
            raise Inapplicable("missing boundary motif and empty field")
        if any(value[r][c] != background for r in range(h) for c in range(width, w)):
            raise Inapplicable("field is not empty")
        first = tuple(value[r][0] for r in range(h))
        last = tuple(value[r][width - 1] for r in range(h))
        if first != last:
            raise Inapplicable("motif does not expose a repeated anchor lane")
        out = [[first[r] for _ in range(w)] for r in range(h)]
        for r in range(h):
            for c in range(width):
                out[r][c] = value[r][c]
            for offset in range(1, width):
                out[r][w - width + offset] = value[r][offset]
        return tuple(tuple(row) for row in out)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if self.direction == "right":
            return self._right(value)
        if self.direction == "left":
            return _flip_cols(self._right(_flip_cols(value)))
        if self.direction == "down":
            return _transpose(self._right(_transpose(value)))
        if self.direction == "up":
            return _flip_rows(_transpose(self._right(_transpose(_flip_rows(value)))))
        raise Inapplicable("unknown motif direction")

    def describe(self, pairs):
        return _law(
            self,
            scene="boundary_motif_with_equal_anchor_lanes_and_background_field",
            relation="motif_anchor_broadcast_with_opposite_boundary_replica",
            operator="periodic_field_emission",
            parameters={"direction": self.direction},
            definitions={
                "motif": "the maximal full-depth nonbackground block at one boundary",
                "anchor": "the equal first and last lane of that motif",
                "replica": "the motif interior copied to the opposite boundary",
            },
            propositions=[
                "The anchor lane labels every unspecified field lane.",
                "The motif remains at its source boundary.",
                "The non-anchor motif lanes are reproduced in order at the opposite boundary.",
            ],
            corollary="Complete the field from the anchor and preserve the motif at both boundaries.",
            common_notions=["boundary motif", "anchor", "ordered replica", "field completion"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: bounded-region materialisation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DiagonalPaletteNestedFrameProgram:
    kind = "diagonal_palette_nested_frame"

    @property
    def schema_key(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        frames = _hollow_rectangles(value)
        if len(frames) != 1:
            raise Inapplicable("requires one hollow rectangular frame")
        frame = frames[0]
        r0, c0, r1, c1 = frame["bbox"]
        frame_colour = frame["colour"]
        candidates = []
        for cr, cc, dr, dc in (
            (r0, c0, -1, -1),
            (r0, c1, -1, 1),
            (r1, c0, 1, -1),
            (r1, c1, 1, 1),
        ):
            sequence = []
            rr, nc = cr + dr, cc + dc
            while 0 <= rr < h and 0 <= nc < w and value[rr][nc] not in (background, frame_colour):
                sequence.append(value[rr][nc])
                rr += dr
                nc += dc
            if len(sequence) < 2:
                continue
            chain = {(cr + dr * index, cc + dc * index) for index in range(1, len(sequence) + 1)}
            outside = {
                (r, c)
                for r in range(h)
                for c in range(w)
                if value[r][c] != background and (r, c) not in frame["cells"]
            }
            if outside == chain:
                candidates.append(tuple(reversed(sequence)))
        if len(candidates) != 1:
            raise Inapplicable("requires one diagonal palette chain")
        palette = candidates[0]
        interior_h = r1 - r0 - 1
        interior_w = c1 - c0 - 1
        available_layers = (min(interior_h, interior_w) + 1) // 2
        if len(palette) > available_layers:
            raise Inapplicable("palette exceeds available nested shells")
        return value, frame, palette

    def predict(self, value: Grid) -> Grid:
        value, frame, palette = self.analyse(value)
        r0, c0, r1, c1 = frame["bbox"]
        out = _array(value)
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                depth = min(r - r0 - 1, r1 - 1 - r, c - c0 - 1, c1 - 1 - c)
                out[r][c] = palette[min(depth, len(palette) - 1)]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="hollow_rectangle_with_external_diagonal_palette_chain",
            relation="ordered_palette_nodes_map_to_successive_interior_shell_depths",
            operator="bounded_region_materialisation",
            parameters={},
            definitions={
                "frame": "the unique hollow rectangular boundary",
                "palette_chain": "the contiguous diagonal sequence ending at a frame corner",
                "shell_depth": "minimum distance from an interior cell to the frame",
            },
            propositions=[
                "Palette order is read from the outermost chain node toward the frame.",
                "Each shell depth receives the corresponding palette role.",
                "The final role covers any remaining centre when fewer roles than depths exist.",
            ],
            corollary="Materialise the frame interior as ordered nested palette shells.",
            common_notions=["frame", "ordered chain", "shell depth", "bounded cover"],
        )


@dataclass(frozen=True)
class CornerLegendQuadrantProgram:
    kind = "corner_legend_quadrant_fill"

    @property
    def schema_key(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        frames = _hollow_rectangles(value)
        if len(frames) != 1:
            raise Inapplicable("requires one hollow rectangular frame")
        frame = frames[0]
        r0, c0, r1, c1 = frame["bbox"]
        interior_h, interior_w = r1 - r0 - 1, c1 - c0 - 1
        if interior_h < 2 or interior_w < 2 or interior_h % 2 or interior_w % 2:
            raise Inapplicable("interior must divide into four equal quadrants")
        markers = []
        for r in range(h):
            for c in range(w):
                if value[r][c] == background or (r, c) in frame["cells"]:
                    continue
                if r0 < r < r1 and c0 < c < c1:
                    raise Inapplicable("frame interior is not initially empty")
                markers.append((r, c, value[r][c]))
        if len(markers) != 2 or markers[0][2] == markers[1][2]:
            raise Inapplicable("requires two differently coloured external markers")
        corners = ((r0, c0), (r0, c1), (r1, c0), (r1, c1))
        assignment = {}
        for r, c, colour in markers:
            distances = [abs(r - rr) + abs(c - cc) for rr, cc in corners]
            distance = min(distances)
            if distances.count(distance) != 1:
                raise Inapplicable("marker has no unique nearest frame corner")
            index = distances.index(distance)
            assignment[index] = colour
            assignment[3 - index] = colour
        if len(assignment) != 4:
            raise Inapplicable("legend roles conflict")
        return value, frame, assignment

    def predict(self, value: Grid) -> Grid:
        value, frame, assignment = self.analyse(value)
        r0, c0, r1, c1 = frame["bbox"]
        row_mid = (r0 + r1) // 2
        col_mid = (c0 + c1) // 2
        out = _array(value)
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                top = r <= row_mid
                left = c <= col_mid
                index = 0 if top and left else 1 if top else 2 if left else 3
                out[r][c] = assignment[index]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="hollow_even_rectangle_with_two_external_corner_role_markers",
            relation="nearest_corner_legend_roles_extend_to_opposite_diagonal_quadrants",
            operator="bounded_region_materialisation",
            parameters={},
            definitions={
                "marker_role": "an external singleton with one unique nearest frame corner",
                "opposite_role": "the diagonally opposite corner sharing that marker colour",
                "quadrant": "one of four equal frame-interior regions",
            },
            propositions=[
                "Each marker labels its nearest corner and the opposite diagonal corner.",
                "The two roles jointly label all four quadrants without conflict.",
                "Frame size and marker coordinates remain input-derived.",
            ],
            corollary="Fill the four interior quadrants from the two diagonal corner roles.",
            common_notions=["nearest corner", "diagonal opposition", "quadrant", "legend transfer"],
        )


@dataclass(frozen=True)
class FrameProtectedMarkerBBoxProgram:
    kind = "frame_fill_preserve_marker_bbox"

    @property
    def schema_key(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        value = grid(value)
        background = _background(value)
        candidates = []
        for frame in _hollow_rectangles(value):
            r0, c0, r1, c1 = frame["bbox"]
            markers = [
                (r, c, value[r][c])
                for r in range(r0 + 1, r1)
                for c in range(c0 + 1, c1)
                if value[r][c] != background
            ]
            if not markers:
                continue
            if len({colour for _, _, colour in markers}) != 1:
                continue
            if any(colour == frame["colour"] for _, _, colour in markers):
                continue
            candidates.append((frame, markers))
        if len(candidates) != 1:
            raise Inapplicable("requires one framed marker set")
        frame, markers = candidates[0]
        rows = [r for r, _, _ in markers]
        cols = [c for _, c, _ in markers]
        return value, frame, (min(rows), min(cols), max(rows), max(cols))

    def predict(self, value: Grid) -> Grid:
        value, frame, protected = self.analyse(value)
        background = _background(value)
        r0, c0, r1, c1 = frame["bbox"]
        pr0, pc0, pr1, pc1 = protected
        out = _array(value)
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                if not (pr0 <= r <= pr1 and pc0 <= c <= pc1) and out[r][c] == background:
                    out[r][c] = frame["colour"]
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="hollow_rectangle_with_internal_marker_constellation",
            relation="marker_bounding_box_is_protected_while_remaining_interior_is_frame_material",
            operator="bounded_region_materialisation",
            parameters={},
            definitions={
                "marker_bbox": "the minimum rectangle containing every internal marker",
                "protected_region": "the marker bounding box, retained exactly",
                "cover_region": "all other strict frame-interior cells",
            },
            propositions=[
                "The marker constellation defines the only protected subregion.",
                "Background outside the protected subregion receives the frame material.",
                "Marker cells and background inside their bounding box remain unchanged.",
            ],
            corollary="Materialise the framed interior everywhere except the marker-defined protected box.",
            common_notions=["frame", "bounding box", "protected region", "material cover"],
        )


def _detect_bulged_frame(component):
    points = set(component["cells"])
    min_r, min_c, max_r, max_c = component["bbox"]

    if max_c - min_c >= 4 and max_r - min_r >= 4:
        r0, r1, c0, c1 = min_r, max_r, min_c + 1, max_c - 1
        top = {(r0, c) for c in range(c0, c1 + 1)}
        bottom = {(r1, c) for c in range(c0, c1 + 1)}
        expected = set(top | bottom)
        outer_left = outer_right = False
        valid = top.issubset(points) and bottom.issubset(points)
        for r in range(r0 + 1, r1):
            row_points = {(rr, cc) for rr, cc in points if rr == r}
            allowed = {(r, c0 - 1), (r, c0), (r, c1), (r, c1 + 1)}
            if not row_points or not row_points.issubset(allowed):
                valid = False
                break
            if not ({(r, c0 - 1), (r, c0)} & row_points):
                valid = False
                break
            if not ({(r, c1), (r, c1 + 1)} & row_points):
                valid = False
                break
            outer_left = outer_left or (r, c0 - 1) in row_points
            outer_right = outer_right or (r, c1 + 1) in row_points
            expected.update(row_points)
        if valid and outer_left and outer_right and points == expected:
            return "vertical_reflect", (r0, c0, r1, c1)

    if max_r - min_r >= 4 and max_c - min_c >= 4:
        r0, r1, c0, c1 = min_r + 1, max_r - 1, min_c, max_c
        left = {(r, c0) for r in range(r0, r1 + 1)}
        right = {(r, c1) for r in range(r0, r1 + 1)}
        expected = set(left | right)
        outer_top = outer_bottom = False
        valid = left.issubset(points) and right.issubset(points)
        for c in range(c0 + 1, c1):
            col_points = {(rr, cc) for rr, cc in points if cc == c}
            allowed = {(r0 - 1, c), (r0, c), (r1, c), (r1 + 1, c)}
            if not col_points or not col_points.issubset(allowed):
                valid = False
                break
            if not ({(r0 - 1, c), (r0, c)} & col_points):
                valid = False
                break
            if not ({(r1, c), (r1 + 1, c)} & col_points):
                valid = False
                break
            outer_top = outer_top or (r0 - 1, c) in col_points
            outer_bottom = outer_bottom or (r1 + 1, c) in col_points
            expected.update(col_points)
        if valid and outer_top and outer_bottom and points == expected:
            return "horizontal_reflect", (r0, c0, r1, c1)
    return None


@dataclass(frozen=True)
class BulgedFrameSymmetryProgram:
    kind = "bulged_frame_symmetry_closure"

    @property
    def schema_key(self):
        return (self.kind,)

    def analyse(self, value: Grid):
        value = grid(value)
        background = _background(value)
        frames = []
        for component in _monochrome_components(value):
            detected = _detect_bulged_frame(component)
            if detected:
                frames.append((component, detected))
        if not frames:
            raise Inapplicable("requires at least one bulged symmetry frame")
        analysed = []
        for component, (mode, core) in frames:
            r0, c0, r1, c1 = core
            payload = [
                (r, c, value[r][c])
                for r in range(r0 + 1, r1)
                for c in range(c0 + 1, c1)
                if value[r][c] not in (background, component["colour"])
            ]
            if not payload or len({colour for _, _, colour in payload}) != 1:
                raise Inapplicable("each bulged frame needs one payload colour")
            analysed.append((component, mode, core, payload))
        return value, analysed

    def predict(self, value: Grid) -> Grid:
        value, analysed = self.analyse(value)
        background = _background(value)
        out = _array(value)
        for component, mode, (r0, c0, r1, c1), payload in analysed:
            for r, c, colour in payload:
                if mode == "vertical_reflect":
                    target = (r, c0 + c1 - c)
                else:
                    target = (r0 + r1 - r, c)
                tr, tc = target
                if out[tr][tc] not in (background, colour):
                    raise Inapplicable("reflected payload conflicts")
                out[tr][tc] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="one_or_more_rectangular_frames_with_opposite_side_bulges_and_internal_payload",
            relation="bulged_sides_select_the_reflection_axis_for_payload_closure",
            operator="bounded_region_materialisation",
            parameters={},
            definitions={
                "bulge_axis": "the opposite sides whose middle segment is displaced outward",
                "reflection_axis": "the perpendicular centre axis of the core frame",
                "payload": "the single-colour pattern strictly inside the frame",
            },
            propositions=[
                "Left/right bulges request vertical-axis reflection.",
                "Top/bottom bulges request horizontal-axis reflection.",
                "Existing payload cells and frame material are preserved.",
            ],
            corollary="Close every framed payload under the axis selected by the frame bulges.",
            common_notions=["typed frame", "axis role", "reflection", "bounded completion"],
        )


# ---------------------------------------------------------------------------
# Shared operator III: interval-graph cover emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class StrictInteriorRectangleBridgeProgram:
    paint_colour: int

    kind = "strict_interior_rectangle_bridge"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour

    def analyse(self, value: Grid):
        value = grid(value)
        rectangles = [component for component in _monochrome_components(value) if _solid_rectangle(component)]
        if len(rectangles) != 2:
            raise Inapplicable("requires exactly two solid rectangular nodes")
        first, second = rectangles
        ar0, ac0, ar1, ac1 = first["bbox"]
        br0, bc0, br1, bc1 = second["bbox"]
        regions = []

        if ac1 < bc0 - 1 or bc1 < ac0 - 1:
            first_h, second_h = ar1 - ar0 + 1, br1 - br0 + 1
            if first_h != second_h:
                sr0, sr1 = (ar0, ar1) if first_h < second_h else (br0, br1)
                if sr1 - sr0 >= 2:
                    columns = range(ac1 + 1, bc0) if ac1 < bc0 else range(bc1 + 1, ac0)
                    regions.append({(r, c) for r in range(sr0 + 1, sr1) for c in columns})

        if ar1 < br0 - 1 or br1 < ar0 - 1:
            first_w, second_w = ac1 - ac0 + 1, bc1 - bc0 + 1
            if first_w != second_w:
                sc0, sc1 = (ac0, ac1) if first_w < second_w else (bc0, bc1)
                if sc1 - sc0 >= 2:
                    rows = range(ar1 + 1, br0) if ar1 < br0 else range(br1 + 1, ar0)
                    regions.append({(r, c) for r in rows for c in range(sc0 + 1, sc1)})

        regions = [region for region in regions if region]
        if len(regions) != 1:
            raise Inapplicable("rectangle relation does not define one bridge")
        return value, regions[0]

    def predict(self, value: Grid) -> Grid:
        value, region = self.analyse(value)
        background = _background(value)
        if self.paint_colour == background:
            raise Inapplicable("bridge colour equals background")
        out = _array(value)
        for r, c in region:
            if out[r][c] != background:
                raise Inapplicable("bridge intersects existing material")
            out[r][c] = self.paint_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="two_separated_solid_rectangles_with_unequal_perpendicular_spans",
            relation="open_separation_interval_cross_strict_interior_of_the_narrower_rectangle",
            operator="interval_graph_cover_emission",
            parameters={"paint_colour": self.paint_colour},
            definitions={
                "separation_interval": "the open rows or columns between the two rectangles",
                "narrower_span": "the shorter rectangle extent perpendicular to separation",
                "strict_interior": "that span with both boundary lanes removed",
            },
            propositions=[
                "Exactly one separation axis must define a nonempty bridge.",
                "The bridge width is the strict interior of the narrower endpoint.",
                "Both endpoint rectangles remain intact.",
            ],
            corollary="Cover the typed open interval between the rectangles with the bridge material.",
            common_notions=["rectangle node", "open interval", "strict interior", "bridge"],
        )


@dataclass(frozen=True)
class SeparatorOverlapComplementProgram:
    paint_colour: int
    axis: str

    kind = "separator_overlap_complement_fill"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.axis

    def _horizontal(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        separators = [
            r
            for r in range(1, h - 1)
            if len(set(value[r])) == 1 and value[r][0] != background
        ]
        if len(separators) != 1:
            raise Inapplicable("requires one complete separator lane")
        separator = separators[0]
        top = _runs(value[0], background)
        bottom = _runs(value[h - 1], background)
        if len(top) != 1 or len(bottom) != 1:
            raise Inapplicable("requires one boundary interval on each side")
        ta, tb, top_colour = top[0]
        ba, bb, bottom_colour = bottom[0]
        if top_colour != bottom_colour or top_colour == value[separator][0]:
            raise Inapplicable("boundary intervals do not share a role")
        overlap_start, overlap_end = max(ta, ba), min(tb, bb)
        if overlap_start > overlap_end:
            raise Inapplicable("boundary intervals do not overlap")
        top_length, bottom_length = tb - ta + 1, bb - ba + 1
        if top_length == bottom_length:
            raise Inapplicable("longer-side role is ambiguous")
        rows = range(1, separator) if top_length > bottom_length else range(separator + 1, h - 1)
        return value, rows, range(overlap_start, overlap_end + 1)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        if self.axis == "vertical":
            return _transpose(
                SeparatorOverlapComplementProgram(self.paint_colour, "horizontal").predict(_transpose(value))
            )
        if self.axis != "horizontal":
            raise Inapplicable("unknown separator axis")
        value, rows, columns = self._horizontal(value)
        background = _background(value)
        if self.paint_colour == background:
            raise Inapplicable("cover colour equals background")
        out = _array(value)
        for r in rows:
            for c in columns:
                if out[r][c] != background:
                    raise Inapplicable("cover intersects existing material")
                out[r][c] = self.paint_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            scene="complete_separator_between_two_same_role_boundary_intervals",
            relation="interval_intersection_projects_from_separator_toward_the_longer_boundary_interval",
            operator="interval_graph_cover_emission",
            parameters={"paint_colour": self.paint_colour, "axis": self.axis},
            definitions={
                "boundary_interval": "a single same-colour run on each opposite canvas boundary",
                "overlap": "the intersection of the two interval coordinates",
                "longer_side": "the side whose boundary interval has greater extent",
            },
            propositions=[
                "The two boundary intervals share one role colour.",
                "Their coordinate overlap defines the cover width.",
                "The cover occupies the open region between the longer interval and separator.",
            ],
            corollary="Materialise the overlap complement on the uniquely longer side of the separator.",
            common_notions=["separator", "interval intersection", "longer-side role", "cover"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and proof obligations.
# ---------------------------------------------------------------------------


def _fit_palette_broadcast(pairs):
    output = []
    for direction in ("down", "up", "right", "left"):
        program = SeparatorPaletteBroadcastProgram(direction)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                output.append(program)
        except Inapplicable:
            pass
    return output


def _fit_edge_motif(pairs):
    output = []
    for direction in ("right", "left", "down", "up"):
        program = EdgeMotifFieldProgram(direction)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                output.append(program)
        except Inapplicable:
            pass
    return output


def _fit_parameterless(pairs, cls):
    program = cls()
    try:
        return [program] if all(program.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_strict_bridge(pairs):
    try:
        program = StrictInteriorRectangleBridgeProgram(_single_paint_colour(pairs))
        return [program] if all(program.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_separator_overlap(pairs):
    try:
        paint_colour = _single_paint_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for axis in ("horizontal", "vertical"):
        program = SeparatorOverlapComplementProgram(paint_colour, axis)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                output.append(program)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "separator_palette_broadcast": _fit_palette_broadcast,
    "edge_motif_field_completion": _fit_edge_motif,
    "diagonal_palette_nested_frame": lambda pairs: _fit_parameterless(pairs, DiagonalPaletteNestedFrameProgram),
    "corner_legend_quadrant_fill": lambda pairs: _fit_parameterless(pairs, CornerLegendQuadrantProgram),
    "frame_fill_preserve_marker_bbox": lambda pairs: _fit_parameterless(pairs, FrameProtectedMarkerBBoxProgram),
    "bulged_frame_symmetry_closure": lambda pairs: _fit_parameterless(pairs, BulgedFrameSymmetryProgram),
    "strict_interior_rectangle_bridge": _fit_strict_bridge,
    "separator_overlap_complement_fill": _fit_separator_overlap,
}


def fit_graph_constructor_grammar_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    programmes = []
    seen = set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            fitted = fitter(pairs)
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            continue
        for programme in fitted:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                programmes.append(programme)
    return programmes


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background = _background(source)
        passed = False
        detail = {}
        try:
            original = programme.predict(source)
            work = _array(source)
            causal = None
            for r in range(len(source)):
                for c in range(len(source[0])):
                    if source[r][c] != background:
                        causal = (r, c)
                        break
                if causal is not None:
                    break
            if causal is None:
                raise Inapplicable("no causal node")
            r, c = causal
            work[r][c] = background
            try:
                passed = programme.predict(tuple(tuple(row) for row in work)) != original
            except Inapplicable:
                passed = True
            detail = {"node_removal_changes_or_rejects": bool(passed), "removed_role": "first_structural_node"}
        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError, ZeroDivisionError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **detail})
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_graph_constructor_grammar(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_graph_constructor_grammar_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "graph_constructor_grammar": True,
            "bounded_relation_chain": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = []
    for programme in fit_graph_constructor_grammar_programs(pairs, minimum_pairs=2, allowed_kinds=allowed):
        try:
            if (
                tuple(programme.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(programme, pairs).get("passed")
            ):
                programmes.append(programme)
        except Inapplicable:
            pass
    return expected, programmes


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_graph_constructor_grammar_programs(
            remaining,
            minimum_pairs=1,
            allowed_kinds=(programme.kind,),
        )
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append(
            {
                "held_index": held_index,
                "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
                "held_example_exact": bool(held_exact),
                "test_prediction_stable": stable,
                "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
                "refitted_programs": len(refitted),
                "held_exact_prediction_groups": len(groups),
            }
        )
    counterfactual = _counterfactual(programme, full_pairs)
    passed = (
        all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds)
        and counterfactual.get("passed")
    )
    return {
        "passed": bool(passed),
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_graph_constructor_grammar(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check.get("passed") for check in checks)
    selected = next((check for check in checks if check.get("passed")), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check.get("counterfactuals", [])],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
