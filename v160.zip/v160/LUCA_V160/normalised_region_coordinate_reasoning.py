"""LUCA V153: normalised region-coordinate materialisation.

This family unifies three input-derived region transformations under a single
coordinate/materialisation operator:

    connected supports -> lower normalised half -> recolour selected material
    outline frame -> strict-interior colour roles -> swap the two payload roles

The family is task-ID blind and test-target blind. Background, source, target,
frame, payload and phase colours are learned from demonstrations or inferred
from the current input. No absolute demonstration coordinates are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_normalised_region_coordinate_grammar"
LANGUAGE = "spinoza_normalised_region_coordinate_grammar_v153"
SCHEMA_VERSION = 1
OPERATOR = "normalised_region_coordinate_materialisation"
NODE_VOCABULARY = "connected_support_and_outline_region_nodes"
EDGE_VOCABULARY = "normalised_axis_fraction_border_distance_and_colour_role_edges"


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "normalised_region_coordinate_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "normalised_region_coordinates": True,
            "shared_region_coordinate_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _common_input_colours(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes:
        return ()
    return tuple(sorted(set.intersection(*palettes)))


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int, connectivity: int = 4):
    value = grid(value)
    h, w = _shape(value)
    remaining = {
        (r, c)
        for r in range(h)
        for c in range(w)
        if value[r][c] == colour
    }
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            neighbours = [(r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)]
            if connectivity == 8:
                neighbours.extend(((r - 1, c - 1), (r - 1, c + 1), (r + 1, c - 1), (r + 1, c + 1)))
            for neighbour in neighbours:
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    stack.append(neighbour)
        output.append(frozenset(component))
    output.sort(key=lambda comp: (_bbox(comp), len(comp)))
    return tuple(output)


def _outline_rectangle(component):
    r0, c0, r1, c1 = _bbox(component)
    if r1 - r0 + 1 < 3 or c1 - c0 + 1 < 3:
        raise Inapplicable("outline rectangle is too small")
    border = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }
    if set(component) != border:
        raise Inapplicable("component is not a one-cell outline rectangle")
    return r0, c0, r1, c1


def _unique_outline_frame(value: Grid, frame_colour: int):
    candidates = []
    for component in _components_of_colour(value, frame_colour):
        try:
            candidates.append((_outline_rectangle(component), component))
        except Inapplicable:
            continue
    if len(candidates) != 1:
        raise Inapplicable("a unique one-cell outline frame is required")
    return candidates[0]


def _changed_pair(source: Grid, target: Grid):
    source, target = grid(source), grid(target)
    if _shape(source) != _shape(target):
        raise Inapplicable("shape-preserving recolour is required")
    pairs = {
        (source[r][c], target[r][c])
        for r in range(len(source))
        for c in range(len(source[0]))
        if source[r][c] != target[r][c]
    }
    if len(pairs) != 1:
        raise Inapplicable("one source-to-target colour role is required")
    return next(iter(pairs))


@dataclass(frozen=True)
class LowerHalfComponentRecolourProgram:
    background: int
    source_colour: int
    target_colour: int

    kind = "component_lower_half_recolour"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.source_colour, self.target_colour

    def _scene(self, value: Grid):
        value = grid(value)
        if _palette(value) != {self.background, self.source_colour}:
            raise Inapplicable("the scene must contain one foreground role and one background role")
        components = _components_of_colour(value, self.source_colour, connectivity=8)
        if not components:
            raise Inapplicable("foreground components are required")
        records = []
        for component in components:
            r0, c0, r1, c1 = _bbox(component)
            height = r1 - r0 + 1
            if height < 2:
                raise Inapplicable("each component must span at least two rows")
            cut = r1 - height // 2 + 1
            lower = frozenset((r, c) for r, c in component if r >= cut)
            upper = frozenset(component - lower)
            if not lower or not upper:
                raise Inapplicable("both upper and lower coordinate roles are required")
            records.append((component, lower, upper, (height, c1 - c0 + 1)))
        return tuple(records)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        records = self._scene(value)
        output = _array(value)
        changed = False
        for _, lower, _, _ in records:
            for r, c in lower:
                changed |= output[r][c] != self.target_colour
                output[r][c] = self.target_colour
        if not changed:
            raise Inapplicable("the lower-half materialisation must change the grid")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one-colour connected supports embedded in a shared background",
            relation_chain=(
                "extract each connected foreground support and its bounding box",
                "normalise every support cell to its vertical coordinate within that box",
                "select the final floor(height/2) rows of each support",
                "recolour only the selected lower-half material while preserving geometry",
            ),
            parameters={
                "background": self.background,
                "source_colour": self.source_colour,
                "target_colour": self.target_colour,
                "vertical_fraction": "lower floor half",
            },
            corollary="Recolour the lower normalised half of every connected support.",
            notions=["connected support", "normalised row coordinate", "lower half", "support-preserving recolour"],
        )


@dataclass(frozen=True)
class FramedPayloadPairSwapProgram:
    background: int
    frame_colour: int

    kind = "framed_payload_pair_swap"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.frame_colour

    def _scene(self, value: Grid):
        value = grid(value)
        (r0, c0, r1, c1), _ = _unique_outline_frame(value, self.frame_colour)
        interior = {
            (r, c)
            for r in range(r0 + 1, r1)
            for c in range(c0 + 1, c1)
        }
        if not interior:
            raise Inapplicable("the frame needs a strict interior")
        payload = sorted({value[r][c] for r, c in interior} - {self.background, self.frame_colour})
        if len(payload) != 2:
            raise Inapplicable("the strict interior must expose exactly two payload colour roles")
        if not all(any(value[r][c] == colour for r, c in interior) for colour in payload):
            raise Inapplicable("both payload roles must be witnessed")
        return (r0, c0, r1, c1), tuple(payload)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        (r0, c0, r1, c1), (first, second) = self._scene(value)
        output = _array(value)
        changed = False
        for r in range(r0 + 1, r1):
            for c in range(c0 + 1, c1):
                if value[r][c] == first:
                    output[r][c] = second
                    changed = True
                elif value[r][c] == second:
                    output[r][c] = first
                    changed = True
        if not changed:
            raise Inapplicable("payload swapping must change the strict interior")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="a unique outline frame whose strict interior contains background plus two payload colours",
            relation_chain=(
                "extract the unique one-cell outline frame",
                "restrict the relation to its strict interior",
                "infer the two non-background payload colour roles from the current input",
                "swap those roles inside the frame while leaving the frame and exterior unchanged",
            ),
            parameters={"background": self.background, "frame_colour": self.frame_colour},
            corollary="Exchange the two payload colours only within the framed region.",
            notions=["outline frame", "strict interior", "payload colour role", "local colour permutation"],
        )


def _fit_lower_half(pairs):
    try:
        changed_pairs = [_changed_pair(source, target) for source, target in pairs]
    except Inapplicable:
        return []
    if len(set(changed_pairs)) != 1:
        return []
    source_colour, target_colour = changed_pairs[0]
    output = []
    for background in _common_input_colours(pairs):
        if background in (source_colour, target_colour):
            continue
        programme = LowerHalfComponentRecolourProgram(background, source_colour, target_colour)
        dimensions = set()
        total_components = 0
        valid = True
        for source, target in pairs:
            try:
                records = programme._scene(source)
                total_components += len(records)
                dimensions.update(record[3] for record in records)
                if programme.predict(source) != grid(target):
                    valid = False
                    break
            except Inapplicable:
                valid = False
                break
        if valid and total_components >= len(pairs) and len(dimensions) >= 2:
            output.append(programme)
    return output


def _fit_payload_swap(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background in common:
        for frame_colour in common:
            if background == frame_colour:
                continue
            programme = FramedPayloadPairSwapProgram(background, frame_colour)
            role_pairs = set()
            valid = True
            for source, target in pairs:
                try:
                    _, payload = programme._scene(source)
                    role_pairs.add(payload)
                    if programme.predict(source) != grid(target):
                        valid = False
                        break
                except Inapplicable:
                    valid = False
                    break
            if valid and len(role_pairs) >= min(2, len(pairs)):
                output.append(programme)
    return output



_FITTERS = {
    "component_lower_half_recolour": _fit_lower_half,
    "framed_payload_pair_swap": _fit_payload_swap,
}


def fit_normalised_region_coordinate_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, LowerHalfComponentRecolourProgram):
                records = programme._scene(source)
                for component, _, _, _ in records:
                    r0, _, r1, _ = _bbox(component)
                    top_cells = sorted((r, c) for r, c in component if r == r0)
                    bottom_cells = sorted((r, c) for r, c in component if r == r1)
                    for r, c in top_cells + bottom_cells:
                        candidates.append((r, c, programme.background, "support_extent"))
            elif isinstance(programme, FramedPayloadPairSwapProgram):
                (r0, c0, _, _), _ = programme._scene(source)
                candidates.append((r0, c0, programme.background, "frame_corner"))
        except Inapplicable:
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {"cell": [r, c], "from": int(previous), "to": int(replacement), "role": role}
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {"kind": programme.kind, "rows": rows, "passed": bool(rows) and all(row["passed"] for row in rows)}


def infer_normalised_region_coordinate_grammar(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_normalised_region_coordinate_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "normalised_region_coordinates": True,
            "shared_region_coordinate_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_normalised_region_coordinate_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_normalised_region_coordinate_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_normalised_region_coordinate_grammar(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
