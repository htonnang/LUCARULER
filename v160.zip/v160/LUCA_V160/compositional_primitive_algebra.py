"""LUCA V128: compositional primitive algebra.

The family exposes conservative, proof-carrying primitives which share one
programme skeleton::

    source abstraction -> relation / quantity -> primitive operator
                       -> boundary policy -> typed emission

Schemas:

* ``row_uniformity_codebook``;
* ``row_marker_position_codebook``;
* ``paired_colour_complement``;
* ``clipped_translation``;
* ``canonical_count_glyph``;
* ``boundary_replica_expansion``;
* ``cyclic_border_growth``;
* ``v_lattice_continuation``.

No task identifier, official target, or stored demonstration coordinate is
available during inference. Exact training fit is necessary but not
sufficient: programmes must agree on the unseen prediction, survive
held-demonstration refitting, and pass schema-specific counterfactual tests.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_compositional_primitive_algebra"
LANGUAGE = "spinoza_compositional_primitive_algebra_v1"
SCHEMA_VERSION = "compositional_primitive_algebra_schema_v1"

# Stable ARC semantic pairs used by the paired-colour complement primitive.
# Each pair is involutive; no task-level output lookup is stored.
ARC_COLOUR_PAIRS = {1: 3, 3: 1, 2: 8, 8: 2, 4: 5, 5: 4}


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    best = max(counts.values())
    modes = [colour for colour, count in counts.items() if count == best]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _transpose(value: Grid) -> Grid:
    value = grid(value)
    return tuple(tuple(value[row][col] for row in range(len(value))) for col in range(len(value[0])))


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _safe_predict(program, source):
    try:
        return program.predict(source)
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
        raise Inapplicable("programme became inapplicable")


# ---------------------------------------------------------------------------
# Row-wise codebooks.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RowUniformityCodebookProgram:
    orientation: str
    uniform_colour: int
    nonuniform_colour: int
    kind: str = "row_uniformity_codebook"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.uniform_colour, self.nonuniform_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        work = _transpose(value) if self.orientation == "column" else value
        rows = []
        result = []
        for row in work:
            uniform = len(set(row)) == 1
            rows.append(uniform)
            colour = self.uniform_colour if uniform else self.nonuniform_colour
            result.append(tuple(colour for _ in row))
        prediction = tuple(result)
        if self.orientation == "column":
            prediction = _transpose(prediction)
        return {"uniformity": rows, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "orientation": self.orientation,
                "uniform_colour": self.uniform_colour,
                "nonuniform_colour": self.nonuniform_colour,
            },
            definitions=[
                {"name": "AxisLine", "type": "Grid x Orientation -> Sequence[Line]"},
                {"name": "UniformityPredicate", "type": "Line -> Bool"},
                {"name": "RowCodebookEmitter", "type": "Bool x ColourMap -> Line"},
            ],
            propositions=[
                {"index": 1, "definition": "ClassifyAxisLines", "effect": "test whether each row/column is uniform"},
                {"index": 2, "definition": "EmitClassColour", "effect": "replace each line with its learned class colour"},
            ],
            corollary="row-wise structural predicates can be emitted through a learned two-class codebook",
            common_notions=[{
                "name": "line_uniformity_evidence",
                "evidence": [self.analyse(source)["uniformity"] for source, _ in pairs],
            }],
        )


@dataclass(frozen=True)
class RowMarkerPositionCodebookProgram:
    orientation: str
    background_colour: int
    mapping: tuple[tuple[int, int], ...]
    kind: str = "row_marker_position_codebook"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.background_colour, self.mapping

    @property
    def description_length(self):
        return 4 + len(self.mapping)

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        work = _transpose(value) if self.orientation == "column" else value
        codebook = dict(self.mapping)
        positions = []
        result = []
        for row in work:
            indices = [index for index, cell in enumerate(row) if cell != self.background_colour]
            if len(indices) != 1:
                raise Inapplicable("every axis line must contain exactly one marker")
            position = indices[0]
            if position not in codebook:
                raise Inapplicable("marker role is absent from the learned codebook")
            positions.append(position)
            result.append(tuple(codebook[position] for _ in row))
        prediction = tuple(result)
        if self.orientation == "column":
            prediction = _transpose(prediction)
        return {"positions": positions, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "orientation": self.orientation,
                "background_colour": self.background_colour,
                "mapping": [list(item) for item in self.mapping],
            },
            definitions=[
                {"name": "SingletonMarkerPosition", "type": "Line x Background -> Index"},
                {"name": "PositionCodebook", "type": "Index -> Colour"},
            ],
            propositions=[
                {"index": 1, "definition": "BindMarkerPosition", "effect": "locate the unique nonbackground cell in each line"},
                {"index": 2, "definition": "EmitPositionClass", "effect": "fill the line with the colour assigned to that relative position"},
            ],
            corollary="relative marker position controls a row-wise codebook independently of absolute row index",
            common_notions=[{
                "name": "marker_position_evidence",
                "evidence": [self.analyse(source)["positions"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Paired-colour complement.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PairedColourComplementProgram:
    background_colour: int
    kind: str = "paired_colour_complement"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        palette = _palette(value)
        foreground = palette - {self.background_colour}
        if len(foreground) != 1:
            raise Inapplicable("paired complement requires one foreground colour")
        source_colour = next(iter(foreground))
        if source_colour not in ARC_COLOUR_PAIRS:
            raise Inapplicable("foreground colour has no stable pair")
        target_colour = ARC_COLOUR_PAIRS[source_colour]
        result = tuple(
            tuple(target_colour if cell == self.background_colour else self.background_colour for cell in row)
            for row in value
        )
        return {
            "source_colour": source_colour,
            "target_colour": target_colour,
            "prediction": result,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "colour_pairing": "ARC_COLOUR_PAIRS"},
            definitions=[
                {"name": "BinarySupportComplement", "type": "Grid x Background -> BinaryMask"},
                {"name": "PairedColour", "type": "Colour -> Colour"},
            ],
            propositions=[
                {"index": 1, "definition": "ComplementSupport", "effect": "select background cells rather than source foreground cells"},
                {"index": 2, "definition": "ApplyPairedColour", "effect": "colour the complemented support with the source colour's stable pair"},
            ],
            corollary="support complementation and semantic colour pairing compose into one equivariant operation",
            common_notions=[{
                "name": "paired_colour_evidence",
                "evidence": [self.analyse(source)["source_colour"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Clipped translation.
# ---------------------------------------------------------------------------


def _shift(value: Grid, dr: int, dc: int, background: int) -> Grid:
    value = grid(value)
    height, width = _shape(value)
    result = [[background for _ in range(width)] for _ in range(height)]
    for row in range(height):
        for col in range(width):
            target_row, target_col = row + dr, col + dc
            if 0 <= target_row < height and 0 <= target_col < width:
                result[target_row][target_col] = value[row][col]
    return tuple(tuple(row) for row in result)


@dataclass(frozen=True)
class ClippedTranslationProgram:
    background_colour: int
    dr: int
    dc: int
    kind: str = "clipped_translation"

    @property
    def schema_key(self):
        return self.kind, self.background_colour, self.dr, self.dc

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def predict(self, value: Grid) -> Grid:
        if self.dr == 0 and self.dc == 0:
            raise Inapplicable("identity is not a translation programme")
        return _shift(value, self.dr, self.dc, self.background_colour)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour, "dr": self.dr, "dc": self.dc},
            definitions=[
                {"name": "TranslationVector", "type": "Integer x Integer"},
                {"name": "ClippedTransport", "type": "Grid x Vector x Background -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindTranslation", "effect": "infer one displacement shared by all demonstrations"},
                {"index": 2, "definition": "TranslateWithClipping", "effect": "move every source cell and fill newly exposed cells with background"},
            ],
            corollary="one coordinate-free displacement explains all examples",
            common_notions=[{"name": "translation_vector", "value": [self.dr, self.dc]}],
        )


# ---------------------------------------------------------------------------
# Count-to-glyph projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CanonicalCountGlyphProgram:
    input_background: int
    output_background: int
    output_colour: int
    output_height: int
    output_width: int
    ordered_cells: tuple[tuple[int, int], ...]
    kind: str = "canonical_count_glyph"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.input_background,
            self.output_background,
            self.output_colour,
            self.output_height,
            self.output_width,
            self.ordered_cells,
        )

    @property
    def description_length(self):
        return 6 + len(self.ordered_cells)

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        quantity = sum(cell != self.input_background for row in value for cell in row)
        if quantity < 1 or quantity > len(self.ordered_cells):
            raise Inapplicable("quantity is outside the learned glyph range")
        result = [[self.output_background for _ in range(self.output_width)] for _ in range(self.output_height)]
        for row, col in self.ordered_cells[:quantity]:
            result[row][col] = self.output_colour
        return {"quantity": quantity, "prediction": tuple(tuple(row) for row in result)}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "input_background": self.input_background,
                "output_background": self.output_background,
                "output_colour": self.output_colour,
                "output_shape": [self.output_height, self.output_width],
                "ordered_cells": [list(cell) for cell in self.ordered_cells],
            },
            definitions=[
                {"name": "ForegroundQuantity", "type": "Grid x Background -> Integer"},
                {"name": "CanonicalGlyphOrder", "type": "Integer -> Sequence[Coordinate]"},
            ],
            propositions=[
                {"index": 1, "definition": "CountMaterial", "effect": "measure nonbackground source cells"},
                {"index": 2, "definition": "ProjectCountGlyph", "effect": "emit the first n cells of the learned canonical order"},
            ],
            corollary="one ordered glyph basis encodes multiple source quantities",
            common_notions=[{
                "name": "count_evidence",
                "evidence": [self.analyse(source)["quantity"] for source, _ in pairs],
            }],
        )


# ---------------------------------------------------------------------------
# Boundary self-replication.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BoundaryReplicaExpansionProgram:
    background_colour: int
    kind: str = "boundary_replica_expansion"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height != width or height < 2 or height > 8:
            raise Inapplicable("boundary-replica source must be a small square")
        foreground = _palette(value) - {self.background_colour}
        if len(foreground) != 1:
            raise Inapplicable("boundary-replica source must be binary")
        colour = next(iter(foreground))
        size = height
        macro = size + 2
        result = [[self.background_colour for _ in range(macro * size)] for _ in range(macro * size)]

        def paint_block(block_row, block_col, block):
            for row in range(size):
                for col in range(size):
                    result[block_row * size + row][block_col * size + col] = block[row][col]

        solid = tuple(tuple(colour for _ in range(size)) for _ in range(size))
        for row in range(size):
            for col in range(size):
                if value[row][col] == self.background_colour:
                    continue
                paint_block(row + 1, col + 1, solid)
                if row == 0:
                    paint_block(0, col + 1, value)
                if row == size - 1:
                    paint_block(size + 1, col + 1, value)
                if col == 0:
                    paint_block(row + 1, 0, value)
                if col == size - 1:
                    paint_block(row + 1, size + 1, value)
        return {"foreground_colour": colour, "prediction": tuple(tuple(row) for row in result)}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "CentralMacroEmbedding", "type": "BinaryGrid -> MacroGrid"},
                {"name": "BoundarySelfReplica", "type": "BoundaryCell -> SourceGridBlock"},
            ],
            propositions=[
                {"index": 1, "definition": "EmbedForegroundAsSolidBlocks", "effect": "place full blocks in the central macro region"},
                {"index": 2, "definition": "ReplicateBoundaryEvidence", "effect": "place source-pattern copies outside every active boundary role"},
            ],
            corollary="boundary roles recursively emit the source pattern while interior roles emit solid material",
            common_notions=[{"name": "boundary_replication", "value": True}],
        )


# ---------------------------------------------------------------------------
# Cyclic border recursion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CyclicBorderGrowthProgram:
    kind: str = "cyclic_border_growth"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        size, width = _shape(value)
        if size != width or size < 5 or size % 2 == 0:
            raise Inapplicable("cyclic-border source must be an odd square")
        if len(_palette(value)) != 3:
            raise Inapplicable("cyclic-border source requires three role colours")
        corner = value[0][0]
        if any(value[row][col] != corner for row, col in ((0, size - 1), (size - 1, 0), (size - 1, size - 1))):
            raise Inapplicable("all corners must share one role colour")
        corner_cells = {(0, 0), (0, size - 1), (size - 1, 0), (size - 1, size - 1)}
        if any(value[row][col] == corner and (row, col) not in corner_cells for row in range(size) for col in range(size)):
            raise Inapplicable("corner colour must be role-specific")
        centre = size // 2
        centre_colour = value[centre][centre]
        plus_cells = {(centre, centre), (centre - 1, centre), (centre + 1, centre), (centre, centre - 1), (centre, centre + 1)}
        if any(value[row][col] != centre_colour for row, col in plus_cells):
            raise Inapplicable("centre colour must form a radius-one plus")
        if any(value[row][col] == centre_colour and (row, col) not in plus_cells for row in range(size) for col in range(size)):
            raise Inapplicable("centre colour must be role-specific")
        remaining = _palette(value) - {corner, centre_colour}
        if len(remaining) != 1:
            raise Inapplicable("background role is ambiguous")
        field = next(iter(remaining))
        cycle = (corner, centre_colour, field)
        output_size = 2 * size
        result = [[field for _ in range(output_size)] for _ in range(output_size)]
        for row in range(size):
            for col in range(size):
                result[row][col] = value[row][col]
        for index in range(size, output_size):
            base = cycle[(index - size) % len(cycle)]
            turn = cycle[(index - size + 1) % len(cycle)]
            for coordinate in range(index):
                result[index][coordinate] = base
                result[coordinate][index] = base
            result[index][index] = turn
        return {"cycle": cycle, "prediction": tuple(tuple(row) for row in result)}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={"role_order": ["corner", "centre", "field"]},
            definitions=[
                {"name": "SemanticRoleCycle", "type": "Corner x Centre x Field -> ColourCycle"},
                {"name": "TopLeftBorderGrowth", "type": "Grid x ColourCycle -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindRoleColours", "effect": "derive corner, centre-plus, and field roles"},
                {"index": 2, "definition": "AppendCyclicBorders", "effect": "grow bottom/right borders using the role cycle"},
            ],
            corollary="semantic role order controls recursive square-border growth",
            common_notions=[{"name": "role_cycle_evidence", "evidence": [list(self.analyse(source)["cycle"]) for source, _ in pairs]}],
        )


# ---------------------------------------------------------------------------
# V-lattice continuation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class VLatticeContinuationProgram:
    orientation: str
    background_colour: int
    secondary_colour: int
    period: int
    start_row: int
    kind: str = "v_lattice_continuation"

    @property
    def schema_key(self):
        return self.kind, self.orientation, self.background_colour, self.secondary_colour, self.period, self.start_row

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        if self.orientation == "vertical":
            value = _transpose(value)
        height, width = _shape(value)
        if height != 1 or width < 5 or width % 2 == 0:
            raise Inapplicable("V-lattice source must be a one-dimensional odd sequence")
        foreground = [(col, value[0][col]) for col in range(width) if value[0][col] != self.background_colour]
        if len(foreground) != 1 or foreground[0][0] != width // 2:
            raise Inapplicable("source must contain one centred marker")
        marker_colour = foreground[0][1]
        if marker_colour == self.secondary_colour or self.secondary_colour == self.background_colour:
            raise Inapplicable("role colours must be distinct")
        centre = width // 2
        result = [[self.background_colour for _ in range(width)] for _ in range(width)]
        for row in range(centre + 1):
            result[row][centre - row] = marker_colour
            result[row][centre + row] = marker_colour
        for row in range(self.start_row, width):
            residue = (row + centre) % self.period
            for col in range(width):
                if col % self.period != residue:
                    continue
                if row <= centre and not (centre - row < col < centre + row):
                    continue
                if result[row][col] == self.background_colour:
                    result[row][col] = self.secondary_colour
        prediction = tuple(tuple(row) for row in result)
        if self.orientation == "vertical":
            prediction = _transpose(prediction)
        return {"marker_colour": marker_colour, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "orientation": self.orientation,
                "background_colour": self.background_colour,
                "secondary_colour": self.secondary_colour,
                "period": self.period,
                "start_row": self.start_row,
            },
            definitions=[
                {"name": "CentredMarker", "type": "Sequence -> Colour"},
                {"name": "ExpandingV", "type": "Marker x Width -> Grid"},
                {"name": "PeriodicInteriorLattice", "type": "Period x Phase x Region -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "EmitExpandingV", "effect": "draw two primary diagonals from the centred marker"},
                {"index": 2, "definition": "ContinuePeriodicInterior", "effect": "fill a phase-locked secondary lattice inside and below the V"},
            ],
            corollary="a one-dimensional centred instruction generates a V boundary and periodic interior continuation",
            common_notions=[{"name": "periodic_lattice", "period": self.period, "start_row": self.start_row}],
        )


# ---------------------------------------------------------------------------
# Fitters.
# ---------------------------------------------------------------------------


def _candidate_backgrounds(pairs):
    candidates = None
    for source, _ in pairs:
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_unique_mode(source))
        except Inapplicable:
            pass
        candidates = values if candidates is None else candidates & values
    return sorted(candidates or ())


def _fit_row_uniformity(pairs):
    programmes = []
    for orientation in ("row", "column"):
        mapping = {}
        evidence = set()
        valid = True
        for source, target in pairs:
            source = _transpose(source) if orientation == "column" else grid(source)
            target = _transpose(target) if orientation == "column" else grid(target)
            if _shape(source) != _shape(target):
                valid = False
                break
            for source_row, target_row in zip(source, target):
                if len(set(target_row)) != 1:
                    valid = False
                    break
                feature = len(set(source_row)) == 1
                colour = target_row[0]
                if feature in mapping and mapping[feature] != colour:
                    valid = False
                    break
                mapping[feature] = colour
                evidence.add(feature)
            if not valid:
                break
        if valid and evidence == {False, True} and mapping[False] != mapping[True]:
            programmes.append(RowUniformityCodebookProgram(orientation, mapping[True], mapping[False]))
    return programmes


def _fit_row_marker_codebook(pairs):
    programmes = []
    for orientation in ("row", "column"):
        for background in _candidate_backgrounds(pairs):
            mapping = {}
            positions = set()
            valid = True
            for source, target in pairs:
                source = _transpose(source) if orientation == "column" else grid(source)
                target = _transpose(target) if orientation == "column" else grid(target)
                if _shape(source) != _shape(target):
                    valid = False
                    break
                for source_row, target_row in zip(source, target):
                    indices = [index for index, cell in enumerate(source_row) if cell != background]
                    if len(indices) != 1 or len(set(target_row)) != 1:
                        valid = False
                        break
                    position = indices[0]
                    colour = target_row[0]
                    if position in mapping and mapping[position] != colour:
                        valid = False
                        break
                    mapping[position] = colour
                    positions.add(position)
                if not valid:
                    break
            if valid and len(positions) >= 3 and len(set(mapping.values())) == len(mapping):
                programmes.append(RowMarkerPositionCodebookProgram(orientation, background, tuple(sorted(mapping.items()))))
    return programmes


def _fit_paired_complement(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        source_colours = set()
        valid = True
        program = PairedColourComplementProgram(background)
        for source, target in pairs:
            try:
                analysis = program.analyse(source)
            except Inapplicable:
                valid = False
                break
            source_colours.add(analysis["source_colour"])
            if analysis["prediction"] != grid(target):
                valid = False
                break
        if valid and len(source_colours) >= 2:
            programmes.append(program)
    return programmes


def _fit_translation(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        for dr in range(-3, 4):
            for dc in range(-3, 4):
                if dr == 0 and dc == 0:
                    continue
                program = ClippedTranslationProgram(background, dr, dc)
                try:
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programmes.append(program)
                except Inapplicable:
                    continue
    return programmes


def _fit_count_glyph(pairs):
    programmes = []
    for input_background in _candidate_backgrounds(pairs):
        output_shapes = {_shape(target) for _, target in pairs}
        if len(output_shapes) != 1:
            continue
        output_height, output_width = next(iter(output_shapes))
        output_background_candidates = {0}
        try:
            modes = {_unique_mode(target) for _, target in pairs}
            if len(modes) == 1:
                output_background_candidates |= modes
        except Inapplicable:
            pass
        for output_background in sorted(output_background_candidates):
            masks = {}
            output_colour = None
            valid = True
            for source, target in pairs:
                quantity = sum(cell != input_background for row in grid(source) for cell in row)
                palette = _palette(target) - {output_background}
                if len(palette) != 1:
                    valid = False
                    break
                colour = next(iter(palette))
                if output_colour is None:
                    output_colour = colour
                elif output_colour != colour:
                    valid = False
                    break
                cells = {(row, col) for row in range(output_height) for col in range(output_width) if grid(target)[row][col] != output_background}
                if len(cells) != quantity or quantity in masks and masks[quantity] != cells:
                    valid = False
                    break
                masks[quantity] = cells
            if not valid or output_colour is None:
                continue
            counts = sorted(masks)
            if not counts or counts[0] != 1 or counts != list(range(1, max(counts) + 1)):
                continue
            if not all(masks[left].issubset(masks[right]) for left, right in zip(counts, counts[1:])):
                continue
            ordered = []
            previous = set()
            for count in counts:
                added = masks[count] - previous
                if len(added) != 1:
                    valid = False
                    break
                ordered.append(next(iter(added)))
                previous = masks[count]
            if valid:
                programmes.append(CanonicalCountGlyphProgram(
                    input_background,
                    output_background,
                    output_colour,
                    output_height,
                    output_width,
                    tuple(ordered),
                ))
    return programmes


def _fit_boundary_replica(pairs):
    programmes = []
    for background in _candidate_backgrounds(pairs):
        program = BoundaryReplicaExpansionProgram(background)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programmes.append(program)
        except Inapplicable:
            continue
    return programmes


def _fit_cyclic_border(pairs):
    program = CyclicBorderGrowthProgram()
    try:
        return [program] if all(program.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_v_lattice(pairs):
    programmes = []
    orientations = ("horizontal", "vertical")
    backgrounds = _candidate_backgrounds(pairs)
    output_colours = sorted(set().union(*(_palette(target) for _, target in pairs)))
    for orientation in orientations:
        for background in backgrounds:
            for secondary in output_colours:
                if secondary == background:
                    continue
                for period in range(2, 9):
                    for start_row in range(0, 7):
                        program = VLatticeContinuationProgram(orientation, background, secondary, period, start_row)
                        try:
                            if all(program.predict(source) == grid(target) for source, target in pairs):
                                programmes.append(program)
                        except Inapplicable:
                            continue
    return programmes


def _role_signature(program, source):
    if isinstance(program, RowUniformityCodebookProgram):
        return tuple(program.analyse(source)["uniformity"])
    if isinstance(program, RowMarkerPositionCodebookProgram):
        return tuple(program.analyse(source)["positions"])
    if isinstance(program, PairedColourComplementProgram):
        return program.analyse(source)["source_colour"]
    if isinstance(program, ClippedTranslationProgram):
        return _shape(source), _serial(source)
    if isinstance(program, CanonicalCountGlyphProgram):
        return program.analyse(source)["quantity"]
    if isinstance(program, BoundaryReplicaExpansionProgram):
        return _serial(source)
    if isinstance(program, CyclicBorderGrowthProgram):
        return tuple(program.analyse(source)["cycle"])
    if isinstance(program, VLatticeContinuationProgram):
        return _shape(source), program.analyse(source)["marker_colour"]
    return program.schema_key


def fit_compositional_primitive_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    fitters = (
        ("row_uniformity_codebook", lambda: _fit_row_uniformity(pairs)),
        ("row_marker_position_codebook", lambda: _fit_row_marker_codebook(pairs)),
        ("paired_colour_complement", lambda: _fit_paired_complement(pairs)),
        ("clipped_translation", lambda: _fit_translation(pairs)),
        ("canonical_count_glyph", lambda: _fit_count_glyph(pairs)),
        ("boundary_replica_expansion", lambda: _fit_boundary_replica(pairs)),
        ("cyclic_border_growth", lambda: _fit_cyclic_border(pairs)),
        ("v_lattice_continuation", lambda: _fit_v_lattice(pairs)),
    )
    candidates = []
    for kind, fitter in fitters:
        if allowed is not None and kind not in allowed:
            continue
        try:
            candidates.extend(fitter())
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    exact = []
    for program in candidates:
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            exact.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    return list({program.schema_key: program for program in exact}.values())


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    return {"kind": kind, "rows": rows, "passed": bool(rows) and all(row.get("passed") for row in rows)}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}

        if isinstance(program, RowUniformityCodebookProgram):
            work = _array(_transpose(source) if program.orientation == "column" else source)
            target_row = next((i for i, row in enumerate(work) if len(set(row)) == 1), None)
            if target_row is not None and len(work[target_row]) > 1:
                fresh = _fresh_colour(source)
                work[target_row][0] = fresh
                modified = tuple(tuple(row) for row in work)
                if program.orientation == "column":
                    modified = _transpose(modified)
                try:
                    passed = program.predict(modified) != original
                except Inapplicable:
                    passed = True
            details = {"uniformity_change": passed}

        elif isinstance(program, RowMarkerPositionCodebookProgram):
            work = _array(_transpose(source) if program.orientation == "column" else source)
            codebook = dict(program.mapping)
            positions = sorted(codebook)
            marker_row = 0
            current = next((c for c, value in enumerate(work[marker_row]) if value != program.background_colour), None)
            alternatives = [position for position in positions if position != current and position < len(work[marker_row])]
            if current is not None and alternatives:
                marker = work[marker_row][current]
                work[marker_row][current] = program.background_colour
                work[marker_row][alternatives[0]] = marker
                modified = tuple(tuple(row) for row in work)
                if program.orientation == "column":
                    modified = _transpose(modified)
                try:
                    changed = program.predict(modified)
                    passed = changed != original
                except Inapplicable:
                    passed = True
            details = {"marker_move_changes_code": passed}

        elif isinstance(program, PairedColourComplementProgram):
            analysis = program.analyse(source)
            source_colour = analysis["source_colour"]
            alternatives = [colour for colour in sorted(ARC_COLOUR_PAIRS) if colour != source_colour and colour != program.background_colour]
            if alternatives:
                new_source = _replace_colour(source, source_colour, alternatives[0])
                try:
                    changed = program.predict(new_source)
                    expected_colour = ARC_COLOUR_PAIRS[alternatives[0]]
                    passed = expected_colour in _palette(changed) and changed != original
                except Inapplicable:
                    passed = False
            details = {"paired_recolour_equivariance": passed}

        elif isinstance(program, ClippedTranslationProgram):
            foreground = sorted(_palette(source) - {program.background_colour})
            if foreground:
                fresh = _fresh_colour(source)
                modified = _replace_colour(source, foreground[0], fresh)
                expected = _replace_colour(original, foreground[0], fresh)
                try:
                    passed = program.predict(modified) == expected
                except Inapplicable:
                    passed = False
            details = {"translation_recolour_equivariance": passed}

        elif isinstance(program, CanonicalCountGlyphProgram):
            work = _array(source)
            background_cells = [(r, c) for r, row in enumerate(work) for c, value in enumerate(row) if value == program.input_background]
            if background_cells and program.analyse(source)["quantity"] < len(program.ordered_cells):
                r, c = background_cells[0]
                work[r][c] = _fresh_colour(source)
                try:
                    changed = program.predict(tuple(tuple(row) for row in work))
                    passed = changed != original
                except Inapplicable:
                    passed = True
            else:
                foreground_cells = [(r, c) for r, row in enumerate(work) for c, value in enumerate(row) if value != program.input_background]
                if len(foreground_cells) > 1:
                    r, c = foreground_cells[-1]
                    work[r][c] = program.input_background
                    try:
                        passed = program.predict(tuple(tuple(row) for row in work)) != original
                    except Inapplicable:
                        passed = True
            details = {"quantity_change_updates_glyph": passed}

        elif isinstance(program, BoundaryReplicaExpansionProgram):
            work = _array(source)
            changed = False
            size = len(work)
            for r, c in [(0, i) for i in range(size)] + [(size - 1, i) for i in range(size)] + [(i, 0) for i in range(size)] + [(i, size - 1) for i in range(size)]:
                if work[r][c] != program.background_colour:
                    work[r][c] = program.background_colour
                    changed = True
                    break
            if changed:
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
            details = {"boundary_evidence_necessary": passed}

        elif isinstance(program, CyclicBorderGrowthProgram):
            analysis = program.analyse(source)
            corner, centre_colour, _ = analysis["cycle"]
            modified = _replace_colour(source, centre_colour, _fresh_colour(source))
            try:
                passed = program.predict(modified) != original
            except Inapplicable:
                passed = True
            details = {"role_recolour_equivariance": passed}

        elif isinstance(program, VLatticeContinuationProgram):
            value = _transpose(source) if program.orientation == "vertical" else source
            work = _array(value)
            centre = len(work[0]) // 2
            work[0][centre] = program.background_colour
            modified = tuple(tuple(row) for row in work)
            if program.orientation == "vertical":
                modified = _transpose(modified)
            try:
                program.predict(modified)
                passed = False
            except Inapplicable:
                passed = True
            details = {"centred_marker_necessary": passed}

        rows.append({"demonstration": index, "passed": passed, **details})
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Inference and validation.
# ---------------------------------------------------------------------------


def infer_compositional_primitives(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_compositional_primitive_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programmes:
        try:
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "compositional_primitive_algebra": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "row_uniformity_codebook":
        return RowUniformityCodebookProgram(str(parameters["orientation"]), int(parameters["uniform_colour"]), int(parameters["nonuniform_colour"]))
    if kind == "row_marker_position_codebook":
        return RowMarkerPositionCodebookProgram(
            str(parameters["orientation"]),
            int(parameters["background_colour"]),
            tuple((int(a), int(b)) for a, b in parameters["mapping"]),
        )
    if kind == "paired_colour_complement":
        return PairedColourComplementProgram(int(parameters["background_colour"]))
    if kind == "clipped_translation":
        return ClippedTranslationProgram(int(parameters["background_colour"]), int(parameters["dr"]), int(parameters["dc"]))
    if kind == "canonical_count_glyph":
        return CanonicalCountGlyphProgram(
            int(parameters["input_background"]),
            int(parameters["output_background"]),
            int(parameters["output_colour"]),
            int(parameters["output_shape"][0]),
            int(parameters["output_shape"][1]),
            tuple((int(a), int(b)) for a, b in parameters["ordered_cells"]),
        )
    if kind == "boundary_replica_expansion":
        return BoundaryReplicaExpansionProgram(int(parameters["background_colour"]))
    if kind == "cyclic_border_growth":
        return CyclicBorderGrowthProgram()
    if kind == "v_lattice_continuation":
        return VLatticeContinuationProgram(
            str(parameters["orientation"]),
            int(parameters["background_colour"]),
            int(parameters["secondary_colour"]),
            int(parameters["period"]),
            int(parameters["start_row"]),
        )
    raise Inapplicable("unknown compositional-primitive schema")


def validate_compositional_primitives(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_compositional_primitive_programs(
            remaining,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                counterfactual = _counterfactual_validation(program, tuple((d["input"], d["output"]) for d in clean["train"]))
                if not counterfactual.get("passed"):
                    continue
                predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def compositional_primitive_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_compositional_primitive_programs(pairs)}))


infer = infer_compositional_primitives
validate = validate_compositional_primitives
