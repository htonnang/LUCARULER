# LUCA V122 — Spinoza-Inspired Learned Counterfactual Feature Architecture

## 1. Research interpretation

V108 introduced proof-carrying causal composition. V109–V121 developed common notions, triggers, operator induction, graph transfer, relational projection, quantified queries, and general selectors. V122 moves from selecting among a fixed list of task mechanisms toward inducing which non-positional feature or structural relation explains the demonstrations:

```text
Scene → Candidate/Relation Language → Feature Induction → Comparison → Role Binding → Emission
```

The philosophical interpretation remains computational and falsifiable. A common notion is a relation supported across demonstrations; a cause is the input evidence that makes a programme applicable; adequate knowledge requires exact demonstrations, stable refitting, necessary evidence, prediction consensus, and no forbidden information.

## 2. Formal programme

A V122 programme is:

```text
P = (S, C, F, R, E, Π)
```

where:

- `S` constructs a scene;
- `C` derives candidate objects, lattice cells, anchors, tiles, or periodic residues;
- `F` induces the explanatory feature or relation;
- `R` compares evidence and binds one unique role;
- `E` emits a crop, seed tile, or reconstructed patch;
- `Π` records demonstrations, held-out folds, counterfactuals, and leakage controls.

The prediction is:

```text
Y = E(R(F(C(S(X)))))
```

A programme is inapplicable when the candidate language is ambiguous, the learned comparison is tied, structural evidence is incomplete, periodic residues conflict, or exact programmes disagree on the test output.

## 3. Learned component feature selector

```text
non-positional components
∧ one feature/comparison pair explains every demonstration
⇒ emit the selected raw crop
```

Current safe features are area, bounding-box area, perimeter, hole count, density, D4 stabiliser, shape frequency, and global colour material. Positional features and output rotations are deliberately excluded. This schema adds `a87f7484` and independently recovers several protected tasks.

## 4. Lattice-cell feature selector

```text
separator lattice
⇒ logical cells
⇒ induce one cell feature and comparison
⇒ emit the selected cell crop
```

V122 learns that `c3202e5a` selects the unique logical cell with the smallest foreground palette. Separator identity is tested under legal colour permutations and is not treated as semantic.

## 5. Homologous anchor-pair window

```text
repeated elongated anchors
⇒ bind the uniquely longest homologous pair
⇒ learn endpoint padding
⇒ emit the relation-defined crop window
```

This schema adds `3f7978a0`. It uses object relation and axis geometry rather than a stored window coordinate.

## 6. Dihedral tile seed extraction

```text
non-overlapping tile partition
∧ every tile is a D4 transform of one seed
⇒ emit the smallest unique seed tile
```

At least four tiles and three distinct orbit members are required, preventing plain repetition from being misclassified as dihedral generation. This schema adds `d10ecb37`.

## 7. Periodic hole recovery

```text
one rectangular zero hole
∧ observed cells support one conflict-free 2D residue law
⇒ reconstruct the missing patch
```

The smallest witnessed period is selected only when every missing residue has external evidence. This schema adds `f9012d9b`.

## 8. Adequacy criterion

A V122 law is accepted only if:

1. every training demonstration is exact;
2. the feature or relation is non-positional and input-derived;
3. the explanatory role varies across demonstrations;
4. exact programmes agree on the unseen output;
5. held-out demonstrations eliminate spurious refits and all held-exact programmes agree on the frozen test prediction;
6. schema-specific counterfactuals alter the answer or destroy applicability as expected;
7. task identifiers and test targets are unavailable during inference;
8. official solutions are opened only after predictions and validation records are frozen.

## 9. Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 12 exact, validation-passing family fits;
- 5 new protected gains and 7 protected independent fits;
- protected boundary **229 → 234**;
- 16/16 new-gain folds and 39/39 accepted-fit folds pass;
- 0 incorrect unique predictions;
- 0 validation-rejected V122 exact predictions;
- 0 crashes and 0 protected-ledger regressions;
- 347/347 packaged tests and 1,185/1,185 archived tests pass.

## 10. Next research stage

V123 should learn a broader relation vocabulary from the successful V122 proof objects and automatically generate falsifying ties, decoys, conflicting residues, and transformed homologs:

```text
Discover candidate language
Discover explanatory invariant under perturbation
Bind relation role
Compose transformation or projection
Falsify against generated counterexamples
```

The immediate scientific test is whether the learned relation/feature schemas transfer to unseen public-evaluation tasks without increasing false activation.

# LUCA V123 — Learned Relation Vocabulary

## 1. Objective

V123 extends learned feature induction from single-object attributes to explicit structural relations:

```text
Scene → Relation Vocabulary → Unique Role → Projection → Proof
```

The aim is not to accumulate task rules, but to discover small relation languages that transfer across positions, colours, dimensions, and object arrangements.

## 2. Programme form

A V123 programme is:

```text
P = (S, R, B, E, Π)
```

where:

- `S` constructs the scene;
- `R` derives a structural relation such as quadrant homology, frame comparison, repeated-class membership, or instruction containment;
- `B` binds one unique role;
- `E` emits the relation-defined projection;
- `Π` stores demonstrations, held-out folds, counterfactuals, and leakage controls.

The prediction is:

```text
Y = E(B(R(S(X))))
```

## 3. Fundamental quadrant projection

```text
object bounding box
∧ four equal structural roles
∧ common palette
∧ D4-equivalent binary support
⇒ emit the learned corner role
```

This relation solves two tasks and demonstrates cross-task reuse. The corner is a parameter; the structural vocabulary is shared.

## 4. Largest closed-frame interior

```text
complete frame set
∧ unique maximum interior area
⇒ emit that frame's interior
```

Frame border colour is nonsemantic. Counterfactual border recolouring preserves the answer, while breaking the winning frame destroys applicability.

## 5. Framed pattern outlier

```text
framed pattern classes
∧ repeated distractor class
∧ exactly one singleton class
⇒ emit the singleton framed pattern
```

The selected frame location and pattern vary. Adding a duplicate of the singleton destroys the unique role.

## 6. Instruction-bounding-box frame selection

```text
clean framed alternatives
∧ one non-frame instruction trace
∧ exactly one frame centre inside its bounding box
⇒ emit the bound frame
```

Instruction colour is nonsemantic; its geometric relation to the alternatives is the cause.

## 7. Adequacy criterion

A V123 law is accepted only if:

1. every training demonstration is exact;
2. no task identifier, test target, or stored demonstration coordinate is used;
3. the selected structural role varies across demonstrations;
4. exact programmes agree on the unseen output;
5. held-exact refits reproduce the held example and agree on the frozen prediction;
6. schema-specific counterfactuals confirm necessity or invariance;
7. official solutions are opened only after inference and validation are frozen.

## 8. Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 5 exact, validation-passing family fits;
- 5 new protected gains;
- protected boundary **234 → 239**;
- 13/13 held-demonstration folds pass;
- 0 incorrect unique predictions;
- 0 validation-rejected V123 exact predictions;
- 0 crashes and 0 protected-ledger regressions;
- 368/368 packaged tests and 1,185/1,185 archived tests pass.

## 9. Next research stage

V124 should compose learned relations with transformed homology and adversarial decoy generation:

```text
Discover relation vocabulary
Generate counterexamples
Bind roles under transformed correspondence
Compose projection or transformation
Reject ties and contradictory evidence
```

# LUCA V124 — Self-Similar Expansion Grammar

## Objective

V124 extends the Spinoza-inspired architecture from learned relations to generative macro–micro laws:

```text
Source → Relation/Transform Roles → Block Grammar → Expanded Consequence → Proof
```

## Programme form

A V124 programme is:

```text
P = (S, R, G, E, Π)
```

where `S` is the source grid, `R` binds transform or selector roles, `G` is a block-substitution grammar, `E` emits the expanded grid, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Reusable schemas

1. `macro_dihedral_wallpaper`: a macro matrix of D4 transform roles.
2. `cell_relation_self_replication`: cell roles selected by frequency, semantic colour, or a unique monochrome line generate full source replicas.
3. `binary_complement_kronecker`: the complement of a binary support becomes the substitution kernel.
4. `binary_kernel_substitution`: a learned multicolour kernel expands every binary foreground role.

The macro-wallpaper family uses symbolic transform-set consensus during leave-one-demonstration-out validation. This proves unseen-output stability even when a held fold admits many symmetry-equivalent templates, without enumerating the Cartesian product.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 21 exact, validation-passing family fits;
- 15 new gains and 6 protected independent fits;
- protected boundary **239 → 254**;
- 54/54 new-gain folds and 72/72 accepted-fit folds pass;
- 0 incorrect unique predictions;
- 0 validation-rejected exact predictions;
- 0 crashes and 0 protected-ledger regressions;
- 393/393 packaged tests and 1,185/1,185 archived tests pass.

## Next research stage

V125 should learn a unified generative expansion algebra:

```text
Infer macro roles
Infer substitution or transform grammar
Compose grammar recursively or across a role graph
Falsify with selector ties, transform conflicts, and kernel perturbations
```


# LUCA V125 — Unified Generative Expansion Algebra

## Objective

V125 anti-unifies additional expansion families through a common programme:

```text
Source → Relation/Role → Block Operator → Macro Composition → Expanded Consequence → Proof
```

## Programme form

A V125 programme is `P = (S, R, B, M, E, Π)`, where `S` is the source grid, `R` binds source roles or relations, `B` is a local block/stencil operator, `M` composes blocks at macro scale, `E` emits the grid, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 13 exact family fits;
- 12 new gains and 1 protected independent fit;
- protected boundary **254 → 266**;
- 41/41 new-gain folds and 44/44 accepted-fit folds pass;
- 0 incorrect unique predictions, validation rejections, crashes, or regressions;
- 424/424 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V126 should form a smaller recursive generative algebra from selector, stencil, substitution, tiling, and boundary primitives, then compose those primitives under adversarial conflict tests.

# LUCA V126 — Recursive Unified Generative Algebra

## Objective

V126 continues the geometrical-method programme by factoring new expansion tasks into a small set of typed derivations:

```text
Source
→ derive quantity or relation
→ select expansion operator
→ compose consequence
→ verify demonstrations and counterexamples
```

## Programme form

A V126 programme is:

```text
P = (S, Q, R, O, E, Π)
```

where `S` is the source grid, `Q` derives a quantity such as palette cardinality or material count, `R` identifies a spatial relation such as translation, periodicity, diagonal-band orientation, or ring order, `O` is the expansion operator, `E` emits the larger grid, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Reusable schemas

1. `palette_cardinality_expansion`: semantic palette cardinality controls cell scaling or complete-source tiling.
2. `count_packed_source_replication`: background and foreground material counts determine macro capacity and replica count.
3. `uniform_square_lattice`: a uniform square determines separator spacing in a generated lattice.
4. `diagonal_translation_closure`: a sparse seed is closed under a learned translation vector.
5. `diagonal_band_periodic_extension`: a periodic main- or anti-diagonal band is extended to a homologous larger canvas.
6. `corner_ring_periodic_extension`: constant corner rings are extended under a cyclic colour law.

## Adequacy boundary

A V126 law is accepted only when:

1. every training demonstration is exact;
2. the relation or quantity is derived from the current input;
3. task IDs, test targets, and stored demonstration coordinates are excluded;
4. exact programmes agree on every unseen output;
5. held-exact refits reproduce the held example and preserve the test prediction;
6. relation-specific counterfactuals confirm necessity or equivariance;
7. official solutions are opened only after inference and validation freeze.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 11 exact, validation-passing family fits;
- 9 new gains and 2 protected independent fits;
- protected boundary **266 → 275**;
- 36/36 new-gain folds and 41/41 accepted-fit folds pass;
- 0 incorrect unique predictions, validation rejections, crashes, or regressions;
- 451/451 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V127 should anti-unify the six schemas into independently composable quantity, relation, operator, boundary, and recursion primitives, then test mixed recursive programmes under generated conflicts.


# LUCA V127 — Composable Recursive Generative Primitives

## Objective

V127 separates twelve transformations into reusable typed primitives over colour classes, panels, edges, rows, frequencies, recurrences, sequences, markers, and palettes.

## Programme form

```text
P = (S, R, O, E, Π)
```

`S` is the source abstraction, `R` binds the relation or role, `O` is the primitive operator, `E` emits the consequence, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Adequacy boundary

A V127 law is accepted only when every demonstration is exact, role evidence varies where required, every held-exact refit agrees on the unseen prediction, relation-specific counterfactuals pass, and forbidden task metadata cannot affect inference.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 12 exact family fits and 12 new gains;
- protected boundary **275 → 287**;
- 39/39 held-demonstration folds pass;
- 0 incorrect unique predictions, validation rejections, ambiguities, crashes, or regressions;
- 484/484 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V128 should anti-unify the twelve primitives into a smaller compositional algebra and test multi-primitive programmes under automatically generated conflicts.

# LUCA V128 — Compositional Primitive Algebra

## Objective

V128 broadens LUCA's primitive layer while keeping one proof-carrying programme:

```text
Source abstraction → Relation/Codebook → Primitive operator → Boundary policy → Emission → Proof
```

## Programme form

A V128 programme is `P = (S, R, O, B, E, Π)`, where `S` constructs a source abstraction, `R` derives a role, codebook, pairing, displacement, count, or recursive instruction, `O` is the primitive operator, `B` is the boundary policy, `E` emits the consequence, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Reusable schemas

1. `row_uniformity_codebook`: structural row classes are emitted through a learned two-class codebook.
2. `row_marker_position_codebook`: relative marker position controls a row-wise codebook.
3. `paired_colour_complement`: support complementation composes with a semantic colour involution.
4. `clipped_translation`: one coordinate-free displacement moves all foreground material with clipping.
5. `canonical_count_glyph`: source material count indexes a learned nested glyph basis.
6. `boundary_replica_expansion`: boundary roles recursively emit source-pattern blocks while interior roles emit solid material.
7. `cyclic_border_growth`: semantic corner, centre, and field roles drive recursive square-border growth.
8. `v_lattice_continuation`: a centred one-dimensional instruction generates a V boundary and periodic interior lattice.

## Adequacy boundary

A V128 law is accepted only when all demonstrations are exact, the role is input-derived, exact programmes agree on unseen outputs, held-exact refits preserve the frozen prediction, schema-specific counterfactuals pass, and task IDs and test targets are unavailable during inference.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 8 exact family fits and 8 new gains;
- protected boundary **287 → 295**;
- 36/36 held-demonstration folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- 511/511 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V129 should anti-unify these schemas with the V127 primitive vocabulary and search for genuine two-primitive programmes under automatically generated conflicts.
# LUCA V129 — Anti-Unified Compositional Search

## Objective

V129 composes instruction discovery, selector relations, object binding, local transformation, and canonical emission in one proof-carrying language.

## Programme form

```text
P = (S, I, R, B, T, E, Π)
```

`S` constructs the scene, `I` identifies instruction evidence, `R` derives the selector relation, `B` binds semantic roles, `T` performs the local transformation, `E` emits the result, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 8 exact family fits, 6 new gains, and 2 protected independent fits;
- protected boundary **295 → 301**;
- 21/21 new-gain and 28/28 accepted-fit held-demonstration folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- 538/538 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V130 should factor the six schemas into independently composable instruction, selector, binding, transform, and emitter primitives, with automatic conflict generation.

# LUCA V130 — Anti-Unified Multi-Stage Composition

## Objective

V130 composes scene perception, structural relation binding, semantic roles, a local transformation, and canonical emission in one proof-carrying programme.

## Programme form

```text
P = (S, R, B, T, E, Π)
```

`S` constructs the scene, `R` identifies the relation or instruction, `B` binds semantic roles, `T` applies the local operator, `E` emits the consequence, and `Π` records exactness, held-example consensus, counterfactuals, and leakage controls.

## Reusable schemas

1. `concentric_palette_program` — reverse or cyclically shift monochrome concentric palette roles.
2. `framed_reference_homology_recolour` — transfer an L-frame instruction to one homologous external target.
3. `cyclic_region_palette_rotation` — rotate region colours around a skeleton-defined angular order.
4. `cyclic_framed_motif_recolour` — rotate payload colours around a cycle of framed motifs.

## Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 5 exact family fits and 5 new gains;
- protected boundary **301 → 306**;
- 16/16 held-demonstration folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- 559/559 current tests and 1,185/1,185 archived tests pass.

## Next research stage

V131 should learn smaller relation, role-binding, sequence, and emission primitives from V130 proof traces and test genuine multi-stage compositions with generated decoys and conflicting cyclic orders.

## V131 — Learned Stage Algebra

V131 adds the compositional form:

```text
scene → instruction/relation → semantic binding → local operator → emission
```

Its witnessed shape-codebook protocol distinguishes redundant-witness leave-one-out evidence from singleton direct code witnesses. Relational selectors continue to use full held-exact consensus. All accepted laws require counterfactual adequacy before they may contribute to prediction consensus.

## V132 — Anti-Unified Instruction–Relation Stage Algebra

V132 extends the proof-carrying architecture with the common stage programme:

```text
scene → instruction/relation → role binding → operator → emission
```

It adds five conservative schemas: witnessed frame-size fill codebooks, framed-payload normalisation and diagonal duplication, symbolic turn-path execution, four-way object composition, and mask–kernel colour composition. Frame-size mappings use a mixed evidence protocol: redundant mappings are tested by leave-one-out refitting, singleton mappings are disclosed as direct witnesses, and unseen frame sizes cause abstention.


## V133 — Relational Completion and Projection Algebra

V133 introduces a typed stage language for resolving previously withheld tasks:

```text
scene → candidate/relation → feature or instruction → operator → emission
```

The central advance is not a list of eighteen patches. Component features, correspondence, lattice alignment, region filling, frame relations, inventory projection, centring, extrema, gravity, and marker transfer all use one proof-carrying interface with held-example consensus, counterfactual adequacy, and leakage exclusion.

## V134 — Anti-Unified Relational Completion Algebra

V134 introduces the typed programme:

```text
scene → candidate/relation → operator → emission
```

It anti-unifies eight conservative mechanisms: background-component extrema, panel-priority overlay, dominant-component cleanup, exterior-boundary projection, domino-halo completion, colour-height histogram projection, instruction-bounding-box recolouring, and diagonal-orientation frequency recolouring.

### Adequacy boundary

Every accepted V134 law must reproduce all demonstrations exactly, infer its relation from the current input, exclude task IDs and test targets, pass held-exact refitting, survive schema-specific counterfactuals, and agree with all other exact laws on the unseen prediction. Absolute demonstration coordinates are not stored.

### Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 10 exact family fits, 8 new gains, and 2 protected independent fits;
- protected boundary **334 → 342**;
- 24/24 new-gain and 33/33 accepted-fit folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- 678/678 current tests and 1,185/1,185 archived tests pass.

### Next research stage

V135 should anti-unify these schemas into smaller completion primitives and search for composed extrema, priority, boundary, local-completion, instruction-region, and orientation relations under automatically generated ties and decoys.

## V135 — Anti-Unified Completion Primitives

V135 adds the typed programme:

```text
scene → candidate/relation → completion or transfer primitive → emission
```

Its six conservative schemas are frequency-tail recolouring, exact-cover piece decomposition, external-marker boundary projection, spatial legend-to-object transfer, D4-aware scaled pattern transfer, and panel-template occurrence recolouring.

### Adequacy boundary

Every accepted V135 programme reproduces all demonstrations exactly, infers its roles from the current grid, excludes task IDs and test targets, passes held-exact consensus refitting, survives a schema-specific counterfactual, and agrees with every other exact law on the unseen output.

### Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 6 exact family fits and 6 new protected gains;
- protected boundary **342 → 348**;
- 17/17 held-demonstration folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- 701/701 current tests and 1,185/1,185 archived tests pass.

### Next research stage

V136 should anti-unify the six schemas into reusable frequency, exact-cover, correspondence, pattern-lifting, and occurrence-matching stages and generate ties, competing covers, marker conflicts, scale conflicts, and template decoys automatically.

## V136 — Anti-Unified Transfer and Cover Algebra

V136 factors eight relation schemas into two multi-task operators under the programme:

```text
scene → relation → shared operator → deterministic full-grid emission → proof
```

### Shared operator I: correspondence transfer

Five exact tasks use one transfer principle. A structurally inferred relation maps palette pairs, axis coordinates, normalized bins, ordered coordinate classes, or D4-equivalent shapes to semantic colours. The emitter transfers the mapped colour while preserving all cells outside the bound recipient roles.

### Shared operator II: derived-cover completion

Three exact tasks use one completion principle. A relation derives a cover from full separator membership, distance from a rectangle boundary, or modular coordinate equivalence. The emitter fills precisely the derived cover with the fitted semantic material.

### Adequacy boundary

Every accepted programme must reproduce all demonstrations, infer roles from the current input, exclude task identifiers and test targets, agree with every other exact programme on all test inputs, pass leave-one-demonstration-out refitting, and survive a relation-specific counterfactual. Conflicting legends, incomplete covers, ambiguous dictionaries, and non-unique relations cause abstention.

### Measured evidence

- 1,000 training tasks and 1,076 test inputs screened;
- 8 exact family fits and 8 new protected gains;
- protected boundary **348 → 356**;
- operator support: correspondence transfer **5 tasks**, derived-cover completion **3 tasks**;
- 21/21 held-demonstration folds pass;
- 0 incorrect unique predictions, ambiguities, validation rejections, crashes, or regressions;
- complete execution parity across isolated, registered, CLI, and 60-family engine paths.

### Next research stage

V137 should anti-unify the relation constructors themselves, allowing one graph-based correspondence learner and one cover-generation learner to compose with existing emitters without introducing single-task operators.


## V139 — Graph-Constructor Grammar and Bounded Relation-Chain Search

V139 factors eight scene-specific constructors into a common proof form:

```text
scene → typed nodes → bounded relation chain → shared operator → emission → validation proof
```

Three operators are promoted with real-task support 4, 2, and 2: bounded-region materialisation, periodic-field emission, and interval-graph cover emission. V139 accepts only exact demonstration fits whose held-example refits, ordinary test predictions, counterfactual interventions, and metadata-leakage checks agree.

## V140 — Learned Constructor Grammar and Bounded Proof Search

V140 factors seven scene programmes through three operators under the proof form:

```text
scene → typed nodes → derived relation → shared operator → deterministic grid → proof
```

The operators are component-region materialisation, extremal-axis emission, and relational-structure completion. V140 advances the protected boundary **383 → 390**, with 19/19 held folds and no false accepted predictions.

## V141 — Reusable Node/Edge Grammar and Bounded Two-Step Proof Search

V141 makes node and edge vocabularies explicit:

```text
scene → typed nodes → typed edge/relation → shared operator → deterministic grid → proof
```

Three operators each have three real-task witnesses: shape-envelope materialisation, node/edge graph emission, and anchor-role projection. Nine exact family fits advance the protected boundary **390 → 399**. All 27 held folds, nine counterfactual suites, nine leakage checks, and all isolated/registered/CLI/65-family execution paths pass.

V142 should compose these vocabularies across operators through bounded two-step relation chains while preserving the 399-task protected boundary.

## V142 — Anti-Unified Node/Edge Vocabulary and Bounded Composition

V142 compresses six relation schemas into two reusable node vocabularies, two edge vocabularies, and two consequence operators. Rectilinear support nodes feed derived interval/path edges for cluster envelopes, frame escape, lattice closure, and portal shortest-path union. Axis seed nodes feed periodic successor edges for alternating rays and periodic combs. The family adds seven protected tasks, resolves the prior 60b61512 ambiguity, and preserves zero accepted errors under full-corpus screening and proof-carrying validation.



## V143 - Parameterised Node/Edge Grammar

V143 introduces dimension nodes, periodic motif nodes, extremal marker nodes, successor edges, parity edges, phase-class edges, and rectilinear incidence edges. Seven schemas share three consequence operators and are accepted only after exact demonstration fit, prediction consensus, held-example refitting, structural counterfactual necessity, and leakage checks.

## V144 - Primitive anti-unification and bounded relation search

V144 represents each accepted explanation as a typed two-relation derivation:

```text
scene -> node role -> edge relation -> consequence operator -> full-grid emission
```

The periodic family anti-unifies template-role mapping, repeated-prefix tiling, boundary-motif phase continuation, and an anchored public-evaluation transfer probe. The rectilinear family anti-unifies axis incidence, occlusion continuity, and maximal-empty-region enclosure. Acceptance retains exact refitting, prediction consensus, structural counterfactual necessity, leakage resistance, and protected-ledger replay.

## V145 — Learned Primitive Graph Grammar

V145 represents every accepted explanation through a three-stage graph derivation:

```text
scene → typed nodes → typed edges → relation chain → shared operator → full-grid emission → proof
```

Three operators each have four exact real-task witnesses: D4 diagonal-ray emission, axis-role projection, and D4 orbit materialisation. Ten applications are new protected gains and two are independent overlaps with previously protected solutions. The family reaches twelve exact applications on the complete 1,000-task screen, with 38/38 held-demonstration folds, no incorrect accepted prediction, and complete parity across isolated, registered, CLI, and 69-family engine paths.

The next research direction is to anti-unify the three node classes and three edge classes into reusable extractors and relation constructors, then compose the existing diagonal, axis, and orbit operators through bounded multi-operator proof search.
