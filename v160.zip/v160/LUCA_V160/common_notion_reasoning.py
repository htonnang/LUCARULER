"""LUCA V109: cross-task common notions and component-attribute extraction.

V109 turns the Spinoza-inspired idea of *common notions* into two executable
capabilities:

1. a corpus miner that records structural/transition properties shared by every
   demonstration of a task and anti-unifies successful laws into schemas; and
2. a conservative extraction family that selects an object by a reusable
   component attribute (for example, the uniquely most chromatically diverse
   object) and returns its canonical bounding-box representation.

The runtime family never receives task identifiers or official test targets.
Training outputs are used only to fit and verify a general program.  Ambiguous
or underdetermined explanations are retained as ambiguity/no-fit rather than
forced into a prediction.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from hashlib import sha256
from itertools import combinations
import json
from typing import Iterable, Mapping, Sequence

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_common_notion_extraction"
LANGUAGE = "spinoza_common_notion_program_v1"
SCHEMA_VERSION = "common_notion_schema_v1"


# ---------------------------------------------------------------------------
# Component representation and canonical extraction programs
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Component:
    cells: tuple[tuple[int, int], ...]
    box: tuple[int, int, int, int]
    area: int
    bbox_area: int
    height: int
    width: int
    density_numerator: int
    density_denominator: int
    colours: tuple[int, ...]
    top: int
    left: int
    left_right_symmetry: bool
    top_bottom_symmetry: bool
    half_turn_symmetry: bool
    main_diagonal_symmetry: bool
    anti_diagonal_symmetry: bool

    @property
    def distinct_colours(self) -> int:
        return len(self.colours)

    @property
    def density(self) -> float:
        return self.density_numerator / self.density_denominator

    def metric(self, selector: str):
        mapping = {
            "distinct_colours": self.distinct_colours,
            "area": self.area,
            "bbox_area": self.bbox_area,
            "height": self.height,
            "width": self.width,
            "density": self.density,
            "left_right_symmetry": int(self.left_right_symmetry),
            "top_bottom_symmetry": int(self.top_bottom_symmetry),
            "half_turn_symmetry": int(self.half_turn_symmetry),
            "main_diagonal_symmetry": int(self.main_diagonal_symmetry),
            "anti_diagonal_symmetry": int(self.anti_diagonal_symmetry),
        }
        try:
            return mapping[selector]
        except KeyError as exc:
            raise Inapplicable("unknown component selector metric") from exc

    def to_dict(self):
        return {
            "box": list(self.box),
            "area": self.area,
            "bbox_area": self.bbox_area,
            "height": self.height,
            "width": self.width,
            "density": self.density,
            "left_right_symmetry": int(self.left_right_symmetry),
            "top_bottom_symmetry": int(self.top_bottom_symmetry),
            "half_turn_symmetry": int(self.half_turn_symmetry),
            "main_diagonal_symmetry": int(self.main_diagonal_symmetry),
            "anti_diagonal_symmetry": int(self.anti_diagonal_symmetry),
            "distinct_colours": self.distinct_colours,
            "colours": list(self.colours),
            "left_right_symmetry": self.left_right_symmetry,
            "top_bottom_symmetry": self.top_bottom_symmetry,
            "half_turn_symmetry": self.half_turn_symmetry,
            "main_diagonal_symmetry": self.main_diagonal_symmetry,
            "anti_diagonal_symmetry": self.anti_diagonal_symmetry,
        }


@dataclass(frozen=True)
class ComponentExtractionProgram:
    """Select one component by a unique extremum and crop its canonical box."""

    connectivity: int
    extremum: str
    metric: str
    crop_mode: str = "raw_bbox"
    minimum_components: int = 3

    @property
    def selector(self) -> str:
        return f"{self.extremum}_{self.metric}"

    @property
    def description_length(self) -> int:
        # One selection proposition + one canonicalization proposition.
        return 2 + int(self.connectivity == 8) + int(self.crop_mode == "component_mask")

    @property
    def permissiveness_cost(self) -> tuple[int, int, int]:
        metric_order = {
            "distinct_colours": 0,
            "left_right_symmetry": 1,
            "top_bottom_symmetry": 1,
            "half_turn_symmetry": 2,
            "main_diagonal_symmetry": 2,
            "anti_diagonal_symmetry": 2,
            "area": 3,
            "bbox_area": 4,
            "density": 5,
            "height": 6,
            "width": 7,
        }
        return (
            metric_order.get(self.metric, 99),
            0 if self.connectivity == 4 else 1,
            0 if self.crop_mode == "raw_bbox" else 1,
        )

    def select(self, value: Grid):
        components, background = extract_components(value, self.connectivity)
        if len(components) < self.minimum_components:
            return None, components, background
        values = [component.metric(self.metric) for component in components]
        target = max(values) if self.extremum == "max" else min(values)
        winners = [component for component, value in zip(components, values) if value == target]
        if len(winners) != 1:
            return None, components, background
        winner = winners[0]
        # A distinct-colour selector must be genuinely informative rather than
        # choosing among monochrome pieces by an accidental tie-breaking path.
        if self.metric == "distinct_colours" and winner.distinct_colours < 2:
            return None, components, background
        return winner, components, background

    def predict(self, value: Grid):
        a = grid(value)
        winner, _, background = self.select(a)
        if winner is None or background is None:
            return None
        r0, c0, r1, c1 = winner.box
        selected = set(winner.cells)
        out = []
        for r in range(r0, r1 + 1):
            row = []
            for c in range(c0, c1 + 1):
                if self.crop_mode == "component_mask" and (r, c) not in selected:
                    row.append(background)
                else:
                    row.append(a[r][c])
            out.append(tuple(row))
        return tuple(out)

    def describe(self, training_pairs: Sequence[tuple[Grid, Grid]] = ()):  # proof-carrying law
        proofs = []
        positions = []
        palettes = []
        for index, (a, y) in enumerate(training_pairs):
            a, y = grid(a), grid(y)
            winner, components, _ = self.select(a)
            predicted = self.predict(a)
            if winner is not None:
                positions.append((winner.top, winner.left))
                palettes.append(winner.colours)
            proofs.append(
                {
                    "demonstration": index,
                    "exact": predicted == y,
                    "candidate_components": len(components),
                    "selected_component": winner.to_dict() if winner else None,
                }
            )
        return {
            "language": LANGUAGE,
            "family": FAMILY,
            "schema": "select_unique_component_extremum_then_crop",
            "definitions": [
                {
                    "name": "ConnectedComponent",
                    "input_type": "Grid",
                    "output_type": "ComponentSet",
                    "contract": ["input-derived", "background-excluding", "no task identifier"],
                },
                {
                    "name": "UniqueAttributeExtremum",
                    "input_type": "ComponentSet",
                    "output_type": "Component",
                    "contract": ["unique winner required", "ties rejected"],
                },
                {
                    "name": "CanonicalBoundingBox",
                    "input_type": "Component",
                    "output_type": "Grid",
                    "contract": ["original colours retained", "no coordinate template"],
                },
            ],
            "axioms": [
                "training_demonstrations_exact",
                "unique_selector_winner",
                "selector_role_varies_across_demonstrations",
                "no_task_identifier",
                "no_test_target_access",
                "ambiguity_is_preserved",
            ],
            "propositions": [
                {
                    "definition": "select_component",
                    "parameters": [self.connectivity, self.extremum, self.metric, self.minimum_components],
                    "cause": "one component is the unique requested attribute extremum",
                    "effect": "bind that component as the explanatory object",
                },
                {
                    "definition": "canonical_crop",
                    "parameters": [self.crop_mode],
                    "cause": "a unique explanatory object has been bound",
                    "effect": "emit its bounding-box representation",
                },
            ],
            "corollary": "select_component -> canonical_crop",
            "parameters": {
                "connectivity": self.connectivity,
                "extremum": self.extremum,
                "metric": self.metric,
                "crop_mode": self.crop_mode,
                "minimum_components": self.minimum_components,
            },
            "adequacy": {
                "demonstrations_exact": all(proof["exact"] for proof in proofs) if proofs else None,
                "role_positions_vary": len(set(positions)) >= 2 if positions else None,
                "selected_palettes_vary": len(set(palettes)) >= 2 if palettes else None,
                "description_length": self.description_length,
                "permissiveness_cost": list(self.permissiveness_cost),
            },
            "proofs": proofs,
        }


def _unique_modal_background(value: Grid):
    counts = Counter(v for row in value for v in row)
    if not counts:
        raise Inapplicable("empty grid")
    ranked = counts.most_common()
    if len(ranked) > 1 and ranked[0][1] == ranked[1][1]:
        raise Inapplicable("ambiguous modal background")
    return ranked[0][0]


def _component_symmetries(a: Grid, cells, box):
    r0, c0, r1, c1 = box
    height, width = r1 - r0 + 1, c1 - c0 + 1
    selected = set(cells)
    pattern = tuple(
        tuple(a[r0 + r][c0 + c] if (r0 + r, c0 + c) in selected else None for c in range(width))
        for r in range(height)
    )
    left_right = all(pattern[r][c] == pattern[r][width - 1 - c] for r in range(height) for c in range(width))
    top_bottom = all(pattern[r][c] == pattern[height - 1 - r][c] for r in range(height) for c in range(width))
    half_turn = all(pattern[r][c] == pattern[height - 1 - r][width - 1 - c] for r in range(height) for c in range(width))
    if height == width:
        main_diagonal = all(pattern[r][c] == pattern[c][r] for r in range(height) for c in range(width))
        anti_diagonal = all(pattern[r][c] == pattern[height - 1 - c][width - 1 - r] for r in range(height) for c in range(width))
    else:
        main_diagonal = anti_diagonal = False
    return left_right, top_bottom, half_turn, main_diagonal, anti_diagonal


def extract_components(value: Grid, connectivity: int = 4):
    """Return multicolour non-background components and the unique modal background."""
    a = grid(value)
    background = _unique_modal_background(a)
    if connectivity == 4:
        steps = ((1, 0), (-1, 0), (0, 1), (0, -1))
    elif connectivity == 8:
        steps = tuple(
            (dr, dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr, dc) != (0, 0)
        )
    else:
        raise Inapplicable("connectivity must be 4 or 8")
    height, width = len(a), len(a[0])
    seen = set()
    components = []
    for r in range(height):
        for c in range(width):
            if (r, c) in seen or a[r][c] == background:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in steps:
                    q = (rr + dr, cc + dc)
                    if not (0 <= q[0] < height and 0 <= q[1] < width):
                        continue
                    if q in seen or a[q[0]][q[1]] == background:
                        continue
                    seen.add(q)
                    stack.append(q)
            r0 = min(rr for rr, _ in cells)
            r1 = max(rr for rr, _ in cells)
            c0 = min(cc for _, cc in cells)
            c1 = max(cc for _, cc in cells)
            bbox_area = (r1 - r0 + 1) * (c1 - c0 + 1)
            colours = tuple(sorted({a[rr][cc] for rr, cc in cells}))
            symmetries = _component_symmetries(a, cells, (r0, c0, r1, c1))
            components.append(
                Component(
                    tuple(sorted(cells)),
                    (r0, c0, r1, c1),
                    len(cells),
                    bbox_area,
                    r1 - r0 + 1,
                    c1 - c0 + 1,
                    len(cells),
                    bbox_area,
                    colours,
                    r0,
                    c0,
                    *symmetries,
                )
            )
    components.sort(key=lambda component: (component.top, component.left, component.box))
    return tuple(components), background


_SELECTOR_METRICS = (
    "distinct_colours",
    "left_right_symmetry",
    "top_bottom_symmetry",
    "half_turn_symmetry",
    "main_diagonal_symmetry",
    "anti_diagonal_symmetry",
    "area",
    "bbox_area",
    "density",
    "height",
    "width",
)


def candidate_component_programs():
    programs = []
    symmetry_metrics = {
        "left_right_symmetry", "top_bottom_symmetry", "half_turn_symmetry",
        "main_diagonal_symmetry", "anti_diagonal_symmetry",
    }
    for metric in _SELECTOR_METRICS:
        extrema = ("max",) if metric in symmetry_metrics else ("max", "min")
        for extremum in extrema:
            for connectivity in (4, 8):
                for crop_mode in ("raw_bbox", "component_mask"):
                    programs.append(
                        ComponentExtractionProgram(connectivity, extremum, metric, crop_mode, 3)
                    )
    return tuple(programs)


def _role_varies(program: ComponentExtractionProgram, pairs: Sequence[tuple[Grid, Grid]]):
    positions = []
    palettes = []
    for a, _ in pairs:
        winner, components, _ = program.select(a)
        if winner is None or len(components) < program.minimum_components:
            return False
        positions.append((winner.top, winner.left))
        palettes.append(winner.colours)
    # The selected role must move spatially, preventing a fixed-window crop.
    if len(set(positions)) < 2:
        return False
    # Require colour-role variation for every selector.  This prevents a fixed
    # colour identity from masquerading as an attribute/common-notion rule.
    if len(set(palettes)) < 2:
        return False
    return True


def fit_component_extraction(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 3,
    allowed_schemas: Iterable[tuple] | None = None,
):
    pairs = tuple((grid(a), grid(y)) for a, y in pairs)
    if len(pairs) < minimum_pairs:
        return []
    if not all(len(y) <= len(a) and len(y[0]) <= len(a[0]) for a, y in pairs):
        return []
    allowed = set(allowed_schemas) if allowed_schemas is not None else None
    models = []
    for program in candidate_component_programs():
        key = (
            program.connectivity,
            program.extremum,
            program.metric,
            program.crop_mode,
            program.minimum_components,
        )
        if allowed is not None and key not in allowed:
            continue
        try:
            if not all(program.predict(a) == y for a, y in pairs):
                continue
        except (Inapplicable, ValueError, IndexError, TypeError):
            continue
        if not _role_varies(program, pairs):
            continue
        models.append(program)

    # Deduplicate exact programs and retain the least permissive explanations.
    unique = {
        (
            model.connectivity,
            model.extremum,
            model.metric,
            model.crop_mode,
            model.minimum_components,
        ): model
        for model in models
    }
    models = list(unique.values())
    if models:
        best = min((model.description_length, model.permissiveness_cost) for model in models)
        models = [
            model
            for model in models
            if (model.description_length, model.permissiveness_cost) == best
        ]
    models.sort(
        key=lambda model: (
            model.description_length,
            model.permissiveness_cost,
            model.selector,
            model.crop_mode,
        )
    )
    return models


def infer_common_notion_extraction(task, *, minimum_pairs: int = 3, allowed_schemas=None):
    clean = public_task(task)
    pairs = tuple((d["input"], d["output"]) for d in clean["train"])
    models = fit_component_extraction(
        pairs, minimum_pairs=minimum_pairs, allowed_schemas=allowed_schemas
    )
    groups = {}
    invalid = 0
    for model in models:
        predictions = []
        try:
            for case in clean["test"]:
                predicted = model.predict(case["input"])
                if predicted is None:
                    raise Inapplicable("component extraction inapplicable to test input")
                predictions.append(predicted)
        except (Inapplicable, ValueError, IndexError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups.setdefault(key, []).append(model.describe(pairs))
        if len(groups) >= 2:
            break

    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:20] if chosen else [],
        "witness_predictions": [
            [[[int(v) for v in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(models),
            "inapplicable_programs": invalid,
            "common_notion_routed": True,
            "proof_carrying": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def validate_common_notion_extraction(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": []}
    if len(clean["train"]) < 3:
        return {"passed": False, "reason": "requires_three_demonstrations", "folds": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    schemas = []
    for law in full.get("supporting_laws", ()):
        p = law.get("parameters", {})
        if p:
            schemas.append(
                (
                    p.get("connectivity"),
                    p.get("extremum"),
                    p.get("metric"),
                    p.get("crop_mode"),
                    p.get("minimum_components"),
                )
            )
    allowed = tuple(sorted(set(schemas), key=repr))
    folds = []
    for held, demo in enumerate(clean["train"]):
        fold = {
            "train": [d for index, d in enumerate(clean["train"]) if index != held],
            "test": [{"input": demo["input"]}] + clean["test"],
        }
        result = infer_common_notion_extraction(
            fold, minimum_pairs=2, allowed_schemas=allowed
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append(
            {
                "held_index": held,
                "status": result["status"],
                "held_example_exact": result["status"] == "unique"
                and predictions[0] == demo["output"],
                "test_prediction_stable": result["status"] == "unique"
                and predictions[1:] == expected,
                "joint_hypotheses": result["joint_hypotheses"],
            }
        )
    passed = all(
        fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds
    )
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure",
        "folds": folds,
    }


# ---------------------------------------------------------------------------
# Cross-task common-notion signatures
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TaskSignature:
    atoms: tuple[str, ...]

    @property
    def key(self):
        return sha256("\n".join(self.atoms).encode("utf-8")).hexdigest()[:16]

    def to_dict(self):
        return {"signature_id": self.key, "atoms": list(self.atoms)}


def _palette_relation(a: Grid, y: Grid):
    pa = {v for row in a for v in row}
    py = {v for row in y for v in row}
    if pa == py:
        return "equal"
    if py < pa:
        return "subset"
    if pa < py:
        return "superset"
    return "mixed"


def _is_submatrix(big: Grid, small: Grid):
    if len(small) > len(big) or len(small[0]) > len(big[0]):
        return False
    for r in range(len(big) - len(small) + 1):
        for c in range(len(big[0]) - len(small[0]) + 1):
            if all(tuple(big[r + rr][c : c + len(small[0])]) == tuple(small[rr]) for rr in range(len(small))):
                return True
    return False


def _demo_signature_atoms(a: Grid, y: Grid):
    a, y = grid(a), grid(y)
    atoms = set()
    ah, aw, yh, yw = len(a), len(a[0]), len(y), len(y[0])
    if (ah, aw) == (yh, yw):
        atoms.add("canvas_shape:preserved")
    else:
        atoms.add("canvas_shape:changed")
        if yh <= ah and yw <= aw:
            atoms.add("output_extent:smaller_or_equal")
        if yh >= ah and yw >= aw:
            atoms.add("output_extent:larger_or_equal")
    atoms.add("palette_relation:" + _palette_relation(a, y))
    if _is_submatrix(a, y):
        atoms.add("output_relation:input_submatrix")
    try:
        ba, by = _unique_modal_background(a), _unique_modal_background(y)
        ca = sum(v != ba for row in a for v in row)
        cy = sum(v != by for row in y for v in row)
        atoms.add(
            "nonbackground_material:"
            + ("preserved" if ca == cy else "increased" if cy > ca else "decreased")
        )
        if ba == by:
            atoms.add("background:preserved")
    except Inapplicable:
        atoms.add("background:ambiguous")
    if a != y:
        atoms.add("effect:non_identity")
    try:
        components4, _ = extract_components(a, 4)
        atoms.add(
            "input_components4:"
            + ("at_least_three" if len(components4) >= 3 else str(len(components4)))
        )
        if len(components4) >= 3:
            values = [component.distinct_colours for component in components4]
            if values.count(max(values)) == 1:
                atoms.add("affordance:unique_max_distinct_colours")
            lr = [int(component.left_right_symmetry) for component in components4]
            if max(lr, default=0) == 1 and lr.count(1) == 1:
                atoms.add("affordance:unique_left_right_symmetric_component")
    except Inapplicable:
        pass
    return atoms


def extract_task_signature(task) -> TaskSignature:
    clean = public_task(task)
    demo_atoms = [
        _demo_signature_atoms(d["input"], d["output"]) for d in clean["train"]
    ]
    common = set.intersection(*demo_atoms) if demo_atoms else set()
    common.add(f"demonstrations:{len(clean['train'])}")
    common.add(f"test_inputs:{len(clean['test'])}")
    return TaskSignature(tuple(sorted(common)))


def route_signature(signature: TaskSignature):
    atoms = set(signature.atoms)
    routes = []
    if {
        "output_extent:smaller_or_equal",
        "output_relation:input_submatrix",
        "input_components4:at_least_three",
    } <= atoms:
        routes.append(FAMILY)
    return tuple(routes)


def mine_corpus_common_notions(
    challenges: Mapping[str, dict],
    ledger: Mapping[str, Mapping] | None = None,
    *,
    minimum_atom_support: int = 10,
    minimum_pair_support: int = 10,
):
    signatures = {}
    clusters = defaultdict(list)
    atom_counts = Counter()
    atom_exact = Counter()
    pair_counts = Counter()
    pair_exact = Counter()
    for task_id, task in challenges.items():
        signature = extract_task_signature(task)
        signatures[task_id] = signature
        clusters[signature.key].append(task_id)
        exact = bool(ledger and ledger.get(task_id, {}).get("final_grade") == "exact")
        for atom in signature.atoms:
            atom_counts[atom] += 1
            atom_exact[atom] += int(exact)
        for pair in combinations(signature.atoms, 2):
            pair_counts[pair] += 1
            pair_exact[pair] += int(exact)
    atom_rows = [
        {
            "atom": atom,
            "support": count,
            "protected_exact": atom_exact[atom],
            "exact_rate": atom_exact[atom] / count if count else 0.0,
        }
        for atom, count in atom_counts.items()
        if count >= minimum_atom_support
    ]
    atom_rows.sort(key=lambda row: (-row["support"], row["atom"]))
    pair_rows = [
        {
            "atoms": list(pair),
            "support": count,
            "protected_exact": pair_exact[pair],
            "exact_rate": pair_exact[pair] / count if count else 0.0,
        }
        for pair, count in pair_counts.items()
        if count >= minimum_pair_support
    ]
    pair_rows.sort(key=lambda row: (-row["support"], row["atoms"]))
    cluster_rows = []
    for signature_id, task_ids in clusters.items():
        exemplar = signatures[task_ids[0]]
        protected = sum(
            1
            for task_id in task_ids
            if ledger and ledger.get(task_id, {}).get("final_grade") == "exact"
        )
        cluster_rows.append(
            {
                "signature_id": signature_id,
                "support": len(task_ids),
                "protected_exact": protected,
                "exact_rate": protected / len(task_ids) if task_ids else 0.0,
                "atoms": list(exemplar.atoms),
                "task_ids": sorted(task_ids),
            }
        )
    cluster_rows.sort(key=lambda row: (-row["support"], row["signature_id"]))
    return {
        "tasks": len(challenges),
        "unique_signatures": len(clusters),
        "signatures": {task_id: signature.to_dict() for task_id, signature in signatures.items()},
        "clusters": cluster_rows,
        "frequent_atoms": atom_rows,
        "frequent_pairs": pair_rows,
    }


# ---------------------------------------------------------------------------
# Program anti-unification
# ---------------------------------------------------------------------------


def _law_steps(law: Mapping):
    if law.get("propositions"):
        steps = []
        for proposition in law["propositions"]:
            steps.append(
                {
                    "definition": proposition.get("definition"),
                    "motion": proposition.get("motion"),
                    "source_policy": proposition.get("source_policy"),
                    "parameters": proposition.get("parameters", ()),
                }
            )
        return tuple(steps)
    if law.get("relation"):
        return (
            {
                "definition": law.get("relation"),
                "motion": law.get("motion"),
                "source_policy": law.get("source_policy"),
                "parameters": law.get("parameters", ()),
            },
        )
    if law.get("schema") == "select_unique_component_extremum_then_crop":
        p = law.get("parameters", {})
        return (
            {
                "definition": "select_component",
                "motion": None,
                "source_policy": None,
                "parameters": (
                    p.get("connectivity"),
                    p.get("extremum"),
                    p.get("metric"),
                    p.get("minimum_components"),
                ),
            },
            {
                "definition": "canonical_crop",
                "motion": None,
                "source_policy": None,
                "parameters": (p.get("crop_mode"),),
            },
        )
    return ()


def _value_type(value):
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "symbol"
    if isinstance(value, (list, tuple)):
        return "tuple"
    if value is None:
        return "null"
    return type(value).__name__


def anti_unify_program_laws(records: Iterable[Mapping]):
    """Group successful laws by operator skeleton and abstract varying parameters."""
    groups = defaultdict(list)
    for record in records:
        law = record.get("law", record)
        steps = _law_steps(law)
        if not steps:
            continue
        skeleton = tuple(
            (step["definition"], step.get("motion"), step.get("source_policy"))
            for step in steps
        )
        groups[skeleton].append((record.get("task_id"), steps, law))

    schemas = []
    for skeleton, entries in groups.items():
        step_schemas = []
        for index, (definition, motion, source_policy) in enumerate(skeleton):
            parameter_lists = [tuple(steps[index].get("parameters", ())) for _, steps, _ in entries]
            width = max((len(parameters) for parameters in parameter_lists), default=0)
            parameters = []
            for position in range(width):
                values = [
                    parameters[position] if position < len(parameters) else None
                    for parameters in parameter_lists
                ]
                serialized = {json.dumps(value, sort_keys=True, default=repr) for value in values}
                if len(serialized) == 1:
                    parameters.append({"kind": "constant", "value": values[0]})
                else:
                    parameters.append(
                        {
                            "kind": "variable",
                            "name": f"{definition}_p{position}",
                            "types": sorted({_value_type(value) for value in values}),
                            "observed_values": values[:20],
                        }
                    )
            step_schemas.append(
                {
                    "definition": definition,
                    "motion": motion,
                    "source_policy": source_policy,
                    "parameters": parameters,
                }
            )
        task_ids = sorted({task_id for task_id, _, _ in entries if task_id})
        schemas.append(
            {
                "schema_version": SCHEMA_VERSION,
                "skeleton": [list(item) for item in skeleton],
                "support": len(entries),
                "task_ids": task_ids,
                "steps": step_schemas,
            }
        )
    schemas.sort(key=lambda schema: (-schema["support"], repr(schema["skeleton"])))
    return schemas
