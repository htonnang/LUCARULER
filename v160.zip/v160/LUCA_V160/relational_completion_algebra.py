"""LUCA V134: anti-unified relational completion algebra.

Typed stage language:
scene -> candidate/relation -> operator -> emission.

The family intentionally excludes task identifiers, official test targets, and
stored absolute demonstration coordinates.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import permutations

from runtime import public_task

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anti_unified_relational_completion_algebra"
LANGUAGE = "spinoza_relational_completion_v134"
SCHEMA_VERSION = 1


class Inapplicable(ValueError):
    pass


def grid(value) -> Grid:
    return tuple(tuple(int(cell) for cell in row) for row in value)


def _array(value: Grid):
    return [list(row) for row in grid(value)]


def _shape(value: Grid):
    value = grid(value)
    return len(value), len(value[0])


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _mode(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    best = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == best]
    if len(winners) != 1:
        raise Inapplicable("background mode not unique")
    return int(winners[0])


def _candidate_backgrounds(pairs):
    candidates = None
    for source, _ in pairs:
        source = grid(source)
        values = set()
        if 0 in _palette(source):
            values.add(0)
        try:
            values.add(_mode(source))
        except Inapplicable:
            pass
        corners = {source[0][0], source[0][-1], source[-1][0], source[-1][-1]}
        if len(corners) == 1:
            values.add(int(next(iter(corners))))
        candidates = values if candidates is None else candidates & values
    return tuple(sorted(candidates or ()))


def _dirs(connectivity=4):
    if connectivity == 4:
        return ((-1, 0), (1, 0), (0, -1), (0, 1))
    return tuple(
        (dr, dc)
        for dr in (-1, 0, 1)
        for dc in (-1, 0, 1)
        if (dr, dc) != (0, 0)
    )


def _bbox(cells):
    rows = [cell[0] for cell in cells]
    cols = [cell[1] for cell in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if value[r][c] != colour or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and value[nr][nc] == colour
                        and (nr, nc) not in seen
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            components.append(tuple(sorted(cells)))
    components.sort(key=lambda cells: _bbox(cells))
    return tuple(components)


def _foreground_components(value: Grid, background: int, connectivity=4):
    value = grid(value)
    h, w = _shape(value)
    seen = set()
    components = []
    for r in range(h):
        for c in range(w):
            if value[r][c] == background or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            cells = []
            while stack:
                rr, cc = stack.pop()
                cells.append((rr, cc))
                for dr, dc in _dirs(connectivity):
                    nr, nc = rr + dr, cc + dc
                    if (
                        0 <= nr < h
                        and 0 <= nc < w
                        and value[nr][nc] != background
                        and (nr, nc) not in seen
                    ):
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            components.append(tuple(sorted(cells)))
    components.sort(key=lambda cells: _bbox(cells))
    return tuple(components)


def _fresh_colour(value, forbidden=()):
    used = _palette(value) | set(forbidden)
    for colour in range(1, 10):
        if colour not in used:
            return colour
    raise Inapplicable("no fresh ARC colour")


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


# ---------------------------------------------------------------------------
# 1. Background-component extrema.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BackgroundComponentExtremaProgram:
    background: int
    connectivity: int
    minimum_colour: int
    maximum_colour: int

    kind = "background_component_extrema_recolour"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background,
            self.connectivity,
            self.minimum_colour,
            self.maximum_colour,
        )

    def analyse(self, value):
        value = grid(value)
        components = _components_of_colour(value, self.background, self.connectivity)
        if len(components) < 3:
            raise Inapplicable("requires at least three background regions")
        sizes = [len(cells) for cells in components]
        smallest = min(sizes)
        largest = max(sizes)
        if smallest == largest:
            raise Inapplicable("no extrema")
        mins = [cells for cells in components if len(cells) == smallest]
        maxs = [cells for cells in components if len(cells) == largest]
        if len(mins) != 1 or len(maxs) != 1:
            raise Inapplicable("component extrema not unique")
        return mins[0], maxs[0]

    def predict(self, value):
        value = grid(value)
        minimum, maximum = self.analyse(value)
        out = _array(value)
        for r, c in minimum:
            out[r][c] = self.minimum_colour
        for r, c in maximum:
            out[r][c] = self.maximum_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "connectivity": self.connectivity,
                "minimum_colour": self.minimum_colour,
                "maximum_colour": self.maximum_colour,
            },
            definitions={
                "background_region": "one connected component of the background colour",
                "extrema": "unique minimum-area and maximum-area background regions",
            },
            propositions=[
                "Background regions are compared by area rather than coordinates.",
                "The unique minimum and maximum receive two learned semantic colours.",
            ],
            corollary="Recolour the smallest and largest background regions.",
            common_notions=["connected region", "area", "extremum", "role recolouring"],
        )


def _fit_background_extrema(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        for connectivity in (4, 8):
            first_source, first_target = pairs[0]
            if _shape(first_source) != _shape(first_target):
                continue
            try:
                probe = BackgroundComponentExtremaProgram(background, connectivity, 1, 2)
                minimum, maximum = probe.analyse(first_source)
            except Inapplicable:
                continue
            min_values = {grid(first_target)[r][c] for r, c in minimum}
            max_values = {grid(first_target)[r][c] for r, c in maximum}
            if len(min_values) != 1 or len(max_values) != 1:
                continue
            min_colour = int(next(iter(min_values)))
            max_colour = int(next(iter(max_values)))
            if min_colour == background or max_colour == background or min_colour == max_colour:
                continue
            program = BackgroundComponentExtremaProgram(
                background, connectivity, min_colour, max_colour
            )
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 2. Four-panel priority overlay.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PanelPriorityOverlayProgram:
    background: int
    priority: tuple[int, int, int, int]

    kind = "panel_priority_overlay"

    @property
    def schema_key(self):
        return self.kind, self.background, self.priority

    def _panels(self, value):
        value = grid(value)
        h, w = _shape(value)
        if h % 2 or w % 2 or h // 2 < 2 or w // 2 < 2:
            raise Inapplicable("requires a 2x2 equal panel layout")
        ph, pw = h // 2, w // 2
        panels = (
            tuple(tuple(value[r][c] for c in range(0, pw)) for r in range(0, ph)),
            tuple(tuple(value[r][c] for c in range(pw, w)) for r in range(0, ph)),
            tuple(tuple(value[r][c] for c in range(0, pw)) for r in range(ph, h)),
            tuple(tuple(value[r][c] for c in range(pw, w)) for r in range(ph, h)),
        )
        colours = []
        for panel in panels:
            foreground = _palette(panel) - {self.background}
            if len(foreground) != 1:
                raise Inapplicable("each panel requires one foreground colour")
            colours.append(int(next(iter(foreground))))
        if len(set(colours)) != 4:
            raise Inapplicable("panel foreground colours must be distinct")
        return panels, tuple(colours)

    def predict(self, value):
        panels, colours = self._panels(value)
        ph, pw = _shape(panels[0])
        out = [[self.background] * pw for _ in range(ph)]
        for r in range(ph):
            for c in range(pw):
                for index in self.priority:
                    if panels[index][r][c] != self.background:
                        out[r][c] = colours[index]
                        break
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "priority": list(self.priority)},
            definitions={
                "panel_role": "one of four equal masks with a unique foreground colour",
                "priority": "a learned strict order over panel roles",
            },
            propositions=[
                "At each logical cell all active panel roles are compared.",
                "The highest-priority active role supplies the output colour.",
            ],
            corollary="Overlay the four panel masks under the learned priority order.",
            common_notions=["panel role", "overlay", "priority", "mask composition"],
        )


def _fit_panel_priority(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        for priority in permutations(range(4)):
            program = PanelPriorityOverlayProgram(background, tuple(priority))
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 3. Dominant-colour cleanup inside multicolour components.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DominantComponentCleanupProgram:
    background: int
    connectivity: int

    kind = "dominant_component_cleanup"

    @property
    def schema_key(self):
        return self.kind, self.background, self.connectivity

    def _multicolour(self, value):
        value = grid(value)
        components = _foreground_components(value, self.background, self.connectivity)
        records = []
        for cells in components:
            counts = Counter(value[r][c] for r, c in cells)
            if len(counts) == 1:
                continue
            best = max(counts.values())
            winners = [colour for colour, count in counts.items() if count == best]
            if len(winners) != 1:
                raise Inapplicable("multicolour component has no unique dominant colour")
            dominant = int(winners[0])
            if best <= len(cells) - best:
                raise Inapplicable("dominant colour lacks majority support")
            records.append((cells, dominant, _bbox(cells)))
        if not records:
            raise Inapplicable("no multicolour component")
        return tuple(components), tuple(records)

    def predict(self, value):
        value = grid(value)
        components, records = self._multicolour(value)
        out = _array(value)
        clear = set()
        for cells, dominant, (r0, c0, r1, c1) in records:
            host = set(cells)
            # Minority cells connected to the dominant structure are intrusions.
            for r, c in cells:
                if value[r][c] != dominant:
                    clear.add((r, c))
            # A fully enclosed foreign component is also an intrusion even when
            # background separates it from the dominant structure.
            for other in components:
                if set(other) == host:
                    continue
                if all(r0 < r < r1 and c0 < c < c1 for r, c in other):
                    if all(value[r][c] != dominant for r, c in other):
                        clear.update(other)
        if not clear:
            raise Inapplicable("no intrusions to remove")
        for r, c in clear:
            out[r][c] = self.background
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "connectivity": self.connectivity},
            definitions={
                "multicolour_component": "one connected foreground object containing several colours",
                "dominant_colour": "the unique majority colour of that object",
            },
            propositions=[
                "Pure components are preserved.",
                "Minority-colour intrusions in each multicolour object are erased.",
            ],
            corollary="Clean every multicolour object to its dominant structural colour.",
            common_notions=["connected object", "majority", "intrusion", "cleanup"],
        )


def _fit_dominant_cleanup(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        for connectivity in (4, 8):
            program = DominantComponentCleanupProgram(background, connectivity)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 4. Exterior-boundary projection.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ExteriorBoundaryProjectionProgram:
    background: int
    object_connectivity: int

    kind = "exterior_boundary_projection"

    @property
    def schema_key(self):
        return self.kind, self.background, self.object_connectivity

    def analyse(self, value):
        value = grid(value)
        components = _foreground_components(value, self.background, self.object_connectivity)
        if len(components) != 1:
            raise Inapplicable("requires one foreground object")
        colours = Counter(value[r][c] for r, c in components[0])
        if len(colours) < 2:
            raise Inapplicable("requires a multicolour object")
        smallest = min(colours.values())
        winners = [colour for colour, count in colours.items() if count == smallest]
        if len(winners) != 1:
            raise Inapplicable("signal colour not uniquely least frequent")
        return set(components[0]), int(winners[0])

    def predict(self, value):
        value = grid(value)
        h, w = _shape(value)
        foreground, signal = self.analyse(value)

        # External background only; holes are excluded.
        external = set()
        stack = []
        for r in range(h):
            for c in (0, w - 1):
                if value[r][c] == self.background and (r, c) not in external:
                    external.add((r, c)); stack.append((r, c))
        for c in range(w):
            for r in (0, h - 1):
                if value[r][c] == self.background and (r, c) not in external:
                    external.add((r, c)); stack.append((r, c))
        while stack:
            r, c = stack.pop()
            for dr, dc in _dirs(4):
                nr, nc = r + dr, c + dc
                if (
                    0 <= nr < h
                    and 0 <= nc < w
                    and value[nr][nc] == self.background
                    and (nr, nc) not in external
                ):
                    external.add((nr, nc)); stack.append((nr, nc))

        boundary = {
            (r, c)
            for r, c in external
            if any((r + dr, c + dc) in foreground for dr, dc in _dirs(4))
        }
        if not boundary:
            raise Inapplicable("external boundary empty")
        out = [[self.background] * w for _ in range(h)]
        for r, c in boundary:
            out[r][c] = signal
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background, "object_connectivity": self.object_connectivity},
            definitions={
                "signal_colour": "the unique least frequent foreground colour",
                "exterior_boundary": "external background cells orthogonally adjacent to the foreground object",
            },
            propositions=[
                "The original object is removed from the emission.",
                "Only the clipped exterior boundary is painted in the signal colour.",
            ],
            corollary="Project the object's exterior contour in its signal colour.",
            common_notions=["foreground object", "external boundary", "frequency role", "contour"],
        )


def _fit_exterior_boundary(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        for connectivity in (4, 8):
            program = ExteriorBoundaryProjectionProgram(background, connectivity)
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


# ---------------------------------------------------------------------------
# 5. Domino-halo completion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DominoHaloProgram:
    background: int
    seed_colour: int
    halo_colour: int
    padding: int = 1

    kind = "domino_halo_completion"

    @property
    def schema_key(self):
        return self.kind, self.background, self.seed_colour, self.halo_colour, self.padding

    def _dominoes(self, value):
        value = grid(value)
        dominoes = []
        for cells in _components_of_colour(value, self.seed_colour, 4):
            if len(cells) != 2:
                continue
            (r0, c0), (r1, c1) = cells
            if abs(r0 - r1) + abs(c0 - c1) == 1:
                dominoes.append(cells)
        if not dominoes:
            raise Inapplicable("no seed domino")
        return tuple(dominoes)

    def predict(self, value):
        value = grid(value)
        h, w = _shape(value)
        out = _array(value)
        changed = 0
        for cells in self._dominoes(value):
            r0, c0, r1, c1 = _bbox(cells)
            for r in range(max(0, r0 - self.padding), min(h - 1, r1 + self.padding) + 1):
                for c in range(max(0, c0 - self.padding), min(w - 1, c1 + self.padding) + 1):
                    if out[r][c] == self.background:
                        out[r][c] = self.halo_colour
                        changed += 1
        if not changed:
            raise Inapplicable("halo adds no material")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "seed_colour": self.seed_colour,
                "halo_colour": self.halo_colour,
                "padding": self.padding,
            },
            definitions={"seed_domino": "an orthogonally connected two-cell component"},
            propositions=[
                "Each seed domino defines a clipped padded bounding box.",
                "Only background cells in that box receive the halo colour.",
            ],
            corollary="Complete a one-cell halo around every seed domino.",
            common_notions=["domino", "bounding box", "padding", "completion"],
        )


def _fit_domino_halo(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        source_colours = sorted(set.intersection(*(_palette(grid(s)) for s, _ in pairs)) - {background})
        output_only = sorted(set.union(*(_palette(grid(t)) for _, t in pairs)) - set.union(*(_palette(grid(s)) for s, _ in pairs)))
        # Output-only is the safest candidate; fall back to all output colours.
        halo_candidates = output_only or sorted(set.union(*(_palette(grid(t)) for _, t in pairs)) - {background})
        for seed_colour in source_colours:
            for halo_colour in halo_candidates:
                if halo_colour in (background, seed_colour):
                    continue
                program = DominoHaloProgram(background, seed_colour, halo_colour, 1)
                try:
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programs.append(program)
                except Inapplicable:
                    pass
    return programs


# ---------------------------------------------------------------------------
# 6. Colour bounding-box height histogram.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColourHeightHistogramProgram:
    background: int

    kind = "colour_bbox_height_histogram"

    @property
    def schema_key(self):
        return self.kind, self.background

    def records(self, value):
        value = grid(value)
        by_colour = defaultdict(list)
        for r, row in enumerate(value):
            for c, colour in enumerate(row):
                if colour != self.background:
                    by_colour[int(colour)].append((r, c))
        if len(by_colour) < 3:
            raise Inapplicable("requires at least three foreground colours")
        records = []
        for colour, cells in by_colour.items():
            r0, _, r1, _ = _bbox(cells)
            records.append((r1 - r0 + 1, colour))
        if len({height for height, _ in records}) != len(records):
            raise Inapplicable("colour heights must be strict")
        return tuple(sorted(records, key=lambda item: (-item[0], item[1])))

    def predict(self, value):
        records = self.records(value)
        height = records[0][0]
        out = [[self.background] * len(records) for _ in range(height)]
        for c, (extent, colour) in enumerate(records):
            for r in range(extent):
                out[r][c] = colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={"background": self.background},
            definitions={"colour_height": "height of the global bounding box of all cells of one colour"},
            propositions=[
                "Colours are strictly ranked by decreasing global bounding-box height.",
                "Every colour emits a top-aligned unary column of that height.",
            ],
            corollary="Project colour extents into a canonical height histogram.",
            common_notions=["colour class", "bounding box", "height", "histogram"],
        )


def _fit_colour_height_histogram(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        program = ColourHeightHistogramProgram(background)
        try:
            if all(program.predict(source) == grid(target) for source, target in pairs):
                programs.append(program)
        except Inapplicable:
            pass
    return programs


# ---------------------------------------------------------------------------
# 7. Bounding-box instruction recolouring.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BoundingBoxInstructionRecolourProgram:
    instruction_colour: int
    target_colour: int
    replacement_colour: int

    kind = "bbox_instruction_recolour"

    @property
    def schema_key(self):
        return self.kind, self.instruction_colour, self.target_colour, self.replacement_colour

    def predict(self, value):
        value = grid(value)
        instruction = [
            (r, c)
            for r, row in enumerate(value)
            for c, colour in enumerate(row)
            if colour == self.instruction_colour
        ]
        if len(instruction) < 2:
            raise Inapplicable("instruction support too small")
        r0, c0, r1, c1 = _bbox(instruction)
        # The box must be genuinely local: target-colour evidence outside it
        # demonstrates that the instruction selects a region rather than merely
        # recolouring the entire target class.
        outside_target = any(
            value[r][c] == self.target_colour
            and not (r0 <= r <= r1 and c0 <= c <= c1)
            for r in range(len(value))
            for c in range(len(value[0]))
        )
        if not outside_target:
            raise Inapplicable("instruction box is not selective")
        out = _array(value)
        changed = 0
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                if out[r][c] == self.target_colour:
                    out[r][c] = self.replacement_colour
                    changed += 1
        if not changed:
            raise Inapplicable("instruction box contains no target cells")
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "instruction_colour": self.instruction_colour,
                "target_colour": self.target_colour,
                "replacement_colour": self.replacement_colour,
            },
            definitions={"instruction_box": "the bounding box of all cells of the instruction colour"},
            propositions=[
                "Only target-colour cells inside the instruction box are changed.",
                "Instruction geometry rather than absolute coordinates defines the action region.",
            ],
            corollary="Apply a learned recolouring inside the instruction bounding box.",
            common_notions=["instruction support", "bounding box", "local recolouring"],
        )


def _fit_bbox_instruction(pairs):
    programs = []
    shared_source = set.intersection(*(_palette(grid(source)) for source, _ in pairs))
    output_colours = set.union(*(_palette(grid(target)) for _, target in pairs))
    for instruction_colour in sorted(shared_source):
        for target_colour in sorted(shared_source - {instruction_colour}):
            for replacement_colour in sorted(output_colours - {instruction_colour, target_colour}):
                program = BoundingBoxInstructionRecolourProgram(
                    instruction_colour, target_colour, replacement_colour
                )
                try:
                    if all(program.predict(source) == grid(target) for source, target in pairs):
                        programs.append(program)
                except Inapplicable:
                    pass
    return programs


# ---------------------------------------------------------------------------
# 8. Diagonal-orientation frequency recolouring.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DiagonalOrientationFrequencyProgram:
    background: int
    line_colour: int
    majority_colour: int
    minority_colour: int

    kind = "diagonal_orientation_frequency_recolour"

    @property
    def schema_key(self):
        return (
            self.kind,
            self.background,
            self.line_colour,
            self.majority_colour,
            self.minority_colour,
        )

    def analyse(self, value):
        value = grid(value)
        h, w = _shape(value)
        cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] == self.line_colour}
        if len(cells) < 4:
            raise Inapplicable("insufficient diagonal evidence")
        groups = {"backslash": set(), "slash": set()}
        for r, c in cells:
            backslash = ((r - 1, c - 1) in cells) or ((r + 1, c + 1) in cells)
            slash = ((r - 1, c + 1) in cells) or ((r + 1, c - 1) in cells)
            if backslash == slash:
                raise Inapplicable("line cell is isolated or belongs to both diagonal orientations")
            groups["backslash" if backslash else "slash"].add((r, c))
        if not groups["backslash"] or not groups["slash"]:
            raise Inapplicable("both diagonal orientations are required")
        counts = {name: len(points) for name, points in groups.items()}
        if counts["backslash"] == counts["slash"]:
            raise Inapplicable("diagonal orientation counts tied")
        majority = max(counts, key=counts.get)
        minority = "slash" if majority == "backslash" else "backslash"
        return groups, majority, minority

    def predict(self, value):
        value = grid(value)
        groups, majority, minority = self.analyse(value)
        out = _array(value)
        for r, c in groups[majority]:
            out[r][c] = self.majority_colour
        for r, c in groups[minority]:
            out[r][c] = self.minority_colour
        return tuple(tuple(row) for row in out)

    def describe(self, pairs):
        return _law(
            self,
            parameters={
                "background": self.background,
                "line_colour": self.line_colour,
                "majority_colour": self.majority_colour,
                "minority_colour": self.minority_colour,
            },
            definitions={
                "orientation_support": "cells belonging exclusively to one diagonal line orientation",
                "majority_orientation": "the diagonal orientation with more supported cells",
            },
            propositions=[
                "Both slash and backslash line families are identified from local diagonal adjacency.",
                "The majority orientation and minority orientation receive two learned colours.",
            ],
            corollary="Recolour diagonal lines by orientation frequency.",
            common_notions=["diagonal line", "orientation", "frequency", "role recolouring"],
        )


def _fit_diagonal_orientation_frequency(pairs):
    programs = []
    for background in _candidate_backgrounds(pairs):
        shared = set.intersection(*(_palette(grid(source)) for source, _ in pairs)) - {background}
        for line_colour in sorted(shared):
            first_source, first_target = pairs[0]
            if _shape(first_source) != _shape(first_target):
                continue
            probe = DiagonalOrientationFrequencyProgram(background, line_colour, 1, 2)
            try:
                groups, majority, minority = probe.analyse(first_source)
            except Inapplicable:
                continue
            majority_values = {grid(first_target)[r][c] for r, c in groups[majority]}
            minority_values = {grid(first_target)[r][c] for r, c in groups[minority]}
            if len(majority_values) != 1 or len(minority_values) != 1:
                continue
            majority_colour = int(next(iter(majority_values)))
            minority_colour = int(next(iter(minority_values)))
            if majority_colour in (background, line_colour) or minority_colour in (background, line_colour):
                continue
            if majority_colour == minority_colour:
                continue
            program = DiagonalOrientationFrequencyProgram(
                background, line_colour, majority_colour, minority_colour
            )
            try:
                if all(program.predict(source) == grid(target) for source, target in pairs):
                    programs.append(program)
            except Inapplicable:
                pass
    return programs


FITTERS = (
    _fit_background_extrema,
    _fit_panel_priority,
    _fit_dominant_cleanup,
    _fit_exterior_boundary,
    _fit_domino_halo,
    _fit_colour_height_histogram,
    _fit_bbox_instruction,
    _fit_diagonal_orientation_frequency,
)


def fit_relational_completion_algebra_programs(pairs, *, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return ()
    programs = []
    seen = set()
    for fitter in FITTERS:
        for program in fitter(pairs):
            if allowed_kinds and program.kind not in allowed_kinds:
                continue
            if program.schema_key in seen:
                continue
            seen.add(program.schema_key)
            programs.append(program)
    return tuple(sorted(programs, key=lambda program: repr(program.schema_key)))


def _counterfactual(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        passed = False
        details = {}
        try:
            if isinstance(program, BackgroundComponentExtremaProgram):
                minimum, _ = program.analyse(source)
                work = _array(source)
                r, c = minimum[0]
                work[r][c] = _fresh_colour(source, (program.minimum_colour, program.maximum_colour))
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"extremum_region_perturbation_changes_or_rejects": passed}

            elif isinstance(program, PanelPriorityOverlayProgram):
                panels, _ = program._panels(source)
                ph, pw = _shape(panels[0])
                work = _array(source)
                altered = False
                for r in range(ph):
                    for c in range(pw):
                        active = [idx for idx in program.priority if panels[idx][r][c] != program.background]
                        if len(active) >= 2:
                            idx = active[0]
                            rr = r + (ph if idx >= 2 else 0)
                            cc = c + (pw if idx % 2 else 0)
                            work[rr][cc] = program.background
                            altered = True
                            break
                    if altered:
                        break
                if not altered:
                    raise Inapplicable("no priority-sensitive overlap")
                passed = program.predict(tuple(tuple(row) for row in work)) != original
                details = {"priority_overlap_perturbation_changes_output": passed}

            elif isinstance(program, DominantComponentCleanupProgram):
                _, records = program._multicolour(source)
                cells, dominant, _ = records[0]
                minority = next((cell for cell in cells if source[cell[0]][cell[1]] != dominant), None)
                if minority is None:
                    raise Inapplicable("no minority cell")
                work = _array(source)
                work[minority[0]][minority[1]] = dominant
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"minority_intrusion_removal_changes_or_rejects": passed}

            elif isinstance(program, ExteriorBoundaryProjectionProgram):
                _, signal = program.analyse(source)
                fresh = _fresh_colour(source)
                recoloured = tuple(
                    tuple(fresh if cell == signal else cell for cell in row)
                    for row in source
                )
                changed = program.predict(recoloured)
                expected = tuple(
                    tuple(fresh if cell == signal else cell for cell in row)
                    for row in original
                )
                passed = changed == expected
                details = {"signal_recolour_equivariance": passed}

            elif isinstance(program, DominoHaloProgram):
                domino = program._dominoes(source)[0]
                work = _array(source)
                r, c = domino[0]
                work[r][c] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"domino_break_changes_or_rejects": passed}

            elif isinstance(program, ColourHeightHistogramProgram):
                records = program.records(source)
                _, colour = records[0]
                work = _array(source)
                positions = [(r, c) for r, row in enumerate(source) for c, cell in enumerate(row) if cell == colour]
                top = min(r for r, _ in positions)
                for r, c in positions:
                    if r == top:
                        work[r][c] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"height_change_changes_or_rejects": passed}

            elif isinstance(program, DiagonalOrientationFrequencyProgram):
                groups, majority, _ = program.analyse(source)
                work = _array(source)
                r, c = next(iter(groups[majority]))
                work[r][c] = program.background
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"orientation_support_change_changes_or_rejects": passed}

            elif isinstance(program, BoundingBoxInstructionRecolourProgram):
                positions = [
                    (r, c)
                    for r, row in enumerate(source)
                    for c, cell in enumerate(row)
                    if cell == program.instruction_colour
                ]
                r0, c0, r1, c1 = _bbox(positions)
                work = _array(source)
                extreme = [cell for cell in positions if cell[0] == r0]
                for r, c in extreme:
                    work[r][c] = _fresh_colour(source, (program.replacement_colour,))
                try:
                    passed = program.predict(tuple(tuple(row) for row in work)) != original
                except Inapplicable:
                    passed = True
                details = {"instruction_bbox_change_changes_or_rejects": passed}

        except (Inapplicable, StopIteration, IndexError, KeyError, ValueError, TypeError):
            passed = False
        rows.append({"demonstration": index, "passed": bool(passed), **details})
    return {
        "kind": program.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_relational_completion_algebra(task, *, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = fit_relational_completion_algebra_programs(
        pairs, minimum_pairs=minimum_pairs, allowed_kinds=allowed_kinds
    )
    groups = defaultdict(list)
    invalid = 0
    rejected = 0
    for program in programs:
        try:
            counterfactual = _counterfactual(program, pairs)
            if not counterfactual.get("passed"):
                rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)

    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[list(row) for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programs),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_relational_completion_algebra": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programs_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programs = []
    for program in fit_relational_completion_algebra_programs(
        pairs, minimum_pairs=2, allowed_kinds=allowed
    ):
        try:
            if (
                tuple(program.predict(case["input"]) for case in clean["test"]) == expected
                and _counterfactual(program, pairs).get("passed")
            ):
                programs.append(program)
        except Inapplicable:
            pass
    return expected, programs


def _validate_program(clean, program, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_relational_completion_algebra_programs(
            remaining, minimum_pairs=1, allowed_kinds=(program.kind,)
        )
        groups = set()
        held_exact = 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs).get("passed"):
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append(
            {
                "held_index": held_index,
                "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
                "held_example_exact": bool(held_exact),
                "test_prediction_stable": stable,
                "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
                "refitted_programs": len(refitted),
                "held_exact_prediction_groups": len(groups),
            }
        )
    counterfactual = _counterfactual(program, full_pairs)
    passed = all(
        fold["held_example_exact"] and fold["test_prediction_stable"]
        for fold in folds
    ) and counterfactual.get("passed")
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_relational_completion_algebra(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programs = _programs_for_expected(clean, full)
    if not programs:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_program(clean, program, expected) for program in programs]
    passed = [check for check in checks if check.get("passed")]
    return passed[0] if passed else checks[0]


def relational_completion_algebra_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_relational_completion_algebra_programs(pairs)}))


infer = infer_relational_completion_algebra
validate = validate_relational_completion_algebra
