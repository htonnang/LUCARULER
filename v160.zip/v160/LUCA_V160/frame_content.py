"""V73: one finite frame/content/reference extraction grammar.

Shared V70 components; explicit frame boundaries, payload and external cues.
No task IDs, stored targets, arbitrary tie breakers or test-answer selection.
"""
from __future__ import annotations
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from itertools import product

from attributes import background, components, normalized_shape
from correspondence import grid
from runtime import public_task

FAMILY='frame_content_v73'
VIEWS=('outer','inner','payload_box')
PAINTS=('preserve','frame_to_payload','payload_to_frame','erase_frame')
METRICS=('area','payload_count','payload_palette','payload_fraction','external_frame_colour',
         'external_payload_colour','external_shape','external_shape_d4')

@dataclass(frozen=True)
class Frame:
    box: tuple[int,int,int,int]
    colour: int
    kind: str
    def interior(self):
        r0,c0,r1,c1=self.box
        return tuple((r,c) for r in range(r0+1,r1) for c in range(c0+1,c1))
    def payload(self,a,bg):
        return tuple((r,c) for r,c in self.interior() if a[r][c] not in (bg,self.colour))
    def describe(self):return {'box':list(self.box),'frame_colour':self.colour,'kind':self.kind}

def detect_frames(a,bg,kind):
    """Closed component perimeters or exactly four same-colour scene corners.

    Solid blocks are not closed frames. This intentionally does not enumerate
    every possible rectangle in a dense texture. Sorting never selects a winner.
    """
    if kind not in ('closed','corners'):raise ValueError('unknown frame kind')
    a=grid(a);found=set()
    if kind=='closed':
        for conn in (4,8):
            for o in components(a,bg,conn,True):
                r0,c0,r1,c1=o.box
                if r1-r0<2 or c1-c0<2:continue
                col=a[o.cells[0][0]][o.cells[0][1]]
                if any(a[r][c]!=col for r in (r0,r1) for c in range(c0,c1+1)):continue
                if any(a[r][c]!=col for c in (c0,c1) for r in range(r0,r1+1)):continue
                if all(a[r][c]==col for r in range(r0+1,r1) for c in range(c0+1,c1)):continue
                found.add(Frame(o.box,col,kind))
    else:
        for col,n in Counter(v for row in a for v in row).items():
            if col==bg or n!=4:continue
            pts={(r,c) for r,row in enumerate(a) for c,v in enumerate(row) if v==col}
            r0=min(r for r,c in pts);r1=max(r for r,c in pts)
            c0=min(c for r,c in pts);c1=max(c for r,c in pts)
            if r1-r0>=2 and c1-c0>=2 and pts=={(r0,c0),(r0,c1),(r1,c0),(r1,c1)}:
                found.add(Frame((r0,c0,r1,c1),col,kind))
    return tuple(sorted(found,key=lambda f:(f.box,f.colour)))

def local_shape(pts):
    if not pts:return ()
    r0=min(r for r,c in pts);c0=min(c for r,c in pts)
    return tuple(sorted((r-r0,c-c0) for r,c in pts))

@lru_cache(maxsize=256)
def perceive_frames(a,bg_rule,kind):
    a=grid(a);bg=background(a,bg_rule)
    if bg is None:return None
    fs=detect_frames(a,bg,kind)
    if not fs:return None
    # References are external to ALL candidate frame boxes, never borrowed from
    # a competing frame's contents. Shape reference segmentation is 8-connected.
    inside=set()
    for f in fs:
        r0,c0,r1,c1=f.box
        inside.update((r,c) for r in range(r0,r1+1) for c in range(c0,c1+1))
    ext=tuple(tuple(bg if (r,c) in inside else v for c,v in enumerate(row)) for r,row in enumerate(a))
    hist=Counter(v for row in ext for v in row if v!=bg)
    obs=components(ext,bg,8,False)
    shapes=Counter(local_shape(o.cells) for o in obs)
    d4shapes=Counter(normalized_shape(o.cells) for o in obs)
    values=[]
    for f in fs:
        r0,c0,r1,c1=f.box;pts=f.payload(a,bg);cols={a[r][c] for r,c in pts}
        values.append({'area':(r1-r0+1)*(c1-c0+1),'payload_count':len(pts),
          'payload_palette':len(cols),'payload_fraction':Fraction(len(pts),(r1-r0-1)*(c1-c0-1)),
          'external_frame_colour':hist[f.colour],
          'external_payload_colour':sum(hist[c] for c in cols),
          'external_shape':shapes[local_shape(pts)] if pts else 0,
          'external_shape_d4':d4shapes[normalized_shape(pts)] if pts else 0})
    return bg,fs,tuple(values)

@dataclass(frozen=True)
class FrameSelector:
    metric: str
    operator: str
    colour: int | None=None
    def indices(self,scene):
        bg,fs,vs=scene
        if self.metric=='all':return tuple(range(len(fs)))
        if self.metric=='frame_colour':return tuple(i for i,f in enumerate(fs) if f.colour==self.colour)
        values=tuple(v[self.metric] for v in vs)
        if self.operator=='min':t=min(values);return tuple(i for i,v in enumerate(values) if v==t)
        if self.operator=='max':t=max(values);return tuple(i for i,v in enumerate(values) if v==t)
        if self.operator=='positive':return tuple(i for i,v in enumerate(values) if v>0)
        if self.operator=='zero':return tuple(i for i,v in enumerate(values) if v==0)
        raise ValueError('unknown selector')
    def describe(self):return {'metric':self.metric,'operator':self.operator,'colour':self.colour}

def render_frame(a,bg,f,view,paint):
    if view not in VIEWS or paint not in PAINTS:raise ValueError('unknown rendering')
    r0,c0,r1,c1=f.box;pts=f.payload(a,bg)
    if view=='inner':r0+=1;c0+=1;r1-=1;c1-=1
    elif view=='payload_box':
        if not pts:return None
        r0=min(r for r,c in pts);r1=max(r for r,c in pts)
        c0=min(c for r,c in pts);c1=max(c for r,c in pts)
    cols={a[r][c] for r,c in pts}
    if paint=='frame_to_payload' and len(cols)!=1:return None
    ink=next(iter(cols)) if len(cols)==1 else None
    out=[]
    for r in range(r0,r1+1):
        row=[]
        for c in range(c0,c1+1):
            v=a[r][c]
            if paint=='frame_to_payload' and v==f.colour:v=ink
            elif paint=='payload_to_frame' and v not in (bg,f.colour):v=f.colour
            elif paint=='erase_frame' and v==f.colour:v=bg
            row.append(v)
        out.append(tuple(row))
    return tuple(out)

@dataclass(frozen=True)
class FrameProgram:
    background_rule: str | int
    kind: str
    selector: FrameSelector
    view: str
    paint: str
    def options(self,a):
        a=grid(a);s=perceive_frames(a,self.background_rule,self.kind)
        if s is None:return ()
        ii=self.selector.indices(s)
        if not ii:return ()
        opts=[render_frame(a,s[0],s[1][i],self.view,self.paint) for i in ii]
        # Unsupported evidence in any selected frame invalidates this program.
        if any(p is None for p in opts):return ()
        return tuple(sorted(set(opts)))
    def predict(self,a):
        ps=self.options(a);return ps[0] if len(ps)==1 else None
    def describe(self):
        return {'family':FAMILY,'background_rule':self.background_rule,'frame_kind':self.kind,
          'selector':self.selector.describe(),'view':self.view,'paint':self.paint,
          'tie_policy':'retain every selected frame; require output agreement'}
    def trace(self,a):
        a=grid(a);s=perceive_frames(a,self.background_rule,self.kind)
        if s is None:return None
        ii=self.selector.indices(s)
        return {'program':self.describe(),'background':s[0],
          'frames':[dict(f.describe(),selected=i in ii,payload_cells=len(f.payload(a,s[0])),
                        measurements={k:str(v) for k,v in s[2][i].items()}) for i,f in enumerate(s[1])],
          'predictions':[[list(r) for r in y] for y in self.options(a)]}

def fit(pairs):
    pairs=tuple((grid(a),grid(y)) for a,y in pairs)
    if not pairs or not any(a!=y for a,y in pairs):return []
    if any(len(y)>len(a) or len(y[0])>len(a[0]) or
      not {v for row in y for v in row}.issubset({v for row in a for v in row}) for a,y in pairs):return []
    common=set.intersection(*({v for row in a for v in row} for a,y in pairs))
    selectors=(FrameSelector('all','all'),)+tuple(FrameSelector(m,p) for m in METRICS
        for p in ('min','max','positive','zero'))+tuple(FrameSelector('frame_colour','eq',c) for c in sorted(common))
    models=[]
    for bg,kind in product(('modal',*sorted(common)),('closed','corners')):
        ss=tuple(perceive_frames(a,bg,kind) for a,y in pairs)
        if any(s is None for s in ss):continue
        groups={}
        for selector in selectors:
            indices=tuple(selector.indices(s) for s in ss)
            if any(not ii for ii in indices):continue
            groups.setdefault(indices,[]).append(selector)
        for indices,selectors_eq in groups.items():
            for view,paint in product(VIEWS,PAINTS):
                changed=False;ok=True
                for (a,y),s,ii in zip(pairs,ss,indices):
                    for i in ii:
                        f=s[1][i];p=render_frame(a,s[0],f,view,paint)
                        if p!=y:ok=False;break
                        if paint!='preserve':changed |= p!=render_frame(a,s[0],f,view,'preserve')
                    if not ok:break
                if ok and (paint=='preserve' or changed):
                    models.extend(FrameProgram(bg,kind,sel,view,paint) for sel in selectors_eq)
    return models

def infer(task):
    clean=public_task(task);models=fit((d['input'],d['output']) for d in clean['train'])
    groups={};invalid=0;bound=0;factor_ambiguous=False
    for m in models:
        opts=tuple(m.options(t['input']) for t in clean['test'])
        if any(not p for p in opts):invalid+=1;continue
        count=1
        for ps in opts:count*=len(ps)
        bound=max(bound,count);keys=[tuple(ps[0] for ps in opts)]
        if count>1:
            # Retain two complete witnesses; they PROVE ambiguity, not exhaustive
            # enumeration. The explicit count flag prevents overstated precision.
            factor_ambiguous=True;j=next(i for i,ps in enumerate(opts) if len(ps)>1)
            alt=list(keys[0]);alt[j]=opts[j][1];keys.append(tuple(alt))
        for key in keys:groups.setdefault(key,[]).append(m.describe())
    status='unique' if len(groups)==1 and not factor_ambiguous else 'ambiguous' if groups else 'no_fit'
    chosen=next(iter(groups)) if status=='unique' else None
    return {'status':status,'joint_hypotheses':max(len(groups),bound),'joint_hypotheses_is_exact':not factor_ambiguous,
      'tests':[{'status':status,'prediction':[list(r) for r in chosen[i]] if chosen else None} for i in range(len(clean['test']))],
      'supporting_families':[FAMILY] if chosen else [],'supporting_laws':groups[chosen][:20] if chosen else [],
      'witness_predictions':[[[list(r) for r in p] for p in key] for key in list(groups)[:2]],
      'stats':{'fitted_programs':len(models),'inapplicable_programs':invalid,'factorized_ties_preserved':True}}

def validate(task,full):
    clean=public_task(task)
    if full['status']!='unique':return {'passed':False,'reason':'full_fit_not_unique','folds':[]}
    if len(clean['train'])<2:return {'passed':False,'reason':'requires_two_demonstrations','folds':[]}
    expected=[t['prediction'] for t in full['tests']];folds=[]
    for held,demo in enumerate(clean['train']):
        task_fold={'train':[d for i,d in enumerate(clean['train']) if i!=held],
                   'test':[{'input':demo['input']}]+clean['test']}
        r=infer(task_fold);ps=[t['prediction'] for t in r['tests']]
        folds.append({'held_index':held,'status':r['status'],
          'held_example_exact':r['status']=='unique' and ps[0]==demo['output'],
          'test_prediction_stable':r['status']=='unique' and ps[1:]==expected,
          'joint_hypotheses':r['joint_hypotheses']})
    ok=all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed':ok,'reason':'passed' if ok else 'held_example_or_stability_failure','folds':folds}


