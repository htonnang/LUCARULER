"""LUCA V156: anchor-relative stencil materialisation.

This family anti-unifies local constructions in which a compact anchor defines
an input-relative coordinate frame and the output materialises a small stencil
around that frame:

    repeated monochrome square anchors -> four learned role colours
    singleton anchors -> four learned orthogonal role colours
    one multicolour 2x2 anchor -> opposite clipped colour blocks

The implementation is task-ID blind and target blind. Anchor colours, output
role colours, positions, counts, clipping, and multicolour cell roles are
inferred from the training demonstrations or the current input. No absolute
training coordinates are stored.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import permutations

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anchor_relative_stencil_materialisation"
LANGUAGE = "spinoza_anchor_relative_stencil_materialisation_v156"
SCHEMA_VERSION = 1
OPERATOR = "anchor_relative_stencil_materialisation"
NODE_VOCABULARY = "anchor_components_and_local_cell_roles"
EDGE_VOCABULARY = "d4_relative_offset_role_and_clipping_edges"


def _law(programme, *, scene, relation_chain, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": programme.kind,
        "algebra": {
            "scene": scene,
            "nodes": programme.node_vocabulary,
            "edges": programme.edge_vocabulary,
            "relation": " -> ".join(relation_chain),
            "relation_chain": list(relation_chain),
            "operator": programme.operator,
            "emitter": "anchor_relative_stencil_field",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "anchor_relative_coordinates": True,
            "d4_relative_roles": True,
            "shared_anchor_stencil_operator": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _palette(value: Grid):
    return {cell for row in grid(value) for cell in row}


def _background(value: Grid):
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    return counts.most_common(1)[0][0]


def _common_input_colours(pairs):
    palettes = [_palette(source) for source, _ in pairs]
    if not palettes:
        return ()
    return tuple(sorted(set.intersection(*palettes)))


def _bbox(cells):
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    cols = [c for _, c in cells]
    return min(rows), min(cols), max(rows), max(cols)


def _components_of_colour(value: Grid, colour: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
    output = []
    while remaining:
        seed = next(iter(remaining))
        remaining.remove(seed)
        stack = [seed]
        component = {seed}
        while stack:
            r, c = stack.pop()
            for point in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
                if point in remaining:
                    remaining.remove(point)
                    component.add(point)
                    stack.append(point)
        output.append(frozenset(component))
    output.sort(key=lambda cells: (_bbox(cells), len(cells)))
    return tuple(output)


def _normalise(cells):
    r0, c0, _, _ = _bbox(cells)
    return frozenset((r - r0, c - c0) for r, c in cells)


def _solid_square_shape(cells):
    r0, c0, r1, c1 = _bbox(cells)
    height, width = r1 - r0 + 1, c1 - c0 + 1
    if height != width:
        raise Inapplicable("anchor is not square")
    expected = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
    if set(cells) != expected:
        raise Inapplicable("anchor is not a filled square")
    return height, frozenset((r - r0, c - c0) for r, c in cells)


def _d4_orbit(offsets, side):
    offsets = set(offsets)
    if len(offsets) != 4:
        return False
    doubled = {(2 * dr - (side - 1), 2 * dc - (side - 1)) for dr, dc in offsets}
    seed = next(iter(doubled))
    x, y = seed
    orbit = {(x, y), (-y, x), (-x, -y), (y, -x)}
    return doubled == orbit and len(orbit) == 4


def _anchors(value: Grid, background: int, anchor_colour: int, anchor_shape):
    value = grid(value)
    palette = _palette(value)
    if palette != {background, anchor_colour}:
        raise Inapplicable("the fixed-stencil scene requires exactly background and one anchor colour")
    components = _components_of_colour(value, anchor_colour)
    if not components:
        raise Inapplicable("at least one anchor is required")
    for component in components:
        if _normalise(component) != anchor_shape:
            raise Inapplicable("all anchors must share one shape")
    return components


def _derive_four_role_stencil(pairs, background, anchor_colour, anchor_shape):
    side, expected_shape = _solid_square_shape(anchor_shape)
    if expected_shape != anchor_shape:
        raise Inapplicable("invalid anchor shape")
    candidate_offsets = [
        (dr, dc)
        for dr in range(-1, side + 1)
        for dc in range(-1, side + 1)
        if not (0 <= dr < side and 0 <= dc < side)
    ]
    observations = {offset: [] for offset in candidate_offsets}
    for source, target in pairs:
        source, target = grid(source), grid(target)
        if _shape(source) != _shape(target):
            raise Inapplicable("stencil emission preserves canvas dimensions")
        components = _anchors(source, background, anchor_colour, anchor_shape)
        h, w = _shape(source)
        anchor_support = set().union(*components)
        for r in range(h):
            for c in range(w):
                if source[r][c] != background and target[r][c] != source[r][c]:
                    raise Inapplicable("anchor material must be preserved")
                if source[r][c] == background and target[r][c] == anchor_colour:
                    raise Inapplicable("the anchor colour cannot be emitted as a role colour")
        for component in components:
            r0, c0, _, _ = _bbox(component)
            for offset in candidate_offsets:
                rr, cc = r0 + offset[0], c0 + offset[1]
                if not (0 <= rr < h and 0 <= cc < w):
                    continue
                if (rr, cc) in anchor_support:
                    continue
                observations[offset].append(target[rr][cc])
    stencil = []
    for offset, values in observations.items():
        if not values:
            continue
        unique = set(values)
        if unique == {background}:
            continue
        if background in unique or len(unique) != 1:
            raise Inapplicable("the local stencil is not translation-consistent")
        stencil.append((offset[0], offset[1], next(iter(unique))))
    if len(stencil) != 4 or len({colour for _, _, colour in stencil}) != 4:
        raise Inapplicable("exactly four distinct stencil roles are required")
    offsets = {(dr, dc) for dr, dc, _ in stencil}
    if not _d4_orbit(offsets, side):
        raise Inapplicable("the four stencil locations must form one D4 orbit")
    return side, tuple(sorted(stencil))


@dataclass(frozen=True)
class FixedFourRoleAnchorStencilProgram:
    background: int
    anchor_colour: int
    anchor_shape: frozenset
    stencil: tuple

    kind = "fixed_four_role_anchor_stencil"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.anchor_colour, tuple(sorted(self.anchor_shape)), self.stencil

    def _scene(self, value: Grid):
        components = _anchors(value, self.background, self.anchor_colour, self.anchor_shape)
        side, _ = _solid_square_shape(self.anchor_shape)
        if not _d4_orbit({(dr, dc) for dr, dc, _ in self.stencil}, side):
            raise Inapplicable("stored stencil is not D4-relative")
        return components

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        components = self._scene(value)
        h, w = _shape(value)
        output = _array(value)
        anchor_support = set().union(*components)
        claims = {}
        for component in components:
            r0, c0, _, _ = _bbox(component)
            for dr, dc, colour in self.stencil:
                r, c = r0 + dr, c0 + dc
                if not (0 <= r < h and 0 <= c < w):
                    continue
                if (r, c) in anchor_support:
                    continue
                if value[r][c] != self.background:
                    raise Inapplicable("stencil collides with non-anchor material")
                previous = claims.get((r, c))
                if previous is not None and previous != colour:
                    raise Inapplicable("competing stencil roles claim one cell")
                claims[(r, c)] = colour
        for (r, c), colour in claims.items():
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        side, _ = _solid_square_shape(self.anchor_shape)
        return _law(
            self,
            scene="one or more congruent monochrome square anchors on a uniform background",
            relation_chain=(
                "extract congruent filled-square anchor components",
                "normalise a one-cell exterior ring around each anchor",
                "assign four learned colours to one D4 orbit of relative positions",
                "clip at the canvas boundary and materialise the shared local stencil",
            ),
            parameters={
                "background": self.background,
                "anchor_colour": self.anchor_colour,
                "anchor_side": side,
                "relative_stencil": [list(item) for item in self.stencil],
            },
            corollary="Emit one learned four-role stencil around every congruent monochrome anchor.",
            notions=["anchor-relative coordinates", "D4 orbit", "translation reuse", "boundary clipping"],
        )


@dataclass(frozen=True)
class OppositeQuadrantRoleBlockProgram:
    background: int
    side: int = 2

    kind = "opposite_quadrant_role_block_stencil"
    operator = OPERATOR
    node_vocabulary = NODE_VOCABULARY
    edge_vocabulary = EDGE_VOCABULARY

    @property
    def schema_key(self):
        return self.kind, self.background, self.side

    def _scene(self, value: Grid):
        value = grid(value)
        h, w = _shape(value)
        cells = {(r, c) for r in range(h) for c in range(w) if value[r][c] != self.background}
        if len(cells) != self.side * self.side:
            raise Inapplicable("the role anchor must be one complete square block")
        r0, c0, r1, c1 = _bbox(cells)
        if r1 - r0 + 1 != self.side or c1 - c0 + 1 != self.side:
            raise Inapplicable("the role anchor has the wrong dimensions")
        expected = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)}
        if cells != expected:
            raise Inapplicable("the role anchor is incomplete")
        colours = [value[r][c] for r, c in sorted(cells)]
        if len(set(colours)) != self.side * self.side:
            raise Inapplicable("every anchor cell must have a distinct role colour")
        if self.side != 2:
            raise Inapplicable("the current role-block grammar requires a 2x2 anchor")
        return (r0, c0, r1, c1)

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        r0, c0, r1, c1 = self._scene(value)
        h, w = _shape(value)
        output = _array(value)
        corners = (
            (r0, c0, r1 + 1, c1 + 1),
            (r0, c1, r1 + 1, c0 - self.side),
            (r1, c0, r0 - self.side, c1 + 1),
            (r1, c1, r0 - self.side, c0 - self.side),
        )
        claims = {}
        for sr, sc, dr0, dc0 in corners:
            colour = value[sr][sc]
            for rr in range(dr0, dr0 + self.side):
                for cc in range(dc0, dc0 + self.side):
                    if not (0 <= rr < h and 0 <= cc < w):
                        continue
                    if r0 <= rr <= r1 and c0 <= cc <= c1:
                        raise Inapplicable("emitted role block overlaps the source anchor")
                    if value[rr][cc] != self.background:
                        raise Inapplicable("emitted role block collides with source material")
                    previous = claims.get((rr, cc))
                    if previous is not None and previous != colour:
                        raise Inapplicable("opposite role blocks conflict")
                    claims[(rr, cc)] = colour
        if not claims:
            raise Inapplicable("all role blocks are clipped away")
        for (r, c), colour in claims.items():
            output[r][c] = colour
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one multicolour 2x2 role anchor on a uniform background",
            relation_chain=(
                "extract the four distinct cell roles of the compact anchor",
                "map each cell role to the diagonally opposite exterior quadrant",
                "materialise a same-size solid block carrying that role colour",
                "clip every block at the canvas boundary while preserving the source anchor",
            ),
            parameters={
                "background": self.background,
                "anchor_side": self.side,
                "role_mapping": "each anchor corner emits into the diagonally opposite quadrant",
            },
            corollary="Project the four anchor-cell roles into clipped opposite-quadrant blocks.",
            notions=["cell role", "opposite quadrant", "same-size block", "boundary clipping"],
        )


def _fit_fixed_four_role(pairs):
    output = []
    common = _common_input_colours(pairs)
    for background, anchor_colour in permutations(common, 2):
        try:
            if any(_background(source) != background for source, _ in pairs):
                continue
            first_components = _anchors(pairs[0][0], background, anchor_colour, _normalise(_components_of_colour(pairs[0][0], anchor_colour)[0]))
            anchor_shape = _normalise(first_components[0])
            side, _ = _solid_square_shape(anchor_shape)
            if side not in (1, 2):
                continue
            _, stencil = _derive_four_role_stencil(pairs, background, anchor_colour, anchor_shape)
            programme = FixedFourRoleAnchorStencilProgram(background, anchor_colour, anchor_shape, stencil)
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration):
            continue
    return output


def _fit_opposite_quadrant(pairs):
    output = []
    for background in _common_input_colours(pairs):
        programme = OppositeQuadrantRoleBlockProgram(background, 2)
        try:
            if any(_background(source) != background for source, _ in pairs):
                continue
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration):
            continue
    return output


_FITTERS = {
    "fixed_four_role_anchor_stencil": _fit_fixed_four_role,
    "opposite_quadrant_role_block_stencil": _fit_opposite_quadrant,
}


def fit_anchor_relative_stencil_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = programme.predict(source)
        candidates = []
        try:
            if isinstance(programme, FixedFourRoleAnchorStencilProgram):
                component = programme._scene(source)[0]
                r, c = sorted(component)[0]
                candidates.append((r, c, programme.background, "anchor_support"))
            elif isinstance(programme, OppositeQuadrantRoleBlockProgram):
                r0, c0, _, _ = programme._scene(source)
                # Collapse two semantic roles without introducing metadata.
                candidates.append((r0, c0, source[r0][c0 + 1], "anchor_cell_role"))
        except Inapplicable:
            candidates = []
        passed = False
        witness = None
        tested = 0
        for r, c, replacement, role in candidates:
            tested += 1
            work = _array(source)
            previous = work[r][c]
            work[r][c] = replacement
            try:
                changed = programme.predict(grid(work)) != original
            except Inapplicable:
                changed = True
            if changed:
                passed = True
                witness = {
                    "cell": [r, c],
                    "from": int(previous),
                    "to": int(replacement),
                    "role": role,
                }
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_mutations_tested": tested,
            "node_or_edge_mutation_changes_or_rejects": passed,
            "witness_role": witness.get("role") if witness else None,
            "witness": witness,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_anchor_relative_stencil_materialisation(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anchor_relative_stencil_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "relation_chains": sorted({tuple(law["algebra"]["relation_chain"]) for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anchor_relative_coordinates": True,
            "d4_relative_roles": True,
            "shared_anchor_stencil_operator": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_anchor_relative_stencil_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anchor_relative_stencil_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_anchor_relative_stencil_materialisation(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
