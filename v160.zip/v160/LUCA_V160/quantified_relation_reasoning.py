"""LUCA V120: unified quantified relation algebra.

This proof-carrying research family anti-unifies three recurrent ARC operations::

    scene -> candidate set -> structural quantity/class -> unique role -> emission

The schemas are deliberately conservative:

* ``component_feature_outlier_crop`` selects the only component whose quantified
  feature differs from a uniform comparison class;
* ``modal_component_class_crop`` selects the uniquely most frequent exact object
  class and emits one canonical member;
* ``component_extremum_colour_projection`` selects the unique largest coherent
  component in a noisy field and emits its colour in a learned fixed tile.

Programs use no task identifiers, stored demonstration coordinates, or test
outputs. Exact demonstration fit is necessary but not sufficient: accepted
predictions must survive leave-one-demonstration-out refitting, schema-specific
counterfactuals, output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_unified_quantified_relation_algebra"
LANGUAGE = "spinoza_unified_quantified_relation_algebra_v1"
SCHEMA_VERSION = "unified_quantified_relation_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    return len(value), len(value[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused counterfactual colour")


def _directions(connectivity: int):
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    result = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        result += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    return result


def _bbox(cells: Iterable[tuple[int, int]]) -> tuple[int, int, int, int]:
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _crop(value: Grid, cells: Iterable[tuple[int, int]]) -> Grid:
    value = grid(value)
    r0, c0, r1, c1 = _bbox(cells)
    return tuple(tuple(value[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _normalised_mask(cells: Iterable[tuple[int, int]]):
    cells = tuple(cells)
    r0, c0, _, _ = _bbox(cells)
    return tuple(sorted((r - r0, c - c0) for r, c in cells))


def _rotate90(value: Grid) -> Grid:
    value = grid(value)
    h, w = _shape(value)
    return tuple(tuple(value[h - 1 - r][c] for r in range(h)) for c in range(w))


def _rotate180(value: Grid) -> Grid:
    return _rotate90(_rotate90(value))


def _flip_lr(value: Grid) -> Grid:
    return tuple(tuple(reversed(row)) for row in grid(value))


def _mask_grid(cells: Iterable[tuple[int, int]]) -> Grid:
    cells = set(cells)
    r0, c0, r1, c1 = _bbox(cells)
    return tuple(
        tuple(1 if (r, c) in cells else 0 for c in range(c0, c1 + 1))
        for r in range(r0, r1 + 1)
    )


def _d4_stabiliser_count(cells: Iterable[tuple[int, int]]) -> int:
    mask = _mask_grid(cells)
    variants = []
    current = mask
    for _ in range(4):
        variants.append(current)
        variants.append(_flip_lr(current))
        current = _rotate90(current)
    return sum(variant == mask for variant in variants)


def _hole_count(cells: Iterable[tuple[int, int]]) -> int:
    occupied = set(cells)
    r0, c0, r1, c1 = _bbox(occupied)
    outside = set()
    queue = deque()
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            if (r, c) in occupied:
                continue
            if r in (r0, r1) or c in (c0, c1):
                outside.add((r, c))
                queue.append((r, c))
    while queue:
        r, c = queue.popleft()
        for dr, dc in _directions(4):
            neighbour = (r + dr, c + dc)
            if not (r0 <= neighbour[0] <= r1 and c0 <= neighbour[1] <= c1):
                continue
            if neighbour in occupied or neighbour in outside:
                continue
            outside.add(neighbour)
            queue.append(neighbour)
    remaining = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if (r, c) not in occupied and (r, c) not in outside
    }
    holes = 0
    while remaining:
        holes += 1
        start = remaining.pop()
        queue = [start]
        while queue:
            r, c = queue.pop()
            for dr, dc in _directions(4):
                neighbour = (r + dr, c + dc)
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    queue.append(neighbour)
    return holes


def _monochrome_components(value: Grid, background: int, connectivity: int):
    value = grid(value)
    h, w = _shape(value)
    result = []
    for colour in sorted(_palette(value) - {background}):
        remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] == colour}
        while remaining:
            start = remaining.pop()
            component = {start}
            queue = [start]
            while queue:
                r, c = queue.pop()
                for dr, dc in _directions(connectivity):
                    neighbour = (r + dr, c + dc)
                    if neighbour in remaining:
                        remaining.remove(neighbour)
                        component.add(neighbour)
                        queue.append(neighbour)
            result.append((colour, tuple(sorted(component))))
    return tuple(result)


def _multicolour_components(value: Grid, background: int, connectivity: int):
    value = grid(value)
    h, w = _shape(value)
    remaining = {(r, c) for r in range(h) for c in range(w) if value[r][c] != background}
    result = []
    while remaining:
        start = remaining.pop()
        component = {start}
        queue = [start]
        while queue:
            r, c = queue.pop()
            for dr, dc in _directions(connectivity):
                neighbour = (r + dr, c + dc)
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        colours = tuple(sorted({value[r][c] for r, c in component}))
        result.append((colours, tuple(sorted(component))))
    return tuple(result)


def _component_feature(value: Grid, colour: int, cells, feature: str):
    if feature == "hole_count":
        return _hole_count(cells)
    if feature == "d4_stabiliser_count":
        return _d4_stabiliser_count(cells)
    if feature == "global_colour_material":
        return sum(cell == colour for row in grid(value) for cell in row)
    raise Inapplicable("unknown component feature")


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


# ---------------------------------------------------------------------------
# Schema I: singleton quantified feature against a uniform comparison class.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ComponentFeatureOutlierCropProgram:
    connectivity: int
    feature: str
    filter_mode: str = "all"
    kind: str = "component_feature_outlier_crop"

    @property
    def schema_key(self):
        return self.kind, self.connectivity, self.feature, self.filter_mode

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return (self.connectivity, self.filter_mode, self.feature)

    def _analyse(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        candidates = []
        for colour, cells in _monochrome_components(value, background, self.connectivity):
            holes = _hole_count(cells)
            if self.filter_mode == "has_hole" and holes <= 0:
                continue
            if self.filter_mode not in ("all", "has_hole"):
                raise Inapplicable("unknown component filter")
            candidates.append({
                "colour": colour,
                "cells": cells,
                "bbox": _bbox(cells),
                "holes": holes,
                "value": _component_feature(value, colour, cells, self.feature),
            })
        if len(candidates) < 3:
            raise Inapplicable("requires at least three candidate components")
        counts = Counter(candidate["value"] for candidate in candidates)
        singleton_values = [feature_value for feature_value, count in counts.items() if count == 1]
        comparison_values = [feature_value for feature_value, count in counts.items() if count == len(candidates) - 1]
        if len(counts) != 2 or len(singleton_values) != 1 or len(comparison_values) != 1:
            raise Inapplicable("feature distribution is not singleton versus uniform comparison class")
        winner = next(candidate for candidate in candidates if candidate["value"] == singleton_values[0])
        return background, tuple(candidates), winner, _crop(value, winner["cells"])

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, candidates, winner, _ = self._analyse(source)
            evidence.append({
                "candidate_values": [candidate["value"] for candidate in candidates],
                "winner_value": winner["value"],
                "winner_colour": winner["colour"],
                "winner_bbox": list(winner["bbox"]),
            })
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "connectivity": self.connectivity,
                "feature": self.feature,
                "filter_mode": self.filter_mode,
                "selector": "singleton_feature_value_against_uniform_class",
                "emission": "raw_bbox_crop",
            },
            definitions=[
                {"name": "CandidateComponentSet", "type": "Grid -> MonochromeComponents"},
                {"name": "QuantifiedFeature", "type": "Component -> Integer"},
                {"name": "SingletonAgainstUniform", "type": "FeatureMultiset -> UniqueComponent"},
                {"name": "CanonicalCrop", "type": "Component -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ExtractCandidates", "effect": "construct the filtered component set"},
                {"index": 2, "definition": "MeasureFeature", "effect": "assign one structural quantity to every candidate"},
                {"index": 3, "definition": "SelectOutlier", "effect": "bind the only value outside a uniform comparison class"},
                {"index": 4, "definition": "ProjectCrop", "effect": "emit the selected component bounding-box crop"},
            ],
            corollary="the only component whose quantified feature differs from all uniform alternatives is the answer",
            common_notions=[{"name": "feature_outlier_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema II: the uniquely most frequent exact component class.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ModalComponentClassCropProgram:
    connectivity: int
    component_mode: str
    signature_mode: str = "coloured_crop"
    kind: str = "modal_component_class_crop"

    @property
    def schema_key(self):
        return self.kind, self.connectivity, self.component_mode, self.signature_mode

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return (self.connectivity, self.component_mode, self.signature_mode)

    def _analyse(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        if self.component_mode == "monochrome":
            raw = [((colour,), cells) for colour, cells in _monochrome_components(value, background, self.connectivity)]
        elif self.component_mode == "multicolour":
            raw = list(_multicolour_components(value, background, self.connectivity))
        else:
            raise Inapplicable("unknown component mode")
        if len(raw) < 3:
            raise Inapplicable("requires at least three components")
        groups = defaultdict(list)
        for colours, cells in raw:
            component_crop = _crop(value, cells)
            if self.signature_mode == "coloured_crop":
                signature = component_crop
            elif self.signature_mode == "mask":
                signature = _normalised_mask(cells)
            else:
                raise Inapplicable("unknown class signature")
            groups[signature].append({
                "colours": colours,
                "cells": cells,
                "bbox": _bbox(cells),
                "crop": component_crop,
            })
        frequencies = Counter({signature: len(items) for signature, items in groups.items()})
        maximum = max(frequencies.values())
        winners = [signature for signature, count in frequencies.items() if count == maximum]
        if maximum < 2 or len(winners) != 1:
            raise Inapplicable("there is not one repeated modal component class")
        winner_items = groups[winners[0]]
        crops = {item["crop"] for item in winner_items}
        if len(crops) != 1:
            raise Inapplicable("modal class has no single canonical coloured crop")
        if not any(count < maximum for count in frequencies.values()):
            raise Inapplicable("all classes have the same multiplicity")
        return background, tuple(raw), groups, winners[0], tuple(winner_items), next(iter(crops))

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, _, groups, winner, items, _ = self._analyse(source)
            evidence.append({
                "class_frequencies": sorted(len(group) for group in groups.values()),
                "winner_frequency": len(items),
                "winner_bboxes": [list(item["bbox"]) for item in items],
            })
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "connectivity": self.connectivity,
                "component_mode": self.component_mode,
                "signature_mode": self.signature_mode,
                "selector": "unique_maximum_class_frequency",
                "emission": "canonical_class_crop",
            },
            definitions=[
                {"name": "ComponentClass", "type": "Component -> TranslationInvariantClass"},
                {"name": "ClassFrequency", "type": "Class -> Integer"},
                {"name": "UniqueModalClass", "type": "ClassFrequencyMap -> Class"},
                {"name": "CanonicalClassCrop", "type": "Class -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ClassifyComponents", "effect": "group components by an exact translation-invariant pattern"},
                {"index": 2, "definition": "CountClasses", "effect": "measure the multiplicity of every class"},
                {"index": 3, "definition": "SelectModalClass", "effect": "bind the sole class with maximum repeated support"},
                {"index": 4, "definition": "ProjectClass", "effect": "emit one canonical coloured member"},
            ],
            corollary="the uniquely most repeated exact object class determines the answer",
            common_notions=[{"name": "modal_class_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema III: unique largest coherent component -> fixed colour tile.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ComponentExtremumColourProjectionProgram:
    connectivity: int
    output_shape: tuple[int, int]
    kind: str = "component_extremum_colour_projection"

    @property
    def schema_key(self):
        return self.kind, self.connectivity, self.output_shape

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return (self.connectivity, self.output_shape)

    def _analyse(self, value: Grid):
        value = grid(value)
        background = _unique_modal(value)
        components = [
            {"colour": colour, "cells": cells, "area": len(cells), "bbox": _bbox(cells)}
            for colour, cells in _monochrome_components(value, background, self.connectivity)
        ]
        if len(components) < 20 or len(_palette(value) - {background}) < 3:
            raise Inapplicable("requires a rich noisy field with multiple foreground colours")
        maximum = max(component["area"] for component in components)
        winners = [component for component in components if component["area"] == maximum]
        if len(winners) != 1 or maximum < 10:
            raise Inapplicable("largest coherent component is not unique and substantial")
        winner = winners[0]
        h, w = self.output_shape
        output = tuple(tuple(winner["colour"] for _ in range(w)) for _ in range(h))
        return background, tuple(components), winner, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, components, winner, _ = self._analyse(source)
            evidence.append({
                "component_count": len(components),
                "winner_colour": winner["colour"],
                "winner_area": winner["area"],
                "second_area": sorted((component["area"] for component in components), reverse=True)[1],
                "winner_bbox": list(winner["bbox"]),
            })
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "connectivity": self.connectivity,
                "quantity": "component_area",
                "selector": "unique_maximum",
                "output_shape": list(self.output_shape),
                "emission": "solid_tile_in_selected_colour",
            },
            definitions=[
                {"name": "CoherentComponent", "type": "Grid -> MonochromeComponents"},
                {"name": "ComponentArea", "type": "Component -> Integer"},
                {"name": "UniqueMaximum", "type": "AreaMap -> Component"},
                {"name": "ColourTile", "type": "Colour x Shape -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ExtractCoherentComponents", "effect": "separate structured signals from disconnected noise"},
                {"index": 2, "definition": "MeasureArea", "effect": "quantify every component"},
                {"index": 3, "definition": "SelectLargest", "effect": "bind the sole maximum-area component"},
                {"index": 4, "definition": "ProjectColour", "effect": "emit a fixed tile in the selected colour"},
            ],
            corollary="the colour carried by the uniquely largest coherent component is the projected answer",
            common_notions=[{"name": "component_extremum_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting, consensus inference, and validation.
# ---------------------------------------------------------------------------


def _fit_simple(programmes, pairs):
    result = []
    for program in programmes:
        try:
            if all(program.predict(source) == target for source, target in pairs):
                result.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            continue
    return result


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programmes = []
    if allowed is None or "component_feature_outlier_crop" in allowed:
        candidates = []
        for connectivity in (4, 8):
            for feature, filter_mode in (
                ("hole_count", "all"),
                ("d4_stabiliser_count", "all"),
                ("global_colour_material", "has_hole"),
            ):
                candidates.append(ComponentFeatureOutlierCropProgram(connectivity, feature, filter_mode))
        programmes.extend(_fit_simple(candidates, pairs))
    if allowed is None or "modal_component_class_crop" in allowed:
        candidates = []
        for connectivity in (4, 8):
            for component_mode in ("monochrome", "multicolour"):
                candidates.append(ModalComponentClassCropProgram(connectivity, component_mode, "coloured_crop"))
        programmes.extend(_fit_simple(candidates, pairs))
    if allowed is None or "component_extremum_colour_projection" in allowed:
        shapes = {_shape(target) for _, target in pairs}
        if len(shapes) == 1:
            output_shape = next(iter(shapes))
            if 1 <= output_shape[0] <= 5 and 1 <= output_shape[1] <= 5:
                if all(len(_palette(target)) == 1 for _, target in pairs):
                    candidates = [ComponentExtremumColourProjectionProgram(connectivity, output_shape) for connectivity in (4, 8)]
                    programmes.extend(_fit_simple(candidates, pairs))
    return programmes


def _role_signature(program, source):
    if isinstance(program, ComponentFeatureOutlierCropProgram):
        _, candidates, winner, _ = program._analyse(source)
        return (
            winner["colour"], winner["bbox"], winner["value"],
            tuple(sorted(candidate["value"] for candidate in candidates)),
        )
    if isinstance(program, ModalComponentClassCropProgram):
        _, _, groups, _, items, _ = program._analyse(source)
        return tuple(item["bbox"] for item in items), tuple(sorted(len(group) for group in groups.values()))
    if isinstance(program, ComponentExtremumColourProjectionProgram):
        _, components, winner, _ = program._analyse(source)
        return winner["colour"], winner["bbox"], winner["area"], len(components)
    raise Inapplicable("unknown quantified relation programme")


def _role_varies(program, pairs):
    try:
        signatures = [_role_signature(program, source) for source, _ in pairs]
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
        return False
    return len({_serial(signature) for signature in signatures}) >= 2


def fit_quantified_relation_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(unique.values(), key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)))


def infer_quantified_relations(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    programmes = fit_quantified_relation_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:30] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "quantified_relation_schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "unified_quantified_relation_algebra": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "component_feature_outlier_crop":
        return ComponentFeatureOutlierCropProgram(
            int(parameters["connectivity"]),
            str(parameters["feature"]),
            str(parameters["filter_mode"]),
        )
    if kind == "modal_component_class_crop":
        return ModalComponentClassCropProgram(
            int(parameters["connectivity"]),
            str(parameters["component_mode"]),
            str(parameters.get("signature_mode", "coloured_crop")),
        )
    if kind == "component_extremum_colour_projection":
        return ComponentExtremumColourProjectionProgram(
            int(parameters["connectivity"]),
            tuple(int(value) for value in parameters["output_shape"]),
        )
    raise Inapplicable("unknown quantified relation schema")


def _rot180(value: Grid) -> Grid:
    return _rotate180(value)


def _counterfactual_result(kind, rows):
    passed = all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _outlier_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background, candidates, winner, original = program._analyse(source)
        replacement = _fresh_colour(source, (winner["colour"],))
        recoloured = _array(source)
        # Recolour the complete semantic colour class, not only the selected
        # component.  Some tasks contain detached same-colour evidence inside
        # the selected bounding box; a colour-equivariant law must transform it
        # consistently as well.
        for r, row in enumerate(source):
            for c, cell_value in enumerate(row):
                if cell_value == winner["colour"]:
                    recoloured[r][c] = replacement
        try:
            recoloured_prediction = program.predict(tuple(tuple(row) for row in recoloured))
            recolour_equivariant = recoloured_prediction == tuple(
                tuple(replacement if cell == winner["colour"] else cell for cell in row)
                for row in original
            )
        except Inapplicable:
            recolour_equivariant = False
        # Remove one causal cell from the selected component. The programme must
        # change or reject rather than preserve an unsupported answer.
        perturbed = _array(source)
        cell = winner["cells"][0]
        perturbed[cell[0]][cell[1]] = background
        try:
            cause_necessary = program.predict(tuple(tuple(row) for row in perturbed)) != original
        except Inapplicable:
            cause_necessary = True
        try:
            rotation_equivariant = program.predict(_rot180(source)) == _rot180(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "recolour_equivariant": recolour_equivariant,
            "cause_necessary": cause_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _modal_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background, _, _, _, items, original = program._analyse(source)
        # Destroy one repeated occurrence by removing a deterministic cell.
        broken = _array(source)
        cell = items[0]["cells"][0]
        broken[cell[0]][cell[1]] = background
        try:
            repetition_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            repetition_necessary = True
        try:
            rotation_equivariant = program.predict(_rot180(source)) == _rot180(original)
        except Inapplicable:
            rotation_equivariant = False
        rows.append({
            "demonstration": index,
            "repetition_necessary": repetition_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _extremum_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background, _, winner, original = program._analyse(source)
        replacement = _fresh_colour(source, (winner["colour"],))
        recoloured = _array(source)
        for r, c in winner["cells"]:
            recoloured[r][c] = replacement
        try:
            recolour_propagates = program.predict(tuple(tuple(row) for row in recoloured)) == tuple(
                tuple(replacement for _ in row) for row in original
            )
        except Inapplicable:
            recolour_propagates = False
        reduced = _array(source)
        # Remove the complete selected signal.  Deleting a single cell can
        # leave the same component as the unique maximum and therefore does
        # not test whether the quantified role is causal.
        for r, c in winner["cells"]:
            reduced[r][c] = background
        try:
            quantity_necessary = program.predict(tuple(tuple(row) for row in reduced)) != original
        except Inapplicable:
            quantity_necessary = True
        try:
            rotation_invariant = program.predict(_rot180(source)) == original
        except Inapplicable:
            rotation_invariant = False
        rows.append({
            "demonstration": index,
            "recolour_propagates": recolour_propagates,
            "quantity_necessary": quantity_necessary,
            "rotation_invariant": rotation_invariant,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_validation(program, pairs):
    if isinstance(program, ComponentFeatureOutlierCropProgram):
        return _outlier_counterfactuals(program, pairs)
    if isinstance(program, ModalComponentClassCropProgram):
        return _modal_counterfactuals(program, pairs)
    if isinstance(program, ComponentExtremumColourProjectionProgram):
        return _extremum_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_quantified_relations(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [item for index, item in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_quantified_relations(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    counterfactuals = []
    for program in programmes:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def quantified_relation_affordances(task):
    clean = public_task(task)
    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    return tuple(sorted({program.kind for program in fit_quantified_relation_programs(pairs)}))


infer = infer_quantified_relations
validate = validate_quantified_relations
