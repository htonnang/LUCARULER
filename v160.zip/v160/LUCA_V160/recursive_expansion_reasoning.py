"""LUCA V126: recursive unified generative algebra.

The family anti-unifies several expansion tasks into a small set of typed
programmes::

    source -> derive parameter / relation -> expansion operator -> output

Six conservative schemas are exposed:

* ``palette_cardinality_expansion`` derives a block factor from the input
  palette and either uniformly expands cells or tiles the entire source;
* ``count_packed_source_replication`` derives a macro canvas from background
  and foreground material counts;
* ``uniform_square_lattice`` converts a solid square into a separator lattice;
* ``diagonal_translation_closure`` repeatedly translates a seed pattern;
* ``diagonal_band_periodic_extension`` extends a periodic diagonal band to a
  larger homologous canvas;
* ``corner_ring_periodic_extension`` extends constant corner rings cyclically.

No task identifiers, test targets, or stored demonstration coordinates are
available to inference. Exact demonstration fit is necessary but not
sufficient: accepted programmes must survive prediction consensus,
held-demonstration refitting, counterfactual interventions, and metadata
poisoning tests.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_recursive_unified_generative_algebra"
LANGUAGE = "spinoza_recursive_unified_generative_algebra_v1"
SCHEMA_VERSION = "recursive_unified_generative_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    if not value or not value[0]:
        raise Inapplicable("empty grid")
    return len(value), len(value[0])


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _unique_mode(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty palette")
    maximum = max(counts.values())
    modes = [colour for colour, count in counts.items() if count == maximum]
    if len(modes) != 1:
        raise Inapplicable("modal colour is ambiguous")
    return modes[0]


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused ARC colour")


def _replace_colour(value: Grid, old: int, new: int) -> Grid:
    return tuple(tuple(new if cell == old else cell for cell in row) for row in grid(value))


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


# ---------------------------------------------------------------------------
# Programme 1: palette-cardinality block expansion.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PaletteCardinalityExpansionProgram:
    operator: str
    count_policy: str
    kind: str = "palette_cardinality_expansion"

    @property
    def schema_key(self):
        return self.kind, self.operator, self.count_policy

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def factor(self, value: Grid) -> int:
        palette = _palette(value)
        if self.count_policy == "all_colours":
            factor = len(palette)
        elif self.count_policy == "nonzero_colours":
            factor = len(palette - {0})
        elif self.count_policy == "nonmodal_colours":
            factor = len(palette - {_unique_mode(value)})
        else:
            raise Inapplicable("unknown palette-count policy")
        if factor < 1:
            raise Inapplicable("empty semantic palette")
        return factor

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        factor = self.factor(value)
        if height * factor > 60 or width * factor > 60:
            raise Inapplicable("expanded grid exceeds conservative bound")

        if self.operator == "cell_scale":
            prediction = tuple(
                tuple(value[r // factor][c // factor] for c in range(width * factor))
                for r in range(height * factor)
            )
        elif self.operator == "source_tile":
            prediction = tuple(
                tuple(value[r % height][c % width] for c in range(width * factor))
                for r in range(height * factor)
            )
        else:
            raise Inapplicable("unknown palette expansion operator")
        return {"factor": factor, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "source_shape": list(_shape(source)),
                "palette": sorted(_palette(source)),
                "factor": analysis["factor"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"operator": self.operator, "count_policy": self.count_policy},
            definitions=[
                {"name": "SemanticPalette", "type": "Grid -> ColourSet"},
                {"name": "PaletteCardinality", "type": "ColourSet -> Integer"},
                {"name": "BlockOperator", "type": "Grid x Integer -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "DerivePaletteFactor", "effect": "count the demonstrated semantic colour roles"},
                {"index": 2, "definition": "ApplyBlockOperator", "effect": "uniformly scale cells or tile the complete source"},
            ],
            corollary="palette cardinality controls a reusable block expansion",
            common_notions=[{"name": "palette_cardinality_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Programme 2: count-packed source replication.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CountPackedSourceReplicationProgram:
    background_colour: int
    kind: str = "count_packed_source_replication"

    @property
    def schema_key(self):
        return self.kind, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        background_count = sum(cell == self.background_colour for row in value for cell in row)
        foreground_count = height * width - background_count
        if background_count < 1 or foreground_count < 1 or background_count > 30:
            raise Inapplicable("invalid material counts")
        out_height, out_width = background_count * height, background_count * width
        if out_height > 70 or out_width > 70:
            raise Inapplicable("expanded grid exceeds conservative bound")

        result = [[self.background_colour for _ in range(out_width)] for _ in range(out_height)]
        for index in range(foreground_count):
            block_row, block_col = divmod(index, background_count)
            if block_row >= background_count:
                raise Inapplicable("source-copy count exceeds macro capacity")
            for r, row in enumerate(value):
                start = block_col * width
                result[block_row * height + r][start:start + width] = list(row)
        prediction = tuple(tuple(row) for row in result)
        return {
            "background_count": background_count,
            "foreground_count": foreground_count,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "background_count": analysis["background_count"],
                "foreground_count": analysis["foreground_count"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"background_colour": self.background_colour},
            definitions=[
                {"name": "BackgroundMaterial", "type": "Grid x Colour -> Integer"},
                {"name": "ForegroundMaterial", "type": "Grid x Colour -> Integer"},
                {"name": "RowMajorMacroPacker", "type": "Grid x Integer x Integer -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "CountMaterialRoles", "effect": "derive macro side and copy count from source material"},
                {"index": 2, "definition": "PackSourceCopies", "effect": "place complete source copies in row-major macro roles"},
            ],
            corollary="complementary material counts determine a source-replication macro canvas",
            common_notions=[{"name": "count_packed_replication_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Programme 3: uniform-square separator lattice.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UniformSquareLatticeProgram:
    target_size: int
    background_colour: int
    kind: str = "uniform_square_lattice"

    @property
    def schema_key(self):
        return self.kind, self.target_size, self.background_colour

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if height != width or height < 1:
            raise Inapplicable("source must be a square")
        palette = _palette(value)
        if len(palette) != 1:
            raise Inapplicable("source square must be uniform")
        line_colour = next(iter(palette))
        if line_colour == self.background_colour:
            raise Inapplicable("line colour equals background")
        if self.target_size <= height or self.target_size > 70:
            raise Inapplicable("invalid lattice target size")

        result = []
        period = height + 1
        for r in range(self.target_size):
            row = []
            for c in range(self.target_size):
                line = (r + 1) % period == 0 or (c + 1) % period == 0
                row.append(line_colour if line else self.background_colour)
            result.append(tuple(row))
        prediction = tuple(result)
        return {"cell_size": height, "line_colour": line_colour, "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "cell_size": analysis["cell_size"],
                "line_colour": analysis["line_colour"],
                "target_size": self.target_size,
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"target_size": self.target_size, "background_colour": self.background_colour},
            definitions=[
                {"name": "UniformSquare", "type": "Grid -> Size x Colour"},
                {"name": "SeparatorPeriod", "type": "Size -> Integer"},
                {"name": "LatticeEmitter", "type": "Period x CanvasSize -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ReadCellScale", "effect": "derive logical cell size from the uniform source"},
                {"index": 2, "definition": "EmitSeparatorLattice", "effect": "draw one-cell separators after every logical cell"},
            ],
            corollary="a solid square defines the cell scale of a larger separator lattice",
            common_notions=[{"name": "uniform_square_lattice_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Programme 4: diagonal translation closure.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DiagonalTranslationClosureProgram:
    scale: int
    step_row: int
    step_col: int
    background_colour: int
    kind: str = "diagonal_translation_closure"

    @property
    def schema_key(self):
        return self.kind, self.scale, self.step_row, self.step_col, self.background_colour

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        height, width = _shape(value)
        if self.scale < 1 or (self.step_row == 0 and self.step_col == 0):
            raise Inapplicable("invalid translation closure")
        out_height, out_width = height * self.scale, width * self.scale
        if out_height > 70 or out_width > 70:
            raise Inapplicable("expanded grid exceeds conservative bound")
        cells = [(r, c, value[r][c]) for r in range(height) for c in range(width)
                 if value[r][c] != self.background_colour]
        if not cells:
            raise Inapplicable("translation closure needs foreground evidence")
        result = [[self.background_colour for _ in range(out_width)] for _ in range(out_height)]
        for multiplier in range(max(out_height, out_width) * 3 + 3):
            visible = False
            for r, c, colour in cells:
                rr = r + multiplier * self.step_row
                cc = c + multiplier * self.step_col
                if 0 <= rr < out_height and 0 <= cc < out_width:
                    visible = True
                    existing = result[rr][cc]
                    if existing != self.background_colour and existing != colour:
                        raise Inapplicable("translated seed colours conflict")
                    result[rr][cc] = colour
            if multiplier > 0 and not visible:
                break
        prediction = tuple(tuple(row) for row in result)
        return {"seed_cells": len(cells), "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "seed_cells": analysis["seed_cells"],
                "step": [self.step_row, self.step_col],
                "scale": self.scale,
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "scale": self.scale,
                "step_row": self.step_row,
                "step_col": self.step_col,
                "background_colour": self.background_colour,
            },
            definitions=[
                {"name": "SeedPattern", "type": "Grid x Colour -> ColouredCells"},
                {"name": "TranslationStep", "type": "Integer x Integer"},
                {"name": "TranslationClosure", "type": "ColouredCells x Step x Canvas -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ExtractSeed", "effect": "retain every non-background source cell"},
                {"index": 2, "definition": "CloseUnderTranslation", "effect": "repeat the seed along the learned direction until the boundary"},
            ],
            corollary="a sparse seed generates its complete translation orbit on the enlarged canvas",
            common_notions=[{"name": "diagonal_translation_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Programme 5: diagonal-band periodic extension.
# ---------------------------------------------------------------------------


def _diagonal_band_models(value: Grid, scale: int):
    value = grid(value)
    size, width = _shape(value)
    if size != width or size < 2:
        raise Inapplicable("diagonal band requires a square source")
    background = _unique_mode(value)
    foreground = [(r, c) for r in range(size) for c in range(size) if value[r][c] != background]
    if not foreground:
        raise Inapplicable("diagonal band has no foreground")

    models = []
    for orientation in ("main", "anti"):
        def coordinate(r, c, canvas_size):
            return (r, c - r) if orientation == "main" else (r, c + r - (canvas_size - 1))

        offsets = [coordinate(r, c, size)[1] for r, c in foreground]
        minimum, maximum = min(offsets), max(offsets)
        for period in range(1, size + 1):
            mapping = {}
            witnesses = Counter()
            conflict = False
            for r in range(size):
                for c in range(size):
                    along, offset = coordinate(r, c, size)
                    if minimum <= offset <= maximum:
                        key = (offset, along % period)
                        colour = value[r][c]
                        if key in mapping and mapping[key] != colour:
                            conflict = True
                            break
                        mapping[key] = colour
                        witnesses[key] += 1
                if conflict:
                    break
            if conflict:
                continue

            target_size = size * scale
            needed = set()
            for r in range(target_size):
                for c in range(target_size):
                    along, offset = coordinate(r, c, target_size)
                    if minimum <= offset <= maximum:
                        needed.add((offset, along % period))
            if not needed <= mapping.keys():
                continue
            repeated = sum(count >= 2 for count in witnesses.values())
            if repeated == 0:
                continue

            result = [[background for _ in range(target_size)] for _ in range(target_size)]
            for r in range(target_size):
                for c in range(target_size):
                    along, offset = coordinate(r, c, target_size)
                    if minimum <= offset <= maximum:
                        result[r][c] = mapping[(offset, along % period)]
            score = (maximum - minimum + 1, len(mapping), period, -repeated)
            models.append({
                "score": score,
                "orientation": orientation,
                "period": period,
                "minimum_offset": minimum,
                "maximum_offset": maximum,
                "mapping": mapping,
                "background_colour": background,
                "prediction": tuple(tuple(row) for row in result),
            })
    models.sort(key=lambda item: item["score"])
    return models


@dataclass(frozen=True)
class DiagonalBandPeriodicExtensionProgram:
    scale: int
    kind: str = "diagonal_band_periodic_extension"

    @property
    def schema_key(self):
        return self.kind, self.scale

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        models = _diagonal_band_models(value, self.scale)
        if not models:
            raise Inapplicable("no diagonal-band law")
        best = models[0]["score"]
        predictions = {}
        for model in models:
            if model["score"] != best:
                break
            predictions.setdefault(model["prediction"], []).append(model)
        if len(predictions) != 1:
            raise Inapplicable("minimum diagonal-band law is ambiguous")
        prediction, witnesses = next(iter(predictions.items()))
        witness = witnesses[0]
        return {
            "orientation": witness["orientation"],
            "period": witness["period"],
            "band_width": witness["maximum_offset"] - witness["minimum_offset"] + 1,
            "prediction": prediction,
        }

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "orientation": analysis["orientation"],
                "period": analysis["period"],
                "band_width": analysis["band_width"],
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={"scale": self.scale},
            definitions=[
                {"name": "DiagonalCoordinates", "type": "Grid x Orientation -> Along x Offset"},
                {"name": "ResidueLaw", "type": "Offset x AlongModuloPeriod -> Colour"},
                {"name": "BandExtension", "type": "ResidueLaw x LargerCanvas -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "InferDiagonalFrame", "effect": "choose the minimum-width main or anti-diagonal band"},
                {"index": 2, "definition": "InferPeriodicResidues", "effect": "derive the shortest conflict-free colour period"},
                {"index": 3, "definition": "ExtendBand", "effect": "evaluate the residue law on the homologous larger diagonal frame"},
            ],
            corollary="a periodic diagonal band is continued on a larger homologous canvas",
            common_notions=[{"name": "diagonal_band_periodic_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Programme 6: corner-ring periodic extension.
# ---------------------------------------------------------------------------


def _corner_ring_index(row: int, col: int, size: int, corner: str) -> int:
    if corner == "top_left":
        return max(row, col)
    if corner == "top_right":
        return max(row, size - 1 - col)
    if corner == "bottom_left":
        return max(size - 1 - row, col)
    if corner == "bottom_right":
        return max(size - 1 - row, size - 1 - col)
    raise Inapplicable("unknown corner")


@dataclass(frozen=True)
class CornerRingPeriodicExtensionProgram:
    scale: int
    corner: str
    drop_trailing_zero: bool
    kind: str = "corner_ring_periodic_extension"

    @property
    def schema_key(self):
        return self.kind, self.scale, self.corner, self.drop_trailing_zero

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return self.schema_key

    def analyse(self, value: Grid):
        value = grid(value)
        size, width = _shape(value)
        if size != width:
            raise Inapplicable("corner-ring extension requires a square source")
        ring_values = []
        for ring in range(size):
            colours = {
                value[r][c]
                for r in range(size)
                for c in range(size)
                if _corner_ring_index(r, c, size, self.corner) == ring
            }
            if len(colours) != 1:
                raise Inapplicable("source ring is not constant")
            ring_values.append(next(iter(colours)))
        if self.drop_trailing_zero and ring_values and ring_values[-1] == 0 and 0 not in ring_values[:-1]:
            ring_values = ring_values[:-1]
        if not ring_values:
            raise Inapplicable("empty corner-ring cycle")
        target_size = size * self.scale
        if target_size > 70:
            raise Inapplicable("expanded grid exceeds conservative bound")
        prediction = tuple(
            tuple(ring_values[_corner_ring_index(r, c, target_size, self.corner) % len(ring_values)]
                  for c in range(target_size))
            for r in range(target_size)
        )
        return {"ring_cycle": tuple(ring_values), "prediction": prediction}

    def predict(self, value: Grid) -> Grid:
        return self.analyse(value)["prediction"]

    def describe(self, pairs):
        evidence = []
        for index, (source, target) in enumerate(pairs):
            analysis = self.analyse(source)
            evidence.append({
                "demonstration": index,
                "corner": self.corner,
                "ring_cycle": list(analysis["ring_cycle"]),
                "output_exact": analysis["prediction"] == grid(target),
            })
        return _law(
            self,
            parameters={
                "scale": self.scale,
                "corner": self.corner,
                "drop_trailing_zero": self.drop_trailing_zero,
            },
            definitions=[
                {"name": "CornerRing", "type": "Grid x Corner x Integer -> Cells"},
                {"name": "RingCycle", "type": "Grid x Corner -> ColourSequence"},
                {"name": "RingEmitter", "type": "ColourSequence x Canvas -> Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "ReadConstantRings", "effect": "extract the ordered corner-ring colour sequence"},
                {"index": 2, "definition": "RemoveTrailingBackgroundRole", "effect": "exclude a sole outer zero ring when demonstrated"},
                {"index": 3, "definition": "RepeatRingCycle", "effect": "continue the sequence over the enlarged canvas"},
            ],
            corollary="constant corner rings define a periodic nested expansion",
            common_notions=[{"name": "corner_ring_periodic_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Fitting.
# ---------------------------------------------------------------------------


def _integer_square_scale(pairs):
    scales = []
    for source, target in pairs:
        sh, sw = _shape(source)
        th, tw = _shape(target)
        if th % sh or tw % sw or th // sh != tw // sw:
            raise Inapplicable("output is not an isotropic integer expansion")
        scales.append(th // sh)
    if len(set(scales)) != 1:
        raise Inapplicable("expansion factor is not task-consistent")
    return scales[0]


def _fit_palette_cardinality(pairs):
    programmes = []
    for operator in ("cell_scale", "source_tile"):
        for policy in ("all_colours", "nonzero_colours", "nonmodal_colours"):
            program = PaletteCardinalityExpansionProgram(operator, policy)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
                continue
    return programmes


def _fit_count_packed(pairs):
    common = set.intersection(*(_palette(source) for source, _ in pairs))
    programmes = []
    for background in sorted(common):
        program = CountPackedSourceReplicationProgram(background)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                programmes.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
            continue
    return programmes


def _fit_uniform_lattice(pairs):
    sizes = {_shape(target) for _, target in pairs}
    if len(sizes) != 1:
        return []
    target_height, target_width = next(iter(sizes))
    if target_height != target_width:
        return []
    common = set.intersection(*(_palette(target) for _, target in pairs))
    programmes = []
    for background in sorted(common):
        program = UniformSquareLatticeProgram(target_height, background)
        try:
            if all(program.predict(source) == target for source, target in pairs):
                programmes.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
            continue
    return programmes


def _fit_diagonal_translation(pairs):
    try:
        scale = _integer_square_scale(pairs)
    except Inapplicable:
        return []
    common = set.intersection(*(_palette(source) for source, _ in pairs))
    programmes = []
    for background in sorted(common):
        for step_row in range(-3, 4):
            for step_col in range(-3, 4):
                if step_row == 0 and step_col == 0:
                    continue
                program = DiagonalTranslationClosureProgram(scale, step_row, step_col, background)
                try:
                    if all(program.predict(source) == target for source, target in pairs):
                        programmes.append(program)
                except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
                    continue
    return programmes


def _fit_diagonal_band(pairs):
    try:
        scale = _integer_square_scale(pairs)
    except Inapplicable:
        return []
    program = DiagonalBandPeriodicExtensionProgram(scale)
    try:
        return [program] if all(program.predict(source) == target for source, target in pairs) else []
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
        return []


def _fit_corner_ring(pairs):
    try:
        scale = _integer_square_scale(pairs)
    except Inapplicable:
        return []
    programmes = []
    for corner in ("top_left", "top_right", "bottom_left", "bottom_right"):
        for drop in (False, True):
            program = CornerRingPeriodicExtensionProgram(scale, corner, drop)
            try:
                if all(program.predict(source) == target for source, target in pairs):
                    programmes.append(program)
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, ZeroDivisionError):
                continue
    return programmes


def _role_signature(program, source):
    analysis = program.analyse(source)
    if isinstance(program, PaletteCardinalityExpansionProgram):
        return analysis["factor"], sorted(_palette(source)), _shape(source)
    if isinstance(program, CountPackedSourceReplicationProgram):
        return analysis["background_count"], analysis["foreground_count"]
    if isinstance(program, UniformSquareLatticeProgram):
        return analysis["cell_size"], analysis["line_colour"]
    if isinstance(program, DiagonalTranslationClosureProgram):
        return analysis["seed_cells"], _serial(source)
    if isinstance(program, DiagonalBandPeriodicExtensionProgram):
        return analysis["orientation"], analysis["period"], analysis["band_width"]
    if isinstance(program, CornerRingPeriodicExtensionProgram):
        return analysis["ring_cycle"]
    raise Inapplicable("unknown recursive-expansion programme")


def fit_recursive_expansion_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    fitters = (
        ("palette_cardinality_expansion", lambda: _fit_palette_cardinality(pairs)),
        ("count_packed_source_replication", lambda: _fit_count_packed(pairs)),
        ("uniform_square_lattice", lambda: _fit_uniform_lattice(pairs)),
        ("diagonal_translation_closure", lambda: _fit_diagonal_translation(pairs)),
        ("diagonal_band_periodic_extension", lambda: _fit_diagonal_band(pairs)),
        ("corner_ring_periodic_extension", lambda: _fit_corner_ring(pairs)),
    )
    selected = []
    for kind, fitter in fitters:
        if allowed is not None and kind not in allowed:
            continue
        try:
            selected.extend(fitter())
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue

    exact = []
    for program in selected:
        try:
            if any(program.predict(source) != target for source, target in pairs):
                continue
            if require_role_variation:
                signatures = [_role_signature(program, source) for source, _ in pairs]
                if len({_serial(signature) for signature in signatures}) < 2:
                    continue
            exact.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
    unique = {program.schema_key: program for program in exact}
    return sorted(unique.values(), key=lambda program: (program.description_length, repr(program.permissiveness_cost)))


# ---------------------------------------------------------------------------
# Inference.
# ---------------------------------------------------------------------------


def infer_recursive_expansion(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_recursive_expansion_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    counterfactual_rejected = 0
    for program in programmes:
        try:
            # Counterfactual adequacy is part of the inference boundary, not only
            # a post-hoc report.  Exact but causally unstable descriptions are
            # excluded before prediction consensus.
            counterfactual = _counterfactual_validation(program, pairs)
            if not counterfactual.get("passed"):
                counterfactual_rejected += 1
                continue
            predictions = tuple(program.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = program.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[int(cell) for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": counterfactual_rejected,
            "schemas": sorted({law.get("schema") for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "recursive_unified_generative_algebra": True,
            "absolute_coordinates_stored": False,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "palette_cardinality_expansion":
        return PaletteCardinalityExpansionProgram(str(parameters["operator"]), str(parameters["count_policy"]))
    if kind == "count_packed_source_replication":
        return CountPackedSourceReplicationProgram(int(parameters["background_colour"]))
    if kind == "uniform_square_lattice":
        return UniformSquareLatticeProgram(int(parameters["target_size"]), int(parameters["background_colour"]))
    if kind == "diagonal_translation_closure":
        return DiagonalTranslationClosureProgram(
            int(parameters["scale"]), int(parameters["step_row"]), int(parameters["step_col"]), int(parameters["background_colour"])
        )
    if kind == "diagonal_band_periodic_extension":
        return DiagonalBandPeriodicExtensionProgram(int(parameters["scale"]))
    if kind == "corner_ring_periodic_extension":
        return CornerRingPeriodicExtensionProgram(
            int(parameters["scale"]), str(parameters["corner"]), bool(parameters["drop_trailing_zero"])
        )
    raise Inapplicable("unknown recursive-expansion schema")


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _counterfactual_result(kind, rows):
    passed = bool(rows) and all(
        all(value for key, value in row.items() if key != "demonstration")
        for row in rows
    )
    return {"kind": kind, "rows": rows, "passed": passed}


def _counterfactual_validation(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        original = program.predict(source)
        relation_necessary = False
        equivariant = True

        if isinstance(program, PaletteCardinalityExpansionProgram):
            palette = sorted(_palette(source))
            semantic = [colour for colour in palette if colour != 0] or palette
            colour = semantic[0]
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            if len(semantic) >= 2:
                merged = _replace_colour(source, semantic[-1], semantic[0])
                try:
                    relation_necessary = program.predict(merged) != original
                except Inapplicable:
                    relation_necessary = True
            else:
                modified = _array(source)
                modified[0][0] = fresh
                try:
                    relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
                except Inapplicable:
                    relation_necessary = True

        elif isinstance(program, CountPackedSourceReplicationProgram):
            foreground = next(colour for colour in _palette(source) if colour != program.background_colour)
            fresh = _fresh_colour(source, (foreground,))
            recoloured = _replace_colour(source, foreground, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, foreground, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            changed = False
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell == program.background_colour:
                        modified[r][c] = foreground
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, UniformSquareLatticeProgram):
            line_colour = next(iter(_palette(source)))
            fresh = _fresh_colour(source, (line_colour, program.background_colour))
            recoloured = _replace_colour(source, line_colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, line_colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            modified[0][0] = program.background_colour
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, DiagonalTranslationClosureProgram):
            colour = next(colour for colour in _palette(source) if colour != program.background_colour)
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            removed = False
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell != program.background_colour:
                        modified[r][c] = program.background_colour
                        removed = True
                        break
                if removed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, DiagonalBandPeriodicExtensionProgram):
            background = _unique_mode(source)
            colour = next(colour for colour in _palette(source) if colour != background)
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            changed = False
            for r, row in enumerate(source):
                for c, cell in enumerate(row):
                    if cell != background:
                        modified[r][c] = fresh
                        changed = True
                        break
                if changed:
                    break
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        elif isinstance(program, CornerRingPeriodicExtensionProgram):
            analysis = program.analyse(source)
            cycle = analysis["ring_cycle"]
            colour = cycle[0]
            fresh = _fresh_colour(source, (colour,))
            recoloured = _replace_colour(source, colour, fresh)
            try:
                equivariant = program.predict(recoloured) == _replace_colour(original, colour, fresh)
            except Inapplicable:
                equivariant = False
            modified = _array(source)
            modified[0][0] = fresh if source[0][0] != fresh else _fresh_colour(source, (fresh,))
            try:
                relation_necessary = program.predict(tuple(tuple(row) for row in modified)) != original
            except Inapplicable:
                relation_necessary = True

        else:
            return {"kind": "unknown", "passed": False}

        rows.append({
            "demonstration": index,
            "relation_necessary": relation_necessary,
            "equivariant_or_stable": equivariant,
        })
    return _counterfactual_result(program.kind, rows)


# ---------------------------------------------------------------------------
# Validation.
# ---------------------------------------------------------------------------


def validate_recursive_expansion(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected_tuple = tuple(grid(entry["prediction"]) for entry in full["tests"])
    programmes = []
    for law in full.get("supporting_laws", ()): 
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held_index, held_demo in enumerate(clean["train"]):
        remaining_pairs = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_recursive_expansion_programs(
            remaining_pairs,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        held_exact = []
        invalid = 0
        for program in refitted:
            try:
                if program.predict(held_demo["input"]) != grid(held_demo["output"]):
                    continue
                test_predictions = tuple(program.predict(case["input"]) for case in clean["test"])
                held_exact.append((program, test_predictions))
            except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
                invalid += 1
        groups = defaultdict(list)
        for program, predictions in held_exact:
            groups[predictions].append(program.schema_key)
        stable = len(groups) == 1 and next(iter(groups), None) == expected_tuple
        folds.append({
            "held_index": held_index,
            "status": "unique" if bool(held_exact) and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "refitted_programs": len(refitted),
            "held_exact_programs": len(held_exact),
            "held_exact_prediction_groups": len(groups),
            "invalid_programs": invalid,
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_protocol": "held_exact_consensus",
        })

    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    counterfactuals = []
    seen = set()
    for program in programmes:
        if program.schema_key in seen:
            continue
        seen.add(program.schema_key)
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
        "validation_protocol": "held_exact_consensus",
    }


def recursive_expansion_affordances(task):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    return tuple(sorted({program.kind for program in fit_recursive_expansion_programs(pairs)}))


infer = infer_recursive_expansion
validate = validate_recursive_expansion
