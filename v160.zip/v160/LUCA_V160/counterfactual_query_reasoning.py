"""LUCA V119: counterfactual relational query composition.

This proof-carrying research family composes structural predicates, quantified
relations, selectors, and compact projections.  Ten schemas share one form::

    scene -> predicates/quantities -> unique relation -> query or transform

The schemas are:

* ``uninterrupted_stripe_colour_query`` — identify the stripe that overwrites
  every crossing line and return its colour;
* ``bridge_connectivity_query`` — decide whether a bridge colour connects two
  square terminals;
* ``canvas_symmetry_codebook_query`` — infer the output label associated with
  symmetric versus asymmetric 3x3 patterns;
* ``unary_square_count_projection`` — count complete 2x2 objects of the
  instructed colour and emit a unary row;
* ``frequency_ranked_block_colour_projection`` — rank lattice-block colours by
  frequency, excluding the dominant colour;
* ``colour_area_rank_projection`` — rank three colours by total occupied area;
* ``largest_frame_interior_projection`` — select the rectangular frame with the
  largest enclosed area and emit its colour as a 2x2 tile;
* ``separator_growth_comparison_projection`` — compare below-versus-above
  growth of two traces separated by a full row;
* ``paired_half_reversal`` — reverse each half of an odd one-dimensional list
  while preserving its centre;
* ``embedded_object_grid_projection`` — compress coloured patches embedded in
  a dominant rectangle into a logical 2x2 grid.

Programs use no task identifiers, stored demonstration coordinates, or test
outputs.  Exact fit is necessary but not sufficient: accepted predictions must
survive leave-one-demonstration-out refitting, schema-specific counterfactuals,
output consensus, and leakage controls.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass
import json
from typing import Iterable

from correspondence import Grid, grid
from runtime import public_task
from scene_kernel import Inapplicable

FAMILY = "spinoza_counterfactual_relational_query_composition"
LANGUAGE = "spinoza_counterfactual_relational_query_composition_v1"
SCHEMA_VERSION = "counterfactual_relational_query_schema_v1"


def _array(value: Grid) -> list[list[int]]:
    return [list(row) for row in grid(value)]


def _shape(value: Grid) -> tuple[int, int]:
    value = grid(value)
    return len(value), len(value[0])


def _serial(value) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def _palette(value: Grid) -> set[int]:
    return {cell for row in grid(value) for cell in row}


def _unique_modal(value: Grid) -> int:
    counts = Counter(cell for row in grid(value) for cell in row)
    if not counts:
        raise Inapplicable("empty grid")
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("background is not uniquely modal")
    return winners[0]


def _unique_boundary_modal(value: Grid) -> int:
    a = grid(value)
    h, w = _shape(a)
    boundary = [a[0][c] for c in range(w)] + [a[h - 1][c] for c in range(w)]
    boundary += [a[r][0] for r in range(1, h - 1)] + [a[r][w - 1] for r in range(1, h - 1)]
    counts = Counter(boundary)
    top = max(counts.values())
    winners = [colour for colour, count in counts.items() if count == top]
    if len(winners) != 1:
        raise Inapplicable("boundary background is not unique")
    return winners[0]


def _rot180(value: Grid) -> Grid:
    a = grid(value)
    return tuple(tuple(reversed(row)) for row in reversed(a))


def _rot90(value: Grid) -> Grid:
    a = grid(value)
    h, w = _shape(a)
    return tuple(tuple(a[h - 1 - r][c] for r in range(h)) for c in range(w))


def _flip_lr(value: Grid) -> Grid:
    return tuple(tuple(reversed(row)) for row in grid(value))


def _fresh_colour(value: Grid, forbidden=()) -> int:
    used = _palette(value) | set(forbidden)
    for colour in range(10):
        if colour not in used:
            return colour
    raise Inapplicable("no unused counterfactual colour")


def _bbox(cells: Iterable[tuple[int, int]]) -> tuple[int, int, int, int]:
    cells = tuple(cells)
    if not cells:
        raise Inapplicable("empty component")
    return (
        min(r for r, _ in cells),
        min(c for _, c in cells),
        max(r for r, _ in cells),
        max(c for _, c in cells),
    )


def _solid_rectangle(cells: Iterable[tuple[int, int]]) -> bool:
    cells = set(cells)
    r0, c0, r1, c1 = _bbox(cells)
    return len(cells) == (r1 - r0 + 1) * (c1 - c0 + 1)


def _crop(value: Grid, cells: Iterable[tuple[int, int]]) -> Grid:
    a = grid(value)
    r0, c0, r1, c1 = _bbox(cells)
    return tuple(tuple(a[r][c] for c in range(c0, c1 + 1)) for r in range(r0, r1 + 1))


def _components_of_colour(value: Grid, colour: int, connectivity: int = 4) -> tuple[tuple[tuple[int, int], ...], ...]:
    if connectivity not in (4, 8):
        raise Inapplicable("connectivity must be 4 or 8")
    a = grid(value)
    h, w = _shape(a)
    directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    if connectivity == 8:
        directions += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
    remaining = {(r, c) for r in range(h) for c in range(w) if a[r][c] == colour}
    result = []
    while remaining:
        start = next(iter(remaining))
        remaining.remove(start)
        queue = [start]
        component = {start}
        while queue:
            r, c = queue.pop()
            for dr, dc in directions:
                neighbour = (r + dr, c + dc)
                if neighbour in remaining:
                    remaining.remove(neighbour)
                    component.add(neighbour)
                    queue.append(neighbour)
        result.append(tuple(sorted(component)))
    return tuple(result)


def _monochrome_components(value: Grid, background: int, connectivity: int = 4):
    a = grid(value)
    result = []
    for colour in sorted(_palette(a) - {background}):
        for cells in _components_of_colour(a, colour, connectivity):
            result.append((colour, cells))
    return tuple(result)


def _is_solid_2x2(cells) -> bool:
    if len(cells) != 4 or not _solid_rectangle(cells):
        return False
    r0, c0, r1, c1 = _bbox(cells)
    return r1 - r0 == 1 and c1 - c0 == 1


def _closed_frame(cells) -> bool:
    cells = set(cells)
    r0, c0, r1, c1 = _bbox(cells)
    if r1 - r0 < 2 or c1 - c0 < 2:
        return False
    perimeter = {
        (r, c)
        for r in range(r0, r1 + 1)
        for c in range(c0, c1 + 1)
        if r in (r0, r1) or c in (c0, c1)
    }
    return cells == perimeter


def _nontrivial_canvas_symmetry(value: Grid) -> bool:
    a = grid(value)
    h, w = _shape(a)
    if h != w:
        raise Inapplicable("canvas symmetry requires a square")
    variants = []
    r1 = _rot90(a)
    r2 = _rot90(r1)
    r3 = _rot90(r2)
    variants.extend((r1, r2, r3, _flip_lr(a)))
    variants.extend((_rot90(_flip_lr(a)), _rot90(_rot90(_flip_lr(a))), _rot90(_rot90(_rot90(_flip_lr(a))))))
    return any(variant == a for variant in variants)


def _map_colours(value: Grid, mapping: dict[int, int]) -> Grid:
    return tuple(tuple(mapping.get(cell, cell) for cell in row) for row in grid(value))


# ---------------------------------------------------------------------------
# Schema I: the uninterrupted stripe is the topmost relation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UninterruptedStripeColourQueryProgram:
    kind: str = "uninterrupted_stripe_colour_query"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 4

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        background = _unique_modal(a)
        candidates: dict[int, list[tuple[str, int]]] = defaultdict(list)
        for r in range(h):
            if len(set(a[r])) == 1 and a[r][0] != background:
                candidates[a[r][0]].append(("row", r))
        for c in range(w):
            values = {a[r][c] for r in range(h)}
            if len(values) == 1:
                colour = next(iter(values))
                if colour != background:
                    candidates[colour].append(("column", c))
        if len(candidates) != 1:
            raise Inapplicable("there is not exactly one uninterrupted stripe colour")
        if len(_palette(a) - {background}) < 2:
            raise Inapplicable("requires crossing coloured traces")
        colour, stripes = next(iter(candidates.items()))
        return background, colour, tuple(stripes), ((colour,),)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, colour, stripes, _ = self._analyse(source)
            evidence.append({"colour": colour, "stripes": [list(item) for item in stripes]})
        return _law(
            self,
            parameters={"kind": self.kind},
            definitions=[
                {"name": "CompleteStripe", "type": "Grid -> FullRowOrColumn"},
                {"name": "OcclusionOrder", "type": "CrossingTraces -> TopmostColour"},
                {"name": "ScalarProjection", "type": "Colour -> 1x1Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "FindUninterruptedStripe", "effect": "bind the unique full row or column colour"},
                {"index": 2, "definition": "InterpretOcclusion", "effect": "treat uninterrupted colour as topmost at crossings"},
                {"index": 3, "definition": "ProjectColour", "effect": "emit the bound colour as a scalar grid"},
            ],
            corollary="the trace that remains uninterrupted through every crossing determines the queried colour",
            common_notions=[{"name": "uninterrupted_stripe_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema II: a bridge component connects two terminal squares.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class BridgeConnectivityQueryProgram:
    connectivity: int = 4
    kind: str = "bridge_connectivity_query"

    @property
    def schema_key(self):
        return (self.kind, self.connectivity)

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return (self.connectivity,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        colours = _palette(a) - {background}
        hypotheses = []
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        if self.connectivity == 8:
            directions += [(1, 1), (1, -1), (-1, 1), (-1, -1)]
        for terminal_colour in colours:
            terminals = _components_of_colour(a, terminal_colour, 4)
            if len(terminals) != 2 or not all(_is_solid_2x2(component) for component in terminals):
                continue
            bridge_colours = colours - {terminal_colour}
            if len(bridge_colours) != 1:
                continue
            bridge_colour = next(iter(bridge_colours))
            bridge_components = _components_of_colour(a, bridge_colour, self.connectivity)

            def touches(bridge, terminal):
                terminal = set(terminal)
                return any((r + dr, c + dc) in terminal for r, c in bridge for dr, dc in directions)

            linked = any(touches(component, terminals[0]) and touches(component, terminals[1]) for component in bridge_components)
            hypotheses.append((terminal_colour, bridge_colour, terminals, bridge_components, linked))
        if len(hypotheses) != 1:
            raise Inapplicable("bridge terminals are not uniquely identified")
        terminal_colour, bridge_colour, terminals, bridge_components, linked = hypotheses[0]
        answer = bridge_colour if linked else background
        return background, terminal_colour, bridge_colour, terminals, bridge_components, linked, ((answer,),)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, terminal_colour, bridge_colour, terminals, _, linked, _ = self._analyse(source)
            evidence.append({
                "terminal_colour": terminal_colour,
                "bridge_colour": bridge_colour,
                "terminal_boxes": [list(_bbox(component)) for component in terminals],
                "linked": linked,
            })
        return _law(
            self,
            parameters={"kind": self.kind, "connectivity": self.connectivity},
            definitions=[
                {"name": "TerminalPair", "type": "Grid -> TwoSolid2x2Objects"},
                {"name": "BridgeGraph", "type": "ColourCells -> ConnectedComponents"},
                {"name": "ConnectivityQuery", "type": "TerminalPair x BridgeGraph -> Bool"},
            ],
            propositions=[
                {"index": 1, "definition": "BindTerminals", "effect": "identify the unique pair of solid 2x2 terminals"},
                {"index": 2, "definition": "TraceBridge", "effect": "test whether one bridge component touches both terminals"},
                {"index": 3, "definition": "ProjectRelation", "effect": "emit bridge colour when connected and background otherwise"},
            ],
            corollary="the scalar answer reports whether the relational bridge joins both terminal objects",
            common_notions=[{"name": "bridge_connectivity_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema III: learn the codebook for a structural symmetry predicate.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CanvasSymmetryCodebookQueryProgram:
    asymmetric_label: int
    symmetric_label: int
    kind: str = "canvas_symmetry_codebook_query"

    @property
    def schema_key(self):
        return (self.kind, self.asymmetric_label, self.symmetric_label)

    @property
    def description_length(self):
        return 6

    @property
    def permissiveness_cost(self):
        return (0,)

    def _classify(self, value: Grid) -> bool:
        a = grid(value)
        if _shape(a) != (3, 3) or len(_palette(a)) != 2:
            raise Inapplicable("requires a binary 3x3 canvas")
        return _nontrivial_canvas_symmetry(a)

    def predict(self, value: Grid) -> Grid:
        label = self.symmetric_label if self._classify(value) else self.asymmetric_label
        return ((label,),)

    def describe(self, pairs):
        evidence = [{"symmetric": self._classify(source), "label": target[0][0]} for source, target in pairs]
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "asymmetric_label": self.asymmetric_label,
                "symmetric_label": self.symmetric_label,
            },
            definitions=[
                {"name": "CanvasD4Predicate", "type": "3x3Grid -> Bool"},
                {"name": "StructuralCodebook", "type": "Bool -> Colour"},
            ],
            propositions=[
                {"index": 1, "definition": "TestCanvasSymmetry", "effect": "classify the pattern by nonidentity D4 invariance"},
                {"index": 2, "definition": "ApplyCodebook", "effect": "map the structural class to its demonstrated label"},
            ],
            corollary="the output label encodes whether the complete canvas has a nontrivial symmetry",
            common_notions=[{"name": "symmetry_codebook_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema IV: count complete squares and emit a unary row.
# ---------------------------------------------------------------------------


def _count_solid_2x2(value: Grid, colour: int):
    count = 0
    singleton_count = 0
    components = _components_of_colour(value, colour, 4)
    for component in components:
        if _is_solid_2x2(component):
            count += 1
        elif len(component) == 1:
            singleton_count += 1
        else:
            raise Inapplicable("colour contains a component other than a singleton or solid 2x2 square")
    return count, singleton_count, components


@dataclass(frozen=True)
class UnarySquareCountProjectionProgram:
    width: int
    count_colour: int
    background: int
    kind: str = "unary_square_count_projection"

    @property
    def schema_key(self):
        return (self.kind, self.width, self.count_colour, self.background)

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return (-self.width,)

    def _analyse(self, value: Grid):
        a = grid(value)
        if _unique_modal(a) != self.background:
            raise Inapplicable("background does not match the learned unary programme")
        colours = _palette(a) - {self.background}
        if len(colours) != 2 or self.count_colour not in colours:
            raise Inapplicable("requires two foreground colours including the counted colour")
        evidence = {}
        total_singletons = 0
        for colour in colours:
            count, singletons, components = _count_solid_2x2(a, colour)
            evidence[colour] = {"squares": count, "singletons": singletons, "components": components}
            total_singletons += singletons
        if total_singletons < 1:
            raise Inapplicable("requires singleton distractor evidence")
        count = evidence[self.count_colour]["squares"]
        if not (0 < count < self.width):
            raise Inapplicable("count does not fit the unary output width")
        output = (tuple([self.count_colour] * count + [self.background] * (self.width - count)),)
        return colours, evidence, count, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        rows = []
        for source, _ in pairs:
            _, evidence, count, _ = self._analyse(source)
            rows.append({
                "count": count,
                "per_colour": {
                    str(colour): {"squares": item["squares"], "singletons": item["singletons"]}
                    for colour, item in evidence.items()
                },
            })
        return _law(
            self,
            parameters={
                "kind": self.kind,
                "width": self.width,
                "count_colour": self.count_colour,
                "background": self.background,
            },
            definitions=[
                {"name": "CompleteSquare", "type": "Component -> Solid2x2"},
                {"name": "ObjectCount", "type": "ColourClass -> Integer"},
                {"name": "UnaryEmitter", "type": "Integer x Colour -> 1xNGrid"},
            ],
            propositions=[
                {"index": 1, "definition": "SeparateSquaresFromSingletons", "effect": "ignore singleton distractors"},
                {"index": 2, "definition": "CountTargetSquares", "effect": "count complete 2x2 objects of the instructed colour"},
                {"index": 3, "definition": "EmitUnaryCount", "effect": "write one target-colour cell per counted object"},
            ],
            corollary="complete objects, rather than isolated pixels, determine the unary count",
            common_notions=[{"name": "square_count_evidence", "evidence": rows}],
        )


# ---------------------------------------------------------------------------
# Schema V: rank lattice-block colours by frequency.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FrequencyRankedBlockColourProjectionProgram:
    kind: str = "frequency_ranked_block_colour_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        components = _monochrome_components(a, background, 4)
        if len(components) < 8:
            raise Inapplicable("requires a repeated block field")
        sizes = set()
        records = []
        for colour, cells in components:
            if not _solid_rectangle(cells):
                raise Inapplicable("all blocks must be solid rectangles")
            r0, c0, r1, c1 = _bbox(cells)
            sizes.add((r1 - r0 + 1, c1 - c0 + 1))
            records.append((colour, (r0, c0)))
        if len(sizes) != 1:
            raise Inapplicable("all blocks must share one size")
        counts = Counter(colour for colour, _ in records)
        if len(counts) != 4:
            raise Inapplicable("requires one dominant and three ranked colours")
        ordered_counts = counts.most_common()
        if ordered_counts[0][1] <= ordered_counts[1][1]:
            raise Inapplicable("dominant block colour is not unique")
        dominant = ordered_counts[0][0]
        first_occurrence = {}
        for colour, position in sorted(records, key=lambda item: item[1]):
            first_occurrence.setdefault(colour, position)
        ranked = [colour for colour in counts if colour != dominant]
        ranked.sort(key=lambda colour: (-counts[colour], first_occurrence[colour]))
        output = tuple((colour,) for colour in ranked)
        return background, sizes.pop(), counts, first_occurrence, dominant, tuple(ranked), output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        rows = []
        for source, _ in pairs:
            _, size, counts, _, dominant, ranked, _ = self._analyse(source)
            rows.append({"block_size": list(size), "counts": dict(counts), "dominant": dominant, "ranked": list(ranked)})
        return _law(
            self,
            parameters={"kind": self.kind, "exclude_unique_dominant": True, "tie_break": "first_occurrence"},
            definitions=[
                {"name": "RepeatedBlockField", "type": "Grid -> EqualRectangleMultiset"},
                {"name": "FrequencyOrder", "type": "ColourMultiset -> OrderedColours"},
                {"name": "RankProjection", "type": "OrderedColours -> Nx1Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "CountBlockColours", "effect": "count equal-sized monochrome blocks"},
                {"index": 2, "definition": "RemoveDominant", "effect": "treat the unique dominant block colour as background class"},
                {"index": 3, "definition": "RankMinorities", "effect": "order remaining colours by frequency and first occurrence"},
            ],
            corollary="the output is the frequency ranking of non-dominant block identities",
            common_notions=[{"name": "block_frequency_evidence", "evidence": rows}],
        )


# ---------------------------------------------------------------------------
# Schema VI: rank colours by occupied area.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ColourAreaRankProjectionProgram:
    kind: str = "colour_area_rank_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        counts = Counter(cell for row in a for cell in row if cell != background)
        if len(counts) != 3 or len(set(counts.values())) != 3:
            raise Inapplicable("requires exactly three colours with distinct total areas")
        ranked = tuple(colour for _, colour in sorted(((area, colour) for colour, area in counts.items()), reverse=True))
        output = tuple((colour,) for colour in ranked)
        return background, counts, ranked, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, counts, ranked, _ = self._analyse(source)
            evidence.append({"areas": dict(counts), "ranked": list(ranked)})
        return _law(
            self,
            parameters={"kind": self.kind, "rank": "descending_total_area"},
            definitions=[
                {"name": "ColourArea", "type": "ColourClass -> Integer"},
                {"name": "StrictAreaOrder", "type": "ThreeIntegers -> OrderedColours"},
            ],
            propositions=[
                {"index": 1, "definition": "MeasureColourAreas", "effect": "sum every cell of each foreground colour"},
                {"index": 2, "definition": "RankByArea", "effect": "order the three colour classes from largest to smallest"},
            ],
            corollary="the vertical output records the strict descending order of foreground colour areas",
            common_notions=[{"name": "colour_area_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema VII: compare enclosed areas of rectangular frames.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LargestFrameInteriorProjectionProgram:
    kind: str = "largest_frame_interior_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 5

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        background = _unique_modal(a)
        components = _monochrome_components(a, background, 4)
        frames = [(colour, cells) for colour, cells in components if _closed_frame(cells)]
        if len(components) != 2 or len(frames) != 2:
            raise Inapplicable("requires exactly two closed monochrome frames")
        scored = []
        for colour, cells in frames:
            r0, c0, r1, c1 = _bbox(cells)
            scored.append(((r1 - r0 - 1) * (c1 - c0 - 1), colour, cells))
        if scored[0][0] == scored[1][0]:
            raise Inapplicable("frame interior areas are tied")
        winner = max(scored, key=lambda item: item[0])
        output = ((winner[1], winner[1]), (winner[1], winner[1]))
        return background, tuple(scored), winner, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, scored, winner, _ = self._analyse(source)
            evidence.append({
                "frames": [{"colour": colour, "interior_area": area, "box": list(_bbox(cells))} for area, colour, cells in scored],
                "winner": winner[1],
            })
        return _law(
            self,
            parameters={"kind": self.kind, "metric": "enclosed_interior_area", "output_shape": [2, 2]},
            definitions=[
                {"name": "ClosedFrame", "type": "Component -> RectangularPerimeter"},
                {"name": "InteriorArea", "type": "ClosedFrame -> Integer"},
                {"name": "ConstantTile", "type": "Colour -> 2x2Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "BindFrames", "effect": "identify exactly two complete rectangular frames"},
                {"index": 2, "definition": "CompareInteriors", "effect": "select the frame enclosing the larger area"},
                {"index": 3, "definition": "ProjectWinnerColour", "effect": "emit a 2x2 tile of the winning frame colour"},
            ],
            corollary="the larger enclosed region determines the projected frame identity",
            common_notions=[{"name": "frame_comparison_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema VIII: compare trace growth across a separator.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SeparatorGrowthComparisonProjectionProgram:
    kind: str = "separator_growth_comparison_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 7

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        background = _unique_modal(a)
        separators = [(r, row[0]) for r, row in enumerate(a) if len(set(row)) == 1 and row[0] != background]
        if len(separators) != 1:
            raise Inapplicable("requires one full-row separator")
        separator_row, separator_colour = separators[0]
        if separator_row in (0, h - 1):
            raise Inapplicable("separator must split the scene")
        colours = _palette(a) - {background, separator_colour}
        if len(colours) != 2:
            raise Inapplicable("requires exactly two compared trace colours")
        evidence = {}
        for colour in colours:
            coordinates = [(r, c) for r in range(h) for c in range(w) if a[r][c] == colour]
            if len({c for _, c in coordinates}) != 1:
                raise Inapplicable("each compared colour must form one vertical trace")
            above = sum(r < separator_row for r, _ in coordinates)
            below = sum(r > separator_row for r, _ in coordinates)
            if above < 1 or below < 1:
                raise Inapplicable("each trace must occur on both sides of the separator")
            evidence[colour] = {"column": coordinates[0][1], "above": above, "below": below, "growth": below - above}
        maximum = max(item["growth"] for item in evidence.values())
        winners = [colour for colour, item in evidence.items() if item["growth"] == maximum]
        if len(winners) != 1:
            raise Inapplicable("growth comparison is tied")
        winner = winners[0]
        output = ((winner, winner), (winner, winner))
        return background, separator_row, separator_colour, evidence, winner, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        rows = []
        for source, _ in pairs:
            _, separator_row, separator_colour, evidence, winner, _ = self._analyse(source)
            rows.append({
                "separator_row": separator_row,
                "separator_colour": separator_colour,
                "traces": {str(colour): values for colour, values in evidence.items()},
                "winner": winner,
            })
        return _law(
            self,
            parameters={"kind": self.kind, "comparison": "below_count_minus_above_count", "output_shape": [2, 2]},
            definitions=[
                {"name": "Separator", "type": "Grid -> FullNonbackgroundRow"},
                {"name": "TraceGrowth", "type": "VerticalTrace x Separator -> Integer"},
                {"name": "WinnerProjection", "type": "UniqueMaximumColour -> 2x2Grid"},
            ],
            propositions=[
                {"index": 1, "definition": "SplitScene", "effect": "bind the full-row separator"},
                {"index": 2, "definition": "MeasureTraceGrowth", "effect": "compare below-versus-above occupancy"},
                {"index": 3, "definition": "ProjectMaximum", "effect": "emit the colour with greater growth"},
            ],
            corollary="the trace that increases most across the separator determines the output colour",
            common_notions=[{"name": "growth_comparison_evidence", "evidence": rows}],
        )


# ---------------------------------------------------------------------------
# Schema IX: reverse each half around a fixed centre.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PairedHalfReversalProgram:
    kind: str = "paired_half_reversal"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 3

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        if h == 1 and w >= 5 and w % 2 == 1:
            orientation = "row"
            values = list(a[0])
        elif w == 1 and h >= 5 and h % 2 == 1:
            orientation = "column"
            values = [row[0] for row in a]
        else:
            raise Inapplicable("requires an odd one-dimensional list of length at least five")
        middle = len(values) // 2
        transformed = list(reversed(values[:middle])) + [values[middle]] + list(reversed(values[middle + 1 :]))
        output = (tuple(transformed),) if orientation == "row" else tuple((value,) for value in transformed)
        return orientation, tuple(values), middle, output

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            orientation, values, middle, _ = self._analyse(source)
            evidence.append({"orientation": orientation, "length": len(values), "middle": middle})
        return _law(
            self,
            parameters={"kind": self.kind, "operation": "reverse_each_half_preserve_centre"},
            definitions=[
                {"name": "OddSequence", "type": "1xNOrNx1Grid -> OrderedValues"},
                {"name": "CentralPivot", "type": "OddSequence -> Value"},
                {"name": "HalfReversal", "type": "OrderedValues -> OrderedValues"},
            ],
            propositions=[
                {"index": 1, "definition": "BindCentre", "effect": "preserve the central value"},
                {"index": 2, "definition": "ReverseLeftHalf", "effect": "reverse values before the centre"},
                {"index": 3, "definition": "ReverseRightHalf", "effect": "reverse values after the centre"},
            ],
            corollary="the two ordered halves reverse independently around an invariant centre",
            common_notions=[{"name": "half_reversal_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Schema X: compress coloured patches embedded in a dominant rectangle.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EmbeddedObjectGridProjectionProgram:
    kind: str = "embedded_object_grid_projection"

    @property
    def schema_key(self):
        return (self.kind,)

    @property
    def description_length(self):
        return 8

    @property
    def permissiveness_cost(self):
        return (0,)

    def _analyse(self, value: Grid):
        a = grid(value)
        h, w = _shape(a)
        background = _unique_boundary_modal(a)
        nonbackground_counts = Counter(cell for row in a for cell in row if cell != background)
        if not nonbackground_counts:
            raise Inapplicable("missing embedded rectangle")
        top = max(nonbackground_counts.values())
        base_candidates = [colour for colour, count in nonbackground_counts.items() if count == top]
        if len(base_candidates) != 1:
            raise Inapplicable("embedded base colour is not unique")
        base = base_candidates[0]
        all_nonbackground = {(r, c) for r in range(h) for c in range(w) if a[r][c] != background}
        r0, c0, r1, c1 = _bbox(all_nonbackground)
        perimeter = {
            (r, c)
            for r in range(r0, r1 + 1)
            for c in range(c0, c1 + 1)
            if r in (r0, r1) or c in (c0, c1)
        }
        if any(a[r][c] != base for r, c in perimeter):
            raise Inapplicable("dominant rectangle perimeter is incomplete")
        inside = [a[r][c] for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)]
        if inside.count(base) < 0.6 * len(inside):
            raise Inapplicable("dominant rectangle is insufficiently filled")
        patches = []
        for colour in sorted(_palette(a) - {background, base}):
            for cells in _components_of_colour(a, colour, 4):
                if not _solid_rectangle(cells):
                    raise Inapplicable("embedded patches must be solid rectangles")
                box = _bbox(cells)
                patches.append((colour, cells, (box[0], box[1]), (box[2] - box[0] + 1, box[3] - box[1] + 1)))
        if not (2 <= len(patches) <= 4) or len({patch[3] for patch in patches}) != 1:
            raise Inapplicable("requires two to four equal embedded patches")
        row_ranks = sorted({patch[2][0] for patch in patches})
        column_ranks = sorted({patch[2][1] for patch in patches})
        if len(row_ranks) != 2 or len(column_ranks) != 2:
            raise Inapplicable("patches must define a 2x2 logical grid")
        output = [[background, background], [background, background]]
        for colour, _, (row, column), _ in patches:
            output[row_ranks.index(row)][column_ranks.index(column)] = colour
        return background, base, (r0, c0, r1, c1), tuple(patches), tuple(row_ranks), tuple(column_ranks), tuple(tuple(row) for row in output)

    def predict(self, value: Grid) -> Grid:
        return self._analyse(value)[-1]

    def describe(self, pairs):
        evidence = []
        for source, _ in pairs:
            _, base, box, patches, rows, columns, _ = self._analyse(source)
            evidence.append({
                "base_colour": base,
                "base_box": list(box),
                "patches": [{"colour": colour, "box": list(_bbox(cells))} for colour, cells, _, _ in patches],
                "row_ranks": list(rows),
                "column_ranks": list(columns),
            })
        return _law(
            self,
            parameters={"kind": self.kind, "logical_shape": [2, 2], "empty_role": "boundary_background"},
            definitions=[
                {"name": "DominantEmbeddedRectangle", "type": "Grid -> BaseRegion"},
                {"name": "EqualColourPatches", "type": "BaseRegion -> PatchSet"},
                {"name": "LogicalPatchGrid", "type": "PatchSet -> 2x2Roles"},
            ],
            propositions=[
                {"index": 1, "definition": "BindBaseRectangle", "effect": "identify the dominant filled rectangle"},
                {"index": 2, "definition": "RankEmbeddedPatches", "effect": "map patch origins to two logical rows and columns"},
                {"index": 3, "definition": "ProjectPatchGrid", "effect": "emit patch colours and background for absent roles"},
            ],
            corollary="embedded objects are compressed into their logical two-dimensional arrangement",
            common_notions=[{"name": "embedded_grid_evidence", "evidence": evidence}],
        )


# ---------------------------------------------------------------------------
# Shared law construction, fitting, inference, and validation.
# ---------------------------------------------------------------------------


def _law(program, *, parameters, definitions, propositions, corollary, common_notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "parameters": parameters,
        "definitions": definitions,
        "propositions": propositions,
        "corollary": corollary,
        "common_notions": common_notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
        },
    }


def _fit_simple(candidates, pairs):
    result = []
    for program in candidates:
        try:
            if all(program.predict(source) == target for source, target in pairs):
                result.append(program)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            continue
    return result


def _fit_symmetry_codebook(pairs):
    mapping = {}
    for source, target in pairs:
        a = grid(source)
        if _shape(a) != (3, 3) or _shape(target) != (1, 1) or len(_palette(a)) != 2:
            return []
        structural_class = _nontrivial_canvas_symmetry(a)
        label = target[0][0]
        if structural_class in mapping and mapping[structural_class] != label:
            return []
        mapping[structural_class] = label
    if set(mapping) != {False, True}:
        return []
    program = CanvasSymmetryCodebookQueryProgram(mapping[False], mapping[True])
    return _fit_simple([program], pairs)


def _fit_unary_square_count(pairs):
    width = None
    count_colour = None
    background = None
    for source, target in pairs:
        target = grid(target)
        if _shape(target)[0] != 1:
            return []
        row = target[0]
        if width is None:
            width = len(row)
        elif width != len(row):
            return []
        if len(set(row)) != 2:
            return []
        split = 0
        while split < len(row) and row[split] == row[0]:
            split += 1
        if split in (0, len(row)) or row[0] == row[-1] or any(value != row[-1] for value in row[split:]):
            return []
        if count_colour is None:
            count_colour, background = row[0], row[-1]
        elif (count_colour, background) != (row[0], row[-1]):
            return []
    if width is None or count_colour is None or background is None:
        return []
    program = UnarySquareCountProjectionProgram(width, count_colour, background)
    return _fit_simple([program], pairs)


def _role_signature(program, source):
    if isinstance(program, UninterruptedStripeColourQueryProgram):
        _, colour, stripes, _ = program._analyse(source)
        return colour, stripes
    if isinstance(program, BridgeConnectivityQueryProgram):
        _, terminal, bridge, terminals, _, linked, _ = program._analyse(source)
        return terminal, bridge, tuple(_bbox(component) for component in terminals), linked
    if isinstance(program, CanvasSymmetryCodebookQueryProgram):
        return program._classify(source), tuple(sorted(_palette(source)))
    if isinstance(program, UnarySquareCountProjectionProgram):
        _, evidence, count, _ = program._analyse(source)
        return count, tuple(sorted((colour, item["squares"], item["singletons"]) for colour, item in evidence.items()))
    if isinstance(program, FrequencyRankedBlockColourProjectionProgram):
        _, size, counts, first, dominant, ranked, _ = program._analyse(source)
        return size, tuple(sorted(counts.items())), tuple(sorted(first.items())), dominant, ranked
    if isinstance(program, ColourAreaRankProjectionProgram):
        _, counts, ranked, _ = program._analyse(source)
        return tuple(sorted(counts.items())), ranked
    if isinstance(program, LargestFrameInteriorProjectionProgram):
        _, scored, winner, _ = program._analyse(source)
        return tuple(sorted((area, colour, _bbox(cells)) for area, colour, cells in scored)), winner[1]
    if isinstance(program, SeparatorGrowthComparisonProjectionProgram):
        _, row, separator, evidence, winner, _ = program._analyse(source)
        return row, separator, tuple(sorted((colour, values["column"], values["growth"]) for colour, values in evidence.items())), winner
    if isinstance(program, PairedHalfReversalProgram):
        orientation, values, middle, _ = program._analyse(source)
        return orientation, values, middle
    if isinstance(program, EmbeddedObjectGridProjectionProgram):
        _, base, box, patches, rows, columns, _ = program._analyse(source)
        return base, box, tuple((colour, _bbox(cells)) for colour, cells, _, _ in patches), rows, columns
    raise Inapplicable("unknown programme")


def _role_varies(program, pairs):
    try:
        evidence = [_role_signature(program, source) for source, _ in pairs]
    except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
        return False
    return len({_serial(item) for item in evidence}) >= 2


def _candidate_programs(pairs, allowed_kinds=None):
    allowed = set(allowed_kinds) if allowed_kinds is not None else None
    programmes = []
    simple = [
        UninterruptedStripeColourQueryProgram(),
        BridgeConnectivityQueryProgram(4),
        FrequencyRankedBlockColourProjectionProgram(),
        ColourAreaRankProjectionProgram(),
        LargestFrameInteriorProjectionProgram(),
        SeparatorGrowthComparisonProjectionProgram(),
        PairedHalfReversalProgram(),
        EmbeddedObjectGridProjectionProgram(),
    ]
    for program in simple:
        if allowed is None or program.kind in allowed:
            programmes.extend(_fit_simple([program], pairs))
    if allowed is None or "canvas_symmetry_codebook_query" in allowed:
        programmes.extend(_fit_symmetry_codebook(pairs))
    if allowed is None or "unary_square_count_projection" in allowed:
        programmes.extend(_fit_unary_square_count(pairs))
    return programmes


def fit_counterfactual_query_programs(
    pairs: Iterable[tuple[Grid, Grid]],
    *,
    minimum_pairs: int = 2,
    allowed_kinds: Iterable[str] | None = None,
    require_role_variation: bool = True,
):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    selected = []
    for program in _candidate_programs(pairs, allowed_kinds):
        try:
            if not all(program.predict(source) == target for source, target in pairs):
                continue
            if require_role_variation and not _role_varies(program, pairs):
                continue
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            continue
        selected.append(program)
    unique = {program.schema_key: program for program in selected}
    return sorted(unique.values(), key=lambda program: (program.description_length, program.permissiveness_cost, repr(program.schema_key)))


def infer_counterfactual_queries(
    task,
    *,
    minimum_pairs: int = 2,
    allowed_kinds=None,
    require_role_variation: bool = True,
):
    clean = public_task(task)
    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    programmes = fit_counterfactual_query_programs(
        pairs,
        minimum_pairs=minimum_pairs,
        allowed_kinds=allowed_kinds,
        require_role_variation=require_role_variation,
    )
    groups = defaultdict(list)
    invalid = 0
    for program in programmes:
        try:
            predictions = [program.predict(case["input"]) for case in clean["test"]]
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError):
            invalid += 1
            continue
        key = tuple(predictions)
        groups[key].append(program.describe(pairs))
        if len(groups) >= 2:
            break
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {"status": status, "prediction": [list(row) for row in chosen[index]] if chosen else None}
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:30] if chosen else [],
        "witness_predictions": [
            [[[int(value) for value in row] for row in prediction] for prediction in key]
            for key in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_query_schemas": sorted({program.kind for program in programmes}),
            "proof_carrying": True,
            "counterfactual_relational_query_composition": True,
            "test_targets_used": False,
            "task_ids_used": False,
        },
    }


def _program_from_law(law):
    parameters = law.get("parameters", {})
    kind = law.get("schema") or parameters.get("kind")
    if kind == "uninterrupted_stripe_colour_query":
        return UninterruptedStripeColourQueryProgram()
    if kind == "bridge_connectivity_query":
        return BridgeConnectivityQueryProgram(int(parameters["connectivity"]))
    if kind == "canvas_symmetry_codebook_query":
        return CanvasSymmetryCodebookQueryProgram(int(parameters["asymmetric_label"]), int(parameters["symmetric_label"]))
    if kind == "unary_square_count_projection":
        return UnarySquareCountProjectionProgram(int(parameters["width"]), int(parameters["count_colour"]), int(parameters["background"]))
    if kind == "frequency_ranked_block_colour_projection":
        return FrequencyRankedBlockColourProjectionProgram()
    if kind == "colour_area_rank_projection":
        return ColourAreaRankProjectionProgram()
    if kind == "largest_frame_interior_projection":
        return LargestFrameInteriorProjectionProgram()
    if kind == "separator_growth_comparison_projection":
        return SeparatorGrowthComparisonProjectionProgram()
    if kind == "paired_half_reversal":
        return PairedHalfReversalProgram()
    if kind == "embedded_object_grid_projection":
        return EmbeddedObjectGridProjectionProgram()
    raise Inapplicable("unknown counterfactual query schema")


# ---------------------------------------------------------------------------
# Counterfactual validation.
# ---------------------------------------------------------------------------


def _stripe_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        background, colour, stripes, original = program._analyse(a)
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        stripe_cells = set()
        for orientation, position in stripes:
            if orientation == "row":
                stripe_cells.update((position, c) for c in range(len(a[0])))
            else:
                stripe_cells.update((r, position) for r in range(len(a)))
        for r, c in stripe_cells:
            recoloured[r][c] = replacement
        recolour_propagates = program.predict(tuple(tuple(row) for row in recoloured)) == ((replacement,),)
        broken = _array(a)
        # Break every complete stripe of the winning colour.  A colour may occupy
        # multiple parallel full rows or columns, so damaging only one would leave
        # the same causal evidence intact.
        for orientation, position in stripes:
            if orientation == "row":
                broken[position][0] = background
            else:
                broken[0][position] = background
        try:
            stripe_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            stripe_necessary = True
        rotation_equivariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "recolour_propagates": recolour_propagates,
            "stripe_necessary": stripe_necessary,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _bridge_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        background, _, bridge_colour, terminals, _, linked, original = program._analyse(a)
        removed = _array(a)
        for r, c in terminals[0]:
            removed[r][c] = background
        try:
            terminal_pair_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            terminal_pair_necessary = True
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        for r, row in enumerate(a):
            for c, colour in enumerate(row):
                if colour == bridge_colour:
                    recoloured[r][c] = replacement
        expected = ((replacement,),) if linked else ((background,),)
        recolour_propagates = program.predict(tuple(tuple(row) for row in recoloured)) == expected
        rotation_equivariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "terminal_pair_necessary": terminal_pair_necessary,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _symmetry_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        background = _unique_modal(a)
        foreground = next(iter(_palette(a) - {background}))
        replacement = _fresh_colour(a)
        recoloured = _map_colours(a, {foreground: replacement})
        colour_invariant = program.predict(recoloured) == original
        rotation_invariant = program.predict(_rot90(a)) == original
        opposite = not program._classify(a)
        toggle_found = False
        coordinates = [(r, c) for r in range(3) for c in range(3)]
        # One-cell changes are sufficient for most examples.  Fully symmetric
        # patterns can retain a residual reflection after any single toggle, so
        # also search two-cell perturbations.
        perturbations = [[coordinate] for coordinate in coordinates]
        perturbations += [
            [coordinates[first], coordinates[second]]
            for first in range(len(coordinates))
            for second in range(first + 1, len(coordinates))
        ]
        for changed_coordinates in perturbations:
            changed = _array(a)
            for r, c in changed_coordinates:
                changed[r][c] = foreground if changed[r][c] == background else background
            changed = tuple(tuple(row) for row in changed)
            try:
                if program._classify(changed) == opposite:
                    label = program.symmetric_label if opposite else program.asymmetric_label
                    toggle_found = program.predict(changed) == ((label,),)
                    if toggle_found:
                        break
            except Inapplicable:
                pass
        rows.append({
            "demonstration": index,
            "colour_invariant": colour_invariant,
            "rotation_invariant": rotation_invariant,
            "class_toggle_changes_label": toggle_found,
        })
    return _counterfactual_result(program.kind, rows)


def _unary_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        _, evidence, count, original = program._analyse(a)
        rotation_invariant = program.predict(_rot180(a)) == original
        squares = [component for component in evidence[program.count_colour]["components"] if _is_solid_2x2(component)]
        removed = _array(a)
        for r, c in squares[0]:
            removed[r][c] = program.background
        try:
            changed = program.predict(tuple(tuple(row) for row in removed))
            count_controls_length = changed == (tuple([program.count_colour] * (count - 1) + [program.background] * (program.width - count + 1)),)
        except Inapplicable:
            count_controls_length = count == 1
        rows.append({
            "demonstration": index,
            "rotation_invariant": rotation_invariant,
            "count_controls_length": count_controls_length,
        })
    return _counterfactual_result(program.kind, rows)


def _frequency_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        _, _, counts, _, dominant, ranked, original = program._analyse(a)
        colours = [dominant] + list(ranked)
        mapping = {colour: colours[(position + 1) % len(colours)] for position, colour in enumerate(colours)}
        recoloured = _map_colours(a, mapping)
        expected = tuple((mapping[colour],) for colour in ranked)
        colour_equivariant = program.predict(recoloured) == expected
        # Remove one block from the least frequent class; the exact four-class ranking must change or reject.
        least = ranked[-1]
        component = _components_of_colour(a, least, 4)[0]
        removed = _array(a)
        background = _unique_modal(a)
        for r, c in component:
            removed[r][c] = background
        try:
            frequency_necessary = program.predict(tuple(tuple(row) for row in removed)) != original
        except Inapplicable:
            frequency_necessary = True
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "frequency_necessary": frequency_necessary,
        })
    return _counterfactual_result(program.kind, rows)


def _area_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        _, counts, ranked, original = program._analyse(a)
        colours = list(ranked)
        mapping = {colour: colours[(position + 1) % len(colours)] for position, colour in enumerate(colours)}
        recoloured = _map_colours(a, mapping)
        expected = tuple((mapping[colour],) for colour in ranked)
        colour_equivariant = program.predict(recoloured) == expected
        rotation_invariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "rotation_invariant": rotation_invariant,
        })
    return _counterfactual_result(program.kind, rows)


def _frame_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        background, _, winner, original = program._analyse(a)
        winner_colour, winner_cells = winner[1], winner[2]
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        for r, c in winner_cells:
            recoloured[r][c] = replacement
        recolour_propagates = program.predict(tuple(tuple(row) for row in recoloured)) == ((replacement, replacement), (replacement, replacement))
        broken = _array(a)
        r, c = next(iter(winner_cells))
        broken[r][c] = background
        try:
            frame_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            frame_necessary = True
        rotation_invariant = program.predict(_rot180(a)) == original
        rows.append({
            "demonstration": index,
            "recolour_propagates": recolour_propagates,
            "frame_necessary": frame_necessary,
            "rotation_invariant": rotation_invariant,
        })
    return _counterfactual_result(program.kind, rows)


def _growth_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        background, separator_row, separator_colour, evidence, winner, original = program._analyse(a)
        colours = sorted(evidence)
        swapped = _map_colours(a, {colours[0]: colours[1], colours[1]: colours[0]})
        expected = ((colours[1] if winner == colours[0] else colours[0],) * 2,) * 2
        colour_equivariant = program.predict(swapped) == expected
        broken = _array(a)
        broken[separator_row][0] = background
        try:
            separator_necessary = program.predict(tuple(tuple(row) for row in broken)) != original
        except Inapplicable:
            separator_necessary = True
        mirror_invariant = program.predict(_flip_lr(a)) == original
        rows.append({
            "demonstration": index,
            "colour_equivariant": colour_equivariant,
            "separator_necessary": separator_necessary,
            "horizontal_translation_invariant": mirror_invariant,
        })
    return _counterfactual_result(program.kind, rows)


def _half_reversal_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        original = program.predict(a)
        involutive = program.predict(original) == a
        reversed_input = tuple(tuple(reversed(row)) for row in a) if len(a) == 1 else tuple(reversed(a))
        reversed_output = tuple(tuple(reversed(row)) for row in original) if len(original) == 1 else tuple(reversed(original))
        reversal_equivariant = program.predict(reversed_input) == reversed_output
        changed = _array(a)
        replacement = _fresh_colour(a)
        if len(a) == 1:
            changed[0][0] = replacement
        else:
            changed[0][0] = replacement
        perturbation_propagates = program.predict(tuple(tuple(row) for row in changed)) != original
        rows.append({
            "demonstration": index,
            "involutive": involutive,
            "reversal_equivariant": reversal_equivariant,
            "perturbation_propagates": perturbation_propagates,
        })
    return _counterfactual_result(program.kind, rows)


def _embedded_grid_counterfactuals(program, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        a = grid(source)
        _, _, _, patches, row_ranks, column_ranks, original = program._analyse(a)
        colour, cells, (row, column), _ = patches[0]
        replacement = _fresh_colour(a)
        recoloured = _array(a)
        for r, c in cells:
            recoloured[r][c] = replacement
        changed = [list(row_values) for row_values in original]
        changed[row_ranks.index(row)][column_ranks.index(column)] = replacement
        recolour_propagates = program.predict(tuple(tuple(row_values) for row_values in recoloured)) == tuple(tuple(row_values) for row_values in changed)
        rotation_equivariant = program.predict(_rot180(a)) == _rot180(original)
        rows.append({
            "demonstration": index,
            "recolour_propagates": recolour_propagates,
            "rotation_equivariant": rotation_equivariant,
        })
    return _counterfactual_result(program.kind, rows)


def _counterfactual_result(kind, rows):
    passed = all(all(value for key, value in row.items() if key != "demonstration") for row in rows)
    return {"kind": kind, "rows": rows, "passed": passed}


def _counterfactual_validation(program, pairs):
    if isinstance(program, UninterruptedStripeColourQueryProgram):
        return _stripe_counterfactuals(program, pairs)
    if isinstance(program, BridgeConnectivityQueryProgram):
        return _bridge_counterfactuals(program, pairs)
    if isinstance(program, CanvasSymmetryCodebookQueryProgram):
        return _symmetry_counterfactuals(program, pairs)
    if isinstance(program, UnarySquareCountProjectionProgram):
        return _unary_counterfactuals(program, pairs)
    if isinstance(program, FrequencyRankedBlockColourProjectionProgram):
        return _frequency_counterfactuals(program, pairs)
    if isinstance(program, ColourAreaRankProjectionProgram):
        return _area_counterfactuals(program, pairs)
    if isinstance(program, LargestFrameInteriorProjectionProgram):
        return _frame_counterfactuals(program, pairs)
    if isinstance(program, SeparatorGrowthComparisonProjectionProgram):
        return _growth_counterfactuals(program, pairs)
    if isinstance(program, PairedHalfReversalProgram):
        return _half_reversal_counterfactuals(program, pairs)
    if isinstance(program, EmbeddedObjectGridProjectionProgram):
        return _embedded_grid_counterfactuals(program, pairs)
    return {"kind": "unknown", "passed": False}


def validate_counterfactual_queries(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected = [entry["prediction"] for entry in full["tests"]]
    programmes = []
    for law in full.get("supporting_laws", ()):
        try:
            programmes.append(_program_from_law(law))
        except (Inapplicable, KeyError, TypeError, ValueError):
            continue
    allowed_kinds = tuple(sorted({program.kind for program in programmes}))
    if not allowed_kinds:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    if len(clean["train"]) < 2:
        return {"passed": False, "reason": "insufficient_demonstrations", "folds": [], "counterfactuals": []}

    folds = []
    for held, demonstration in enumerate(clean["train"]):
        fold = {
            "train": [item for index, item in enumerate(clean["train"]) if index != held],
            "test": [{"input": demonstration["input"]}] + clean["test"],
        }
        result = infer_counterfactual_queries(
            fold,
            minimum_pairs=1,
            allowed_kinds=allowed_kinds,
            require_role_variation=False,
        )
        predictions = [entry["prediction"] for entry in result["tests"]]
        folds.append({
            "held_index": held,
            "status": result["status"],
            "held_example_exact": result["status"] == "unique" and predictions[0] == demonstration["output"],
            "test_prediction_stable": result["status"] == "unique" and predictions[1:] == expected,
            "joint_hypotheses": result["joint_hypotheses"],
        })

    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    counterfactuals = []
    for program in programmes:
        try:
            counterfactuals.append(_counterfactual_validation(program, pairs))
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration) as exc:
            counterfactuals.append({"kind": program.kind, "passed": False, "error": str(exc)})

    folds_passed = all(row["held_example_exact"] and row["test_prediction_stable"] for row in folds)
    counterfactual_passed = any(row.get("passed") for row in counterfactuals)
    passed = folds_passed and counterfactual_passed
    return {
        "passed": passed,
        "reason": "passed" if passed else "leave_one_demonstration_out_failure" if not folds_passed else "causal_counterfactual_failure",
        "folds": folds,
        "counterfactuals": counterfactuals,
    }


def counterfactual_query_affordances(task):
    clean = public_task(task)
    pairs = tuple((demonstration["input"], demonstration["output"]) for demonstration in clean["train"])
    return tuple(sorted({program.kind for program in fit_counterfactual_query_programs(pairs)}))


infer = infer_counterfactual_queries
validate = validate_counterfactual_queries
