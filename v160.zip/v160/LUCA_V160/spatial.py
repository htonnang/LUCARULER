"""One registered spatial family with two explicitly ordered grammar strata.

This consolidates inference/validation, not the hypotheses into an ungated union.
Each stratum retains *all* complete predictions; no task IDs or targets are used.
The older proposal generators are reusable building blocks, not dispatchers.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable


from runtime import public_task, joint_result

from lines import fit as fit_aligned
from strokes import fit_strokes

@dataclass(frozen=True)
class Grammar:
    name: str
    fit: Callable

GRAMMARS = (Grammar('aligned', fit_aligned), Grammar('directed', fit_strokes))
FAMILY = 'spatial_relations_v69'


def get_grammar(name: str) -> Grammar:
    for grammar in GRAMMARS:
        if grammar.name == name:
            return grammar
    raise ValueError('unknown spatial grammar: ' + str(name))


def evaluate(programs, inputs, grammar: str) -> dict:
    """Require one whole program to predict all inputs; preserve every joint output."""
    get_grammar(grammar)
    inputs = tuple(inputs)
    groups, supports = {}, {}
    invalid = 0
    for law in programs:
        key = tuple(law.predict(a) for a in inputs)
        if not key or any(p is None for p in key):
            invalid += 1
            continue
        ss = groups.setdefault(key, [])
        if len(ss) < 20:
            ss.append({'family': FAMILY, 'grammar': grammar,
                       'law': law.name(), 'template': law.template()})
        supports[key] = supports.get(key, 0) + 1
    result = joint_result(groups, len(inputs))
    result['candidates'] = [
        {'predictions': [[list(row) for row in p] for p in key],
         'program_groups': supports[key], 'representative_laws': [s['law'] for s in ss]}
        for key, ss in sorted(groups.items())]
    result['grammar'] = grammar
    result['stats'] = {'fitted_programs': len(programs), 'inapplicable_programs': invalid,
                       'beam_pruning': False, 'all_joint_predictions_retained': True}
    return result


def infer_stratum(task: dict, grammar: str) -> dict:
    clean = public_task(task)
    laws = get_grammar(grammar).fit((d['input'], d['output']) for d in clean['train'])
    return evaluate(laws, (d['input'] for d in clean['test']), grammar)


def validate(task: dict, full: dict, grammar: str) -> dict:
    """Held example's output stays outside its fitting call; test targets unused."""
    clean = public_task(task)
    if full['status'] != 'unique':
        return {'passed': False, 'reason': 'full_fit_not_unique', 'folds': []}
    if len(clean['train']) < 2:
        return {'passed': False, 'reason': 'requires_two_demonstrations', 'folds': []}
    expected = [d['prediction'] for d in full['tests']]
    folds = []
    for held, demo in enumerate(clean['train']):
        fold = {'train': [d for i, d in enumerate(clean['train']) if i != held],
                'test': [{'input': demo['input']}] + clean['test']}
        r = infer_stratum(fold, grammar)
        predictions = [t['prediction'] for t in r['tests']]
        folds.append({'held_index': held, 'status': r['status'],
                      'held_example_exact': r['status'] == 'unique' and predictions[0] == demo['output'],
                      'test_prediction_stable': r['status'] == 'unique' and predictions[1:] == expected,
                      'joint_hypotheses': r['joint_hypotheses'],
                      'fitted_programs': r['stats']['fitted_programs']})
    passed = all(f['held_example_exact'] and f['test_prediction_stable'] for f in folds)
    return {'passed': passed, 'reason': 'passed' if passed else 'held_example_or_stability_failure', 'folds': folds}


