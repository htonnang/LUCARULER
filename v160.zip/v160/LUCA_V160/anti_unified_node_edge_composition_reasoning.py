"""LUCA V142: anti-unified node/edge grammar with bounded composition.

Six input-derived schemas reuse two consequence operators:

    scene -> anti-unified nodes -> derived edges -> operator -> full grid

The family is task-ID blind and test-target blind. Programmes store only
semantic colour roles, orientation parameters, and local graph policies learned
from demonstrations.
"""
from __future__ import annotations

from collections import Counter, defaultdict, deque
from dataclasses import dataclass

from runtime import public_task
from completion_primitives_reasoning import Inapplicable, _array, _shape, grid
from learned_constructor_proof_search_reasoning import _background, _palette

Grid = tuple[tuple[int, ...], ...]
FAMILY = "spinoza_anti_unified_node_edge_composition"
LANGUAGE = "spinoza_anti_unified_node_edge_composition_v142"
SCHEMA_VERSION = 1


# ---------------------------------------------------------------------------
# Shared evidence language.
# ---------------------------------------------------------------------------


def _law(program, *, scene, relation, parameters, corollary, notions):
    return {
        "family": FAMILY,
        "language": LANGUAGE,
        "schema_version": SCHEMA_VERSION,
        "schema": program.kind,
        "algebra": {
            "scene": scene,
            "nodes": program.node_vocabulary,
            "edges": program.edge_vocabulary,
            "relation": relation,
            "operator": program.operator,
            "emitter": "deterministic_full_grid",
        },
        "parameters": parameters,
        "definitions": [],
        "propositions": [],
        "corollary": corollary,
        "common_notions": notions,
        "adequacy": {
            "exact_training_fit": True,
            "typed_program": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
            "input_derived_graph": True,
            "anti_unified_node_edge_vocabulary": True,
            "bounded_two_step_composition": True,
            "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        },
    }


def _cells(value: Grid, colour: int):
    return [(r, c) for r, row in enumerate(value) for c, cell in enumerate(row) if cell == colour]


def _bbox(cells):
    if not cells:
        raise Inapplicable("empty support")
    rows = [r for r, _ in cells]
    columns = [c for _, c in cells]
    return min(rows), min(columns), max(rows), max(columns)


def _components(value: Grid, colour: int, connectivity: int = 4):
    h, w = _shape(value)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    if connectivity == 8:
        directions += [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    seen, output = set(), []
    for r in range(h):
        for c in range(w):
            if value[r][c] != colour or (r, c) in seen:
                continue
            stack = [(r, c)]
            seen.add((r, c))
            current = []
            while stack:
                rr, cc = stack.pop()
                current.append((rr, cc))
                for dr, dc in directions:
                    nr, nc = rr + dr, cc + dc
                    if 0 <= nr < h and 0 <= nc < w and value[nr][nc] == colour and (nr, nc) not in seen:
                        seen.add((nr, nc))
                        stack.append((nr, nc))
            output.append(tuple(sorted(current)))
    return output


def _single_background_paint(pairs):
    paint = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        if _shape(source) != _shape(target):
            raise Inapplicable("shape changed")
        background = _background(source)
        changes = []
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] != target[r][c]:
                    changes.append((source[r][c], target[r][c]))
        if not changes or any(before != background for before, _ in changes):
            raise Inapplicable("not a background-only emission")
        colours = {after for _, after in changes}
        if len(colours) != 1:
            raise Inapplicable("multiple consequence colours")
        current = int(next(iter(colours)))
        if current in _palette(source):
            raise Inapplicable("consequence colour already present")
        if paint is None:
            paint = current
        elif paint != current:
            raise Inapplicable("consequence role changes")
    if paint is None:
        raise Inapplicable("missing consequence role")
    return paint


def _single_new_colour(pairs):
    colour = None
    for source, target in pairs:
        source, target = grid(source), grid(target)
        extra = _palette(target) - _palette(source)
        if len(extra) != 1:
            raise Inapplicable("one new semantic colour required")
        current = int(next(iter(extra)))
        if colour is None:
            colour = current
        elif colour != current:
            raise Inapplicable("new colour changes between demonstrations")
    if colour is None:
        raise Inapplicable("missing new colour")
    return colour


def _union_find_groups(count):
    parent = list(range(count))

    def find(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(left, right):
        left, right = find(left), find(right)
        if left != right:
            parent[right] = left

    return parent, find, union


# ---------------------------------------------------------------------------
# Shared operator I: derived rectilinear materialisation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RowIntervalClusterBoxProgram:
    paint_colour: int

    kind = "row_interval_cluster_box_materialisation"
    operator = "derived_rectilinear_materialisation"
    node_vocabulary = "rectilinear_support_nodes"
    edge_vocabulary = "derived_interval_path_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        background = _background(value)
        roles = _palette(value) - {background}
        if len(roles) != 1 or self.paint_colour in _palette(value):
            raise Inapplicable("binary foreground field and new consequence role required")
        foreground = int(next(iter(roles)))
        components = _components(value, foreground, 4)
        if not components:
            raise Inapplicable("missing support components")

        # A field made entirely of three-cell L pieces has a competing local
        # 2x2-completion explanation.  The cluster-envelope law must abstain
        # rather than use a demonstration coincidence to merge those pieces.
        if all(
            len(component) == 3
            and (_bbox(component)[2] - _bbox(component)[0] + 1)
            * (_bbox(component)[3] - _bbox(component)[1] + 1) == 4
            for component in components
        ):
            raise Inapplicable("local L-triomino completion ambiguity")

        parent, find, union = _union_find_groups(len(components))
        boxes = [_bbox(component) for component in components]

        # First relation: transitive overlap of component row intervals.
        for left in range(len(components)):
            r0, _, r1, _ = boxes[left]
            for right in range(left + 1, len(components)):
                s0, _, s1, _ = boxes[right]
                if max(r0, s0) <= min(r1, s1):
                    union(left, right)

        # Second relation: singleton nodes may bridge one-cell diagonal gaps.
        # This is iterated because a bridge can attach two already formed groups.
        changed = True
        while changed:
            changed = False
            groups = defaultdict(list)
            for index, component in enumerate(components):
                groups[find(index)].extend(component)
            for index, component in enumerate(components):
                if len(component) != 1:
                    continue
                root = find(index)
                r, c = component[0]
                for other_root, other_cells in tuple(groups.items()):
                    if other_root == root:
                        continue
                    distance = min(max(abs(r - rr), abs(c - cc)) for rr, cc in other_cells)
                    if distance == 1:
                        union(root, other_root)
                        changed = True
                        break
                if changed:
                    break

        groups = defaultdict(list)
        for index, component in enumerate(components):
            groups[find(index)].extend(component)

        output = _array(value)
        emitted = 0
        for cells in groups.values():
            r0, c0, r1, c1 = _bbox(cells)
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    if output[r][c] == background:
                        output[r][c] = self.paint_colour
                        emitted += 1
        if not emitted:
            raise Inapplicable("cluster envelopes add no material")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="monochrome components arranged in row-overlapping object bands",
            relation="row-interval overlap followed by singleton diagonal bridging induces object clusters",
            parameters={"paint_colour": self.paint_colour, "connectivity": 4, "singleton_bridge_distance": 1},
            corollary="Materialise every background cell in each induced cluster envelope.",
            notions=["component node", "row interval", "singleton bridge", "bounding envelope"],
        )


@dataclass(frozen=True)
class FrameApertureFillProgram:
    paint_colour: int

    kind = "frame_aperture_fill_and_escape"
    operator = "derived_rectilinear_materialisation"
    node_vocabulary = "rectilinear_support_nodes"
    edge_vocabulary = "derived_interval_path_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour

    @staticmethod
    def _frames(value, foreground):
        frames = []
        components = _components(value, foreground, 4)
        for component in components:
            cells = set(component)
            r0, c0, r1, c1 = _bbox(cells)
            if r1 - r0 < 2 or c1 - c0 < 2:
                raise Inapplicable("support component is not a frame")
            perimeter = {
                (r, c)
                for r in range(r0, r1 + 1)
                for c in range(c0, c1 + 1)
                if r in (r0, r1) or c in (c0, c1)
            }
            if not cells <= perimeter or len(cells) < max(4, len(perimeter) // 2):
                raise Inapplicable("component is not a sufficiently supported rectangular frame")
            missing = perimeter - cells
            for r, c in missing:
                sides = int(r == r0) + int(r == r1) + int(c == c0) + int(c == c1)
                if sides != 1:
                    raise Inapplicable("corner aperture is directionally ambiguous")
            frames.append(((r0, c0, r1, c1), tuple(sorted(missing))))
        if not frames:
            raise Inapplicable("no frames")
        return frames

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        roles = _palette(value) - {background}
        if len(roles) != 1 or self.paint_colour in _palette(value):
            raise Inapplicable("binary frame field and new consequence role required")
        foreground = int(next(iter(roles)))
        output = _array(value)
        emitted = 0
        for (r0, c0, r1, c1), missing in self._frames(value, foreground):
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    if output[r][c] == background:
                        output[r][c] = self.paint_colour
                        emitted += 1
            for r, c in missing:
                if r == r0:
                    dr, dc = -1, 0
                elif r == r1:
                    dr, dc = 1, 0
                elif c == c0:
                    dr, dc = 0, -1
                else:
                    dr, dc = 0, 1
                rr, cc = r + dr, c + dc
                while 0 <= rr < h and 0 <= cc < w:
                    if output[rr][cc] != background:
                        raise Inapplicable("aperture escape collides with another structure")
                    output[rr][cc] = self.paint_colour
                    emitted += 1
                    rr += dr
                    cc += dc
        if not emitted:
            raise Inapplicable("empty frame consequence")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="rectangular support frames with zero or more directional apertures",
            relation="a perimeter gap induces an outward axis edge from the filled frame to the canvas boundary",
            parameters={"paint_colour": self.paint_colour, "escape_policy": "straight_to_boundary"},
            corollary="Fill every frame envelope and continue its aperture edge to the boundary.",
            notions=["frame node", "perimeter aperture", "outward normal", "boundary ray"],
        )


@dataclass(frozen=True)
class OrthogonalRunLatticeProgram:
    paint_colour: int

    kind = "orthogonal_run_lattice_closure"
    operator = "derived_rectilinear_materialisation"
    node_vocabulary = "rectilinear_support_nodes"
    edge_vocabulary = "derived_interval_path_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour

    @staticmethod
    def _adjacent(sequence, value):
        return any(sequence[index] == value and sequence[index + 1] == value for index in range(len(sequence) - 1))

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        roles = _palette(value) - {background}
        if len(roles) != 1 or self.paint_colour in _palette(value):
            raise Inapplicable("binary run lattice and new consequence role required")
        foreground = int(next(iter(roles)))
        rows = [r for r in range(h) if self._adjacent(value[r], foreground)]
        columns = [c for c in range(w) if self._adjacent([value[r][c] for r in range(h)], foreground)]
        if len(rows) < 2 or len(columns) < 2:
            raise Inapplicable("insufficient horizontal or vertical run evidence")
        output = _array(value)
        emitted = 0
        for r in rows:
            for c in range(min(columns), max(columns) + 1):
                if output[r][c] == background:
                    output[r][c] = self.paint_colour
                    emitted += 1
        for c in columns:
            for r in range(min(rows), max(rows) + 1):
                if output[r][c] == background:
                    output[r][c] = self.paint_colour
                    emitted += 1
        if not emitted:
            raise Inapplicable("lattice already closed")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="sparse orthogonal runs encoding the rows and columns of a rectilinear lattice",
            relation="adjacent foreground pairs induce axis nodes whose Cartesian incidence closes the lattice",
            parameters={"paint_colour": self.paint_colour, "axis_evidence": "adjacent_pair"},
            corollary="Complete every induced horizontal and vertical lattice axis.",
            notions=["run node", "axis", "Cartesian incidence", "orthogonal closure"],
        )


@dataclass(frozen=True)
class PortalShortestPathUnionProgram:
    paint_colour: int
    marker_colour: int
    frame_colour: int

    kind = "paired_portal_shortest_path_union"
    operator = "derived_rectilinear_materialisation"
    node_vocabulary = "rectilinear_support_nodes"
    edge_vocabulary = "derived_interval_path_edges"

    @property
    def schema_key(self):
        return self.kind, self.paint_colour, self.marker_colour, self.frame_colour

    def _portals(self, value: Grid):
        h, w = _shape(value)
        background = _background(value)
        portals = []
        for r in range(1, h - 1):
            for c in range(1, w - 1):
                if value[r][c] != self.marker_colour:
                    continue
                ring = [
                    (r + dr, c + dc)
                    for dr in (-1, 0, 1)
                    for dc in (-1, 0, 1)
                    if (dr, dc) != (0, 0)
                ]
                missing = [(rr, cc) for rr, cc in ring if value[rr][cc] != self.frame_colour]
                if len(missing) != 1 or value[missing[0][0]][missing[0][1]] != background:
                    continue
                rr, cc = missing[0]
                dr, dc = rr - r, cc - c
                if abs(dr) + abs(dc) != 1:
                    continue
                portals.append({
                    "center": (r, c),
                    "gap": (rr, cc),
                    "outside": (rr + dr, cc + dc),
                    "direction": (dr, dc),
                })
        if len(portals) != 2:
            raise Inapplicable("exactly two one-aperture portals required")
        return portals

    @staticmethod
    def _distances(value: Grid, source, background):
        h, w = _shape(value)
        distances = {source: 0}
        queue = deque([source])
        while queue:
            r, c = queue.popleft()
            for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                rr, cc = r + dr, c + dc
                if not (0 <= rr < h and 0 <= cc < w) or (rr, cc) in distances:
                    continue
                if value[rr][cc] != background:
                    continue
                distances[(rr, cc)] = distances[(r, c)] + 1
                queue.append((rr, cc))
        return distances

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        if _palette(value) != {background, self.marker_colour, self.frame_colour} or self.paint_colour in _palette(value):
            raise Inapplicable("two-role portal field and new consequence role required")
        portals = self._portals(value)
        start, target = portals[0]["outside"], portals[1]["outside"]
        for r, c in (start, target):
            if not (0 <= r < h and 0 <= c < w) or value[r][c] != background:
                raise Inapplicable("portal exterior is blocked or outside the canvas")
        forward = self._distances(value, start, background)
        backward = self._distances(value, target, background)
        if target not in forward:
            raise Inapplicable("portal exteriors are disconnected")
        distance = forward[target]
        support = {
            cell
            for cell, left in forward.items()
            if cell in backward and left + backward[cell] == distance
        }
        support.update(portal["gap"] for portal in portals)
        output = _array(value)
        emitted = 0
        for r, c in support:
            if output[r][c] == background:
                output[r][c] = self.paint_colour
                emitted += 1
        if not emitted:
            raise Inapplicable("empty portal path union")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="two marked 3x3 frames, each with one cardinal aperture",
            relation="portal exteriors are joined by the union of all obstacle-avoiding shortest rectilinear paths",
            parameters={"paint_colour": self.paint_colour, "marker_colour": self.marker_colour, "frame_colour": self.frame_colour, "metric": "Manhattan"},
            corollary="Materialise every background cell lying on a shortest portal-to-portal path.",
            notions=["portal node", "aperture edge", "shortest path", "path-union region"],
        )


# ---------------------------------------------------------------------------
# Shared operator II: periodic axis emission.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AlternatingAnchorRayProgram:
    separator_colour: int
    direction: str

    kind = "alternating_anchor_rays"
    operator = "periodic_axis_emission"
    node_vocabulary = "axis_seed_nodes"
    edge_vocabulary = "periodic_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.separator_colour, self.direction

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        if self.separator_colour in _palette(value):
            raise Inapplicable("separator role must be new")
        anchors = [(r, c, value[r][c]) for r in range(h) for c in range(w) if value[r][c] != background]
        if not anchors:
            raise Inapplicable("missing anchors")
        if self.direction in ("right", "left"):
            if len({r for r, _, _ in anchors}) != len(anchors):
                raise Inapplicable("multiple anchors share a ray row")
        else:
            if len({c for _, c, _ in anchors}) != len(anchors):
                raise Inapplicable("multiple anchors share a ray column")
        dr, dc = {"right": (0, 1), "left": (0, -1), "down": (1, 0), "up": (-1, 0)}[self.direction]
        output = _array(value)
        emitted = 0
        for r, c, colour in anchors:
            rr, cc, step = r + dr, c + dc, 1
            while 0 <= rr < h and 0 <= cc < w:
                if output[rr][cc] != background:
                    raise Inapplicable("anchor ray collision")
                output[rr][cc] = self.separator_colour if step % 2 else colour
                emitted += 1
                rr, cc, step = rr + dr, cc + dc, step + 1
        if not emitted:
            raise Inapplicable("empty alternating rays")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="isolated coloured anchors on distinct axis lines",
            relation="directed successor edges alternate separator and anchor roles until the canvas boundary",
            parameters={"separator_colour": self.separator_colour, "direction": self.direction, "period": 2},
            corollary="Emit a period-two role sequence from every anchor to the selected boundary.",
            notions=["anchor node", "directed successor", "period two", "boundary termination"],
        )


@dataclass(frozen=True)
class BoundarySeedPeriodicCombProgram:
    marker_colour: int
    orientation: str
    direction: str
    anchor_side: str
    phase: int

    kind = "boundary_seed_periodic_comb"
    operator = "periodic_axis_emission"
    node_vocabulary = "axis_seed_nodes"
    edge_vocabulary = "periodic_successor_edges"

    @property
    def schema_key(self):
        return self.kind, self.marker_colour, self.orientation, self.direction, self.anchor_side, self.phase

    def predict(self, value: Grid) -> Grid:
        value = grid(value)
        h, w = _shape(value)
        background = _background(value)
        anchors = [(r, c, value[r][c]) for r in range(h) for c in range(w) if value[r][c] != background]
        if len(anchors) != 1 or self.marker_colour in _palette(value):
            raise Inapplicable("one boundary seed and a new marker role required")
        r0, c0, colour = anchors[0]
        output = _array(value)
        emitted = 0

        if self.orientation == "vertical":
            if self.anchor_side == "bottom" and r0 != h - 1:
                raise Inapplicable("seed is not on the bottom boundary")
            if self.anchor_side == "top" and r0 != 0:
                raise Inapplicable("seed is not on the top boundary")
            columns = list(range(c0, w)) if self.direction == "right" else list(range(c0, -1, -1))
            for offset, c in enumerate(columns):
                if offset % 2 == 0:
                    for r in range(h):
                        if output[r][c] == background:
                            output[r][c] = colour
                            emitted += 1
                else:
                    gap_index = (offset - 1) // 2
                    first = (gap_index + self.phase) % 2 == 0
                    r = 0 if first == (self.anchor_side == "bottom") else h - 1
                    if output[r][c] == background:
                        output[r][c] = self.marker_colour
                        emitted += 1
        elif self.orientation == "horizontal":
            if self.anchor_side == "left" and c0 != 0:
                raise Inapplicable("seed is not on the left boundary")
            if self.anchor_side == "right" and c0 != w - 1:
                raise Inapplicable("seed is not on the right boundary")
            rows = list(range(r0, h)) if self.direction == "down" else list(range(r0, -1, -1))
            for offset, r in enumerate(rows):
                if offset % 2 == 0:
                    for c in range(w):
                        if output[r][c] == background:
                            output[r][c] = colour
                            emitted += 1
                else:
                    gap_index = (offset - 1) // 2
                    first = (gap_index + self.phase) % 2 == 0
                    c = w - 1 if first == (self.anchor_side == "left") else 0
                    if output[r][c] == background:
                        output[r][c] = self.marker_colour
                        emitted += 1
        else:
            raise Inapplicable("unknown comb orientation")

        if not emitted:
            raise Inapplicable("empty periodic comb")
        return grid(output)

    def describe(self, pairs):
        return _law(
            self,
            scene="one coloured seed located on a canvas boundary",
            relation="period-two axis offsets alternate full seed-colour lines with phase-alternating boundary markers",
            parameters={
                "marker_colour": self.marker_colour,
                "orientation": self.orientation,
                "direction": self.direction,
                "anchor_side": self.anchor_side,
                "phase": self.phase,
                "period": 2,
            },
            corollary="Generate the boundary-seeded periodic comb across the available canvas.",
            notions=["boundary seed", "periodic offset", "alternating phase", "axis line"],
        )


# ---------------------------------------------------------------------------
# Fitting, inference, and proof obligations.
# ---------------------------------------------------------------------------


def _fit_single_paint(pairs, cls):
    try:
        programme = cls(_single_background_paint(pairs))
        return [programme] if all(programme.predict(source) == grid(target) for source, target in pairs) else []
    except Inapplicable:
        return []


def _fit_portal(pairs):
    try:
        paint = _single_background_paint(pairs)
    except Inapplicable:
        return []
    common_roles = None
    for source, _ in pairs:
        roles = _palette(grid(source)) - {_background(grid(source))}
        common_roles = set(roles) if common_roles is None else common_roles & set(roles)
    if not common_roles or len(common_roles) != 2:
        return []
    left, right = sorted(common_roles)
    output = []
    for marker, frame in ((left, right), (right, left)):
        programme = PortalShortestPathUnionProgram(paint, marker, frame)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_alternating_rays(pairs):
    try:
        separator = _single_new_colour(pairs)
    except Inapplicable:
        return []
    output = []
    for direction in ("right", "left", "down", "up"):
        programme = AlternatingAnchorRayProgram(separator, direction)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


def _fit_periodic_comb(pairs):
    try:
        marker = _single_new_colour(pairs)
    except Inapplicable:
        return []
    settings = []
    for direction in ("right", "left"):
        for side in ("bottom", "top"):
            for phase in (0, 1):
                settings.append(("vertical", direction, side, phase))
    for direction in ("down", "up"):
        for side in ("left", "right"):
            for phase in (0, 1):
                settings.append(("horizontal", direction, side, phase))
    output = []
    for orientation, direction, side, phase in settings:
        programme = BoundarySeedPeriodicCombProgram(marker, orientation, direction, side, phase)
        try:
            if all(programme.predict(source) == grid(target) for source, target in pairs):
                output.append(programme)
        except Inapplicable:
            pass
    return output


_FITTERS = {
    "row_interval_cluster_box_materialisation": lambda pairs: _fit_single_paint(pairs, RowIntervalClusterBoxProgram),
    "frame_aperture_fill_and_escape": lambda pairs: _fit_single_paint(pairs, FrameApertureFillProgram),
    "orthogonal_run_lattice_closure": lambda pairs: _fit_single_paint(pairs, OrthogonalRunLatticeProgram),
    "paired_portal_shortest_path_union": _fit_portal,
    "alternating_anchor_rays": _fit_alternating_rays,
    "boundary_seed_periodic_comb": _fit_periodic_comb,
}


def fit_anti_unified_node_edge_programs(pairs, minimum_pairs=2, allowed_kinds=None):
    pairs = tuple((grid(source), grid(target)) for source, target in pairs)
    if len(pairs) < minimum_pairs:
        return []
    kinds = tuple(allowed_kinds) if allowed_kinds else tuple(_FITTERS)
    output, seen = [], set()
    for kind in kinds:
        fitter = _FITTERS.get(kind)
        if fitter is None:
            continue
        try:
            programmes = fitter(pairs)
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            continue
        for programme in programmes:
            if programme.schema_key not in seen:
                seen.add(programme.schema_key)
                output.append(programme)
    return output


def _counterfactual(programme, pairs):
    rows = []
    for index, (source, _) in enumerate(pairs):
        source = grid(source)
        background = _background(source)
        original = programme.predict(source)
        passed, tested = False, 0
        for r in range(len(source)):
            for c in range(len(source[0])):
                if source[r][c] == background:
                    continue
                tested += 1
                work = _array(source)
                work[r][c] = background
                try:
                    changed = programme.predict(grid(work)) != original
                except Inapplicable:
                    changed = True
                if changed:
                    passed = True
                    break
            if passed:
                break
        rows.append({
            "demonstration": index,
            "passed": passed,
            "candidate_nodes_tested": tested,
            "node_removal_changes_or_rejects": passed,
            "witness_role": "anti_unified_node_or_edge" if passed else None,
        })
    return {
        "kind": programme.kind,
        "rows": rows,
        "passed": bool(rows) and all(row["passed"] for row in rows),
    }


def infer_anti_unified_node_edge_composition(task, minimum_pairs=2, allowed_kinds=None):
    clean = public_task(task)
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    programmes = fit_anti_unified_node_edge_programs(pairs, minimum_pairs, allowed_kinds)
    groups = defaultdict(list)
    invalid = rejected = 0
    for programme in programmes:
        try:
            counterfactual = _counterfactual(programme, pairs)
            if not counterfactual["passed"]:
                rejected += 1
                continue
            predictions = tuple(programme.predict(case["input"]) for case in clean["test"])
        except (Inapplicable, ValueError, IndexError, KeyError, TypeError, StopIteration, ZeroDivisionError):
            invalid += 1
            continue
        law = programme.describe(pairs)
        law["adequacy"]["counterfactual_passed"] = True
        groups[predictions].append(law)
    status = "unique" if len(groups) == 1 else "ambiguous" if groups else "no_fit"
    chosen = next(iter(groups)) if status == "unique" else None
    return {
        "status": status,
        "joint_hypotheses": len(groups),
        "joint_hypotheses_is_exact": len(groups) < 2,
        "tests": [
            {
                "status": status,
                "prediction": [list(row) for row in chosen[index]] if chosen else None,
            }
            for index in range(len(clean["test"]))
        ],
        "supporting_families": [FAMILY] if chosen else [],
        "supporting_laws": groups.get(chosen, [])[:100] if chosen else [],
        "witness_predictions": [
            [[[cell for cell in row] for row in prediction] for prediction in predictions]
            for predictions in list(groups)[:2]
        ],
        "stats": {
            "fitted_programs": len(programmes),
            "inapplicable_programs": invalid,
            "counterfactual_rejected_programs": rejected,
            "schemas": sorted({law["schema"] for laws in groups.values() for law in laws}),
            "scene_relations": sorted({law["algebra"]["relation"] for laws in groups.values() for law in laws}),
            "operators": sorted({law["algebra"]["operator"] for laws in groups.values() for law in laws}),
            "node_vocabularies": sorted({law["algebra"]["nodes"] for laws in groups.values() for law in laws}),
            "edge_vocabularies": sorted({law["algebra"]["edges"] for laws in groups.values() for law in laws}),
            "proof_carrying": True,
            "anti_unified_node_edge_vocabulary": True,
            "bounded_two_step_composition": True,
            "task_ids_used": False,
            "test_targets_used": False,
            "absolute_coordinates_stored": False,
        },
    }


def _programmes_for_expected(clean, full):
    expected = tuple(grid(test["prediction"]) for test in full["tests"])
    allowed = tuple(full.get("stats", {}).get("schemas", ()))
    pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    output = []
    for programme in fit_anti_unified_node_edge_programs(pairs, 2, allowed):
        try:
            if tuple(programme.predict(case["input"]) for case in clean["test"]) == expected and _counterfactual(programme, pairs)["passed"]:
                output.append(programme)
        except Inapplicable:
            pass
    return expected, output


def _validate_programme(clean, programme, expected):
    full_pairs = tuple((demo["input"], demo["output"]) for demo in clean["train"])
    folds = []
    for held_index, held in enumerate(clean["train"]):
        remaining = tuple(
            (demo["input"], demo["output"])
            for index, demo in enumerate(clean["train"])
            if index != held_index
        )
        refitted = fit_anti_unified_node_edge_programs(remaining, 1, (programme.kind,))
        groups, held_exact = set(), 0
        for candidate in refitted:
            try:
                if candidate.predict(held["input"]) != grid(held["output"]):
                    continue
                if not _counterfactual(candidate, full_pairs)["passed"]:
                    continue
                held_exact += 1
                groups.add(tuple(candidate.predict(case["input"]) for case in clean["test"]))
            except Inapplicable:
                pass
        stable = len(groups) == 1 and next(iter(groups), None) == expected
        folds.append({
            "held_index": held_index,
            "status": "unique" if held_exact and stable else "ambiguous" if len(groups) > 1 else "no_fit",
            "held_example_exact": bool(held_exact),
            "test_prediction_stable": stable,
            "validation_mode": "held_exact_consensus_with_counterfactual_pruning",
            "refitted_programs": len(refitted),
            "held_exact_prediction_groups": len(groups),
        })
    counterfactual = _counterfactual(programme, full_pairs)
    passed = all(fold["held_example_exact"] and fold["test_prediction_stable"] for fold in folds) and counterfactual["passed"]
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": folds,
        "counterfactuals": [counterfactual],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
    }


def validate_anti_unified_node_edge_composition(task, full):
    clean = public_task(task)
    if full.get("status") != "unique":
        return {"passed": False, "reason": "full_fit_not_unique", "folds": [], "counterfactuals": []}
    expected, programmes = _programmes_for_expected(clean, full)
    if not programmes:
        return {"passed": False, "reason": "missing_program_schema", "folds": [], "counterfactuals": []}
    checks = [_validate_programme(clean, programme, expected) for programme in programmes]
    passed = any(check["passed"] for check in checks)
    selected = next((check for check in checks if check["passed"]), checks[0])
    return {
        "passed": passed,
        "reason": "passed" if passed else "validation_failure",
        "folds": selected["folds"],
        "counterfactuals": [item for check in checks for item in check["counterfactuals"]],
        "validation_protocol": "held_exact_consensus_with_counterfactual_pruning",
        "program_checks": checks,
    }
