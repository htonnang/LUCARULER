"""LUCA V62: input-derived, per-object correspondence and conditional placement.

One parameterized family handles template-to-marker binding, shape transformation,
move/copy, marker-conditioned recolouring, and transactional rendering. Templates
are extracted from EACH input, never stored from an ARC answer. Unmatched objects
are retained. All fitted laws must reproduce every demonstration exactly.

Domain: rectangular 0..9 grids <=30x30; unique modal background; 4/8-connected
multi-cell sources and singleton references; <=12 source/reference components.
Ambiguous global assignments, collisions and out-of-bounds writes are rejected.
No task IDs, saved target grids, outcome-dependent routing or external packages.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, asdict
from functools import lru_cache
from itertools import product
from typing import Any, Iterable

Grid = tuple[tuple[int, ...], ...]
Cell = tuple[int, int, int]
GEOMETRIES = ('identity', 'rot90', 'rot180', 'rot270',
              'flip_h', 'flip_h_rot90', 'flip_h_rot180', 'flip_h_rot270')
ANCHORS = ('top_left', 'top_right', 'bottom_left', 'bottom_right', 'center', 'matching_cell')
BINDINGS = ('color', 'anchor_color', 'unique_source', 'unique_reference', 'nearest', 'aligned')
SELECTORS = ('all', 'largest', 'smallest')


class OutsideDomain(ValueError):
    """An explicit structural guard rejected this candidate, not a software error."""


def grid(raw: Iterable[Iterable[int]]) -> Grid:
    a = tuple(tuple(row) for row in raw)
    if not a or not a[0] or len(a) > 30 or len(a[0]) > 30:
        raise ValueError('grid dimensions must be 1..30')
    if any(len(row) != len(a[0]) for row in a):
        raise ValueError('ragged grid')
    if any(type(v) is not int or not 0 <= v <= 9 for row in a for v in row):
        raise ValueError('grid cells must be integers in 0..9')
    return a


@dataclass(frozen=True)
class Object:
    cells: tuple[Cell, ...]

    @property
    def box(self) -> tuple[int, int, int, int]:
        return (min(r for r,c,v in self.cells), min(c for r,c,v in self.cells),
                max(r for r,c,v in self.cells), max(c for r,c,v in self.cells))

    @property
    def palette(self) -> frozenset[int]:
        return frozenset(v for r,c,v in self.cells)


@dataclass(frozen=True)
class Scene:
    background: int
    sources: tuple[Object, ...]
    references: tuple[Object, ...]


@lru_cache(maxsize=256)
def perceive(a: Grid, connectivity: int, monochrome: bool) -> Scene:
    if connectivity not in (4, 8):
        raise ValueError('connectivity must be 4 or 8')
    counts = Counter(v for row in a for v in row)
    top = max(counts.values())
    bgs = [v for v,n in counts.items() if n == top]
    if len(bgs) != 1:
        raise OutsideDomain('background is not uniquely modal')
    bg = bgs[0]
    h,w = len(a),len(a[0])
    directions = ((-1,0),(1,0),(0,-1),(0,1))
    if connectivity == 8:
        directions += ((-1,-1),(-1,1),(1,-1),(1,1))
    seen: set[tuple[int,int]] = set()
    objects = []
    for r in range(h):
        for c in range(w):
            if (r,c) in seen or a[r][c] == bg:
                continue
            stack = [(r,c)]
            seen.add((r,c))
            cells = []
            while stack:
                rr,cc = stack.pop()
                cells.append((rr,cc,a[rr][cc]))
                for dr,dc in directions:
                    nr,nc = rr+dr,cc+dc
                    if (0 <= nr < h and 0 <= nc < w and (nr,nc) not in seen
                            and a[nr][nc] != bg
                            and (not monochrome or a[nr][nc] == a[r][c])):
                        seen.add((nr,nc))
                        stack.append((nr,nc))
            objects.append(Object(tuple(sorted(cells))))
    sources = tuple(o for o in objects if len(o.cells) >= 2)
    refs = tuple(o for o in objects if len(o.cells) == 1)
    if not 1 <= len(sources) <= 12 or not 1 <= len(refs) <= 12:
        raise OutsideDomain('requires 1..12 multi-cell sources and 1..12 singleton references')
    return Scene(bg,sources,refs)


def select_sources(scene: Scene, selector: str) -> tuple[Object, ...]:
    if selector == 'all':
        return scene.sources
    if selector not in ('largest','smallest'):
        raise ValueError('unknown source selector')
    n = (max if selector == 'largest' else min)(len(o.cells) for o in scene.sources)
    return tuple(o for o in scene.sources if len(o.cells) == n)


def minimum_assignment(costs: tuple[tuple[int | None, ...], ...]) -> tuple[int,...]:
    """Unique global minimum-cost injective assignment, rows=refs, columns=sources.

    Ties are structural ambiguity. A greedy nearest-neighbour assignment is not
    substituted when it disagrees with the global optimum.
    """
    if not costs or not costs[0] or any(len(r) != len(costs[0]) for r in costs):
        raise OutsideDomain('empty or ragged assignment')
    n,m = len(costs),len(costs[0])
    if n > m or m > 12:
        raise OutsideDomain('injective assignment needs at least as many sources as references')

    @lru_cache(None)
    def search(i: int, used: int) -> tuple[float,int,tuple[int,...]]:
        if i == n:
            return (0,1,())
        best,count,path = float('inf'),0,()
        for j,cost in enumerate(costs[i]):
            if cost is None or used & (1 << j):
                continue
            tail,k,rest = search(i+1,used | (1 << j))
            if not k:
                continue
            candidate = cost + tail
            if candidate < best:
                best,count,path = candidate,k,(j,)+rest
            elif candidate == best:
                count = min(2,count+k)
        return best,count,path

    _,count,path = search(0,0)
    if count != 1:
        raise OutsideDomain('assignment absent or globally tied')
    return path


@lru_cache(maxsize=2048)
def bind(scene: Scene, selector: str, mode: str) -> tuple[tuple[Object,Object], ...]:
    src = select_sources(scene,selector)
    refs = scene.references
    if mode not in BINDINGS:
        raise ValueError('unknown correspondence rule')
    if mode in ('nearest','aligned'):
        costs = []
        for ref in refs:
            mr,mc,mv = ref.cells[0]
            row = []
            for obj in src:
                r,c,rr,cc = obj.box
                eligible = mode == 'nearest' or r <= mr <= rr or c <= mc <= cc
                # Exact integer distance between doubled bounding-box centres.
                row.append(abs((r+rr)-2*mr)+abs((c+cc)-2*mc) if eligible else None)
            costs.append(tuple(row))
        indices = minimum_assignment(tuple(costs))
        return tuple((src[j],ref) for ref,j in zip(refs,indices))
    if mode == 'unique_reference':
        if len(refs) != 1:
            raise OutsideDomain('requires one unique reference for all selected sources')
        return tuple((obj,refs[0]) for obj in src)
    pairs = []
    for ref in refs:
        color = ref.cells[0][2]
        if mode == 'color':
            choices = [o for o in src if o.palette == {color}]
        elif mode == 'anchor_color':
            choices = [o for o in src if sum(v == color for r,c,v in o.cells) == 1]
        else:
            choices = list(src)
        if len(choices) > 1:
            raise OutsideDomain('marker has multiple eligible source objects')
        if choices:
            pairs.append((choices[0],ref))
    if not pairs:
        raise OutsideDomain('no matching object-reference pairs')
    return tuple(pairs)


@lru_cache(maxsize=4096)
def transformed(obj: Object, geometry: str) -> tuple[Cell,...]:
    if geometry not in GEOMETRIES:
        raise ValueError('unknown geometry')
    r0,c0,_,_ = obj.box
    pts = [(r-r0,c-c0,v) for r,c,v in obj.cells]
    flipped = geometry.startswith('flip_h')
    if flipped:
        width = max(c for r,c,v in pts) + 1
        pts = [(r,width-1-c,v) for r,c,v in pts]
    turns = 0
    if 'rot90' in geometry: turns = 1
    elif 'rot180' in geometry: turns = 2
    elif 'rot270' in geometry: turns = 3
    for _ in range(turns):
        height = max(r for r,c,v in pts)+1
        pts = [(c,height-1-r,v) for r,c,v in pts]
    return tuple(sorted(pts))


def local_anchor(pattern: tuple[Cell,...], rule: str, marker_color: int) -> tuple[int,int]:
    h = max(r for r,c,v in pattern)+1
    w = max(c for r,c,v in pattern)+1
    if rule == 'top_left': return 0,0
    if rule == 'top_right': return 0,w-1
    if rule == 'bottom_left': return h-1,0
    if rule == 'bottom_right': return h-1,w-1
    if rule == 'center':
        if h%2 != 1 or w%2 != 1:
            raise OutsideDomain('object has no integral bounding-box centre')
        return h//2,w//2
    if rule == 'matching_cell':
        matches = [(r,c) for r,c,v in pattern if v == marker_color]
        if len(matches) != 1:
            raise OutsideDomain('source lacks a unique matching-colour anchor cell')
        return matches[0]
    raise ValueError('unknown anchor')


@dataclass(frozen=True)
class CorrespondenceLaw:
    connectivity: int = 4
    monochrome: bool = False
    selector: str = 'all'
    binding: str = 'anchor_color'
    geometry: str = 'identity'
    anchor: str = 'matching_cell'
    offset_r: int = 0
    offset_c: int = 0
    action: str = 'copy'
    paint: str = 'preserve'
    consume_reference: bool = False
    target_frame: str = 'reference'

    def specification(self) -> dict[str,Any]:
        return {'family':'object_correspondence',**asdict(self)}

    def name(self) -> str:
        return (f'correspondence:{self.binding}/{self.selector}/{self.geometry}/'
                f'{self.anchor}@{self.offset_r},{self.offset_c}/{self.action}/'
                f'{self.paint}/consume={self.consume_reference}/'
                f'conn={self.connectivity}/mono={self.monochrome}/frame={self.target_frame}')

    def predict_with_trace(self, raw: Iterable[Iterable[int]]) -> tuple[Grid | None,dict[str,Any]]:
        a = grid(raw)
        if self.target_frame not in ('reference','source_origin'):
            raise ValueError('unknown target coordinate frame')
        if self.target_frame == 'source_origin' and (self.offset_r or self.offset_c):
            raise ValueError('in-place frame cannot encode an arbitrary displacement')
        if self.action not in ('move','copy') or self.paint not in ('preserve','reference'):
            raise ValueError('unknown edit action')
        try:
            scene = perceive(a,self.connectivity,self.monochrome)
            pairs = bind(scene,self.selector,self.binding)
            erasures: set[tuple[int,int]] = set()
            if self.action == 'move':
                erasures.update((r,c) for obj,_ in pairs for r,c,v in obj.cells)
            if self.consume_reference:
                erasures.update((r,c) for _,ref in pairs for r,c,v in ref.cells)
            writes: dict[tuple[int,int],int] = {}
            mappings = []
            for obj,ref in pairs:
                mr,mc,mv = ref.cells[0]
                pts = transformed(obj,self.geometry)
                ar,ac = local_anchor(pts,self.anchor,mv)
                tr,tc = (obj.box[:2] if self.target_frame == 'source_origin'
                         else (mr+self.offset_r-ar,mc+self.offset_c-ac))
                for r,c,v in pts:
                    dest = (tr+r,tc+c)
                    value = mv if self.paint == 'reference' else v
                    if not (0 <= dest[0] < len(a) and 0 <= dest[1] < len(a[0])):
                        raise OutsideDomain('placement extends beyond grid')
                    if dest in writes and writes[dest] != value:
                        raise OutsideDomain('two placements conflict')
                    # Same-colour coincidence is harmless; unequal occupied cells
                    # are writable only if explicitly erased in this transaction.
                    if a[dest[0]][dest[1]] not in (scene.background,value) and dest not in erasures:
                        raise OutsideDomain('placement overwrites an unrelated occupied cell')
                    writes[dest] = value
                mappings.append({'source_box':list(obj.box),'reference':[mr,mc,mv],
                                 'destination_origin':[tr,tc]})
            out = [list(row) for row in a]
            for r,c in erasures: out[r][c] = scene.background
            for (r,c),v in writes.items(): out[r][c] = v
            return grid(out),{'matched_pairs':mappings,'background':scene.background,
                              'erased_cells':len(erasures),'written_cells':len(writes)}
        except OutsideDomain as e:
            return None,{'rejection':str(e)}

    def predict(self, raw: Iterable[Iterable[int]]) -> Grid | None:
        return self.predict_with_trace(raw)[0]


def possible_offsets(target: Grid, pairs: tuple[tuple[Object,Object],...],
                     geometry: str, anchor: str, paint: str) -> set[tuple[int,int]]:
    """Derive offsets from exact coloured-shape embeddings in a DEMONSTRATION.

    No constant translation menu or task-specific coordinates are used. The
    intersection requires every matched object to obey the same relative law.
    Remaining cells are checked by full transactional replay in fit().
    """
    h,w = len(target),len(target[0])
    counts = Counter(v for row in target for v in row)
    options: set[tuple[int,int]] | None = None
    # Check the richest source first for faster constraint propagation.
    for obj,ref in sorted(pairs,key=lambda z:-len(z[0].cells)):
        mr,mc,mv = ref.cells[0]
        pattern = transformed(obj,geometry)
        ar,ac = local_anchor(pattern,anchor,mv)
        pts = tuple((r,c,mv if paint == 'reference' else v) for r,c,v in pattern)
        valid: set[tuple[int,int]] = set()
        if options is None:
            pr,pc,pv = min(pts,key=lambda p:counts.get(p[2],0))
            candidates = ((r-pr-mr+ar,c-pc-mc+ac)
                          for r,row in enumerate(target) for c,v in enumerate(row) if v == pv)
        else:
            candidates = iter(options)
        for dr,dc in candidates:
            tr,tc = mr+dr-ar,mc+dc-ac
            if all(0 <= tr+r < h and 0 <= tc+c < w and target[tr+r][tc+c] == v for r,c,v in pts):
                valid.add((dr,dc))
        options = valid
        if not valid: break
    return options or set()


def fit(pairs: Iterable[tuple[Any,Any]]) -> list[CorrespondenceLaw]:
    demos = [(grid(x),grid(y)) for x,y in pairs]
    if len(demos) < 2 or all(x == y for x,y in demos):
        return []
    if any((len(x),len(x[0])) != (len(y),len(y[0])) for x,y in demos):
        return []
    laws: list[CorrespondenceLaw] = []
    x0,y0 = demos[0]
    for conn,mono in product((4,8),(False,True)):
        try:
            scenes = [perceive(x,conn,mono) for x,y in demos]
        except OutsideDomain:
            continue
        for selector,binding in product(SELECTORS,BINDINGS):
            try:
                matches = [bind(scene,selector,binding) for scene in scenes]
            except OutsideDomain:
                continue
            for geom,anchor,paint in product(GEOMETRIES,ANCHORS,('preserve','reference')):
                try:
                    offsets = possible_offsets(y0,matches[0],geom,anchor,paint)
                except OutsideDomain:
                    continue
                if not offsets: continue
                # A candidate is retained ONLY by replaying the full demonstrations.
                for dr,dc in sorted(offsets):
                    for action,consume in product(('copy','move'),(False,True)):
                        law = CorrespondenceLaw(conn,mono,selector,binding,geom,anchor,
                                                dr,dc,action,paint,consume)
                        if all(law.predict(x) == y for x,y in demos):
                            # Do not infer marker-controlled displacement from
                            # demonstrations in which no source is displaced.
                            # Such evidence belongs to the explicit in-place frame.
                            relocated = any(
                                tuple(link['destination_origin']) != tuple(link['source_box'][:2])
                                for x,y in demos
                                for link in law.predict_with_trace(x)[1].get('matched_pairs',[]))
                            if relocated:
                                laws.append(law)
            # Reference attributes can control an edit without controlling its
            # position. This replaces accidental constant marker offsets by
            # the simpler input-relative invariant: keep each source origin.
            for geom,paint,consume in product(GEOMETRIES,('preserve','reference'),(False,True)):
                law = CorrespondenceLaw(conn,mono,selector,binding,geom,'top_left',
                                        0,0,'move',paint,consume,'source_origin')
                if all(law.predict(x) == y for x,y in demos):
                    laws.append(law)
    return laws


